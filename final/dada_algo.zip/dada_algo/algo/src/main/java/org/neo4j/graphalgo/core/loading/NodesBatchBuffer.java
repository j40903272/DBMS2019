package org.neo4j.graphalgo.core.loading;

import org.neo4j.kernel.impl.store.NodeLabelsField;
import org.neo4j.kernel.impl.store.NodeStore;
import org.neo4j.kernel.impl.store.record.AbstractBaseRecord;
import org.neo4j.kernel.impl.store.record.NodeRecord;





















public final class NodesBatchBuffer
  extends RecordsBatchBuffer<NodeRecord>
{
  private final int label;
  private final NodeStore nodeStore;
  private final long[] properties;
  
  public NodesBatchBuffer(NodeStore store, int label, int capacity, boolean readProperty) {
    super(capacity);
    this.label = label;
    this.nodeStore = store;
    this.properties = readProperty ? new long[capacity] : null;
  }

  
  public void offer(NodeRecord record) {
    if (hasCorrectLabel(record)) {
      add(record.getId(), record.getNextProp());
    }
  }
  
  public void add(long nodeId, long propertiesIndex) {
    int len = this.length++;
    this.buffer[len] = nodeId;
    if (this.properties != null) {
      this.properties[len] = propertiesIndex;
    }
  }

  
  private boolean hasCorrectLabel(NodeRecord record) {
    if (this.label == -1) {
      return true;
    }
    long[] labels = NodeLabelsField.get(record, this.nodeStore);
    long label = this.label;
    for (long l : labels) {
      if (l == label) {
        return true;
      }
    } 
    return false;
  }

  
  long[] properties() { return this.properties; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\NodesBatchBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */