package org.neo4j.graphalgo.core.utils;



























public interface RenamesCurrentThread
{
  default String threadName() { return getClass().getSimpleName() + "-" + System.identityHashCode(this); }

  
  static Revert renameThread(String newThreadName) {
    Thread currentThread = Thread.currentThread();
    String oldThreadName = currentThread.getName();
    
    boolean renamed = false;
    if (!oldThreadName.equals(newThreadName)) {
      try {
        currentThread.setName(newThreadName);
        renamed = true;
      } catch (SecurityException securityException) {}
    }


    
    if (renamed) {
      return () -> currentThread.setName(oldThreadName);
    }
    return EMPTY;
  }
  
  public static final Revert EMPTY = () -> {
    
    };
  
  public static interface Revert extends AutoCloseable {
    void close();
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\RenamesCurrentThread.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */