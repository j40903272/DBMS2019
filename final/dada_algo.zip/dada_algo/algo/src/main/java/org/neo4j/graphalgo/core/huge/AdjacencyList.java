package org.neo4j.graphalgo.core.huge;

import org.neo4j.graphalgo.core.GraphDimensions;
import org.neo4j.graphalgo.core.loading.MutableIntValue;
import org.neo4j.graphalgo.core.loading.VarLongEncoding;
import org.neo4j.graphalgo.core.utils.BitUtil;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.mem.MemoryRange;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
import org.neo4j.graphalgo.core.utils.paged.PageUtil;

























public final class AdjacencyList
{
  public static final int PAGE_SHIFT = 18;
  public static final int PAGE_SIZE = 262144;
  public static final long PAGE_MASK = 262143L;
  private final long allocatedMemory;
  private byte[][] pages;
  
  public static MemoryEstimation compressedMemoryEstimation(boolean undirected) { return 
      MemoryEstimations.builder(AdjacencyList.class)
      .rangePerGraphDimension("pages", dim -> {
          long nodeCount = dim.nodeCount();
          long relCount = undirected ? (dim.maxRelCount() * 2L) : dim.maxRelCount();
          long avgDegree = (nodeCount > 0L) ? BitUtil.ceilDiv(relCount, nodeCount) : 0L;



          
          int deltaBestCase = 1;
          long bestCaseAdjacencySize = computeAdjacencyByteSize(avgDegree, nodeCount, deltaBestCase);




          
          long deltaWorstCase = (avgDegree > 0L) ? BitUtil.ceilDiv(nodeCount, avgDegree) : 0L;
          long worstCaseAdjacencySize = computeAdjacencyByteSize(avgDegree, nodeCount, deltaWorstCase);
          
          int minPages = PageUtil.numPagesFor(bestCaseAdjacencySize, 18, 262143L);
          int maxPages = PageUtil.numPagesFor(worstCaseAdjacencySize, 18, 262143L);
          
          long bytesPerPage = MemoryUsage.sizeOfByteArray(262144);
          long minMemoryReqs = minPages * bytesPerPage + MemoryUsage.sizeOfObjectArray(minPages);
          long maxMemoryReqs = maxPages * bytesPerPage + MemoryUsage.sizeOfObjectArray(maxPages);
          
          return MemoryRange.of(minMemoryReqs, maxMemoryReqs);
        
        }).build(); }



  
  public static MemoryEstimation uncompressedMemoryEstimation(boolean undirected) { return 
      MemoryEstimations.builder(AdjacencyList.class)
      .perGraphDimension("pages", dim -> {
          long nodeCount = dim.nodeCount();
          long relCount = undirected ? (dim.maxRelCount() * 2L) : dim.maxRelCount();
          
          long uncompressedAdjacencySize = relCount * 8L + nodeCount * 4L;
          int pages = PageUtil.numPagesFor(uncompressedAdjacencySize, 18, 262143L);
          long bytesPerPage = MemoryUsage.sizeOfByteArray(262144);
          
          return pages * bytesPerPage + MemoryUsage.sizeOfObjectArray(pages);
        
        }).build(); }


  
  static long computeAdjacencyByteSize(long avgDegree, long nodeCount, long delta) {
    long firstAdjacencyIdAvgByteSize = (avgDegree > 0L) ? BitUtil.ceilDiv(VarLongEncoding.encodedVLongSize(nodeCount), 2L) : 0L;
    int relationshipByteSize = VarLongEncoding.encodedVLongSize(delta);
    int degreeByteSize = 4;
    long compressedAdjacencyByteSize = relationshipByteSize * Math.max(0L, avgDegree - 1L);
    return (degreeByteSize + firstAdjacencyIdAvgByteSize + compressedAdjacencyByteSize) * nodeCount;
  }
  
  public AdjacencyList(byte[][] pages) {
    this.pages = pages;
    this.allocatedMemory = memoryOfPages(pages);
  }
  
  private static long memoryOfPages(byte[][] pages) {
    long memory = MemoryUsage.sizeOfObjectArray(pages.length);
    for (byte[] page : pages) {
      if (page != null) {
        memory += MemoryUsage.sizeOfByteArray(page.length);
      }
    } 
    return memory;
  }
  
  int getDegree(long index) {
    return AdjacencyDecompressingReader.readInt(this.pages[
          PageUtil.pageIndex(index, 18)], 
        PageUtil.indexInPage(index, 262143L));
  }
  
  public final long release() {
    if (this.pages == null) {
      return 0L;
    }
    this.pages = (byte[][])null;
    return this.allocatedMemory;
  }



  
  Cursor cursor(long offset) { return (new Cursor(this.pages)).init(offset); }





  
  DecompressingCursor rawDecompressingCursor() { return new DecompressingCursor(this.pages); }





  
  DecompressingCursor decompressingCursor(long offset) { return rawDecompressingCursor().init(offset); }





  
  DecompressingCursor decompressingCursor(DecompressingCursor reuse, long offset) { return reuse.init(offset); }
  
  public static final class Cursor
    extends MutableIntValue
  {
    static final Cursor EMPTY = new Cursor(new byte[0][]);
    
    private final byte[][] pages;
    
    private byte[] currentPage;
    
    private int degree;
    
    private int offset;
    private int limit;
    
    private Cursor(byte[][] pages) { this.pages = pages; }


    
    public int length() { return this.degree; }





    
    boolean hasNextLong() { return (this.offset < this.limit); }





    
    long nextLong() {
      long value = AdjacencyDecompressingReader.readLong(this.currentPage, this.offset);
      this.offset += 8;
      return value;
    }
    
    Cursor init(long fromIndex) {
      this.currentPage = this.pages[PageUtil.pageIndex(fromIndex, 18)];
      this.offset = PageUtil.indexInPage(fromIndex, 262143L);
      this.degree = AdjacencyDecompressingReader.readInt(this.currentPage, this.offset);
      this.offset += 4;
      this.limit = this.offset + this.degree * 8;
      return this;
    }
  }

  
  public static final class DecompressingCursor
    extends MutableIntValue
  {
    private byte[][] pages;
    private final AdjacencyDecompressingReader decompress;
    private int maxTargets;
    private int currentTarget;
    
    private DecompressingCursor(byte[][] pages) {
      this.pages = pages;
      this.decompress = new AdjacencyDecompressingReader();
    }



    
    void copyFrom(DecompressingCursor other) {
      this.decompress.copyFrom(other.decompress);
      this.currentTarget = other.currentTarget;
      this.maxTargets = other.maxTargets;
    }




    
    public int cost() { return this.maxTargets; }





    
    int remaining() { return this.maxTargets - this.currentTarget; }





    
    boolean hasNextVLong() { return (this.currentTarget < this.maxTargets); }





    
    long nextVLong() {
      int current = this.currentTarget++;
      int remaining = this.maxTargets - current;
      return this.decompress.next(remaining);
    }







    
    long skipUntil(long target) {
      long value = this.decompress.skipUntil(target, remaining(), this);
      this.currentTarget += this.value;
      return value;
    }







    
    long advance(long target) {
      long value = this.decompress.advance(target, remaining(), this);
      this.currentTarget += this.value;
      return value;
    }
    
    DecompressingCursor init(long fromIndex) {
      this.maxTargets = this.decompress.reset(this.pages[
            PageUtil.pageIndex(fromIndex, 18)], 
          PageUtil.indexInPage(fromIndex, 262143L));
      this.currentTarget = 0;
      return this;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\huge\AdjacencyList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */