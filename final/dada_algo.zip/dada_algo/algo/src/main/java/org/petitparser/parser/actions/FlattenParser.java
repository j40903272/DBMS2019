package org.petitparser.parser.actions;

import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.parser.Parser;
import org.petitparser.parser.combinators.DelegateParser;




public class FlattenParser
  extends DelegateParser
{
  public FlattenParser(Parser delegate) { super(delegate); }


  
  public Result parseOn(Context context) {
    Result result = this.delegate.parseOn(context);
    if (result.isSuccess()) {
      
      String flattened = context.getBuffer().substring(context.getPosition(), result.getPosition());
      return (Result)result.success(flattened);
    } 
    return result;
  }



  
  public FlattenParser copy() { return new FlattenParser(this.delegate); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\actions\FlattenParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */