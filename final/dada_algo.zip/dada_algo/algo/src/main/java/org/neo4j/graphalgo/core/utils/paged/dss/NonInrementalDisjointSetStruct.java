package org.neo4j.graphalgo.core.utils.paged.dss;

import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;























@Deprecated
public final class NonInrementalDisjointSetStruct
  extends SequentialDisjointSetStruct
{
  public static final MemoryEstimation MEMORY_ESTIMATION = MemoryEstimations.builder(NonInrementalDisjointSetStruct.class)
    .perNode("parent", HugeLongArray::memoryEstimation)
    .build();
  
  private final HugeLongArray parent;
  
  private final long size;
  
  public static MemoryEstimation memoryEstimation() { return MEMORY_ESTIMATION; }






  
  public NonInrementalDisjointSetStruct(long size, AllocationTracker tracker) {
    this.parent = HugeLongArray.newArray(size, tracker);
    this.size = size;
    this.parent.fill(-1L);
  }


  
  public HugeLongArray parent() { return this.parent; }



  
  public long size() { return this.size; }


  
  public long find(long nodeId) {
    long p = nodeId;
    long np;
    while ((np = this.parent.get(p)) != -1L) {
      p = np;
    }
    return p;
  }


  
  public long setIdOf(long nodeId) { return find(nodeId); }



  
  long setIdOfRoot(long rootId) { return rootId; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\dss\NonInrementalDisjointSetStruct.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */