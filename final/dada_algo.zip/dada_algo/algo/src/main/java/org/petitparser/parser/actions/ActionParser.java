package org.petitparser.parser.actions;

import java.util.Objects;
import java.util.function.Function;
import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.parser.Parser;
import org.petitparser.parser.combinators.DelegateParser;








public class ActionParser<T, R>
  extends DelegateParser
{
  protected final Function<T, R> function;
  
  public ActionParser(Parser delegate, Function<T, R> function) {
    super(delegate);
    this.function = Objects.requireNonNull(function, "Undefined function");
  }

  
  public Result parseOn(Context context) {
    Result result = this.delegate.parseOn(context);
    if (result.isSuccess()) {
      return (Result)result.success(this.function.apply((T)result.get()));
    }
    return result;
  }


  
  protected boolean hasEqualProperties(Parser other) {
    return (super.hasEqualProperties(other) && 
      Objects.equals(this.function, ((ActionParser)other).function));
  }


  
  public ActionParser<T, R> copy() { return new ActionParser(this.delegate, this.function); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\actions\ActionParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */