package org.neo4j.graphalgo.core.utils.container;

import java.util.concurrent.atomic.AtomicIntegerArray;

























public class AtomicBitSet
{
  private final AtomicIntegerArray elements;
  
  public AtomicBitSet(int length) { this.elements = new AtomicIntegerArray(length + 31 >>> 5); }




  
  public void clear() {
    for (int i = this.elements.length() - 1; i >= 0; i--) {
      this.elements.set(i, 0);
    }
  }





  
  public void set(long n) {
    int value, current, bit = 1 << (int)n;
    int index = (int)(n >>> 5L);
    do {
      current = this.elements.get(index);
      value = current | bit;
    } while (current != value && !this.elements.compareAndSet(index, current, value));
  }








  
  public boolean trySet(long n) {
    int value, current, bit = 1 << (int)n;
    int index = (int)(n >>> 5L);
    
    do {
      current = this.elements.get(index);
      value = current | bit;
      if (current == value) {
        return false;
      }
    } while (!this.elements.compareAndSet(index, current, value));
    return true;
  }





  
  public void unset(long n) {
    int value, current, bit = 1 << (int)n ^ 0xFFFFFFFF;
    int index = (int)(n >>> 5L);
    do {
      current = this.elements.get(index);
      value = current & bit;
    } while (current != value && !this.elements.compareAndSet(index, current, value));
  }








  
  public boolean get(long n) {
    int bit = 1 << (int)n;
    int index = (int)(n >>> 5L);
    int value = this.elements.get(index);
    return ((value & bit) != 0);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\container\AtomicBitSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */