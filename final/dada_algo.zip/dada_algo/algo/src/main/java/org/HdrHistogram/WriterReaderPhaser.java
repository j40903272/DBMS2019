package org.HdrHistogram;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.locks.ReentrantLock;







































public class WriterReaderPhaser
{
  private volatile long startEpoch = 0L;
  private volatile long evenEndEpoch = 0L;
  private volatile long oddEndEpoch = Long.MIN_VALUE;
  
  private final ReentrantLock readerLock = new ReentrantLock();

  
  private static final AtomicLongFieldUpdater<WriterReaderPhaser> startEpochUpdater = AtomicLongFieldUpdater.newUpdater(WriterReaderPhaser.class, "startEpoch");
  
  private static final AtomicLongFieldUpdater<WriterReaderPhaser> evenEndEpochUpdater = AtomicLongFieldUpdater.newUpdater(WriterReaderPhaser.class, "evenEndEpoch");
  
  private static final AtomicLongFieldUpdater<WriterReaderPhaser> oddEndEpochUpdater = AtomicLongFieldUpdater.newUpdater(WriterReaderPhaser.class, "oddEndEpoch");














  
  public long writerCriticalSectionEnter() { return startEpochUpdater.getAndIncrement(this); }















  
  public void writerCriticalSectionExit(long criticalValueAtEnter) {
    if (criticalValueAtEnter < 0L) {
      oddEndEpochUpdater.getAndIncrement(this);
    } else {
      evenEndEpochUpdater.getAndIncrement(this);
    } 
  }









  
  public void readerLock() { this.readerLock.lock(); }






  
  public void readerUnlock() { this.readerLock.unlock(); }


















  
  public void flipPhase(long yieldTimeNsec) {
    long initialStartValue;
    if (!this.readerLock.isHeldByCurrentThread()) {
      throw new IllegalStateException("flipPhase() can only be called while holding the readerLock()");
    }
    
    boolean nextPhaseIsEven = (this.startEpoch < 0L);


    
    if (nextPhaseIsEven) {
      initialStartValue = 0L;
      evenEndEpochUpdater.lazySet(this, initialStartValue);
    } else {
      initialStartValue = Long.MIN_VALUE;
      oddEndEpochUpdater.lazySet(this, initialStartValue);
    } 

    
    long startValueAtFlip = startEpochUpdater.getAndSet(this, initialStartValue);

    
    boolean caughtUp = false;
    do {
      if (nextPhaseIsEven) {
        caughtUp = (this.oddEndEpoch == startValueAtFlip);
      } else {
        caughtUp = (this.evenEndEpoch == startValueAtFlip);
      } 
      if (caughtUp)
        continue;  if (yieldTimeNsec == 0L) {
        Thread.yield();
      } else {
        try {
          TimeUnit.NANOSECONDS.sleep(yieldTimeNsec);
        } catch (InterruptedException interruptedException) {}
      }
    
    }
    while (!caughtUp);
  }


















  
  public void flipPhase() { flipPhase(0L); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\WriterReaderPhaser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */