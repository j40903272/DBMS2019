package org.neo4j.graphalgo.core.loading;

import java.util.Arrays;
import org.neo4j.internal.kernel.api.PropertyCursor;
import org.neo4j.values.storable.NumberValue;
import org.neo4j.values.storable.Value;
import org.neo4j.values.storable.Values;






















public final class ReadHelper
{
  private ReadHelper() { throw new UnsupportedOperationException("No instances"); }

  
  public static double[] readProperties(PropertyCursor pc, int[] propertyIds, double[] defaultValues) {
    double[] properties = new double[propertyIds.length];
    Arrays.setAll(properties, i -> defaultValues[i]);
    while (pc.next()) {

      
      for (int indexOfPropertyId = 0; indexOfPropertyId < propertyIds.length; indexOfPropertyId++) {
        if (propertyIds[indexOfPropertyId] == pc.propertyKey()) {
          Value value = pc.propertyValue();
          double defaultValue = defaultValues[indexOfPropertyId];
          double propertyValue = extractValue(value, defaultValue);
          properties[indexOfPropertyId] = propertyValue;
        } 
      } 
    } 
    return properties;
  }


  
  public static double extractValue(Value value, double defaultValue) {
    if (value instanceof NumberValue) {
      return ((NumberValue)value).doubleValue();
    }
    if (Values.NO_VALUE.eq(value)) {
      return defaultValue;
    }


    
    throw new IllegalArgumentException(String.format("Unsupported type [%s] of value %s. Please use a numeric property.", new Object[] { value
            
            .valueGroup(), value }));
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\ReadHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */