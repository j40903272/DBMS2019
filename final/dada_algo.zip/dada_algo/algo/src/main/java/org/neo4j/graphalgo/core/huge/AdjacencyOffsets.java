package org.neo4j.graphalgo.core.huge;

import org.neo4j.graphalgo.core.GraphDimensions;
import org.neo4j.graphalgo.core.loading.ImportSizing;
import org.neo4j.graphalgo.core.utils.BitUtil;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;

























public abstract class AdjacencyOffsets
{
  public static AdjacencyOffsets of(long[][] pages, int pageSize) {
    if (pages.length == 1) {
      return new SinglePageOffsets(pages[0]);
    }
    return new PagedOffsets(pages, pageSize);
  }
  
  static MemoryEstimation memoryEstimation(int pageSize, int numberOfPages) {
    if (numberOfPages == 1) {
      return SinglePageOffsets.memoryEstimation(pageSize);
    }
    return PagedOffsets.memoryEstimation(pageSize, numberOfPages);
  }

  
  public static MemoryEstimation memoryEstimation() {
    return MemoryEstimations.setup("adjacency offsets", (dimensions, concurrency) -> {

          
          ImportSizing importSizing = ImportSizing.of(concurrency, dimensions.nodeCount());
          return memoryEstimation(importSizing
              .pageSize(), importSizing
              .numberOfPages());
        });
  }

  
  public static AdjacencyOffsets of(long[] page) { return new SinglePageOffsets(page); }
  
  abstract long get(long paramLong);
  
  abstract long release();
  
  private static final class PagedOffsets
    extends AdjacencyOffsets {
    private final int pageShift;
    
    static MemoryEstimation memoryEstimation(int pageSize, int numberOfPages) { return MemoryEstimations.builder(PagedOffsets.class)
        .fixed("pages wrapper", MemoryUsage.sizeOfObjectArray(numberOfPages))
        .fixed("page[]", MemoryUsage.sizeOfLongArray(pageSize) * numberOfPages)
        .build(); }
    private final long pageMask; private long[][] pages;
    
    private PagedOffsets(long[][] pages, int pageSize) {
      assert pageSize == 0 || BitUtil.isPowerOfTwo(pageSize);
      this.pageShift = Integer.numberOfTrailingZeros(pageSize);
      this.pageMask = (pageSize - 1);
      this.pages = pages;
    }

    
    long get(long index) {
      int pageIndex = (int)(index >>> this.pageShift);
      int indexInPage = (int)(index & this.pageMask);
      return this.pages[pageIndex][indexInPage];
    }

    
    long release() {
      if (this.pages != null) {
        long memoryUsed = MemoryUsage.sizeOfObjectArray(this.pages.length);
        for (long[] page : this.pages) {
          memoryUsed += MemoryUsage.sizeOfLongArray(page.length);
        }
        this.pages = (long[][])null;
        return memoryUsed;
      } 
      return 0L;
    }
  }
  
  private static final class SinglePageOffsets
    extends AdjacencyOffsets
  {
    private long[] page;
    
    static MemoryEstimation memoryEstimation(int pageSize) { return MemoryEstimations.builder(SinglePageOffsets.class)
        .fixed("page", MemoryUsage.sizeOfLongArray(pageSize))
        .build(); }


    
    private SinglePageOffsets(long[] page) { this.page = page; }



    
    long get(long index) { return this.page[(int)index]; }


    
    long release() {
      if (this.page != null) {
        long memoryUsed = MemoryUsage.sizeOfLongArray(this.page.length);
        this.page = null;
        return memoryUsed;
      } 
      return 0L;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\huge\AdjacencyOffsets.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */