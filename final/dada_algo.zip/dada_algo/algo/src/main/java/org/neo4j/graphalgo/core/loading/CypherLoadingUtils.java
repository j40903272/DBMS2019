package org.neo4j.graphalgo.core.loading;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import org.neo4j.graphdb.Result;
























final class CypherLoadingUtils
{
  static final int NO_BATCHING = -1;
  
  static boolean canBatchLoad(int concurrency, String statement) {
    return (concurrency > 1 && (statement
      .contains("{limit}") || statement.contains("$limit")) && (statement
      .contains("{skip}") || statement.contains("$skip")));
  }
  
  public static Map<String, Object> params(Map<String, Object> baseParams, long offset, int batchSize) {
    Map<String, Object> params = new HashMap<>(baseParams);
    params.put("skip", Long.valueOf(offset));
    params.put("limit", Integer.valueOf(batchSize));
    return params;
  }
  
  public static <T> T get(String message, Future<T> future) {
    try {
      return future.get();
    } catch (InterruptedException e) {
      throw new RuntimeException("Interrupted: " + message, e);
    } catch (ExecutionException e) {
      throw new RuntimeException(message, e);
    } 
  }
  
  public static Object getProperty(Result.ResultRow row, String propertyName) {
    try {
      return row.get(propertyName);
    } catch (IllegalArgumentException|java.util.NoSuchElementException e) {
      return null;
    } 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\CypherLoadingUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */