package org.neo4j.graphalgo.core.utils;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.FutureTask;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.neo4j.helpers.NamedThreadFactory;


















public final class Pools
{
  private static final int MAX_CONCURRENCY;
  public static final int DEFAULT_CONCURRENCY;
  public static final int DEFAULT_QUEUE_SIZE;
  public static final ExecutorService DEFAULT;
  public static final ForkJoinPool FJ_POOL;
  
  static  {
    ConcurrencyConfig concurrencyConfig = ConcurrencyConfig.of();
    MAX_CONCURRENCY = concurrencyConfig.maxConcurrency;
    DEFAULT_CONCURRENCY = concurrencyConfig.defaultConcurrency;





    
    DEFAULT_QUEUE_SIZE = DEFAULT_CONCURRENCY * 50;
    
    DEFAULT = createDefaultPool();
    FJ_POOL = createFJPool();
  }
  
  private Pools() { throw new UnsupportedOperationException(); }

  
  public static ExecutorService createDefaultPool() {
    return new ThreadPoolExecutor(DEFAULT_CONCURRENCY, DEFAULT_CONCURRENCY * 2, 30L, TimeUnit.SECONDS, new ArrayBlockingQueue<>(DEFAULT_QUEUE_SIZE), 




        
        (ThreadFactory)NamedThreadFactory.daemon("algo"), new CallerBlocksPolicy());
  }
  
  public static int allowedConcurrency(int concurrency) { return Math.min(MAX_CONCURRENCY, concurrency); }
  
  public static ForkJoinPool createFJPool() { return new ForkJoinPool(DEFAULT_CONCURRENCY); }


  
  static class CallerBlocksPolicy
    implements RejectedExecutionHandler
  {
    public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
      FutureTask<Void> task = (FutureTask)new FutureTask<>(r, null);
      BlockingQueue<Runnable> queue = executor.getQueue();
      while (!executor.isShutdown()) {
        try {
          if (queue.offer(task, 250L, TimeUnit.MILLISECONDS)) {
            while (!executor.isShutdown()) {
              try {
                task.get(250L, TimeUnit.MILLISECONDS);
                return;
              } catch (TimeoutException timeoutException) {}
            }
          
          }
        }
        catch (InterruptedException|java.util.concurrent.ExecutionException e) {
          throw new RuntimeException(e);
        } 
      } 
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\Pools.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */