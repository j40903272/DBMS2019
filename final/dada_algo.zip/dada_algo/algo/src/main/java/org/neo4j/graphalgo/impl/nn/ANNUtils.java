package org.neo4j.graphalgo.impl.nn;

import java.util.HashSet;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import org.neo4j.graphalgo.core.huge.HugeGraph;
import org.neo4j.graphalgo.core.loading.IdsAndProperties;
import org.neo4j.graphalgo.core.loading.Relationships;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.roaringbitmap.RoaringBitmap;





















public class ANNUtils
{
  public static long[] sampleNeighbors(long[] potentialNeighbors, double initialSampleSize, Random random) {
    shuffleArray(potentialNeighbors, random);
    
    int sampleSize = (int)Math.min(initialSampleSize, potentialNeighbors.length);
    long[] sampled = new long[sampleSize];
    System.arraycopy(potentialNeighbors, 0, sampled, 0, sampleSize);
    return sampled;
  }



  
  private static void shuffleArray(long[] array, Random random) {
    for (int i = array.length - 1; i > 0; i--) {
      int index = random.nextInt(i + 1);
      long temp = array[index];
      array[index] = array[i];
      array[i] = temp;
    } 
  }
  
  static HugeGraph hugeGraph(IdsAndProperties nodes, Relationships hugeRels) {
    return HugeGraph.create(AllocationTracker.EMPTY, nodes
        
        .idMap(), nodes
        .properties(), hugeRels
        .relationshipCount(), hugeRels
        .inAdjacency(), hugeRels
        .outAdjacency(), hugeRels
        .inOffsets(), hugeRels
        .outOffsets(), hugeRels
        .maybeDefaultRelProperty(), 
        Optional.ofNullable(hugeRels.inRelProperties()), 
        Optional.ofNullable(hugeRels.outRelProperties()), 
        Optional.ofNullable(hugeRels.inRelPropertyOffsets()), 
        Optional.ofNullable(hugeRels.outRelPropertyOffsets()), false);
  }

  
  static RoaringBitmap[] initializeRoaringBitmaps(int length) {
    RoaringBitmap[] tempVisitedRelationships = new RoaringBitmap[length];
    for (int i = 0; i < length; i++) {
      tempVisitedRelationships[i] = new RoaringBitmap();
    }
    return tempVisitedRelationships;
  }


  
  public static Set<Integer> selectRandomNeighbors(int topK, int numberOfInputs, int excludeIndex, Random random) {
    Set<Integer> randomNeighbors = new HashSet<>();
    while (randomNeighbors.size() < topK && randomNeighbors.size() < numberOfInputs - 1) {
      int index = random.nextInt(numberOfInputs);
      if (index != excludeIndex) {
        randomNeighbors.add(Integer.valueOf(index));
      }
    } 
    return randomNeighbors;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\nn\ANNUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */