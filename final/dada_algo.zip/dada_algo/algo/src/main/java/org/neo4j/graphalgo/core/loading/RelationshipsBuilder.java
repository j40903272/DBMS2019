package org.neo4j.graphalgo.core.loading;

import java.util.Arrays;
import org.neo4j.graphalgo.core.DeduplicationStrategy;
import org.neo4j.graphalgo.core.huge.AdjacencyList;
import org.neo4j.graphalgo.core.huge.AdjacencyOffsets;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;






















public class RelationshipsBuilder
{
  private static final AdjacencyListBuilder[] EMPTY_WEIGHTS = new AdjacencyListBuilder[0];
  
  private final DeduplicationStrategy[] deduplicationStrategies;
  
  final AdjacencyListBuilder adjacency;
  
  final AdjacencyListBuilder[] weights;
  
  AdjacencyOffsets globalAdjacencyOffsets;
  
  AdjacencyOffsets[] globalWeightOffsets;
  
  public RelationshipsBuilder(DeduplicationStrategy[] deduplicationStrategies, AllocationTracker tracker, int numberOfRelationshipWeights) {
    if (Arrays.stream(deduplicationStrategies).anyMatch(d -> (d == DeduplicationStrategy.DEFAULT))) {
      throw new IllegalArgumentException(String.format("Needs an explicit deduplicateRelationshipsStrategy, but got %s", new Object[] {
              
              Arrays.toString((Object[])deduplicationStrategies)
            }));
    }
    this.deduplicationStrategies = deduplicationStrategies;
    this.adjacency = AdjacencyListBuilder.newBuilder(tracker);
    if (numberOfRelationshipWeights > 0) {
      this.weights = new AdjacencyListBuilder[numberOfRelationshipWeights];

      
      Arrays.setAll(this.weights, i -> AdjacencyListBuilder.newBuilder(tracker));
    } else {
      this.weights = EMPTY_WEIGHTS;
    } 
  }


  
  final ThreadLocalRelationshipsBuilder threadLocalRelationshipsBuilder(long[] adjacencyOffsets, long[][] weightOffsets) {
    return new ThreadLocalRelationshipsBuilder(this.deduplicationStrategies, this.adjacency
        
        .newAllocator(), 
        (AdjacencyListBuilder.Allocator[])Arrays.stream(this.weights)
        .map(AdjacencyListBuilder::newAllocator)
        .toArray(x$0 -> new AdjacencyListBuilder.Allocator[x$0]), adjacencyOffsets, weightOffsets);
  }



  
  final void setGlobalAdjacencyOffsets(AdjacencyOffsets globalAdjacencyOffsets) { this.globalAdjacencyOffsets = globalAdjacencyOffsets; }


  
  final void setGlobalWeightOffsets(AdjacencyOffsets[] globalWeightOffsets) { this.globalWeightOffsets = globalWeightOffsets; }


  
  public AdjacencyList adjacency() { return this.adjacency.build(); }


  
  public AdjacencyList weights() { return (this.weights.length > 0) ? this.weights[0].build() : null; }


  
  public AdjacencyOffsets globalAdjacencyOffsets() { return this.globalAdjacencyOffsets; }


  
  public AdjacencyOffsets globalWeightOffsets() { return this.globalWeightOffsets[0]; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\RelationshipsBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */