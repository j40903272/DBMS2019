package org.petitparser.parser.combinators;

import java.util.Objects;
import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.parser.Parser;




public class EndOfInputParser
  extends DelegateParser
{
  protected final String message;
  
  public EndOfInputParser(Parser delegate, String message) {
    super(delegate);
    this.message = Objects.requireNonNull(message, "Undefined message");
  }

  
  public Result parseOn(Context context) {
    Result result = this.delegate.parseOn(context);
    if (result.isFailure()) {
      return result;
    }
    if (result.getPosition() == result.getBuffer().length()) {
      return result;
    }
    return (Result)result.failure(this.message, result.getPosition());
  }

  
  protected boolean hasEqualProperties(Parser other) {
    return (super.hasEqualProperties(other) && 
      Objects.equals(this.message, ((EndOfInputParser)other).message));
  }


  
  public EndOfInputParser copy() { return new EndOfInputParser(this.delegate, this.message); }



  
  public String toString() { return super.toString() + "[" + this.message + "]"; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\combinators\EndOfInputParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */