package org.neo4j.graphalgo.core.utils.paged;

import java.util.concurrent.atomic.AtomicLong;






















public final class PaddedAtomicLong
  extends AtomicLong
{
  public volatile long p1 = 1L, p2 = 2L, p3 = 3L, p4 = 4L, p5 = 5L, p6 = 6L, p7 = 7L;

  
  public long sum() { return this.p1 + this.p2 + this.p3 + this.p4 + this.p5 + this.p6 + this.p7; }


  
  public PaddedAtomicLong() {}


  
  public PaddedAtomicLong(long initialValue) { super(initialValue); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\PaddedAtomicLong.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */