package org.jctools.queues;

import org.jctools.util.UnsafeAccess;





















public class MpscLinkedQueue7<E>
  extends MpscLinkedQueue<E>
{
  protected final LinkedQueueNode<E> xchgProducerNode(LinkedQueueNode<E> newVal) {
    Object<E> oldVal;
    do {
      oldVal = (Object<E>)this.producerNode;
    }
    while (!UnsafeAccess.UNSAFE.compareAndSwapObject(this, P_NODE_OFFSET, oldVal, newVal));
    return (LinkedQueueNode<E>)oldVal;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\jctools\queues\MpscLinkedQueue7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */