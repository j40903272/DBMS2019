package org.neo4j.graphalgo.core.utils.container;

import java.util.function.IntPredicate;
import org.apache.lucene.util.ArrayUtil;


























public class Path
{
  private int[] nodes;
  private int offset = 0;

  
  public Path() { this(10); }


  
  public Path(int initialSize) { this.nodes = new int[initialSize]; }

  
  public void append(int nodeId) {
    this.nodes = ArrayUtil.grow(this.nodes, this.offset + 1);
    this.nodes[this.offset++] = nodeId;
  }

  
  public int size() { return this.offset; }

  
  public void forEach(IntPredicate consumer) {
    for (int i = 0; i < this.offset; i++) {
      if (!consumer.test(this.nodes[i])) {
        return;
      }
    } 
  }

  
  public void clear() { this.offset = 0; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\container\Path.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */