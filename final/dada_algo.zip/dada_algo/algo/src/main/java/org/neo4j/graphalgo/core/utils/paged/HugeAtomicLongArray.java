package org.neo4j.graphalgo.core.utils.paged;

import java.util.function.IntToLongFunction;
import java.util.function.LongUnaryOperator;
import java.util.stream.IntStream;
import org.neo4j.graphalgo.core.utils.ArrayUtil;
import org.neo4j.graphalgo.core.utils.BitUtil;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
import org.neo4j.graphalgo.core.write.PropertyTranslator;
import org.neo4j.unsafe.impl.internal.dragons.UnsafeUtil;


























































































































public abstract class HugeAtomicLongArray
{
  private static final int base;
  private static final int shift;
  
  public static HugeAtomicLongArray newArray(long size, AllocationTracker tracker) { return newArray(size, null, tracker); }





  
  public static HugeAtomicLongArray newArray(long size, LongUnaryOperator gen, AllocationTracker tracker)
  {
    if (size <= ArrayUtil.MAX_ARRAY_LENGTH) {
      return 
































































        
        SingleHugeAtomicLongArray.of(size, gen, tracker);
    }

















































































    
    return PagedHugeAtomicLongArray.of(size, gen, tracker); } public static long memoryEstimation(long size) { long dataSize; long instanceSize; assert size >= 0L; if (size <= ArrayUtil.MAX_ARRAY_LENGTH) { instanceSize = MemoryUsage.sizeOfInstance(SingleHugeAtomicLongArray.class); dataSize = MemoryUsage.sizeOfLongArray((int)size); } else { instanceSize = MemoryUsage.sizeOfInstance(PagedHugeAtomicLongArray.class); dataSize = PagedHugeAtomicLongArray.memoryUsageOfData(size); }  return instanceSize + dataSize; } static HugeAtomicLongArray newPagedArray(long size, LongUnaryOperator gen, AllocationTracker tracker) { return PagedHugeAtomicLongArray.of(size, gen, tracker); } static HugeAtomicLongArray newSingleArray(int size, LongUnaryOperator gen, AllocationTracker tracker) { return SingleHugeAtomicLongArray.of(size, gen, tracker); } public static class Translator implements PropertyTranslator.OfLong<HugeAtomicLongArray> {
    public static final Translator INSTANCE = new Translator(); public long toLong(HugeAtomicLongArray data, long nodeId) { return data.get(nodeId); } } static  { UnsafeUtil.assertHasUnsafe(); base = UnsafeUtil.arrayBaseOffset(long[].class); int scale = UnsafeUtil.arrayIndexScale(long[].class); if (!BitUtil.isPowerOfTwo(scale)) throw new Error("data type scale not a power of two");  shift = 31 - Integer.numberOfLeadingZeros(scale); } private static long memoryOffset(int i) { return (i << shift) + base; } public abstract long get(long paramLong); public abstract void set(long paramLong1, long paramLong2); public abstract boolean compareAndSet(long paramLong1, long paramLong2, long paramLong3); public abstract void update(long paramLong, LongUnaryOperator paramLongUnaryOperator); public abstract long size(); public abstract long sizeOf(); public abstract long release(); private static final class SingleHugeAtomicLongArray extends HugeAtomicLongArray {
    private final int size; private long[] page; private static HugeAtomicLongArray of(long size, LongUnaryOperator gen, AllocationTracker tracker) { assert size <= ArrayUtil.MAX_ARRAY_LENGTH; int intSize = (int)size; tracker.add(MemoryUsage.sizeOfLongArray(intSize)); long[] page = new long[intSize]; if (gen != null) parallelSetAll(gen, page);  return new SingleHugeAtomicLongArray(intSize, page); } private static void parallelSetAll(LongUnaryOperator gen, long[] page) { ParallelUtil.parallelStreamConsume(IntStream.range(0, page.length), stream -> stream.forEach(())); } private SingleHugeAtomicLongArray(int size, long[] page) { this.size = size; this.page = page; } public long get(long index) { assert index < this.size; return getRaw(HugeAtomicLongArray.memoryOffset((int)index)); } public void set(long index, long value) { assert index < this.size; UnsafeUtil.putLongVolatile(this.page, HugeAtomicLongArray.memoryOffset((int)index), value); } public boolean compareAndSet(long index, long expect, long update) { assert index < this.size; return compareAndSetRaw(HugeAtomicLongArray.memoryOffset((int)index), expect, update); } public void update(long index, LongUnaryOperator updateFunction) { long next, prev; assert index < this.size; long offset = HugeAtomicLongArray.memoryOffset((int)index); do { prev = getRaw(offset); next = updateFunction.applyAsLong(prev); } while (!compareAndSetRaw(offset, prev, next)); } public long size() { return this.size; } public long sizeOf() { return MemoryUsage.sizeOfLongArray(this.size); } public long release() { if (this.page != null) { this.page = null; return MemoryUsage.sizeOfLongArray(this.size); }  return 0L; } private long getRaw(long offset) { return UnsafeUtil.getLongVolatile(this.page, offset); } private boolean compareAndSetRaw(long offset, long expect, long update) { return UnsafeUtil.compareAndSwapLong(this.page, offset, expect, update); } } private static final class PagedHugeAtomicLongArray extends HugeAtomicLongArray {
    private final long size; private static HugeAtomicLongArray of(long size, LongUnaryOperator gen, AllocationTracker tracker) { int numPages = HugeArrays.numberOfPages(size);
      int lastPage = numPages - 1;
      int lastPageSize = HugeArrays.exclusiveIndexOfPage(size);
      
      long[][] pages = new long[numPages][];
      for (int i = 0; i < lastPage; i++) {
        pages[i] = new long[16384];
        if (gen != null) {
          long base = i << 14L;
          parallelSetAll(pages[i], j -> gen.applyAsLong(base + j));
        } 
      } 
      pages[lastPage] = new long[lastPageSize];
      if (gen != null) {
        long base = lastPage << 14L;
        parallelSetAll(pages[lastPage], j -> gen.applyAsLong(base + j));
      } 
      
      long memoryUsed = memoryUsageOfData(size);
      tracker.add(memoryUsed);
      return new PagedHugeAtomicLongArray(size, pages, memoryUsed); }
    
    private long[][] pages; private final long memoryUsed;
    private static void parallelSetAll(long[] array, IntToLongFunction generator) {
      ParallelUtil.parallelStreamConsume(
          IntStream.range(0, array.length), intStream -> 
          intStream.forEach(()));
    }
    
    private static long memoryUsageOfData(long size) {
      int numberOfPages = HugeArrays.numberOfPages(size);
      int numberOfFullPages = numberOfPages - 1;
      long bytesPerPage = MemoryUsage.sizeOfLongArray(16384);
      int sizeOfLastPast = HugeArrays.exclusiveIndexOfPage(size);
      long bytesOfLastPage = MemoryUsage.sizeOfLongArray(sizeOfLastPast);
      long memoryUsed = MemoryUsage.sizeOfObjectArray(numberOfPages);
      memoryUsed += numberOfFullPages * bytesPerPage;
      memoryUsed += bytesOfLastPage;
      return memoryUsed;
    }




    
    private PagedHugeAtomicLongArray(long size, long[][] pages, long memoryUsed) {
      this.size = size;
      this.pages = pages;
      this.memoryUsed = memoryUsed;
    }

    
    public long get(long index) {
      assert index < this.size && index >= 0L;
      int pageIndex = HugeArrays.pageIndex(index);
      int indexInPage = HugeArrays.indexInPage(index);
      return getRaw(this.pages[pageIndex], HugeAtomicLongArray.memoryOffset(indexInPage));
    }

    
    public void set(long index, long value) {
      assert index < this.size && index >= 0L;
      int pageIndex = HugeArrays.pageIndex(index);
      int indexInPage = HugeArrays.indexInPage(index);
      UnsafeUtil.putLongVolatile(this.pages[pageIndex], HugeAtomicLongArray.memoryOffset(indexInPage), value);
    }

    
    public boolean compareAndSet(long index, long expect, long update) {
      assert index < this.size && index >= 0L;
      int pageIndex = HugeArrays.pageIndex(index);
      int indexInPage = HugeArrays.indexInPage(index);
      return compareAndSetRaw(this.pages[pageIndex], HugeAtomicLongArray.memoryOffset(indexInPage), expect, update);
    }
    
    public void update(long index, LongUnaryOperator updateFunction) {
      long next, prev;
      assert index < this.size && index >= 0L;
      int pageIndex = HugeArrays.pageIndex(index);
      int indexInPage = HugeArrays.indexInPage(index);
      long[] page = this.pages[pageIndex];
      long offset = HugeAtomicLongArray.memoryOffset(indexInPage);
      
      do {
        prev = getRaw(page, offset);
        next = updateFunction.applyAsLong(prev);
      } while (!compareAndSetRaw(page, offset, prev, next));
    }


    
    public long size() { return this.size; }



    
    public long sizeOf() { return this.memoryUsed; }


    
    public long release() {
      if (this.pages != null) {
        this.pages = (long[][])null;
        return this.memoryUsed;
      } 
      return 0L;
    }

    
    private long getRaw(long[] page, long offset) { return UnsafeUtil.getLongVolatile(page, offset); }


    
    private boolean compareAndSetRaw(long[] page, long offset, long expect, long update) { return UnsafeUtil.compareAndSwapLong(page, offset, expect, update); }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\HugeAtomicLongArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */