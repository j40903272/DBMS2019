package org.neo4j.graphalgo.core.loading;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.concurrent.ExecutorService;
import org.neo4j.graphalgo.core.GraphDimensions;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
import org.neo4j.kernel.impl.store.record.AbstractBaseRecord;
import org.neo4j.kernel.internal.GraphDatabaseAPI;
import org.neo4j.logging.Log;
























abstract class ScanningRecordsImporter<Record extends AbstractBaseRecord, T>
{
  private static final BigInteger A_BILLION = BigInteger.valueOf(1000000000L);
  
  private final AbstractStorePageCacheScanner.Access<Record> access;
  
  private final String label;
  
  final GraphDatabaseAPI api;
  
  final GraphDimensions dimensions;
  
  private final ExecutorService threadPool;
  
  final int concurrency;

  
  ScanningRecordsImporter(AbstractStorePageCacheScanner.Access<Record> access, String label, GraphDatabaseAPI api, GraphDimensions dimensions, ExecutorService threadPool, int concurrency) {
    this.access = access;
    this.label = label;
    this.api = api;
    this.dimensions = dimensions;
    this.threadPool = threadPool;
    this.concurrency = concurrency;
  }
  
  final T call(Log log) {
    long nodeCount = this.dimensions.nodeCount();
    ImportSizing sizing = ImportSizing.of(this.concurrency, nodeCount);
    int numberOfThreads = sizing.numberOfThreads();
    
    AbstractStorePageCacheScanner<Record> scanner = new AbstractStorePageCacheScanner<>(100, this.api, this.access);

    
    InternalImporter.CreateScanner creator = creator(nodeCount, sizing, scanner);
    InternalImporter importer = new InternalImporter(numberOfThreads, creator);
    InternalImporter.ImportResult importResult = importer.runImport(this.threadPool);
    
    long requiredBytes = scanner.storeSize();
    long recordsImported = importResult.recordsImported;
    long propertiesImported = importResult.propertiesImported;
    BigInteger bigNanos = BigInteger.valueOf(importResult.tookNanos);

    
    double tookInSeconds = (new BigDecimal(bigNanos)).divide(new BigDecimal(A_BILLION), 9, RoundingMode.CEILING).doubleValue();
    long bytesPerSecond = A_BILLION.multiply(BigInteger.valueOf(requiredBytes)).divide(bigNanos).longValueExact();
    
    log.info("%s Store Scan: Imported %,d records and %,d properties from %s (%,d bytes); took %.3f s, %,.2f %1$ss/s, %s/s (%,d bytes/s) (per thread: %,.2f %1$ss/s, %s/s (%,d bytes/s))", new Object[] { this.label, 

          
          Long.valueOf(recordsImported), 
          Long.valueOf(propertiesImported), 
          MemoryUsage.humanReadable(requiredBytes), 
          Long.valueOf(requiredBytes), 
          Double.valueOf(tookInSeconds), 
          Double.valueOf(recordsImported / tookInSeconds), 
          MemoryUsage.humanReadable(bytesPerSecond), 
          Long.valueOf(bytesPerSecond), 
          Double.valueOf(recordsImported / tookInSeconds / numberOfThreads), 
          MemoryUsage.humanReadable(bytesPerSecond / numberOfThreads), 
          Long.valueOf(bytesPerSecond / numberOfThreads) });

    
    return build();
  }
  
  abstract InternalImporter.CreateScanner creator(long paramLong, ImportSizing paramImportSizing, AbstractStorePageCacheScanner<Record> paramAbstractStorePageCacheScanner);
  
  abstract T build();
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\ScanningRecordsImporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */