package org.HdrHistogram;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.zip.DataFormatException;





































public class Histogram
  extends AbstractHistogram
{
  long totalCount;
  long[] counts;
  int normalizingIndexOffset;
  
  long getCountAtIndex(int index) { return this.counts[normalizeIndex(index, this.normalizingIndexOffset, this.countsArrayLength)]; }



  
  long getCountAtNormalizedIndex(int index) { return this.counts[index]; }



  
  void incrementCountAtIndex(int index) { this.counts[normalizeIndex(index, this.normalizingIndexOffset, this.countsArrayLength)] = this.counts[normalizeIndex(index, this.normalizingIndexOffset, this.countsArrayLength)] + 1L; }



  
  void addToCountAtIndex(int index, long value) { this.counts[normalizeIndex(index, this.normalizingIndexOffset, this.countsArrayLength)] = this.counts[normalizeIndex(index, this.normalizingIndexOffset, this.countsArrayLength)] + value; }



  
  void setCountAtIndex(int index, long value) { this.counts[normalizeIndex(index, this.normalizingIndexOffset, this.countsArrayLength)] = value; }



  
  void setCountAtNormalizedIndex(int index, long value) { this.counts[index] = value; }



  
  int getNormalizingIndexOffset() { return this.normalizingIndexOffset; }



  
  void setNormalizingIndexOffset(int normalizingIndexOffset) { this.normalizingIndexOffset = normalizingIndexOffset; }



  
  void shiftNormalizingIndexByOffset(int offsetToAdd, boolean lowestHalfBucketPopulated) { nonConcurrentNormalizingIndexShift(offsetToAdd, lowestHalfBucketPopulated); }


  
  void clearCounts() {
    Arrays.fill(this.counts, 0L);
    this.totalCount = 0L;
  }

  
  public Histogram copy() {
    Histogram copy = new Histogram(this);
    copy.add(this);
    return copy;
  }

  
  public Histogram copyCorrectedForCoordinatedOmission(long expectedIntervalBetweenValueSamples) {
    Histogram copy = new Histogram(this);
    copy.addWhileCorrectingForCoordinatedOmission(this, expectedIntervalBetweenValueSamples);
    return copy;
  }


  
  public long getTotalCount() { return this.totalCount; }



  
  void setTotalCount(long totalCount) { this.totalCount = totalCount; }



  
  void incrementTotalCount() { this.totalCount++; }



  
  void addToTotalCount(long value) { this.totalCount += value; }



  
  int _getEstimatedFootprintInBytes() { return 512 + 8 * this.counts.length; }


  
  void resize(long newHighestTrackableValue) {
    int oldNormalizedZeroIndex = normalizeIndex(0, this.normalizingIndexOffset, this.countsArrayLength);
    
    establishSize(newHighestTrackableValue);
    
    int countsDelta = this.countsArrayLength - this.counts.length;
    
    this.counts = Arrays.copyOf(this.counts, this.countsArrayLength);
    
    if (oldNormalizedZeroIndex != 0) {
      
      int newNormalizedZeroIndex = oldNormalizedZeroIndex + countsDelta;
      int lengthToCopy = this.countsArrayLength - countsDelta - oldNormalizedZeroIndex;
      System.arraycopy(this.counts, oldNormalizedZeroIndex, this.counts, newNormalizedZeroIndex, lengthToCopy);
      Arrays.fill(this.counts, oldNormalizedZeroIndex, newNormalizedZeroIndex, 0L);
    } 
  }








  
  public Histogram(int numberOfSignificantValueDigits) {
    this(1L, 2L, numberOfSignificantValueDigits);
    setAutoResize(true);
  }











  
  public Histogram(long highestTrackableValue, int numberOfSignificantValueDigits) { this(1L, highestTrackableValue, numberOfSignificantValueDigits); }



















  
  public Histogram(long lowestDiscernibleValue, long highestTrackableValue, int numberOfSignificantValueDigits) { this(lowestDiscernibleValue, highestTrackableValue, numberOfSignificantValueDigits, true); }







  
  public Histogram(AbstractHistogram source) { this(source, true); }

  
  Histogram(AbstractHistogram source, boolean allocateCountsArray) {
    super(source);
    if (allocateCountsArray) {
      this.counts = new long[this.countsArrayLength];
    }
    this.wordSizeInBytes = 8;
  }

  
  Histogram(long lowestDiscernibleValue, long highestTrackableValue, int numberOfSignificantValueDigits, boolean allocateCountsArray) {
    super(lowestDiscernibleValue, highestTrackableValue, numberOfSignificantValueDigits);
    if (allocateCountsArray) {
      this.counts = new long[this.countsArrayLength];
    }
    this.wordSizeInBytes = 8;
  }








  
  public static Histogram decodeFromByteBuffer(ByteBuffer buffer, long minBarForHighestTrackableValue) { return decodeFromByteBuffer(buffer, Histogram.class, minBarForHighestTrackableValue); }










  
  public static Histogram decodeFromCompressedByteBuffer(ByteBuffer buffer, long minBarForHighestTrackableValue) throws DataFormatException { return decodeFromCompressedByteBuffer(buffer, Histogram.class, minBarForHighestTrackableValue); }



  
  private void readObject(ObjectInputStream o) throws IOException, ClassNotFoundException { o.defaultReadObject(); }



  
  synchronized void fillCountsArrayFromBuffer(ByteBuffer buffer, int length) { buffer.asLongBuffer().get(this.counts, 0, length); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\Histogram.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */