package org.neo4j.graphalgo.core.loading;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import org.neo4j.graphalgo.core.utils.RawValues;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.internal.kernel.api.CursorFactory;
import org.neo4j.internal.kernel.api.PropertyCursor;
import org.neo4j.internal.kernel.api.Read;





























public class RelationshipImporter
{
  private final AllocationTracker tracker;
  private final AdjacencyBuilder outAdjacency;
  private final AdjacencyBuilder inAdjacency;
  
  public RelationshipImporter(AllocationTracker tracker, AdjacencyBuilder outAdjacency, AdjacencyBuilder inAdjacency) {
    this.tracker = tracker;
    this.outAdjacency = outAdjacency;
    this.inAdjacency = inAdjacency;
  }










  
  public Imports imports(boolean loadAsUndirected, boolean loadOutgoing, boolean loadIncoming, boolean loadProperties) {
    if (loadAsUndirected) {
      return loadProperties ? this::importBothOrUndirectedWithProperties : this::importBothOrUndirected;
    }

    
    if (loadOutgoing) {
      if (loadIncoming) {
        return loadProperties ? this::importBothOrUndirectedWithProperties : this::importBothOrUndirected;
      }

      
      return loadProperties ? this::importOutgoingWithProperties : this::importOutgoing;
    } 

    
    if (loadIncoming) {
      return loadProperties ? this::importIncomingWithProperties : this::importIncoming;
    }

    
    return null;
  }
  
  private long importBothOrUndirected(RelationshipsBatchBuffer buffer, PropertyReader propertyReader) {
    long[] batch = buffer.sortBySource();
    int importedOut = importRelationships(buffer, batch, (long[][])null, this.outAdjacency, this.tracker);
    batch = buffer.sortByTarget();
    int importedIn = importRelationships(buffer, batch, (long[][])null, this.inAdjacency, this.tracker);
    return RawValues.combineIntInt(importedOut + importedIn, 0);
  }
  
  private long importBothOrUndirectedWithProperties(RelationshipsBatchBuffer buffer, PropertyReader reader) {
    int batchLength = buffer.length;
    long[] batch = buffer.sortBySource();
    long[][] outProperties = reader.readProperty(batch, batchLength, this.outAdjacency

        
        .getPropertyKeyIds(), this.outAdjacency
        .getDefaultValues());
    int importedOut = importRelationships(buffer, batch, outProperties, this.outAdjacency, this.tracker);
    batch = buffer.sortByTarget();
    
    long[][] inProperties = reader.readProperty(batch, batchLength, this.inAdjacency

        
        .getPropertyKeyIds(), this.inAdjacency
        .getDefaultValues());
    int importedIn = importRelationships(buffer, batch, inProperties, this.inAdjacency, this.tracker);
    return RawValues.combineIntInt(importedOut + importedIn, importedOut + importedIn);
  }
  
  private long importOutgoing(RelationshipsBatchBuffer buffer, PropertyReader propertyReader) {
    long[] batch = buffer.sortBySource();
    return RawValues.combineIntInt(importRelationships(buffer, batch, (long[][])null, this.outAdjacency, this.tracker), 0);
  }
  
  private long importOutgoingWithProperties(RelationshipsBatchBuffer buffer, PropertyReader propertyReader) {
    int batchLength = buffer.length;
    long[] batch = buffer.sortBySource();
    long[][] outProperties = propertyReader.readProperty(batch, batchLength, this.outAdjacency

        
        .getPropertyKeyIds(), this.outAdjacency
        .getDefaultValues());
    int importedOut = importRelationships(buffer, batch, outProperties, this.outAdjacency, this.tracker);
    return RawValues.combineIntInt(importedOut, importedOut);
  }
  
  private long importIncoming(RelationshipsBatchBuffer buffer, PropertyReader propertyReader) {
    long[] batch = buffer.sortByTarget();
    return RawValues.combineIntInt(importRelationships(buffer, batch, (long[][])null, this.inAdjacency, this.tracker), 0);
  }
  
  private long importIncomingWithProperties(RelationshipsBatchBuffer buffer, PropertyReader propertyReader) {
    int batchLength = buffer.length;
    long[] batch = buffer.sortByTarget();
    long[][] inProperties = propertyReader.readProperty(batch, batchLength, this.inAdjacency

        
        .getPropertyKeyIds(), this.inAdjacency
        .getDefaultValues());
    int importedIn = importRelationships(buffer, batch, inProperties, this.inAdjacency, this.tracker);
    return RawValues.combineIntInt(importedIn, importedIn);
  }














  
  public Collection<Runnable> flushTasks() {
    if (this.outAdjacency != null) {
      if (this.inAdjacency == null || this.inAdjacency == this.outAdjacency) {
        return this.outAdjacency.flushTasks();
      }
      Collection<Runnable> tasks = new ArrayList<>(this.outAdjacency.flushTasks());
      tasks.addAll(this.inAdjacency.flushTasks());
      return tasks;
    } 
    if (this.inAdjacency != null) {
      return this.inAdjacency.flushTasks();
    }
    return Collections.emptyList();
  }
  
  PropertyReader storeBackedPropertiesReader(CursorFactory cursors, Read read) {
    return (batch, batchLength, relationshipProperties, defaultPropertyValues) -> {
        long[][] properties = new long[relationshipProperties.length][batchLength / 4];
        try (PropertyCursor pc = cursors.allocatePropertyCursor()) {
          for (int i = 0; i < batchLength; i += 4) {
            long relationshipReference = batch[2 + i];
            long propertiesReference = batch[3 + i];
            read.relationshipProperties(relationshipReference, propertiesReference, pc);
            double[] relProps = ReadHelper.readProperties(pc, relationshipProperties, defaultPropertyValues);
            int propertyPos = i / 4;
            for (int j = 0; j < relProps.length; j++) {
              properties[j][propertyPos] = Double.doubleToLongBits(relProps[j]);
            }
          } 
        } 
        return properties;
      };
  }

  
  public static PropertyReader preLoadedPropertyReader() {
    return (batch, batchLength, weightProperty, defaultWeight) -> {
        long[] properties = new long[batchLength / 4];
        for (int i = 0; i < batchLength; i += 4) {
          long property = batch[3 + i];
          properties[i / 4] = property;
        } 
        return new long[][] { properties };
      };
  }






  
  private static int importRelationships(RelationshipsBatchBuffer buffer, long[] batch, long[][] properties, AdjacencyBuilder adjacency, AllocationTracker tracker) {
    int batchLength = buffer.length;
    
    int[] offsets = buffer.spareInts();
    long[] targets = buffer.spareLongs();
    
    long prevSource = batch[0];
    int offset = 0, nodesLength = 0;
    
    for (int i = 0; i < batchLength; i += 4) {
      long source = batch[i];
      long target = batch[1 + i];

      
      if (source > prevSource) {
        offsets[nodesLength++] = offset;
        prevSource = source;
      } 
      targets[offset++] = target;
    } 
    offsets[nodesLength++] = offset;
    
    adjacency.addAll(batch, targets, properties, offsets, nodesLength, tracker);







    
    return batchLength >> 2;
  }
  
  public static interface PropertyReader {
    long[][] readProperty(long[] param1ArrayOflong, int param1Int, int[] param1ArrayOfint, double[] param1ArrayOfdouble);
  }
  
  public static interface Imports {
    long importRels(RelationshipsBatchBuffer param1RelationshipsBatchBuffer, RelationshipImporter.PropertyReader param1PropertyReader);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\RelationshipImporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */