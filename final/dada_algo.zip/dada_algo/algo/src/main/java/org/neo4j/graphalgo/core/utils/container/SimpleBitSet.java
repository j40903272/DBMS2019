package org.neo4j.graphalgo.core.utils.container;

import java.util.Arrays;
import java.util.concurrent.locks.StampedLock;
import org.neo4j.collection.primitive.PrimitiveIntIterable;
import org.neo4j.collection.primitive.PrimitiveIntIterator;



































public class SimpleBitSet
  extends StampedLock
  implements PrimitiveIntIterable
{
  private long lastCheckPointKey;
  private long[] data;
  
  public SimpleBitSet(int size) {
    int initialCapacity = size / 64;
    int capacity = 1;
    while (capacity < initialCapacity) {
      capacity <<= 1;
    }
    long stamp = writeLock();
    this.data = new long[capacity];
    unlockWrite(stamp);
  } public boolean contains(int key) {
    long stamp;
    boolean result;
    int idx = key >>> 6;

    
    do {
      stamp = tryOptimisticRead();
      result = (this.data.length > idx && (this.data[idx] & 1L << (key & 0x3F)) != 0L);
    }
    while (!validate(stamp));
    return result;
  }
  
  public void put(int key) {
    long stamp = writeLock();
    int idx = key >>> 6;
    ensureCapacity(idx);
    this.data[idx] = this.data[idx] | 1L << (key & 0x3F);
    unlockWrite(stamp);
  }
  
  public void put(SimpleBitSet other) {
    long stamp = writeLock();
    ensureCapacity(other.data.length - 1);
    for (int i = 0; i < this.data.length && i < other.data.length; i++) {
      this.data[i] = this.data[i] | other.data[i];
    }
    unlockWrite(stamp);
  }
  
  public void clear() {
    long stamp = writeLock();
    Arrays.fill(this.data, 0L);
    unlockWrite(stamp);
  }
  
  public void remove(int key) {
    long stamp = writeLock();
    int idx = key >>> 6;
    if (this.data.length > idx) {
      this.data[idx] = this.data[idx] & (1L << (key & 0x3F) ^ 0xFFFFFFFFFFFFFFFFL);
    }
    unlockWrite(stamp);
  }
  
  public void remove(SimpleBitSet other) {
    long stamp = writeLock();
    for (int i = 0; i < this.data.length; i++) {
      this.data[i] = this.data[i] & (other.data[i] ^ 0xFFFFFFFFFFFFFFFFL);
    }
    unlockWrite(stamp);
  }

  
  public long checkPointAndPut(long checkPoint, int key) {
    if (!validate(checkPoint) || key != this.lastCheckPointKey) {
      long stamp = writeLock();
      int idx = key >>> 6;
      if (idx < this.data.length) {
        Arrays.fill(this.data, 0L);
      } else {
        int len = this.data.length;
        len = findNewLength(idx, len);
        this.data = new long[len];
      } 
      this.data[idx] = this.data[idx] | 1L << (key & 0x3F);
      this.lastCheckPointKey = key;
      checkPoint = tryConvertToOptimisticRead(stamp);
    } 
    return checkPoint;
  }
  
  private int findNewLength(int idx, int len) {
    while (len <= idx) {
      len *= 2;
    }
    return len;
  }
  
  public int size() {
    int size = 0;
    for (int i = 0; i < this.data.length; i++) {
      size += Long.bitCount(this.data[i]);
    }
    return size;
  }
  
  private void ensureCapacity(int arrayIndex) {
    if (this.data.length <= arrayIndex) {
      this.data = Arrays.copyOf(this.data, findNewLength(arrayIndex, this.data.length));
    }
  }





  
  public PrimitiveIntIterator iterator() {
    return new PrimitiveIntIterator() {
        private int next = 0;
        private final int size = SimpleBitSet.this.data.length * 64;









        
        public boolean hasNext() { return (this.next < this.size); }


        
        public int next() {
          int current = this.next;
          this.next++;
          while (this.next < this.size && !SimpleBitSet.this.contains(this.next)) {
            this.next++;
          }
          return current;
        }
      };
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\container\SimpleBitSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */