package org.neo4j.graphalgo.core.utils;

import java.util.concurrent.TimeUnit;
import java.util.function.LongConsumer;























public class ProgressTimer
  implements AutoCloseable
{
  private final LongConsumer onStop;
  private final long startTime;
  private long duration = 0L;
  
  private ProgressTimer(LongConsumer onStop) {
    this.onStop = (onStop == null) ? (l -> {  }) : onStop;
    this.startTime = System.nanoTime();
  }
  
  public ProgressTimer stop() {
    this.duration = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - this.startTime);
    this.onStop.accept(this.duration);
    return this;
  }

  
  public long getDuration() { return this.duration; }


  
  public static ProgressTimer start(LongConsumer onStop) { return new ProgressTimer(onStop); }


  
  public static ProgressTimer start() { return new ProgressTimer(null); }



  
  public void close() { stop(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\ProgressTimer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */