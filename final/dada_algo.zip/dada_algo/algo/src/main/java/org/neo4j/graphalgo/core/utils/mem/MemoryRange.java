package org.neo4j.graphalgo.core.utils.mem;

import java.util.Objects;



























public final class MemoryRange
{
  private static final MemoryRange NULL_RANGE = new MemoryRange(0L, 0L);
  public final long min;
  
  public static MemoryRange of(long value) { return of(value, value); }
  public final long max;
  
  public static MemoryRange of(long min, long max) {
    if (min == 0L && max == 0L) {
      return NULL_RANGE;
    }
    if (min < 0L) {
      throw new IllegalArgumentException("min range < 0: " + min);
    }
    if (max < 0L) {
      throw new IllegalArgumentException("max range < 0: " + max);
    }
    if (max < min) {
      throw new IllegalArgumentException("max range < min: " + max + " < " + min);
    }
    return new MemoryRange(min, max);
  }

  
  public static MemoryRange empty() { return NULL_RANGE; }




  
  private MemoryRange(long min, long max) {
    this.min = min;
    this.max = max;
  }
  
  public MemoryRange add(MemoryRange other) {
    if (isEmpty()) {
      return other;
    }
    if (other.isEmpty()) {
      return this;
    }
    long newMin = Math.addExact(this.min, other.min);
    long newMax = Math.addExact(this.max, other.max);
    if (newMin == this.min && newMax == this.max) {
      return this;
    }
    return new MemoryRange(newMin, newMax);
  }
  
  public MemoryRange times(long count) {
    if (isEmpty() || count == 1L) {
      return this;
    }
    if (count == 0L) {
      return NULL_RANGE;
    }
    long newMin = Math.multiplyExact(this.min, count);
    long newMax = Math.multiplyExact(this.max, count);
    return new MemoryRange(newMin, newMax);
  }

  
  public MemoryRange union(MemoryRange other) { return of(Math.min(this.min, other.min), Math.max(this.max, other.max)); }


  
  public boolean isEmpty() { return (this.min == 0L && this.max == 0L); }


  
  public boolean equals(Object o) {
    if (this == o) return true; 
    if (o == null || getClass() != o.getClass()) return false; 
    MemoryRange range = (MemoryRange)o;
    return (this.min == range.min && this.max == range.max);
  }



  
  public int hashCode() { return Objects.hash(new Object[] { Long.valueOf(this.min), Long.valueOf(this.max) }); }


  
  public String toString() {
    if (this.min == this.max) {
      return MemoryUsage.humanReadable(this.min);
    }
    return "[" + MemoryUsage.humanReadable(this.min) + " ... " + MemoryUsage.humanReadable(this.max) + "]";
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\mem\MemoryRange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */