package org.neo4j.graphalgo.core.write;

import java.util.Collection;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.IntFunction;
import java.util.function.LongUnaryOperator;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.core.utils.LazyBatchCollection;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.Pools;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.ProgressLoggerAdapter;
import org.neo4j.graphalgo.core.utils.StatementApi;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.internal.kernel.api.Write;
import org.neo4j.internal.kernel.api.exceptions.KernelException;
import org.neo4j.kernel.api.KernelTransaction;
import org.neo4j.kernel.internal.GraphDatabaseAPI;
import org.neo4j.logging.Log;
import org.neo4j.values.storable.Value;





















public final class Exporter
  extends StatementApi
{
  private static final long MIN_BATCH_SIZE = 10000L;
  private static final long MAX_BATCH_SIZE = 100000L;
  public static final String TASK_EXPORT = "EXPORT";
  private final TerminationFlag terminationFlag;
  private final ExecutorService executorService;
  private final ProgressLogger progressLogger;
  private final int concurrency;
  private final long nodeCount;
  private final LongUnaryOperator toOriginalId;
  
  public static Builder of(GraphDatabaseAPI db, IdMapping idMapping) { return new Builder(db, idMapping); }
  
  public static interface PropertyWriteConsumer {
    void accept(Write param1Write, int param1Int1, int param1Int2) throws KernelException; }
  
  public static interface WriteConsumer {
    void accept(Write param1Write, long param1Long) throws KernelException; }
  
  public static final class Builder {
    private final GraphDatabaseAPI db;
    private final LongUnaryOperator toOriginalId;
    private final long nodeCount;
    
    private Builder(GraphDatabaseAPI db, IdMapping idMapping) {
      Objects.requireNonNull(idMapping);
      this.db = Objects.requireNonNull(db);
      this.nodeCount = idMapping.nodeCount();
      this.toOriginalId = idMapping::toOriginalNodeId;
      this.concurrency = Pools.DEFAULT_CONCURRENCY;
    }
    private TerminationFlag terminationFlag; private ExecutorService executorService; private ProgressLoggerAdapter loggerAdapter; private int concurrency;
    public Builder withLog(Log log) {
      this.loggerAdapter = new ProgressLoggerAdapter(Objects.requireNonNull(log), "EXPORT");
      return this;
    }
    
    public Builder withLogInterval(long time, TimeUnit unit) {
      if (this.loggerAdapter == null) {
        throw new IllegalStateException("no logger set");
      }
      long logTime = unit.toMillis(time);
      if ((int)logTime != logTime) {
        throw new IllegalArgumentException("timespan too large");
      }
      this.loggerAdapter.withLogIntervalMillis((int)logTime);
      return this;
    }
    
    public Builder parallel(ExecutorService es, int concurrency, TerminationFlag flag) {
      this.executorService = es;
      this.concurrency = Pools.allowedConcurrency(concurrency);
      this.terminationFlag = flag;
      return this;
    }
    
    public Exporter build() {
      Object object = (this.loggerAdapter == null) ? ProgressLogger.NULL_LOGGER : this.loggerAdapter;

      
      TerminationFlag flag = (this.terminationFlag == null) ? TerminationFlag.RUNNING_TRUE : this.terminationFlag;

      
      return new Exporter(this.db, this.nodeCount, this.toOriginalId, flag, (ProgressLogger)object, this.concurrency, this.executorService, null);
    }
  }















  
  private Exporter(GraphDatabaseAPI db, long nodeCount, LongUnaryOperator toOriginalId, TerminationFlag terminationFlag, ProgressLogger log, int concurrency, ExecutorService executorService) {
    super(db);
    this.nodeCount = nodeCount;
    this.toOriginalId = toOriginalId;
    this.terminationFlag = terminationFlag;
    this.progressLogger = log;
    this.concurrency = concurrency;
    this.executorService = executorService;
  }



  
  public <T> void write(String property, T data, PropertyTranslator<T> translator) {
    int propertyId = getOrCreatePropertyId(property);
    if (propertyId == -1) {
      throw new IllegalStateException("no write property id is set");
    }
    if (ParallelUtil.canRunInParallel(this.executorService)) {
      writeParallel(propertyId, data, translator);
    } else {
      writeSequential(propertyId, data, translator);
    } 
  }






  
  public <T, U> void write(String property1, T data1, PropertyTranslator<T> translator1, String property2, U data2, PropertyTranslator<U> translator2) {
    int propertyId1 = getOrCreatePropertyId(property1);
    if (propertyId1 == -1) {
      throw new IllegalStateException("no write property id is set");
    }
    int propertyId2 = getOrCreatePropertyId(property2);
    if (propertyId2 == -1) {
      throw new IllegalStateException("no write property id is set");
    }
    if (ParallelUtil.canRunInParallel(this.executorService)) {
      writeParallel(propertyId1, data1, translator1, propertyId2, data2, translator2);
    } else {
      writeSequential(propertyId1, data1, translator1, propertyId2, data2, translator2);
    } 
  }
  
  public void write(String property, IntFunction<WriteConsumer> createWriter) {
    int propertyId = getOrCreatePropertyId(property);
    if (propertyId == -1) {
      throw new IllegalStateException("no write property id is set");
    }
    WriteConsumer writer = createWriter.apply(propertyId);
    if (ParallelUtil.canRunInParallel(this.executorService)) {
      writeParallel(writer);
    } else {
      writeSequential(writer);
    } 
  }
  
  public void writeRelationships(String relationship, WriteConsumer writer) {
    int propertyId = getOrCreateRelationshipId(relationship);
    if (propertyId == -1) {
      throw new IllegalStateException("no write property id is set");
    }
    acceptInTransaction(stmt -> {
          Write write = stmt.dataWrite();
          writer.accept(write, propertyId);
        });
  }
  
  public void writeRelationshipAndProperty(String relationship, String property, PropertyWriteConsumer writer) {
    int relationshipId = getOrCreateRelationshipId(relationship);
    int propertyId = getOrCreatePropertyId(property);
    if (relationshipId == -1) {
      throw new IllegalStateException("no write property id is set");
    }
    acceptInTransaction(stmt -> writer.accept(stmt.dataWrite(), relationshipId, propertyId));
  }




  
  private <T> void writeSequential(int propertyId, T data, PropertyTranslator<T> translator) { writeSequential((ops, offset) -> doWrite(propertyId, data, translator, ops, offset)); }








  
  private <T, U> void writeSequential(int propertyId1, T data1, PropertyTranslator<T> translator1, int propertyId2, U data2, PropertyTranslator<U> translator2) { writeSequential((ops, offset) -> doWrite(propertyId1, data1, translator1, propertyId2, data2, translator2, ops, offset)); }













  
  private <T> void writeParallel(int propertyId, T data, PropertyTranslator<T> translator) { writeParallel((ops, offset) -> doWrite(propertyId, data, translator, ops, offset)); }








  
  private <T, U> void writeParallel(int propertyId1, T data1, PropertyTranslator<T> translator1, int propertyId2, U data2, PropertyTranslator<U> translator2) { writeParallel((ops, offset) -> doWrite(propertyId1, data1, translator1, propertyId2, data2, translator2, ops, offset)); }









  
  private void writeSequential(WriteConsumer writer) {
    acceptInTransaction(stmt -> {
          this.terminationFlag.assertRunning();
          long progress = 0L;
          Write ops = stmt.dataWrite(); long i;
          for (i = 0L; i < this.nodeCount; i++) {
            writer.accept(ops, i);
            progress++;
            if (progress % 10000L == 0L) {
              this.progressLogger.logProgress(progress, this.nodeCount);
              this.terminationFlag.assertRunning();
            } 
          } 
          this.progressLogger.logProgress(this.nodeCount, this.nodeCount);
        });
  }


  
  private void writeParallel(WriteConsumer writer) {
    long batchSize = ParallelUtil.adjustedBatchSize(this.nodeCount, this.concurrency, 10000L, 100000L);



    
    AtomicLong progress = new AtomicLong(0L);
    Collection<Runnable> runnables = LazyBatchCollection.of(this.nodeCount, batchSize, (start, len) -> ());


























    
    ParallelUtil.runWithConcurrency(this.concurrency, runnables, 2147483647L, 10L, TimeUnit.MICROSECONDS, this.terminationFlag, this.executorService);
  }













  
  private <T> void doWrite(int propertyId, T data, PropertyTranslator<T> trans, Write ops, long nodeId) throws KernelException {
    Value prop = trans.toProperty(propertyId, data, nodeId);
    if (prop != null) {
      ops.nodeSetProperty(this.toOriginalId
          .applyAsLong(nodeId), propertyId, prop);
    }
  }











  
  private <T, U> void doWrite(int propertyId1, T data1, PropertyTranslator<T> translator1, int propertyId2, U data2, PropertyTranslator<U> translator2, Write ops, long nodeId) throws KernelException {
    long originalNodeId = this.toOriginalId.applyAsLong(nodeId);
    Value prop1 = translator1.toProperty(propertyId1, data1, nodeId);
    if (prop1 != null) {
      ops.nodeSetProperty(originalNodeId, propertyId1, prop1);
    }
    Value prop2 = translator2.toProperty(propertyId2, data2, nodeId);
    if (prop2 != null) {
      ops.nodeSetProperty(originalNodeId, propertyId2, prop2);
    }
  }

  
  private int getOrCreatePropertyId(String propertyName) { return ((Integer)applyInTransaction(stmt -> Integer.valueOf(stmt
          .tokenWrite()
          .propertyKeyGetOrCreateForName(propertyName)))).intValue(); }


  
  private int getOrCreateRelationshipId(String propertyName) { return ((Integer)applyInTransaction(stmt -> Integer.valueOf(stmt
          .tokenWrite()
          .relationshipTypeGetOrCreateForName(propertyName)))).intValue(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\write\Exporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */