package org.neo4j.graphalgo.core.utils.paged.dss;

public interface DisjointSetStruct {
  void union(long paramLong1, long paramLong2);
  
  long setIdOf(long paramLong);
  
  @Deprecated
  boolean sameSet(long paramLong1, long paramLong2);
  
  long size();
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\dss\DisjointSetStruct.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */