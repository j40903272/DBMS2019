package org.neo4j.graphalgo.impl.similarity;



















public class RleDecoder
{
  private RleReader item1Reader;
  private RleReader item2Reader;
  
  public RleDecoder(int initialSize) {
    this.item1Reader = new RleReader(initialSize);
    this.item2Reader = new RleReader(initialSize);
  }
  
  public void reset(double[] item1, double[] item2) {
    this.item1Reader.reset(item1);
    this.item2Reader.reset(item2);
  }

  
  public double[] item1() { return this.item1Reader.read(); }


  
  public double[] item2() { return this.item2Reader.read(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\similarity\RleDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */