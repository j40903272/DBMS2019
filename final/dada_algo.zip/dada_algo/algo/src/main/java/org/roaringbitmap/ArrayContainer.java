package org.roaringbitmap;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.nio.ShortBuffer;
import java.util.Arrays;
import java.util.Iterator;
import org.roaringbitmap.buffer.MappeableArrayContainer;
import org.roaringbitmap.buffer.MappeableContainer;









public final class ArrayContainer
  extends Container
  implements Cloneable
{
  private static final int DEFAULT_INIT_SIZE = 4;
  private static final int ARRAY_LAZY_LOWERBOUND = 1024;
  static final int DEFAULT_MAX_SIZE = 4096;
  private static final long serialVersionUID = 1L;
  
  protected static int serializedSizeInBytes(int cardinality) { return cardinality * 2 + 2; }

  
  protected int cardinality = 0;


  
  short[] content;



  
  public ArrayContainer() { this(4); }


  
  public static ArrayContainer empty() { return new ArrayContainer(); }






  
  public ArrayContainer(int capacity) { this.content = new short[capacity]; }








  
  public ArrayContainer(int firstOfRun, int lastOfRun) {
    int valuesInRange = lastOfRun - firstOfRun;
    this.content = new short[valuesInRange];
    for (int i = 0; i < valuesInRange; i++) {
      this.content[i] = (short)(firstOfRun + i);
    }
    this.cardinality = valuesInRange;
  }






  
  public ArrayContainer(int newCard, short[] newContent) {
    this.cardinality = newCard;
    this.content = Arrays.copyOf(newContent, newCard);
  }





  
  public ArrayContainer(MappeableArrayContainer bc) {
    this.cardinality = bc.getCardinality();
    this.content = bc.toShortArray();
  }
  
  protected ArrayContainer(short[] newContent) {
    this.cardinality = newContent.length;
    this.content = newContent;
  }

  
  public Container add(int begin, int end) {
    if (end == begin) {
      return clone();
    }
    if (begin > end || end > 65536) {
      throw new IllegalArgumentException("Invalid range [" + begin + "," + end + ")");
    }
    
    int indexstart = Util.unsignedBinarySearch(this.content, 0, this.cardinality, (short)begin);
    if (indexstart < 0) {
      indexstart = -indexstart - 1;
    }
    int indexend = Util.unsignedBinarySearch(this.content, 0, this.cardinality, (short)(end - 1));
    if (indexend < 0) {
      indexend = -indexend - 1;
    } else {
      indexend++;
    } 
    int rangelength = end - begin;
    int newcardinality = indexstart + this.cardinality - indexend + rangelength;
    if (newcardinality > 4096) {
      BitmapContainer a = toBitmapContainer();
      return a.iadd(begin, end);
    } 
    ArrayContainer answer = new ArrayContainer(newcardinality, this.content);
    System.arraycopy(this.content, indexend, answer.content, indexstart + rangelength, this.cardinality - indexend);
    
    for (int k = 0; k < rangelength; k++) {
      answer.content[k + indexstart] = (short)(begin + k);
    }
    answer.cardinality = newcardinality;
    return answer;
  }






  
  public Container add(short x) {
    int loc = Util.unsignedBinarySearch(this.content, 0, this.cardinality, x);
    if (loc < 0) {

      
      if (this.cardinality >= 4096) {
        BitmapContainer a = toBitmapContainer();
        a.add(x);
        return a;
      } 
      if (this.cardinality >= this.content.length) {
        increaseCapacity();
      }


      
      System.arraycopy(this.content, -loc - 1, this.content, -loc, this.cardinality + loc + 1);
      this.content[-loc - 1] = x;
      this.cardinality++;
    } 
    return this;
  }
  
  private int advance(ShortIterator it) {
    if (it.hasNext()) {
      return Util.toIntUnsigned(it.next());
    }
    return -1;
  }


  
  public ArrayContainer and(ArrayContainer value2) {
    ArrayContainer value1 = this;
    int desiredCapacity = Math.min(value1.getCardinality(), value2.getCardinality());
    ArrayContainer answer = new ArrayContainer(desiredCapacity);
    answer.cardinality = Util.unsignedIntersect2by2(value1.content, value1.getCardinality(), value2.content, value2
        .getCardinality(), answer.content);
    return answer;
  }


  
  public Container and(BitmapContainer x) { return x.and(this); }




  
  public Container and(RunContainer x) { return x.and(this); }


  
  public int andCardinality(ArrayContainer value2) {
    return Util.unsignedLocalIntersect2by2Cardinality(this.content, this.cardinality, value2.content, value2
        .getCardinality());
  }


  
  public int andCardinality(BitmapContainer x) { return x.andCardinality(this); }




  
  public int andCardinality(RunContainer x) { return x.andCardinality(this); }


  
  public ArrayContainer andNot(ArrayContainer value2) {
    ArrayContainer value1 = this;
    int desiredCapacity = value1.getCardinality();
    ArrayContainer answer = new ArrayContainer(desiredCapacity);
    answer.cardinality = Util.unsignedDifference(value1.content, value1.getCardinality(), value2.content, value2
        .getCardinality(), answer.content);
    return answer;
  }

  
  public ArrayContainer andNot(BitmapContainer value2) {
    ArrayContainer answer = new ArrayContainer(this.content.length);
    int pos = 0;
    for (int k = 0; k < this.cardinality; k++) {
      short val = this.content[k];
      answer.content[pos] = val;
      pos = (int)(pos + 1L - value2.bitValue(val));
    } 
    answer.cardinality = pos;
    return answer;
  }

  
  public ArrayContainer andNot(RunContainer x) {
    if (x.numberOfRuns() == 0)
      return clone(); 
    if (x.isFull()) {
      return empty();
    }
    int write = 0;
    int read = 0;
    ArrayContainer answer = new ArrayContainer(this.cardinality);
    for (int i = 0; i < x.numberOfRuns() && read < this.cardinality; i++) {
      int runStart = Util.toIntUnsigned(x.getValue(i));
      int runEnd = runStart + Util.toIntUnsigned(x.getLength(i));
      if (Util.toIntUnsigned(this.content[read]) <= runEnd) {

        
        int firstInRun = Util.iterateUntil(this.content, read, this.cardinality, runStart);
        int toWrite = firstInRun - read;
        System.arraycopy(this.content, read, answer.content, write, toWrite);
        write += toWrite;
        
        read = Util.iterateUntil(this.content, firstInRun, this.cardinality, runEnd + 1);
      } 
    }  System.arraycopy(this.content, read, answer.content, write, this.cardinality - read);
    write += this.cardinality - read;
    answer.cardinality = write;
    return answer;
  }


  
  public void clear() { this.cardinality = 0; }



  
  public ArrayContainer clone() { return new ArrayContainer(this.cardinality, this.content); }



  
  public boolean isEmpty() { return (this.cardinality == 0); }



  
  public boolean contains(short x) { return (Util.unsignedBinarySearch(this.content, 0, this.cardinality, x) >= 0); }


  
  public boolean contains(int minimum, int supremum) {
    int maximum = supremum - 1;
    int start = Util.advanceUntil(this.content, -1, this.cardinality, (short)minimum);
    int end = Util.advanceUntil(this.content, start - 1, this.cardinality, (short)maximum);
    return (start < this.cardinality && end < this.cardinality && end - start == maximum - minimum && this.content[start] == (short)minimum && this.content[end] == (short)maximum);
  }






  
  protected boolean contains(RunContainer runContainer) {
    if (runContainer.getCardinality() > this.cardinality) {
      return false;
    }
    
    for (int i = 0; i < runContainer.numberOfRuns(); i++) {
      int start = Util.toIntUnsigned(runContainer.getValue(i));
      int length = Util.toIntUnsigned(runContainer.getLength(i));
      if (!contains(start, start + length)) {
        return false;
      }
    } 
    return true;
  }

  
  protected boolean contains(ArrayContainer arrayContainer) {
    if (this.cardinality < arrayContainer.cardinality) {
      return false;
    }
    int i1 = 0, i2 = 0;
    while (i1 < this.cardinality && i2 < arrayContainer.cardinality) {
      if (this.content[i1] == arrayContainer.content[i2]) {
        i1++;
        i2++; continue;
      }  if (Util.compareUnsigned(this.content[i1], arrayContainer.content[i2]) < 0) {
        i1++; continue;
      } 
      return false;
    } 
    
    return (i2 == arrayContainer.cardinality);
  }


  
  protected boolean contains(BitmapContainer bitmapContainer) { return false; }


  
  public void deserialize(DataInput in) throws IOException {
    this.cardinality = 0xFFFF & Short.reverseBytes(in.readShort());
    if (this.content.length < this.cardinality) {
      this.content = new short[this.cardinality];
    }
    for (int k = 0; k < this.cardinality; k++) {
      this.content[k] = Short.reverseBytes(in.readShort());
    }
  }

  
  private void emit(short val) {
    if (this.cardinality == this.content.length) {
      increaseCapacity(true);
    }
    this.content[this.cardinality++] = val;
  }


  
  public boolean equals(Object o) {
    if (o instanceof ArrayContainer) {
      ArrayContainer srb = (ArrayContainer)o;
      return ArraysShim.equals(this.content, 0, this.cardinality, srb.content, 0, srb.cardinality);
    }  if (o instanceof RunContainer) {
      return o.equals(this);
    }
    return false;
  }

  
  public void fillLeastSignificant16bits(int[] x, int i, int mask) {
    for (int k = 0; k < this.cardinality; k++) {
      x[k + i] = Util.toIntUnsigned(this.content[k]) | mask;
    }
  }


  
  public Container flip(short x) {
    int loc = Util.unsignedBinarySearch(this.content, 0, this.cardinality, x);
    if (loc < 0) {

      
      if (this.cardinality >= 4096) {
        BitmapContainer a = toBitmapContainer();
        a.add(x);
        return a;
      } 
      if (this.cardinality >= this.content.length) {
        increaseCapacity();
      }


      
      System.arraycopy(this.content, -loc - 1, this.content, -loc, this.cardinality + loc + 1);
      this.content[-loc - 1] = x;
      this.cardinality++;
    } else {
      System.arraycopy(this.content, loc + 1, this.content, loc, this.cardinality - loc - 1);
      this.cardinality--;
    } 
    return this;
  }


  
  protected int getArraySizeInBytes() { return this.cardinality * 2; }



  
  public int getCardinality() { return this.cardinality; }



  
  public ShortIterator getReverseShortIterator() { return new ReverseArrayContainerShortIterator(this); }



  
  public PeekableShortIterator getShortIterator() { return new ArrayContainerShortIterator(this); }




  
  public PeekableShortRankIterator getShortRankIterator() { return new ArrayContainerShortIterator(this); }



  
  public ContainerBatchIterator getBatchIterator() { return new ArrayBatchIterator(this); }




  
  public int getSizeInBytes() { return this.cardinality * 2 + 4; }


  
  public int hashCode() {
    int hash = 0;
    for (int k = 0; k < this.cardinality; k++) {
      hash += 31 * hash + this.content[k];
    }
    return hash;
  }


  
  public Container iadd(int begin, int end) {
    if (end == begin) {
      return this;
    }
    if (begin > end || end > 65536) {
      throw new IllegalArgumentException("Invalid range [" + begin + "," + end + ")");
    }
    int indexstart = Util.unsignedBinarySearch(this.content, 0, this.cardinality, (short)begin);
    if (indexstart < 0) {
      indexstart = -indexstart - 1;
    }
    int indexend = Util.unsignedBinarySearch(this.content, 0, this.cardinality, (short)(end - 1));
    if (indexend < 0) {
      indexend = -indexend - 1;
    } else {
      indexend++;
    } 
    int rangelength = end - begin;
    int newcardinality = indexstart + this.cardinality - indexend + rangelength;
    if (newcardinality > 4096) {
      BitmapContainer a = toBitmapContainer();
      return a.iadd(begin, end);
    } 





















    
    if (newcardinality >= this.content.length) {
      short[] destination = new short[calculateCapacity(newcardinality)];
      
      System.arraycopy(this.content, 0, destination, 0, indexstart);
      
      for (int k = 0; k < rangelength; k++) {
        destination[k + indexstart] = (short)(begin + k);
      }



      
      System.arraycopy(this.content, indexend, destination, indexstart + rangelength, this.cardinality - indexend);
      
      this.content = destination;
    } else {
      
      System.arraycopy(this.content, indexend, this.content, indexstart + rangelength, this.cardinality - indexend);
      for (int k = 0; k < rangelength; k++) {
        this.content[k + indexstart] = (short)(begin + k);
      }
    } 
    this.cardinality = newcardinality;
    return this;
  }


  
  public ArrayContainer iand(ArrayContainer value2) {
    ArrayContainer value1 = this;
    value1.cardinality = Util.unsignedIntersect2by2(value1.content, value1.getCardinality(), value2.content, value2
        .getCardinality(), value1.content);
    return this;
  }

  
  public Container iand(BitmapContainer value2) {
    int pos = 0;
    for (int k = 0; k < this.cardinality; k++) {
      short v = this.content[k];
      this.content[pos] = v;
      pos = (int)(pos + value2.bitValue(v));
    } 
    this.cardinality = pos;
    return this;
  }



  
  public Container iand(RunContainer x) { return x.and(this); }



  
  public ArrayContainer iandNot(ArrayContainer value2) {
    this.cardinality = Util.unsignedDifference(this.content, getCardinality(), value2.content, value2
        .getCardinality(), this.content);
    return this;
  }

  
  public ArrayContainer iandNot(BitmapContainer value2) {
    int pos = 0;
    for (int k = 0; k < this.cardinality; k++) {
      short v = this.content[k];
      this.content[pos] = v;
      pos = (int)(pos + 1L - value2.bitValue(v));
    } 
    this.cardinality = pos;
    return this;
  }




  
  public Container iandNot(RunContainer x) { return andNot(x); }


  
  private void increaseCapacity() { increaseCapacity(false); }







  
  private void increaseCapacity(boolean allowIllegalSize) {
    int newCapacity = (this.content.length == 0) ? 4 : ((this.content.length < 64) ? (this.content.length * 2) : ((this.content.length < 1067) ? (this.content.length * 3 / 2) : (this.content.length * 5 / 4)));
    
    if (newCapacity > 4096 && !allowIllegalSize) {
      newCapacity = 4096;
    }
    
    if (newCapacity > 3840 && !allowIllegalSize)
    {
      newCapacity = 4096;
    }
    this.content = Arrays.copyOf(this.content, newCapacity);
  }




  
  private int calculateCapacity(int min) {
    int newCapacity = (this.content.length == 0) ? 4 : ((this.content.length < 64) ? (this.content.length * 2) : ((this.content.length < 1024) ? (this.content.length * 3 / 2) : (this.content.length * 5 / 4)));
    if (newCapacity < min) {
      newCapacity = min;
    }
    
    if (newCapacity > 4096) {
      newCapacity = 4096;
    }
    
    if (newCapacity > 3840) {
      newCapacity = 4096;
    }
    return newCapacity;
  }



  
  public Container inot(int firstOfRange, int lastOfRange) {
    int startIndex = Util.unsignedBinarySearch(this.content, 0, this.cardinality, (short)firstOfRange);
    if (startIndex < 0) {
      startIndex = -startIndex - 1;
    }
    int lastIndex = Util.unsignedBinarySearch(this.content, 0, this.cardinality, (short)(lastOfRange - 1));
    if (lastIndex < 0) {
      lastIndex = -lastIndex - 1 - 1;
    }
    int currentValuesInRange = lastIndex - startIndex + 1;
    int spanToBeFlipped = lastOfRange - firstOfRange;
    int newValuesInRange = spanToBeFlipped - currentValuesInRange;
    short[] buffer = new short[newValuesInRange];
    int cardinalityChange = newValuesInRange - currentValuesInRange;
    int newCardinality = this.cardinality + cardinalityChange;
    
    if (cardinalityChange > 0) {
      if (newCardinality > this.content.length) {
        
        if (newCardinality > 4096) {
          return toBitmapContainer().inot(firstOfRange, lastOfRange);
        }
        this.content = Arrays.copyOf(this.content, newCardinality);
      } 
      
      System.arraycopy(this.content, lastIndex + 1, this.content, lastIndex + 1 + cardinalityChange, this.cardinality - 1 - lastIndex);
      
      negateRange(buffer, startIndex, lastIndex, firstOfRange, lastOfRange);
    } else {
      negateRange(buffer, startIndex, lastIndex, firstOfRange, lastOfRange);
      if (cardinalityChange < 0)
      {
        
        System.arraycopy(this.content, startIndex + newValuesInRange - cardinalityChange, this.content, startIndex + newValuesInRange, newCardinality - startIndex + newValuesInRange);
      }
    } 
    
    this.cardinality = newCardinality;
    return this;
  }

  
  public boolean intersects(ArrayContainer value2) {
    ArrayContainer value1 = this;
    return Util.unsignedIntersects(value1.content, value1.getCardinality(), value2.content, value2
        .getCardinality());
  }



  
  public boolean intersects(BitmapContainer x) { return x.intersects(this); }



  
  public boolean intersects(RunContainer x) { return x.intersects(this); }


  
  public boolean intersects(int minimum, int supremum) {
    int pos = Util.unsignedBinarySearch(this.content, 0, this.cardinality, (short)minimum);
    int index = (pos >= 0) ? pos : (-pos - 1);
    return (index < this.cardinality && Util.toIntUnsigned(this.content[index]) < supremum);
  }


  
  public Container ior(ArrayContainer value2) {
    int totalCardinality = getCardinality() + value2.getCardinality();
    if (totalCardinality > 4096) {
      BitmapContainer bc = new BitmapContainer();
      for (int k = 0; k < value2.cardinality; k++) {
        short v = value2.content[k];
        int i = Util.toIntUnsigned(v) >>> 6;
        bc.bitmap[i] = bc.bitmap[i] | 1L << v;
      } 
      for (int k = 0; k < this.cardinality; k++) {
        short v = this.content[k];
        int i = Util.toIntUnsigned(v) >>> 6;
        bc.bitmap[i] = bc.bitmap[i] | 1L << v;
      } 
      bc.cardinality = 0;
      for (long k : bc.bitmap) {
        bc.cardinality += Long.bitCount(k);
      }
      if (bc.cardinality <= 4096)
        return bc.toArrayContainer(); 
      if (bc.isFull()) {
        return RunContainer.full();
      }
      return bc;
    } 
    if (totalCardinality >= this.content.length) {
      int newCapacity = calculateCapacity(totalCardinality);
      short[] destination = new short[newCapacity];
      this
        .cardinality = Util.unsignedUnion2by2(this.content, 0, this.cardinality, value2.content, 0, value2.cardinality, destination);
      
      this.content = destination;
    } else {
      System.arraycopy(this.content, 0, this.content, value2.cardinality, this.cardinality);
      this
        .cardinality = Util.unsignedUnion2by2(this.content, value2.cardinality, this.cardinality, value2.content, 0, value2.cardinality, this.content);
    } 
    
    return this;
  }


  
  public Container ior(BitmapContainer x) { return x.or(this); }




  
  public Container ior(RunContainer x) { return x.or(this); }


  
  public Container iremove(int begin, int end) {
    if (end == begin) {
      return this;
    }
    if (begin > end || end > 65536) {
      throw new IllegalArgumentException("Invalid range [" + begin + "," + end + ")");
    }
    int indexstart = Util.unsignedBinarySearch(this.content, 0, this.cardinality, (short)begin);
    if (indexstart < 0) {
      indexstart = -indexstart - 1;
    }
    int indexend = Util.unsignedBinarySearch(this.content, 0, this.cardinality, (short)(end - 1));
    if (indexend < 0) {
      indexend = -indexend - 1;
    } else {
      indexend++;
    } 
    int rangelength = indexend - indexstart;
    System.arraycopy(this.content, indexstart + rangelength, this.content, indexstart, this.cardinality - indexstart - rangelength);
    
    this.cardinality -= rangelength;
    return this;
  }

  
  public Iterator<Short> iterator() {
    return new Iterator<Short>() {
        short pos = 0;


        
        public boolean hasNext() { return (this.pos < ArrayContainer.this.cardinality); }



        
        public Short next() { this.pos = (short)(this.pos + 1); return Short.valueOf(ArrayContainer.this.content[this.pos]); }


        
        public void remove() {
          ArrayContainer.this.removeAtIndex(this.pos - 1);
          this.pos = (short)(this.pos - 1);
        }
      };
  }


  
  public Container ixor(ArrayContainer value2) { return xor(value2); }



  
  public Container ixor(BitmapContainer x) { return x.xor(this); }





  
  public Container ixor(RunContainer x) { return x.xor(this); }



  
  public Container limit(int maxcardinality) {
    if (maxcardinality < getCardinality()) {
      return new ArrayContainer(maxcardinality, this.content);
    }
    return clone();
  }

  
  protected void loadData(BitmapContainer bitmapContainer) {
    this.cardinality = bitmapContainer.cardinality;
    bitmapContainer.fillArray(this.content);
  }




  
  private void negateRange(short[] buffer, int startIndex, int lastIndex, int startRange, int lastRange) {
    int outPos = 0;
    int inPos = startIndex;


    
    int valInRange = startRange;
    for (; valInRange < lastRange && inPos <= lastIndex; valInRange++) {
      if ((short)valInRange != this.content[inPos]) {
        buffer[outPos++] = (short)valInRange;
      } else {
        inPos++;
      } 
    } 


    
    for (; valInRange < lastRange; valInRange++) {
      buffer[outPos++] = (short)valInRange;
    }
    
    if (outPos != buffer.length) {
      throw new RuntimeException("negateRange: outPos " + outPos + " whereas buffer.length=" + buffer.length);
    }

    
    int i = startIndex;
    for (short item : buffer) {
      this.content[i++] = item;
    }
  }



  
  public Container not(int firstOfRange, int lastOfRange) {
    if (firstOfRange >= lastOfRange) {
      return clone();
    }

    
    int startIndex = Util.unsignedBinarySearch(this.content, 0, this.cardinality, (short)firstOfRange);
    if (startIndex < 0) {
      startIndex = -startIndex - 1;
    }
    int lastIndex = Util.unsignedBinarySearch(this.content, 0, this.cardinality, (short)(lastOfRange - 1));
    if (lastIndex < 0) {
      lastIndex = -lastIndex - 2;
    }
    int currentValuesInRange = lastIndex - startIndex + 1;
    int spanToBeFlipped = lastOfRange - firstOfRange;
    int newValuesInRange = spanToBeFlipped - currentValuesInRange;
    int cardinalityChange = newValuesInRange - currentValuesInRange;
    int newCardinality = this.cardinality + cardinalityChange;
    
    if (newCardinality > 4096) {
      return toBitmapContainer().not(firstOfRange, lastOfRange);
    }
    
    ArrayContainer answer = new ArrayContainer(newCardinality);

    
    System.arraycopy(this.content, 0, answer.content, 0, startIndex);
    
    int outPos = startIndex;
    int inPos = startIndex;
    
    int valInRange = firstOfRange;
    for (; valInRange < lastOfRange && inPos <= lastIndex; valInRange++) {
      if ((short)valInRange != this.content[inPos]) {
        answer.content[outPos++] = (short)valInRange;
      } else {
        inPos++;
      } 
    } 
    
    for (; valInRange < lastOfRange; valInRange++) {
      answer.content[outPos++] = (short)valInRange;
    }

    
    for (int i = lastIndex + 1; i < this.cardinality; i++) {
      answer.content[outPos++] = this.content[i];
    }
    answer.cardinality = newCardinality;
    return answer;
  }

  
  int numberOfRuns() {
    if (this.cardinality == 0) {
      return 0;
    }
    int numRuns = 1;
    int oldv = Util.toIntUnsigned(this.content[0]);
    for (int i = 1; i < this.cardinality; i++) {
      int newv = Util.toIntUnsigned(this.content[i]);
      if (oldv + 1 != newv) {
        numRuns++;
      }
      oldv = newv;
    } 
    return numRuns;
  }

  
  public Container or(ArrayContainer value2) {
    ArrayContainer value1 = this;
    int totalCardinality = value1.getCardinality() + value2.getCardinality();
    if (totalCardinality > 4096) {
      BitmapContainer bc = new BitmapContainer();
      for (int k = 0; k < value2.cardinality; k++) {
        short v = value2.content[k];
        int i = Util.toIntUnsigned(v) >>> 6;
        bc.bitmap[i] = bc.bitmap[i] | 1L << v;
      } 
      for (int k = 0; k < this.cardinality; k++) {
        short v = this.content[k];
        int i = Util.toIntUnsigned(v) >>> 6;
        bc.bitmap[i] = bc.bitmap[i] | 1L << v;
      } 
      bc.cardinality = 0;
      for (long k : bc.bitmap) {
        bc.cardinality += Long.bitCount(k);
      }
      if (bc.cardinality <= 4096)
        return bc.toArrayContainer(); 
      if (bc.isFull()) {
        return RunContainer.full();
      }
      return bc;
    } 
    ArrayContainer answer = new ArrayContainer(totalCardinality);
    answer
      .cardinality = Util.unsignedUnion2by2(value1.content, 0, value1
        .getCardinality(), value2.content, 0, value2
        .getCardinality(), answer.content);

    
    return answer;
  }


  
  public Container or(BitmapContainer x) { return x.or(this); }



  
  public Container or(RunContainer x) { return x.or(this); }


  
  protected Container or(ShortIterator it) { return or(it, false); }




  
  private Container or(ShortIterator it, boolean exclusive) {
    ArrayContainer ac = new ArrayContainer();
    int myItPos = 0;
    ac.cardinality = 0;
    
    int myHead = (myItPos == this.cardinality) ? -1 : Util.toIntUnsigned(this.content[myItPos++]);
    int hisHead = advance(it);
    
    while (myHead != -1 && hisHead != -1) {
      if (myHead < hisHead) {
        ac.emit((short)myHead);
        myHead = (myItPos == this.cardinality) ? -1 : Util.toIntUnsigned(this.content[myItPos++]); continue;
      }  if (myHead > hisHead) {
        ac.emit((short)hisHead);
        hisHead = advance(it); continue;
      } 
      if (!exclusive) {
        ac.emit((short)hisHead);
      }
      hisHead = advance(it);
      myHead = (myItPos == this.cardinality) ? -1 : Util.toIntUnsigned(this.content[myItPos++]);
    } 

    
    while (myHead != -1) {
      ac.emit((short)myHead);
      myHead = (myItPos == this.cardinality) ? -1 : Util.toIntUnsigned(this.content[myItPos++]);
    } 
    
    while (hisHead != -1) {
      ac.emit((short)hisHead);
      hisHead = advance(it);
    } 
    
    if (ac.cardinality > 4096) {
      return ac.toBitmapContainer();
    }
    return ac;
  }


  
  public int rank(short lowbits) {
    int answer = Util.unsignedBinarySearch(this.content, 0, this.cardinality, lowbits);
    if (answer >= 0) {
      return answer + 1;
    }
    return -answer - 1;
  }



  
  public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException { deserialize(in); }


  
  public Container remove(int begin, int end) {
    if (end == begin) {
      return clone();
    }
    if (begin > end || end > 65536) {
      throw new IllegalArgumentException("Invalid range [" + begin + "," + end + ")");
    }
    int indexstart = Util.unsignedBinarySearch(this.content, 0, this.cardinality, (short)begin);
    if (indexstart < 0) {
      indexstart = -indexstart - 1;
    }
    int indexend = Util.unsignedBinarySearch(this.content, 0, this.cardinality, (short)(end - 1));
    if (indexend < 0) {
      indexend = -indexend - 1;
    } else {
      indexend++;
    } 
    int rangelength = indexend - indexstart;
    ArrayContainer answer = clone();
    System.arraycopy(this.content, indexstart + rangelength, answer.content, indexstart, this.cardinality - indexstart - rangelength);
    
    this.cardinality -= rangelength;
    return answer;
  }
  
  protected void removeAtIndex(int loc) {
    System.arraycopy(this.content, loc + 1, this.content, loc, this.cardinality - loc - 1);
    this.cardinality--;
  }


  
  public Container remove(short x) {
    int loc = Util.unsignedBinarySearch(this.content, 0, this.cardinality, x);
    if (loc >= 0) {
      removeAtIndex(loc);
    }
    return this;
  }


  
  public Container repairAfterLazy() { return this; }






  
  public Container runOptimize() {
    int numRuns = numberOfRuns();
    int sizeAsRunContainer = RunContainer.serializedSizeInBytes(numRuns);
    if (getArraySizeInBytes() > sizeAsRunContainer) {
      return new RunContainer(this, numRuns);
    }

    
    return this;
  }



  
  public short select(int j) { return this.content[j]; }


  
  public void serialize(DataOutput out) throws IOException {
    out.writeShort(Short.reverseBytes((short)this.cardinality));
    
    for (int k = 0; k < this.cardinality; k++) {
      out.writeShort(Short.reverseBytes(this.content[k]));
    }
  }


  
  public int serializedSizeInBytes() { return serializedSizeInBytes(this.cardinality); }







  
  public BitmapContainer toBitmapContainer() {
    BitmapContainer bc = new BitmapContainer();
    bc.loadData(this);
    return bc;
  }

  
  public int nextValue(short fromValue) {
    int index = Util.advanceUntil(this.content, -1, this.cardinality, fromValue);
    if (index == this.cardinality) {
      return (fromValue == this.content[this.cardinality - 1]) ? Util.toIntUnsigned(fromValue) : -1;
    }
    return Util.toIntUnsigned(this.content[index]);
  }

  
  public int previousValue(short fromValue) {
    int index = Util.advanceUntil(this.content, -1, this.cardinality, fromValue);
    if (index != this.cardinality && this.content[index] == fromValue) {
      return Util.toIntUnsigned(this.content[index]);
    }
    return (index == 0) ? -1 : Util.toIntUnsigned(this.content[index - 1]);
  }

  
  public int nextAbsentValue(short fromValue) {
    int index = Util.advanceUntil(this.content, -1, this.cardinality, fromValue);
    int value = Util.toIntUnsigned(fromValue);
    if (index >= this.cardinality) {
      return value;
    }
    if (index == this.cardinality - 1) {
      return (fromValue == this.content[this.cardinality - 1]) ? (value + 1) : value;
    }
    if (this.content[index] != fromValue) {
      return value;
    }
    if (this.content[index + 1] > fromValue + 1) {
      return value + 1;
    }
    
    int low = index;
    int high = this.cardinality;
    
    while (low + 1 < high) {
      int mid = high + low >>> 1;
      if (mid - index < Util.toIntUnsigned(this.content[mid]) - value) {
        high = mid; continue;
      } 
      low = mid;
    } 

    
    if (low == this.cardinality - 1) {
      return Util.toIntUnsigned(this.content[this.cardinality - 1]) + 1;
    }
    
    assert Util.toIntUnsigned(this.content[low]) + 1 < Util.toIntUnsigned(this.content[high]);
    assert Util.toIntUnsigned(this.content[low]) == value + low - index;
    return Util.toIntUnsigned(this.content[low]) + 1;
  }

  
  public int previousAbsentValue(short fromValue) {
    int index = Util.advanceUntil(this.content, -1, this.cardinality, fromValue);
    int value = Util.toIntUnsigned(fromValue);
    if (index >= this.cardinality) {
      return value;
    }
    if (index == 0) {
      return (fromValue == this.content[0]) ? (value - 1) : value;
    }
    if (this.content[index] != fromValue) {
      return value;
    }
    if (this.content[index - 1] < fromValue - 1) {
      return value - 1;
    }
    
    int low = -1;
    int high = index;


    
    while (low + 1 < high) {
      int mid = high + low >>> 1;
      if (index - mid < value - Util.toIntUnsigned(this.content[mid])) {
        low = mid; continue;
      } 
      high = mid;
    } 

    
    if (high == 0) {
      return Util.toIntUnsigned(this.content[0]) - 1;
    }
    
    assert Util.toIntUnsigned(this.content[low]) + 1 < Util.toIntUnsigned(this.content[high]);
    assert Util.toIntUnsigned(this.content[high]) == value - index - high;
    return Util.toIntUnsigned(this.content[high]) - 1;
  }

  
  public int first() {
    assertNonEmpty((this.cardinality == 0));
    return Util.toIntUnsigned(this.content[0]);
  }

  
  public int last() {
    assertNonEmpty((this.cardinality == 0));
    return Util.toIntUnsigned(this.content[this.cardinality - 1]);
  }


  
  public MappeableContainer toMappeableContainer() { return (MappeableContainer)new MappeableArrayContainer(this); }







  
  public ShortBuffer toShortBuffer() {
    ShortBuffer sb = ShortBuffer.allocate(this.cardinality);
    sb.put(this.content, 0, this.cardinality);
    return sb;
  }

  
  public String toString() {
    if (this.cardinality == 0) {
      return "{}";
    }
    StringBuilder sb = new StringBuilder();
    sb.append("{");
    for (int i = 0; i < this.cardinality - 1; i++) {
      sb.append(Util.toIntUnsigned(this.content[i]));
      sb.append(",");
    } 
    sb.append(Util.toIntUnsigned(this.content[this.cardinality - 1]));
    sb.append("}");
    return sb.toString();
  }

  
  public void trim() {
    if (this.content.length == this.cardinality) {
      return;
    }
    this.content = Arrays.copyOf(this.content, this.cardinality);
  }


  
  protected void writeArray(DataOutput out) throws IOException {
    for (int k = 0; k < this.cardinality; k++) {
      short v = this.content[k];
      out.writeShort(Short.reverseBytes(v));
    } 
  }


  
  public void writeExternal(ObjectOutput out) throws IOException { serialize(out); }


  
  public Container xor(ArrayContainer value2) {
    ArrayContainer value1 = this;
    int totalCardinality = value1.getCardinality() + value2.getCardinality();
    if (totalCardinality > 4096) {
      BitmapContainer bc = new BitmapContainer();
      for (int k = 0; k < value2.cardinality; k++) {
        short v = value2.content[k];
        int i = Util.toIntUnsigned(v) >>> 6;
        bc.bitmap[i] = bc.bitmap[i] ^ 1L << v;
      } 
      for (int k = 0; k < this.cardinality; k++) {
        short v = this.content[k];
        int i = Util.toIntUnsigned(v) >>> 6;
        bc.bitmap[i] = bc.bitmap[i] ^ 1L << v;
      } 
      bc.cardinality = 0;
      for (long k : bc.bitmap) {
        bc.cardinality += Long.bitCount(k);
      }
      if (bc.cardinality <= 4096) {
        return bc.toArrayContainer();
      }
      return bc;
    } 
    ArrayContainer answer = new ArrayContainer(totalCardinality);
    answer.cardinality = Util.unsignedExclusiveUnion2by2(value1.content, value1.getCardinality(), value2.content, value2
        .getCardinality(), answer.content);
    return answer;
  }


  
  public Container xor(BitmapContainer x) { return x.xor(this); }



  
  public Container xor(RunContainer x) { return x.xor(this); }



  
  protected Container xor(ShortIterator it) { return or(it, true); }


  
  public void forEach(short msb, IntConsumer ic) {
    int high = msb << 16;
    for (int k = 0; k < this.cardinality; k++) {
      ic.accept(this.content[k] & 0xFFFF | high);
    }
  }
  
  protected Container lazyor(ArrayContainer value2) {
    ArrayContainer value1 = this;
    int totalCardinality = value1.getCardinality() + value2.getCardinality();
    if (totalCardinality > 1024) {
      BitmapContainer bc = new BitmapContainer();
      for (int k = 0; k < value2.cardinality; k++) {
        short v = value2.content[k];
        int i = Util.toIntUnsigned(v) >>> 6;
        bc.bitmap[i] = bc.bitmap[i] | 1L << v;
      } 
      for (int k = 0; k < this.cardinality; k++) {
        short v = this.content[k];
        int i = Util.toIntUnsigned(v) >>> 6;
        bc.bitmap[i] = bc.bitmap[i] | 1L << v;
      } 
      bc.cardinality = -1;
      return bc;
    } 
    ArrayContainer answer = new ArrayContainer(totalCardinality);
    answer
      .cardinality = Util.unsignedUnion2by2(value1.content, 0, value1
        .getCardinality(), value2.content, 0, value2
        .getCardinality(), answer.content);

    
    return answer;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\roaringbitmap\ArrayContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */