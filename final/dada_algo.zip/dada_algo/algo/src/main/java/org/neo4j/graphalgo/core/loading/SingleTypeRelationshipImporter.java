package org.neo4j.graphalgo.core.loading;

import java.util.concurrent.atomic.LongAdder;
import java.util.stream.Stream;
import org.neo4j.graphalgo.RelationshipTypeMapping;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.internal.kernel.api.CursorFactory;
import org.neo4j.internal.kernel.api.Read;

























final class SingleTypeRelationshipImporter
{
  private final RelationshipImporter.Imports imports;
  private final RelationshipImporter.PropertyReader propertyReader;
  private final RelationshipsBatchBuffer buffer;
  
  private SingleTypeRelationshipImporter(RelationshipImporter.Imports imports, RelationshipImporter.PropertyReader propertyReader, RelationshipsBatchBuffer buffer) {
    this.imports = imports;
    this.propertyReader = propertyReader;
    this.buffer = buffer;
  }

  
  RelationshipsBatchBuffer buffer() { return this.buffer; }


  
  long importRels() { return this.imports.importRels(this.buffer, this.propertyReader); }

  
  static class Builder
  {
    private final RelationshipTypeMapping mapping;
    
    private final RelationshipImporter importer;
    
    private final LongAdder relationshipCounter;

    
    Builder(RelationshipTypeMapping mapping, RelationshipImporter importer, LongAdder relationshipCounter) {
      this.mapping = mapping;
      this.importer = importer;
      this.relationshipCounter = relationshipCounter;
    }

    
    RelationshipTypeMapping mapping() { return this.mapping; }


    
    LongAdder relationshipCounter() { return this.relationshipCounter; }





    
    WithImporter loadImporter(boolean loadAsUndirected, boolean loadOutgoing, boolean loadIncoming, boolean loadWeights) {
      RelationshipImporter.Imports imports = this.importer.imports(loadAsUndirected, loadOutgoing, loadIncoming, loadWeights);



      
      if (imports == null) {
        return null;
      }
      return new WithImporter(imports);
    }
    
    class WithImporter
    {
      private final RelationshipImporter.Imports imports;
      
      WithImporter(RelationshipImporter.Imports imports) { this.imports = imports; }


      
      Stream<Runnable> flushTasks() { return SingleTypeRelationshipImporter.Builder.this.importer.flushTasks().stream(); }

      
      SingleTypeRelationshipImporter withBuffer(IdMapping idMap, int bulkSize, Read read, CursorFactory cursors) {
        RelationshipsBatchBuffer buffer = new RelationshipsBatchBuffer(idMap, SingleTypeRelationshipImporter.Builder.this.mapping.typeId(), bulkSize);
        RelationshipImporter.PropertyReader propertyReader = SingleTypeRelationshipImporter.Builder.this.importer.storeBackedPropertiesReader(cursors, read);
        return new SingleTypeRelationshipImporter(this.imports, propertyReader, buffer, null);
      }
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\SingleTypeRelationshipImporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */