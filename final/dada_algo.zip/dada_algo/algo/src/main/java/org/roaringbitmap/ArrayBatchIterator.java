package org.roaringbitmap;


public class ArrayBatchIterator
  implements ContainerBatchIterator
{
  private int index = 0;
  
  private final ArrayContainer array;
  
  public ArrayBatchIterator(ArrayContainer array) { this.array = array; }


  
  public int next(int key, int[] buffer) {
    int consumed = 0;
    short[] data = this.array.content;
    while (consumed < buffer.length && this.index < this.array.getCardinality()) {
      buffer[consumed++] = key + Util.toIntUnsigned(data[this.index++]);
    }
    return consumed;
  }


  
  public boolean hasNext() { return (this.index < this.array.getCardinality()); }


  
  public ContainerBatchIterator clone() {
    try {
      return (ContainerBatchIterator)super.clone();
    } catch (CloneNotSupportedException e) {
      
      throw new IllegalStateException(e);
    } 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\roaringbitmap\ArrayBatchIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */