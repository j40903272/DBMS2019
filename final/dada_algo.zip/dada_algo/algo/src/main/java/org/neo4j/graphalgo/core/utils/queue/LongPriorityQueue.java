package org.neo4j.graphalgo.core.utils.queue;

import com.carrotsearch.hppc.LongDoubleScatterMap;
import java.util.NoSuchElementException;
import org.apache.lucene.util.ArrayUtil;
import org.neo4j.collection.primitive.PrimitiveLongIterable;
import org.neo4j.collection.primitive.PrimitiveLongIterator;





























public abstract class LongPriorityQueue
  implements PrimitiveLongIterable
{
  private static final int DEFAULT_CAPACITY = 14;
  private int size = 0;
  
  private long[] heap;
  
  protected final LongDoubleScatterMap costs;
  
  public LongPriorityQueue() { this(14); }


  
  public LongPriorityQueue(int initialCapacity) {
    if (0 == initialCapacity) {
      
      heapSize = 2;
    }
    else {
      
      heapSize = initialCapacity + 1;
    } 
    this.heap = new long[ArrayUtil.oversize(heapSize, 4)];
    this.costs = new LongDoubleScatterMap(heapSize);
  }







  
  public long add(long element, double cost) {
    this.size++;
    ensureCapacityForInsert();
    this.heap[this.size] = element;
    this.costs.put(element, cost);
    upHeap(this.size);
    return this.heap[1];
  }

  
  public double getCost(long element) { return this.costs.get(element); }








  
  public long top() { return this.heap[1]; }


  
  public double topCost() { return this.costs.get(top()); }






  
  public long pop() {
    if (this.size > 0) {
      long result = this.heap[1];
      this.heap[1] = this.heap[this.size];
      this.size--;
      downHeap(1);
      this.costs.remove(result);
      return result;
    } 
    return -1L;
  }





  
  public int size() { return this.size; }





  
  public boolean isEmpty() { return (this.size == 0); }





  
  public boolean nonEmpty() { return (this.size != 0); }





  
  public void clear() { this.size = 0; }





  
  public void release() {
    this.size = 0;
    this.heap = null;
    
    this.costs.keys = new long[0];
    this.costs.clear();
    this.costs.keys = null;
    this.costs.values = null;
  }
  
  private boolean upHeap(int origPos) {
    int i = origPos;
    long node = this.heap[i];
    int j = i >>> 1;
    while (j > 0 && lessThan(node, this.heap[j])) {
      this.heap[i] = this.heap[j];
      i = j;
      j >>>= 1;
    } 
    this.heap[i] = node;
    return (i != origPos);
  }
  
  private void downHeap(int i) {
    long node = this.heap[i];
    int j = i << 1;
    int k = j + 1;
    if (k <= this.size && lessThan(this.heap[k], this.heap[j])) {
      j = k;
    }
    while (j <= this.size && lessThan(this.heap[j], node)) {
      this.heap[i] = this.heap[j];
      i = j;
      j = i << 1;
      k = j + 1;
      if (k <= this.size && lessThan(this.heap[k], this.heap[j])) {
        j = k;
      }
    } 
    this.heap[i] = node;
  }
  
  private void ensureCapacityForInsert() {
    if (this.size >= this.heap.length) {
      long[] newHeap = new long[ArrayUtil.oversize(this.size + 1, 4)];

      
      System.arraycopy(this.heap, 0, newHeap, 0, this.heap.length);
      this.heap = newHeap;
    } 
  }

  
  public PrimitiveLongIterator iterator() {
    return new PrimitiveLongIterator()
      {
        int i = 1;


        
        public boolean hasNext() { return (this.i <= LongPriorityQueue.this.size); }


        
        public long next() {
          if (!hasNext()) {
            throw new NoSuchElementException();
          }
          return LongPriorityQueue.this.heap[this.i++];
        }
      };
  }
  
  public static LongPriorityQueue min(int capacity) {
    return new LongPriorityQueue()
      {
        protected boolean lessThan(long a, long b) {
          return (this.costs.get(a) < this.costs.get(b));
        }
      };
  }
  
  public static LongPriorityQueue max(int capacity) {
    return new LongPriorityQueue()
      {
        protected boolean lessThan(long a, long b) {
          return (this.costs.get(a) > this.costs.get(b));
        }
      };
  }

  
  public static LongPriorityQueue min() { return min(14); }


  
  public static LongPriorityQueue max() { return max(14); }
  
  protected abstract boolean lessThan(long paramLong1, long paramLong2);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\queue\LongPriorityQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */