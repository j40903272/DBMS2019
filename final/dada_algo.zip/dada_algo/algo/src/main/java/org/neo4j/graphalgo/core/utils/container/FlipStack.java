package org.neo4j.graphalgo.core.utils.container;

import com.carrotsearch.hppc.IntContainer;
import com.carrotsearch.hppc.IntStack;
import java.util.function.IntConsumer;



























public class FlipStack
{
  private final IntStack[] stacks;
  private int flip = 0;

  
  public FlipStack(int nodeCount) { this.stacks = new IntStack[] { new IntStack(nodeCount), new IntStack(nodeCount) }; }




  
  public FlipStack(IntContainer nodes) {
    this(nodes.size());
    addAll(nodes);
  }
  
  public void reset() {
    this.flip = 0;
    pushStack().clear();
    popStack().clear();
  }





  
  public void flip() { this.flip++; }







  
  public void addAll(IntContainer container) { pushStack().addAll(container); }







  
  public void push(int value) { pushStack().push(value); }







  
  public int pop() { return popStack().pop(); }







  
  public boolean isEmpty() { return popStack().isEmpty(); }







  
  public void forEach(IntConsumer consumer) { popStack().forEach(consumer::accept); }







  
  public IntStack pushStack() { return this.stacks[this.flip % 2]; }







  
  public IntStack popStack() { return this.stacks[(this.flip + 1) % 2]; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\container\FlipStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */