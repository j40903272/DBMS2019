package org.neo4j.graphalgo.core.utils.paged;

import org.neo4j.graphalgo.core.utils.container.SimpleBitSet;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
























public class PagedSimpleBitSet
  extends PagedDataStructure<SimpleBitSet>
{
  private static final PageAllocator.Factory<SimpleBitSet> ALLOCATOR_FACTORY;
  
  static  {
    int pageSize = PageUtil.pageSizeFor(8);
    long pageUsage = MemoryUsage.sizeOfInstance(SimpleBitSet.class) + MemoryUsage.sizeOfLongArray(pageSize);
    
    ALLOCATOR_FACTORY = PageAllocator.of(pageSize, pageUsage, () -> 

        
        new SimpleBitSet(pageSize), new SimpleBitSet[0]);
  }


  
  public static PagedSimpleBitSet newBitSet(long size, AllocationTracker tracker) { return new PagedSimpleBitSet(size, ALLOCATOR_FACTORY.newAllocator(tracker)); }


  
  PagedSimpleBitSet(long size, PageAllocator<SimpleBitSet> allocator) { super(size, allocator); }

  
  public void put(long value) {
    int pageIndex = pageIndex(value);
    int indexInPage = indexInPage(value);
    this.pages[pageIndex].put(indexInPage);
  }
  
  public boolean contains(long value) {
    int pageIndex = pageIndex(value);
    int indexInPage = indexInPage(value);
    return this.pages[pageIndex].contains(indexInPage);
  }
  
  public void remove(long value) {
    int pageIndex = pageIndex(value);
    int indexInPage = indexInPage(value);
    this.pages[pageIndex].remove(indexInPage);
  }

  
  public void clear() {
    int pages = numPages(capacity());
    for (int i = 0; i < pages; i++) {
      this.pages[i].clear();
    }
  }



  
  public long _size() {
    long size = 0L;
    int pages = numPages(capacity());
    for (int i = 0; i < pages; i++) {
      size += this.pages[i].size();
    }
    return size;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\PagedSimpleBitSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */