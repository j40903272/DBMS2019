package org.roaringbitmap;


public class BitmapBatchIterator
  implements ContainerBatchIterator
{
  private int wordIndex = 0;
  private long word;
  private final BitmapContainer bitmap;
  
  public BitmapBatchIterator(BitmapContainer bitmap) {
    this.bitmap = bitmap;
    this.word = bitmap.bitmap[0];
  }

  
  public int next(int key, int[] buffer) {
    int consumed = 0;
    while (consumed < buffer.length) {
      while (this.word == 0L) {
        this.wordIndex++;
        if (this.wordIndex == 1024) {
          return consumed;
        }
        this.word = this.bitmap.bitmap[this.wordIndex];
      } 
      buffer[consumed++] = key + 64 * this.wordIndex + Long.numberOfTrailingZeros(this.word);
      this.word &= this.word - 1L;
    } 
    return consumed;
  }


  
  public boolean hasNext() { return (this.wordIndex < 1024); }


  
  public ContainerBatchIterator clone() {
    try {
      return (ContainerBatchIterator)super.clone();
    } catch (CloneNotSupportedException e) {
      
      throw new IllegalStateException(e);
    } 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\roaringbitmap\BitmapBatchIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */