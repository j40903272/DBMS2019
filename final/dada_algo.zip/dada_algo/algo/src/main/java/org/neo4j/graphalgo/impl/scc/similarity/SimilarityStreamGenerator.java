package org.neo4j.graphalgo.impl.similarity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;
import java.util.Spliterator;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import org.neo4j.graphalgo.core.ProcedureConfiguration;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.Pools;
import org.neo4j.graphalgo.core.utils.QueueBasedSpliterator;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.graphalgo.impl.results.SimilarityResult;



















public class SimilarityStreamGenerator<T>
{
  private final TerminationFlag terminationFlag;
  private final ProcedureConfiguration configuration;
  private final Supplier<RleDecoder> decoderFactory;
  private final SimilarityComputer<T> computer;
  
  public SimilarityStreamGenerator(TerminationFlag terminationFlag, ProcedureConfiguration configuration, Supplier<RleDecoder> decoderFactory, SimilarityComputer<T> computer) {
    this.terminationFlag = terminationFlag;
    this.configuration = configuration;
    this.decoderFactory = decoderFactory;
    this.computer = computer;
  }
  
  public Stream<SimilarityResult> stream(T[] inputs, int[] sourceIndexIds, int[] targetIndexIds, double cutoff, int topK) {
    int concurrency = this.configuration.getConcurrency();
    
    int length = inputs.length;
    if (concurrency == 1) {
      if (topK != 0) {
        return similarityStreamTopK(inputs, sourceIndexIds, targetIndexIds, length, cutoff, topK, this.computer, this.decoderFactory);
      }
      return similarityStream(inputs, sourceIndexIds, targetIndexIds, length, cutoff, this.computer, this.decoderFactory);
    } 
    
    if (topK != 0) {
      return similarityParallelStreamTopK(inputs, sourceIndexIds, targetIndexIds, length, this.terminationFlag, concurrency, cutoff, topK, this.computer, this.decoderFactory);
    }
    return similarityParallelStream(inputs, sourceIndexIds, targetIndexIds, length, this.terminationFlag, concurrency, cutoff, this.computer, this.decoderFactory);
  }


  
  public Stream<SimilarityResult> stream(T[] inputs, double cutoff, int topK) {
    int concurrency = this.configuration.getConcurrency();
    
    int length = inputs.length;
    if (concurrency == 1) {
      if (topK != 0) {
        return similarityStreamTopK(inputs, length, cutoff, topK, this.computer, this.decoderFactory);
      }
      return similarityStream(inputs, length, cutoff, this.computer, this.decoderFactory);
    } 
    
    if (topK != 0) {
      return similarityParallelStreamTopK(inputs, length, this.terminationFlag, concurrency, cutoff, topK, this.computer, this.decoderFactory);
    }
    return similarityParallelStream(inputs, length, this.terminationFlag, concurrency, cutoff, this.computer, this.decoderFactory);
  }




  
  private Stream<SimilarityResult> similarityStreamTopK(T[] inputs, int length, double cutoff, int topK, SimilarityComputer<T> computer, Supplier<RleDecoder> decoderFactory) {
    TopKConsumer[] arrayOfTopKConsumer = (TopKConsumer[])TopKConsumer.initializeTopKConsumers(length, topK);
    RleDecoder decoder = decoderFactory.get();
    
    SimilarityConsumer consumer = TopKConsumer.assignSimilarityPairs((TopKConsumer<SimilarityResult>[])arrayOfTopKConsumer);
    for (int sourceId = 0; sourceId < length; sourceId++) {
      computeSimilarityForSourceIndex(sourceId, inputs, length, cutoff, consumer, computer, decoder);
    }
    return Arrays.stream(arrayOfTopKConsumer).flatMap(TopKConsumer::stream);
  }
  
  private Stream<SimilarityResult> similarityStream(T[] inputs, int length, double cutoff, SimilarityComputer<T> computer, Supplier<RleDecoder> decoderFactory) {
    RleDecoder decoder = decoderFactory.get();
    return IntStream.range(0, length)
      .boxed().flatMap(sourceId -> IntStream.range(sourceId.intValue() + 1, length)
        .mapToObj(()).filter(Objects::nonNull));
  }
  
  private Stream<SimilarityResult> similarityParallelStream(T[] inputs, int length, TerminationFlag terminationFlag, int concurrency, double cutoff, SimilarityComputer<T> computer, Supplier<RleDecoder> decoderFactory) {
    int timeout = 100;
    int queueSize = 1000;
    
    int batchSize = ParallelUtil.adjustedBatchSize(length, concurrency, 1);
    int taskCount = length / batchSize + ((length % batchSize > 0) ? 1 : 0);
    Collection<Runnable> tasks = new ArrayList<>(taskCount);
    
    ArrayBlockingQueue<SimilarityResult> queue = new ArrayBlockingQueue<>(queueSize);
    
    int multiplier = (batchSize < length) ? batchSize : 1;
    for (int taskId = 0; taskId < taskCount; taskId++) {
      int taskOffset = taskId;
      tasks.add(() -> {
            RleDecoder decoder = decoderFactory.get();
            for (int offset = 0; offset < batchSize; offset++) {
              int sourceId = taskOffset * multiplier + offset;
              if (sourceId < length) {
                computeSimilarityForSourceIndex(sourceId, inputs, length, cutoff, (), computer, decoder);
              }
            } 
          });
    } 
    (new Thread(() -> {
          try {
            ParallelUtil.runWithConcurrency(concurrency, tasks, terminationFlag, Pools.DEFAULT);
          } finally {
            put(queue, SimilarityResult.TOMB);
          } 
        })).start();
    
    QueueBasedSpliterator<SimilarityResult> spliterator = new QueueBasedSpliterator(queue, SimilarityResult.TOMB, terminationFlag, timeout);
    return StreamSupport.stream((Spliterator<SimilarityResult>)spliterator, false);
  }
  
  private Stream<SimilarityResult> similarityParallelStreamTopK(T[] inputs, int length, TerminationFlag terminationFlag, int concurrency, double cutoff, int topK, SimilarityComputer<T> computer, Supplier<RleDecoder> decoderFactory) {
    int batchSize = ParallelUtil.adjustedBatchSize(length, concurrency, 1);
    int taskCount = length / batchSize + ((length % batchSize > 0) ? 1 : 0);
    Collection<TopKTask<T>> tasks = new ArrayList<>(taskCount);
    
    int multiplier = (batchSize < length) ? batchSize : 1;
    for (int taskId = 0; taskId < taskCount; taskId++) {
      tasks.add(new TopKTask<>(batchSize, taskId, multiplier, length, inputs, cutoff, topK, computer, decoderFactory.get()));
    }
    ParallelUtil.runWithConcurrency(concurrency, tasks, terminationFlag, Pools.DEFAULT);
    
    TopKConsumer[] arrayOfTopKConsumer = (TopKConsumer[])TopKConsumer.initializeTopKConsumers(length, topK);
    for (Runnable<T> task : tasks) ((TopKTask)task).mergeInto((TopKConsumer<SimilarityResult>[])arrayOfTopKConsumer); 
    return Arrays.stream(arrayOfTopKConsumer).flatMap(TopKConsumer::stream);
  }
  
  public static <T> void computeSimilarityForSourceIndex(int sourceId, T[] inputs, int length, double cutoff, SimilarityConsumer consumer, SimilarityComputer<T> computer, RleDecoder decoder) {
    for (int targetId = sourceId + 1; targetId < length; targetId++) {
      SimilarityResult similarity = computer.similarity(decoder, inputs[sourceId], inputs[targetId], cutoff);
      if (similarity != null) {
        consumer.accept(sourceId, targetId, similarity);
      }
    } 
  }


  
  private Stream<SimilarityResult> similarityStream(T[] inputs, int[] sourceIndexIds, int[] targetIndexIds, int length, double cutoff, SimilarityComputer<T> computer, Supplier<RleDecoder> decoderFactory) {
    RleDecoder decoder = decoderFactory.get();
    
    IntStream sourceRange = idRange(sourceIndexIds, length);
    Function<Integer, IntStream> targetRange = targetRange(targetIndexIds, length);
    
    return sourceRange.boxed().flatMap(sourceId -> ((IntStream)targetRange.apply(sourceId))
        .mapToObj(())
        .filter(Objects::nonNull));
  }

  
  private IntStream idRange(int[] indexIds, int length) { return (indexIds.length > 0) ? Arrays.stream(indexIds) : IntStream.range(0, length); }


  
  private Function<Integer, IntStream> targetRange(int[] targetIndexIds, int length) { return sourceId -> idRange(targetIndexIds, length); }

  
  private Stream<SimilarityResult> similarityStreamTopK(T[] inputs, int[] sourceIndexIds, int[] targetIndexIds, int length, double cutoff, int topK, SimilarityComputer<T> computer, Supplier<RleDecoder> decoderFactory) {
    TopKConsumer[] arrayOfTopKConsumer = (TopKConsumer[])TopKConsumer.initializeTopKConsumers(length, topK);
    RleDecoder decoder = decoderFactory.get();
    
    IntStream sourceRange = idRange(sourceIndexIds, length);
    Function<Integer, IntStream> targetRange = targetRange(targetIndexIds, length);
    
    SimilarityConsumer consumer = TopKConsumer.assignSimilarityPairs((TopKConsumer<SimilarityResult>[])arrayOfTopKConsumer);
    sourceRange.forEach(sourceId -> computeSimilarityForSourceIndex(sourceId, (T[])inputs, cutoff, consumer, computer, decoder, targetRange));
    
    return Arrays.stream(arrayOfTopKConsumer).flatMap(TopKConsumer::stream);
  }

  
  private void computeSimilarityForSourceIndex(int sourceId, T[] inputs, double cutoff, SimilarityConsumer consumer, SimilarityComputer<T> computer, RleDecoder decoder, Function<Integer, IntStream> targetRange) {
    ((IntStream)targetRange.apply(Integer.valueOf(sourceId))).forEach(targetId -> {
          if (sourceId != targetId) {
            SimilarityResult similarity = computer.similarity(decoder, inputs[sourceId], inputs[targetId], cutoff);
            
            if (similarity != null) {
              consumer.accept(sourceId, targetId, similarity);
            }
          } 
        });
  }
  
  private Stream<SimilarityResult> similarityParallelStream(T[] inputs, int[] sourceIndexIds, int[] targetIndexIds, int length, TerminationFlag terminationFlag, int concurrency, double cutoff, SimilarityComputer<T> computer, Supplier<RleDecoder> decoderFactory) {
    Supplier<IntStream> sourceRange = () -> idRange(sourceIndexIds, length);
    Function<Integer, IntStream> targetRange = targetRange(targetIndexIds, length);
    
    int sourceIdsLength = (sourceIndexIds.length > 0) ? sourceIndexIds.length : length;
    
    int timeout = 100;
    int queueSize = 1000;
    
    int batchSize = ParallelUtil.adjustedBatchSize(sourceIdsLength, concurrency, 1);
    int taskCount = sourceIdsLength / batchSize + ((sourceIdsLength % batchSize > 0) ? 1 : 0);
    Collection<Runnable> tasks = new ArrayList<>(taskCount);
    
    ArrayBlockingQueue<SimilarityResult> queue = new ArrayBlockingQueue<>(queueSize);
    
    int multiplier = (batchSize < length) ? batchSize : 1;
    for (int taskId = 0; taskId < taskCount; taskId++) {
      int taskOffset = taskId;
      tasks.add(() -> {
            RleDecoder decoder = decoderFactory.get();
            ((IntStream)sourceRange.get()).skip((taskOffset * multiplier)).limit(batchSize).forEach(());
          });
    } 


    
    (new Thread(() -> {
          try {
            ParallelUtil.runWithConcurrency(concurrency, tasks, terminationFlag, Pools.DEFAULT);
          } finally {
            put(queue, SimilarityResult.TOMB);
          } 
        })).start();
    
    QueueBasedSpliterator<SimilarityResult> spliterator = new QueueBasedSpliterator(queue, SimilarityResult.TOMB, terminationFlag, timeout);
    return StreamSupport.stream((Spliterator<SimilarityResult>)spliterator, false);
  }

  
  private void put(BlockingQueue<SimilarityResult> queue, SimilarityResult items) {
    try {
      queue.put(items);
    } catch (InterruptedException interruptedException) {}
  }


  
  private Stream<SimilarityResult> similarityParallelStreamTopK(T[] inputs, int[] sourceIndexIds, int[] targetIndexIds, int length, TerminationFlag terminationFlag, int concurrency, double cutoff, int topK, SimilarityComputer<T> computer, Supplier<RleDecoder> decoderFactory) {
    Supplier<IntStream> sourceRange = () -> idRange(sourceIndexIds, length);
    Function<Integer, IntStream> targetRange = targetRange(targetIndexIds, length);
    
    int sourceIdsLength = (sourceIndexIds.length > 0) ? sourceIndexIds.length : length;
    
    int batchSize = ParallelUtil.adjustedBatchSize(sourceIdsLength, concurrency, 1);
    int taskCount = sourceIdsLength / batchSize + ((sourceIdsLength % batchSize > 0) ? 1 : 0);
    Collection<SourceTargetTopKTask<T>> tasks = new ArrayList<>(taskCount);
    
    int multiplier = (batchSize < sourceIdsLength) ? batchSize : 1;
    for (int taskId = 0; taskId < taskCount; taskId++) {
      tasks.add(new SourceTargetTopKTask<>(batchSize, taskId, multiplier, length, inputs, cutoff, topK, computer, decoderFactory.get(), sourceRange, targetRange));
    }
    ParallelUtil.runWithConcurrency(concurrency, tasks, terminationFlag, Pools.DEFAULT);
    
    TopKConsumer[] arrayOfTopKConsumer = (TopKConsumer[])TopKConsumer.initializeTopKConsumers(length, topK);
    for (Runnable<T> task : tasks) ((SourceTargetTopKTask)task).mergeInto((TopKConsumer<SimilarityResult>[])arrayOfTopKConsumer); 
    return Arrays.stream(arrayOfTopKConsumer).flatMap(TopKConsumer::stream);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\similarity\SimilarityStreamGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */