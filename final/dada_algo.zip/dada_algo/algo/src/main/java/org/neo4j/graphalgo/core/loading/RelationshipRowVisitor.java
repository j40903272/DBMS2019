package org.neo4j.graphalgo.core.loading;

import java.util.Optional;
import org.neo4j.graphalgo.PropertyMapping;
import org.neo4j.graphalgo.core.utils.RawValues;
import org.neo4j.graphdb.Result;























class RelationshipRowVisitor
  implements Result.ResultVisitor<RuntimeException>
{
  private static final long NO_RELATIONSHIP_REFERENCE = -1L;
  private long lastSourceId = -1L, lastTargetId = -1L;
  private long source = -1L, target = -1L;
  private long rows = 0L;
  
  private final RelationshipsBatchBuffer buffer;
  
  private final IdMap idMap;
  
  private final boolean hasRelationshipProperty;
  
  private final double defaultRelPropertyValue;
  
  private long relationshipCount;
  private final RelationshipImporter.Imports imports;
  private final RelationshipImporter.PropertyReader relPropertyReader;
  
  RelationshipRowVisitor(RelationshipsBatchBuffer buffer, IdMap idMap, Optional<Double> maybeDefaultRelProperty, RelationshipImporter.Imports imports) {
    this.buffer = buffer;
    this.idMap = idMap;
    this.hasRelationshipProperty = maybeDefaultRelProperty.isPresent();
    this.defaultRelPropertyValue = ((Double)maybeDefaultRelProperty.orElseGet(PropertyMapping.EMPTY_PROPERTY::defaultValue)).doubleValue();
    this.imports = imports;
    this.relPropertyReader = RelationshipImporter.preLoadedPropertyReader();
  }

  
  public boolean visit(Result.ResultRow row) throws RuntimeException {
    this.rows++;
    long sourceId = row.getNumber("source").longValue();
    if (sourceId != this.lastSourceId) {
      this.source = this.idMap.toMappedNodeId(sourceId);
      this.lastSourceId = sourceId;
    } 
    if (this.source == -1L) {
      return true;
    }
    long targetId = row.getNumber("target").longValue();
    if (targetId != this.lastTargetId) {
      this.target = this.idMap.toMappedNodeId(targetId);
      this.lastTargetId = targetId;
    } 
    if (this.target == -1L) {
      return true;
    }
    long longWeight = this.hasRelationshipProperty ? Double.doubleToLongBits(extractPropertyValue(row)) : -1L;
    this.buffer.add(this.source, this.target, -1L, longWeight);




    
    if (this.buffer.isFull()) {
      flush();
      reset();
    } 
    return true;
  }
  
  void flush() {
    long imported = this.imports.importRels(this.buffer, this.relPropertyReader);
    this.relationshipCount += RawValues.getHead(imported);
  }

  
  private void reset() { this.buffer.reset(); }

  
  private double extractPropertyValue(Result.ResultRow row) {
    Object property = CypherLoadingUtils.getProperty(row, "weight");
    return (property instanceof Number) ? ((Number)property).doubleValue() : this.defaultRelPropertyValue;
  }

  
  public long rows() { return this.rows; }


  
  public long relationshipCount() { return this.relationshipCount; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\RelationshipRowVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */