package org.HdrHistogram;

import java.util.Iterator;

















public class PercentileIterator
  extends AbstractHistogramIterator
  implements Iterator<HistogramIterationValue>
{
  int percentileTicksPerHalfDistance;
  double percentileLevelToIterateTo;
  double percentileLevelToIterateFrom;
  boolean reachedLastRecordedValue;
  
  public void reset(int percentileTicksPerHalfDistance) { reset(this.histogram, percentileTicksPerHalfDistance); }

  
  private void reset(AbstractHistogram histogram, int percentileTicksPerHalfDistance) {
    resetIterator(histogram);
    this.percentileTicksPerHalfDistance = percentileTicksPerHalfDistance;
    this.percentileLevelToIterateTo = 0.0D;
    this.percentileLevelToIterateFrom = 0.0D;
    this.reachedLastRecordedValue = false;
  }





  
  public PercentileIterator(AbstractHistogram histogram, int percentileTicksPerHalfDistance) { reset(histogram, percentileTicksPerHalfDistance); }


  
  public boolean hasNext() {
    if (super.hasNext()) {
      return true;
    }
    if (!this.reachedLastRecordedValue && this.arrayTotalCount > 0L) {
      this.percentileLevelToIterateTo = 100.0D;
      this.reachedLastRecordedValue = true;
      return true;
    } 
    return false;
  }

  
  void incrementIterationLevel() {
    this.percentileLevelToIterateFrom = this.percentileLevelToIterateTo;














    
    long percentileReportingTicks = this.percentileTicksPerHalfDistance * (long)Math.pow(2.0D, (
        (long)(Math.log(100.0D / (100.0D - this.percentileLevelToIterateTo)) / Math.log(2.0D)) + 1L));
    this.percentileLevelToIterateTo += 100.0D / percentileReportingTicks;
  }

  
  boolean reachedIterationLevel() {
    if (this.countAtThisValue == 0L)
      return false; 
    double currentPercentile = 100.0D * this.totalCountToCurrentIndex / this.arrayTotalCount;
    return (currentPercentile >= this.percentileLevelToIterateTo);
  }


  
  double getPercentileIteratedTo() { return this.percentileLevelToIterateTo; }



  
  double getPercentileIteratedFrom() { return this.percentileLevelToIterateFrom; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\PercentileIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */