package org.neo4j.graphalgo.impl.similarity;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.neo4j.graphalgo.core.utils.Intersections;
import org.neo4j.graphalgo.impl.results.SimilarityResult;



















public class WeightedInput
  implements Comparable<WeightedInput>, SimilarityInput
{
  private final long id;
  private int itemCount;
  private final double[] weights;
  private final int initialSize;
  
  public WeightedInput(long id, double[] weights, int fullSize, int itemCount) {
    this.initialSize = fullSize;
    this.id = id;
    this.weights = weights;
    this.itemCount = itemCount;
  }

  
  public WeightedInput(long id, double[] weights, double skipValue) { this(id, weights, weights.length, calculateCount(weights, skipValue)); }


  
  public WeightedInput(long id, double[] weights) { this(id, weights, weights.length, weights.length); }

  
  private static int calculateCount(double[] weights, double skipValue) {
    boolean skipNan = Double.isNaN(skipValue);
    int count = 0;
    for (double weight : weights) {
      if (weight != skipValue && (!skipNan || !Double.isNaN(weight))) count++; 
    } 
    return count;
  }

  
  public static WeightedInput sparse(long id, double[] weights, int fullSize, int compressedSize) { return new WeightedInput(id, weights, fullSize, compressedSize); }


  
  public static WeightedInput dense(long id, double[] weights, double skipValue) { return new WeightedInput(id, weights, skipValue); }


  
  public static WeightedInput dense(long id, double[] weights) { return new WeightedInput(id, weights); }

  
  public static WeightedInput[] prepareDenseWeights(List<Map<String, Object>> data, long degreeCutoff, Double skipValue) {
    WeightedInput[] inputs = new WeightedInput[data.size()];
    int idx = 0;
    
    boolean skipAnything = (skipValue != null);
    boolean skipNan = (skipAnything && Double.isNaN(skipValue.doubleValue()));
    
    for (Map<String, Object> row : data) {
      List<Number> weightList = SimilarityInput.extractValues(row.get("weights"));
      
      long weightsSize = skipAnything ? skipSize(skipValue, skipNan, weightList) : weightList.size();
      
      if (weightsSize > degreeCutoff) {
        double[] weights = Weights.buildWeights(weightList);
        inputs[idx++] = (skipValue == null) ? dense(((Long)row.get("item")).longValue(), weights) : dense(((Long)row.get("item")).longValue(), weights, skipValue.doubleValue());
      } 
    } 
    if (idx != inputs.length) inputs = Arrays.copyOf(inputs, idx); 
    Arrays.sort((Object[])inputs);
    return inputs;
  }

  
  private static long skipSize(Double skipValue, boolean skipNan, List<Number> weightList) { return weightList.stream().filter(value -> !Intersections.shouldSkip(value.doubleValue(), skipValue.doubleValue(), skipNan)).count(); }


  
  public int compareTo(WeightedInput o) { return Long.compare(this.id, o.id); }

  
  public SimilarityResult sumSquareDeltaSkip(RleDecoder decoder, double similarityCutoff, WeightedInput other, double skipValue, boolean bidirectional) {
    double[] thisWeights = this.weights;
    double[] otherWeights = other.weights;
    if (decoder != null) {
      decoder.reset(this.weights, other.weights);
      thisWeights = decoder.item1();
      otherWeights = decoder.item2();
    } 
    
    int len = Math.min(thisWeights.length, otherWeights.length);
    double sumSquareDelta = Intersections.sumSquareDeltaSkip(thisWeights, otherWeights, len, skipValue);
    long intersection = 0L;
    
    if (similarityCutoff >= 0.0D && sumSquareDelta > similarityCutoff) return null; 
    return new SimilarityResult(this.id, other.id, this.itemCount, other.itemCount, intersection, sumSquareDelta, bidirectional, false);
  }
  
  public SimilarityResult sumSquareDelta(RleDecoder decoder, double similarityCutoff, WeightedInput other, boolean bidirectional) {
    double[] thisWeights = this.weights;
    double[] otherWeights = other.weights;
    if (decoder != null) {
      decoder.reset(this.weights, other.weights);
      thisWeights = decoder.item1();
      otherWeights = decoder.item2();
    } 
    
    int len = Math.min(thisWeights.length, otherWeights.length);
    double sumSquareDelta = Intersections.sumSquareDelta(thisWeights, otherWeights, len);
    long intersection = 0L;
    
    if (similarityCutoff >= 0.0D && sumSquareDelta > similarityCutoff) return null; 
    return new SimilarityResult(this.id, other.id, this.itemCount, other.itemCount, intersection, sumSquareDelta, bidirectional, false);
  }
  
  public SimilarityResult cosineSquaresSkip(RleDecoder decoder, double similarityCutoff, WeightedInput other, double skipValue, boolean bidirectional) {
    double[] thisWeights = this.weights;
    double[] otherWeights = other.weights;
    if (decoder != null) {
      decoder.reset(this.weights, other.weights);
      thisWeights = decoder.item1();
      otherWeights = decoder.item2();
    } 
    
    int len = Math.min(thisWeights.length, otherWeights.length);
    double cosineSquares = Intersections.cosineSquareSkip(thisWeights, otherWeights, len, skipValue);
    long intersection = 0L;
    
    if (similarityCutoff >= 0.0D && (cosineSquares == 0.0D || cosineSquares < similarityCutoff)) return null; 
    return new SimilarityResult(this.id, other.id, this.itemCount, other.itemCount, intersection, cosineSquares, bidirectional, false);
  }
  
  public SimilarityResult cosineSquares(RleDecoder decoder, double similarityCutoff, WeightedInput other, boolean bidirectional) {
    double[] thisWeights = this.weights;
    double[] otherWeights = other.weights;
    if (decoder != null) {
      decoder.reset(this.weights, other.weights);
      thisWeights = decoder.item1();
      otherWeights = decoder.item2();
    } 
    
    int len = Math.min(thisWeights.length, otherWeights.length);
    double cosineSquares = Intersections.cosineSquare(thisWeights, otherWeights, len);
    long intersection = 0L;
    
    if (similarityCutoff >= 0.0D && (cosineSquares == 0.0D || cosineSquares < similarityCutoff)) return null; 
    return new SimilarityResult(this.id, other.id, this.itemCount, other.itemCount, intersection, cosineSquares, bidirectional, false);
  }
  
  public SimilarityResult pearson(RleDecoder decoder, double similarityCutoff, WeightedInput other, boolean bidirectional) {
    double[] thisWeights = this.weights;
    double[] otherWeights = other.weights;
    if (decoder != null) {
      decoder.reset(this.weights, other.weights);
      thisWeights = decoder.item1();
      otherWeights = decoder.item2();
    } 
    
    int len = Math.min(thisWeights.length, otherWeights.length);
    double pearson = Intersections.pearson(thisWeights, otherWeights, len);
    
    if (similarityCutoff >= 0.0D && (pearson == 0.0D || pearson < similarityCutoff)) return null;
    
    return new SimilarityResult(this.id, other.id, this.itemCount, other.itemCount, 0L, pearson, bidirectional, false);
  }
  
  public SimilarityResult pearsonSkip(RleDecoder decoder, double similarityCutoff, WeightedInput other, Double skipValue, boolean bidirectional) {
    double[] thisWeights = this.weights;
    double[] otherWeights = other.weights;
    if (decoder != null) {
      decoder.reset(this.weights, other.weights);
      thisWeights = decoder.item1();
      otherWeights = decoder.item2();
    } 
    
    int len = Math.min(thisWeights.length, otherWeights.length);
    double pearson = Intersections.pearsonSkip(thisWeights, otherWeights, len, skipValue.doubleValue());
    
    if (similarityCutoff >= 0.0D && (pearson == 0.0D || pearson < similarityCutoff)) return null;
    
    return new SimilarityResult(this.id, other.id, this.itemCount, other.itemCount, 0L, pearson, bidirectional, false);
  }


  
  public long getId() { return this.id; }


  
  public int initialSize() { return this.initialSize; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\similarity\WeightedInput.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */