package org.petitparser.context;

import java.util.List;
import java.util.Objects;
import org.petitparser.parser.Parser;
import org.petitparser.parser.primitive.CharacterParser;





























public class Token
{
  private final String buffer;
  private final int start;
  private final int stop;
  private final Object value;
  
  public Token(String buffer, int start, int stop, Object value) {
    this.buffer = buffer;
    this.start = start;
    this.stop = stop;
    this.value = value;
  }




  
  public String getBuffer() { return this.buffer; }





  
  public String getInput() { return this.buffer.substring(this.start, this.stop); }





  
  public int getLength() { return this.stop - this.start; }





  
  public int getStart() { return this.start; }





  
  public int getStop() { return this.stop; }






  
  public <T> T getValue() { return (T)this.value; }





  
  public int getLine() { return lineAndColumnOf(this.buffer, this.start)[0]; }





  
  public int getColumn() { return lineAndColumnOf(this.buffer, this.start)[1]; }


  
  public String toString() {
    int[] tuple = lineAndColumnOf(this.buffer, this.start);
    return "Token[" + tuple[0] + ":" + tuple[1] + "]: " + this.value;
  }

  
  public boolean equals(Object other) {
    if (this == other) {
      return true;
    }
    if (other == null || getClass() != other.getClass()) {
      return false;
    }
    Token token = (Token)other;
    if (this.start != token.start) {
      return false;
    }
    if (this.stop != token.stop) {
      return false;
    }
    if (!Objects.equals(this.buffer, token.buffer)) {
      return false;
    }
    if (!Objects.equals(this.value, token.value)) {
      return false;
    }
    return true;
  }


  
  public int hashCode() { return Objects.hash(new Object[] { this.value, this.buffer, Integer.valueOf(this.start), Integer.valueOf(this.stop) }); }




  
  public static final Parser NEWLINE_PARSER = (Parser)CharacterParser.of('\n').or(new Parser[] { (Parser)CharacterParser.of('\r').seq(new Parser[] { CharacterParser.of('\n').optional() }) });



  
  public static int[] lineAndColumnOf(String buffer, int position) {
    List<Token> tokens = NEWLINE_PARSER.token().matchesSkipping(buffer);
    int line = 1, offset = 0;
    for (Token token : tokens) {
      if (position < token.stop) {
        return new int[] { line, position - offset + 1 };
      }
      line++;
      offset = token.stop;
    } 
    return new int[] { line, position - offset + 1 };
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\context\Token.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */