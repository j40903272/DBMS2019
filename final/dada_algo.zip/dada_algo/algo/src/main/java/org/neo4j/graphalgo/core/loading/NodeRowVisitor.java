package org.neo4j.graphalgo.core.loading;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.neo4j.graphalgo.PropertyMapping;
import org.neo4j.graphdb.Result;
import org.neo4j.values.storable.Values;



















class NodeRowVisitor
  implements Result.ResultVisitor<RuntimeException>
{
  private long rows;
  private long maxNeoId = 0L;
  private Map<PropertyMapping, NodePropertiesBuilder> nodeProperties;
  private NodesBatchBuffer buffer;
  private List<Map<String, Number>> cypherNodeProperties;
  private NodeImporter importer;
  
  public NodeRowVisitor(Map<PropertyMapping, NodePropertiesBuilder> nodeProperties, NodesBatchBuffer buffer, NodeImporter importer) {
    this.nodeProperties = nodeProperties;
    this.buffer = buffer;
    this.importer = importer;
    this.cypherNodeProperties = new ArrayList<>(buffer.capacity());
  }

  
  public boolean visit(Result.ResultRow row) throws RuntimeException {
    long neoId = row.getNumber("id").longValue();
    if (neoId > this.maxNeoId) {
      this.maxNeoId = neoId;
    }
    this.rows++;
    
    HashMap<String, Number> weights = new HashMap<>();
    for (Map.Entry<PropertyMapping, NodePropertiesBuilder> entry : this.nodeProperties.entrySet()) {
      PropertyMapping key = entry.getKey();
      Object value = CypherLoadingUtils.getProperty(row, ((PropertyMapping)entry.getKey()).neoPropertyKey());
      if (value instanceof Number) {
        weights.put(key.propertyKey(), (Number)value); continue;
      }  if (null == value) {
        weights.put(key.propertyKey(), Double.valueOf(key.defaultValue())); continue;
      } 
      throw new IllegalArgumentException(String.format("Unsupported type [%s] of value %s. Please use a numeric property.", new Object[] {
              
              Values.of(value).valueGroup(), value
            }));
    } 

    
    int propRef = this.cypherNodeProperties.size();
    this.cypherNodeProperties.add(weights);
    this.buffer.add(neoId, propRef);
    if (this.buffer.isFull()) {
      flush();
      reset();
    } 
    return true;
  }

  
  void flush() { this.importer.importCypherNodes(this.buffer, this.cypherNodeProperties); }

  
  private void reset() {
    this.buffer.reset();
    this.cypherNodeProperties.clear();
  }

  
  long rows() { return this.rows; }


  
  long maxId() { return this.maxNeoId; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\NodeRowVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */