package org.neo4j.graphalgo.core.utils.paged;

import org.neo4j.graphalgo.core.utils.AtomicDoubleArray;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;





















public final class PagedAtomicDoubleArray
  extends PagedDataStructure<AtomicDoubleArray>
{
  private static final PageAllocator.Factory<AtomicDoubleArray> ALLOCATOR_FACTORY;
  
  static  {
    int pageSize = PageUtil.pageSizeFor(8);
    long pageUsage = MemoryUsage.sizeOfInstance(AtomicDoubleArray.class) + MemoryUsage.sizeOfIntArray(pageSize);
    
    ALLOCATOR_FACTORY = PageAllocator.of(pageSize, pageUsage, () -> 

        
        new AtomicDoubleArray(pageSize), new AtomicDoubleArray[0]);
  }


  
  public static PagedAtomicDoubleArray newArray(long size, AllocationTracker tracker) { return new PagedAtomicDoubleArray(size, ALLOCATOR_FACTORY.newAllocator(tracker)); }




  
  private PagedAtomicDoubleArray(long size, PageAllocator<AtomicDoubleArray> allocator) { super(size, allocator); }

  
  public double get(long index) {
    assert index < capacity();
    int pageIndex = pageIndex(index);
    int indexInPage = indexInPage(index);
    return this.pages[pageIndex].get(indexInPage);
  }
  
  public void set(long index, double value) {
    assert index < capacity();
    int pageIndex = pageIndex(index);
    int indexInPage = indexInPage(index);
    this.pages[pageIndex].set(indexInPage, value);
  }
  
  public void add(long index, double delta) {
    assert index < capacity();
    int pageIndex = pageIndex(index);
    int indexInPage = indexInPage(index);
    this.pages[pageIndex].add(indexInPage, delta);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\PagedAtomicDoubleArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */