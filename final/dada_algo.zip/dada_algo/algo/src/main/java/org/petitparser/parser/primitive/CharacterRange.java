package org.petitparser.parser.primitive;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;







class CharacterRange
{
  static final Comparator<CharacterRange> CHARACTER_RANGE_COMPARATOR = Comparator.comparing(range -> Character.valueOf(range.start))
    .thenComparing(range -> Character.valueOf(range.stop));
  private final char start;
  private final char stop;
  
  static CharacterPredicate toCharacterPredicate(List<CharacterRange> ranges) {
    List<CharacterRange> sortedRanges = new ArrayList<>(ranges);
    sortedRanges.sort(CHARACTER_RANGE_COMPARATOR);

    
    List<CharacterRange> mergedRanges = new ArrayList<>();
    for (CharacterRange thisRange : sortedRanges) {
      if (mergedRanges.isEmpty()) {
        mergedRanges.add(thisRange); continue;
      } 
      CharacterRange lastRange = mergedRanges.get(mergedRanges.size() - 1);
      if (lastRange.stop + 1 >= thisRange.start) {
        CharacterRange characterRange = new CharacterRange(lastRange.start, thisRange.stop);
        mergedRanges.set(mergedRanges.size() - 1, characterRange); continue;
      } 
      mergedRanges.add(thisRange);
    } 



    
    if (mergedRanges.isEmpty())
      return CharacterPredicate.none(); 
    if (mergedRanges.size() == 1) {
      CharacterRange characterRange = mergedRanges.get(0);
      return (characterRange.start == characterRange.stop) ? 
        CharacterPredicate.of(characterRange.start) : 
        CharacterPredicate.range(characterRange.start, characterRange.stop);
    } 
    char[] starts = new char[mergedRanges.size()];
    char[] stops = new char[mergedRanges.size()];
    for (int i = 0; i < mergedRanges.size(); i++) {
      starts[i] = ((CharacterRange)mergedRanges.get(i)).start;
      stops[i] = ((CharacterRange)mergedRanges.get(i)).stop;
    } 
    return CharacterPredicate.ranges(starts, stops);
  }




  
  CharacterRange(char start, char stop) {
    this.start = start;
    this.stop = stop;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\primitive\CharacterRange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */