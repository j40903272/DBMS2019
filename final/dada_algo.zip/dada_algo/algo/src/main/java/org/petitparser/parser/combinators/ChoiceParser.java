package org.petitparser.parser.combinators;

import java.util.Arrays;
import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.parser.Parser;





public class ChoiceParser
  extends ListParser
{
  public ChoiceParser(Parser... parsers) { super(parsers); }


  
  public Result parseOn(Context context) {
    Result result = null;
    for (Parser parser : this.parsers) {
      result = parser.parseOn(context);
      if (result.isSuccess()) {
        return result;
      }
    } 
    return result;
  }

  
  public ChoiceParser or(Parser... others) {
    Parser[] array = Arrays.copyOf(this.parsers, this.parsers.length + others.length);
    System.arraycopy(others, 0, array, this.parsers.length, others.length);
    return new ChoiceParser(array);
  }


  
  public ChoiceParser copy() { return new ChoiceParser(Arrays.copyOf(this.parsers, this.parsers.length)); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\combinators\ChoiceParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */