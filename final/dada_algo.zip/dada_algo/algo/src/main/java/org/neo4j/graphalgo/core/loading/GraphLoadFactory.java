package org.neo4j.graphalgo.core.loading;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import org.neo4j.graphalgo.PropertyMapping;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.GraphFactory;
import org.neo4j.graphalgo.api.GraphSetup;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.kernel.internal.GraphDatabaseAPI;




















public final class GraphLoadFactory
  extends GraphFactory
{
  private static final ConcurrentHashMap<String, GraphsByRelationshipType> graphs = new ConcurrentHashMap<>();



  
  public GraphLoadFactory(GraphDatabaseAPI api, GraphSetup setup) { super(api, setup); }


  
  protected Graph importGraph() {
    assert this.setup.relationshipPropertyMappings.numberOfMappings() <= 1;
    return get(this.setup.name, this.setup.relationshipType, this.setup.relationshipPropertyMappings.head().map(PropertyMapping::propertyKey));
  }


  
  public Graph build() { return importGraph(); }

  
  public MemoryEstimation memoryEstimation() {
    Graph graph = get(this.setup.name, this.setup.relationshipType, this.setup.relationshipPropertyMappings.head().map(PropertyMapping::propertyKey));
    this.dimensions.nodeCount(graph.nodeCount());
    this.dimensions.maxRelCount(graph.relationshipCount());
    
    return HugeGraphFactory.getMemoryEstimation(this.setup, this.dimensions);
  }
  
  public static void set(String name, GraphsByRelationshipType graph) {
    if (name == null || graph == null) {
      throw new IllegalArgumentException("Both name and graph must be not null");
    }
    if (graphs.putIfAbsent((K)name, (V)graph) != null) {
      throw new IllegalStateException("Graph name " + name + " already loaded");
    }
    graph.canRelease(false);
  }
  
  public static Graph get(String name, String relationshipType, Optional<String> maybeRelationshipProperty) {
    if (!exists(name)) {
      throw new IllegalArgumentException(String.format("Graph with name '%s' does not exist.", new Object[] { name }));
    }
    return ((GraphsByRelationshipType)graphs.get(name)).getGraph(relationshipType, maybeRelationshipProperty);
  }





  
  public static Graph getUnion(String name) {
    if (!exists(name))
    {

      
      return null;
    }
    return ((GraphsByRelationshipType)graphs.get(name)).getUnion();
  }

  
  public static boolean exists(String name) { return (name != null && graphs.containsKey(name)); }

  
  public static Graph remove(String name) {
    if (!exists(name))
    {

      
      return null;
    }
    Graph graph = ((GraphsByRelationshipType)graphs.remove(name)).getUnion();
    graph.canRelease(true);
    graph.release();
    return graph;
  }
  
  public static String getType(String name) {
    if (name == null) return null; 
    GraphsByRelationshipType graph = graphs.get(name);
    return (graph == null) ? null : graph.getGraphType();
  }
  
  public static Map<String, Graph> getLoadedGraphs() {
    return (Map<String, Graph>)graphs.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, e -> (
          
          (GraphsByRelationshipType)e.getValue()).getUnion()));
  }


  
  public static void removeAllLoadedGraphs() { graphs.clear(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\GraphLoadFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */