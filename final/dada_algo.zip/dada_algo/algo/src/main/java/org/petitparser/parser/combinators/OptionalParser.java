package org.petitparser.parser.combinators;

import java.util.Objects;
import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.parser.Parser;




public class OptionalParser
  extends DelegateParser
{
  protected final Object otherwise;
  
  public OptionalParser(Parser delegate, Object otherwise) {
    super(delegate);
    this.otherwise = otherwise;
  }

  
  public Result parseOn(Context context) {
    Result result = this.delegate.parseOn(context);
    if (result.isSuccess()) {
      return result;
    }
    return (Result)context.success(this.otherwise);
  }


  
  protected boolean hasEqualProperties(Parser other) {
    return (super.hasEqualProperties(other) && 
      Objects.equals(this.otherwise, ((OptionalParser)other).otherwise));
  }


  
  public OptionalParser copy() { return new OptionalParser(this.delegate, this.otherwise); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\combinators\OptionalParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */