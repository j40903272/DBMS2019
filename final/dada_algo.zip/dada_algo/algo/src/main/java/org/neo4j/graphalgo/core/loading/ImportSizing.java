package org.neo4j.graphalgo.core.loading;

import org.neo4j.graphalgo.core.utils.BitUtil;

























public final class ImportSizing
{
  private static final long MAX_PAGE_SIZE = BitUtil.previousPowerOfTwo(2147483647);
  
  private static final long MIN_PAGE_SIZE = 1024L;
  
  private static final String TOO_MANY_PAGES_REQUIRED = "Importing %d nodes would need %d arrays of %d-long nested arrays each, which cannot be created.";
  
  private final int totalThreads;
  
  private final int pageSize;
  
  private final int numberOfPages;
  
  private ImportSizing(int totalThreads, int pageSize, int numberOfPages) {
    this.totalThreads = totalThreads;
    this.pageSize = pageSize;
    this.numberOfPages = numberOfPages;
  }

  
  public static ImportSizing of(int concurrency, long nodeCount) { return determineBestThreadSize(nodeCount, concurrency); }


  
  private static ImportSizing determineBestThreadSize(long nodeCount, long targetThreads) {
    long pageSize = BitUtil.ceilDiv(nodeCount, targetThreads << 2L);

    
    pageSize = BitUtil.previousPowerOfTwo(pageSize);

    
    pageSize = Math.min(MAX_PAGE_SIZE, pageSize);

    
    pageSize = Math.max(1024L, pageSize);

    
    long numberOfPages = BitUtil.ceilDiv(nodeCount, pageSize);

    
    while (numberOfPages > MAX_PAGE_SIZE && pageSize <= MAX_PAGE_SIZE) {
      pageSize <<= 1L;
      numberOfPages = BitUtil.ceilDiv(nodeCount, pageSize);
    } 
    
    if (numberOfPages > MAX_PAGE_SIZE || pageSize > MAX_PAGE_SIZE) {
      throw new IllegalArgumentException(
          String.format("Importing %d nodes would need %d arrays of %d-long nested arrays each, which cannot be created.", new Object[] { Long.valueOf(nodeCount), Long.valueOf(numberOfPages), Long.valueOf(pageSize) }));
    }


    
    return new ImportSizing((int)targetThreads, (int)pageSize, (int)numberOfPages);
  }





  
  int numberOfThreads() { return this.totalThreads; }


  
  public int pageSize() { return this.pageSize; }


  
  public int numberOfPages() { return this.numberOfPages; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\ImportSizing.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */