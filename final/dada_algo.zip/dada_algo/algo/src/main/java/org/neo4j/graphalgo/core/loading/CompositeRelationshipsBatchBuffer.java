package org.neo4j.graphalgo.core.loading;

import org.neo4j.kernel.impl.store.record.AbstractBaseRecord;
import org.neo4j.kernel.impl.store.record.RelationshipRecord;


















public final class CompositeRelationshipsBatchBuffer
  extends RecordsBatchBuffer<RelationshipRecord>
{
  private final RelationshipsBatchBuffer[] buffers;
  
  private CompositeRelationshipsBatchBuffer(RelationshipsBatchBuffer... buffers) {
    super(0);
    this.buffers = buffers;
  }
  
  static RecordsBatchBuffer<RelationshipRecord> of(RelationshipsBatchBuffer... buffers) {
    if (buffers.length == 1) {
      return buffers[0];
    }
    return new CompositeRelationshipsBatchBuffer(buffers);
  }

  
  public void offer(RelationshipRecord record) {
    for (RelationshipsBatchBuffer buffer : this.buffers) {
      buffer.offer(record);
    }
  }

  
  public void reset() {
    for (RelationshipsBatchBuffer buffer : this.buffers)
      buffer.reset(); 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\CompositeRelationshipsBatchBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */