package org.neo4j.graphalgo.core.loading;

import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.PagedLongDoubleMap;


























public final class NodePropertiesBuilder
{
  private final double defaultValue;
  private final int propertyId;
  private final PagedLongDoubleMap properties;
  private final String propertyKey;
  
  public static NodePropertiesBuilder of(long numberOfNodes, AllocationTracker tracker, double defaultValue, int propertyId, String propertyKey) {
    assert propertyId != -1;
    PagedLongDoubleMap properties = PagedLongDoubleMap.of(numberOfNodes, tracker);
    return new NodePropertiesBuilder(defaultValue, propertyId, properties, propertyKey);
  }




  
  private NodePropertiesBuilder(double defaultValue, int propertyId, PagedLongDoubleMap properties, String propertyKey) {
    this.defaultValue = defaultValue;
    this.propertyId = propertyId;
    this.properties = properties;
    this.propertyKey = propertyKey;
  }

  
  double defaultValue() { return this.defaultValue; }


  
  int propertyId() { return this.propertyId; }


  
  String propertyKey() { return this.propertyKey; }


  
  public void set(long index, double value) { this.properties.put(index, value); }


  
  public NodeProperties build() { return new NodePropertyMap(this.properties, this.defaultValue); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\NodePropertiesBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */