package org.neo4j.graphalgo.core.utils.mem;

import org.neo4j.graphalgo.core.GraphDimensions;





























public interface Assessable
{
  default MemoryEstimation memoryEstimation() { return MemoryEstimations.empty(); }











  
  default MemoryTree memoryEstimation(GraphDimensions dimensions, int concurrency) { return memoryEstimation().estimate(dimensions, concurrency); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\mem\Assessable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */