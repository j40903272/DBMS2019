package org.neo4j.graphalgo.core.utils.paged;

import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Supplier;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;



















public class AllocationTracker
  implements Supplier<String>
{
  public static final AllocationTracker EMPTY = new AllocationTracker()
    {
      public void add(long delta) {}



      
      public void remove(long delta) {}


      
      public long tracked() { return 0L; }



      
      public String get() { return ""; }



      
      public String getUsageString() { return ""; }



      
      public String getUsageString(String label) { return ""; }
    };

  
  private final AtomicLong count = new AtomicLong();

  
  public void add(long delta) { this.count.addAndGet(delta); }


  
  public void remove(long delta) { this.count.addAndGet(-delta); }


  
  public long tracked() { return this.count.get(); }


  
  public String getUsageString() { return MemoryUsage.humanReadable(tracked()); }


  
  public String getUsageString(String label) { return label + MemoryUsage.humanReadable(tracked()); }



  
  public String get() { return getUsageString("Memory usage: "); }


  
  public static AllocationTracker create() { return new AllocationTracker(); }


  
  public static boolean isTracking(AllocationTracker tracker) { return (tracker != null && tracker != EMPTY); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\AllocationTracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */