package org.neo4j.graphalgo.core.utils.paged;























public class PagedLongStack
  extends PagedDataStructure<long[]>
{
  private static final PageAllocator.Factory<long[]> ALLOCATOR_FACTORY = (PageAllocator.Factory)PageAllocator.ofArray((Class)long[].class); private long size;
  private int pageIndex;
  
  public PagedLongStack(long initialSize, AllocationTracker tracker) { this(Math.max(1L, initialSize), (PageAllocator)ALLOCATOR_FACTORY.newAllocator(tracker)); }
  private int pageTop; private int pageLimit; private long[] currentPage;
  
  private PagedLongStack(long initialSize, PageAllocator<long[]> allocator) {
    super(initialSize, (PageAllocator)allocator);
    clear();
  }






  
  public void clear() {
    this.size = 0L;
    this.pageTop = -1;
    this.pageIndex = 0;
    this.currentPage = this.pages[0];
    this.pageLimit = this.currentPage.length;
  }
  
  public void push(long value) {
    int pageTop = ++this.pageTop;
    if (pageTop >= this.pageLimit) {
      pageTop = nextPage();
    }
    this.size++;
    this.currentPage[pageTop] = value;
  }
  
  public long pop() {
    int pageTop = this.pageTop;
    if (pageTop < 0) {
      pageTop = previousPage();
    }
    this.pageTop--;
    this.size--;
    return this.currentPage[pageTop];
  }

  
  public long peek() { return this.currentPage[this.pageTop]; }


  
  public boolean isEmpty() { return (this.size == 0L); }



  
  public long size() { return this.size; }


  
  public long release() {
    long released = super.release();
    this.size = 0L;
    this.pageTop = 0;
    this.pageIndex = 0;
    this.pageLimit = 0;
    this.currentPage = null;
    return released;
  }
  
  private int nextPage() {
    int pageIndex = ++this.pageIndex;
    if (pageIndex >= this.pages.length) {
      grow(capacityFor(pageIndex + 1));
    }
    this.currentPage = this.pages[pageIndex];
    this.pageLimit = this.currentPage.length;
    return this.pageTop = 0;
  }
  
  private int previousPage() {
    int pageIndex = this.pageIndex;
    pageIndex--;
    
    this.currentPage = this.pages[pageIndex];
    this.pageLimit = this.currentPage.length;
    this.pageIndex = pageIndex;
    return this.pageTop = this.pageLimit - 1;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\PagedLongStack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */