package org.neo4j.graphalgo.core.huge;

import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.LongPredicate;
import org.neo4j.collection.primitive.PrimitiveLongIterable;
import org.neo4j.collection.primitive.PrimitiveLongIterator;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.api.RelationshipConsumer;
import org.neo4j.graphalgo.api.RelationshipIntersect;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.api.RelationshipWithPropertyConsumer;
import org.neo4j.graphalgo.core.loading.IdMap;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphdb.Direction;





















































































public class HugeGraph
  implements Graph
{
  public static final double NO_PROPERTY_VALUE = NaND;
  public static final int NO_SUCH_NODE = 0;
  private final IdMap idMapping;
  private final AllocationTracker tracker;
  private final Map<String, NodeProperties> nodeProperties;
  private final long relationshipCount;
  private AdjacencyList inAdjacency;
  private AdjacencyList outAdjacency;
  private AdjacencyOffsets inOffsets;
  private AdjacencyOffsets outOffsets;
  private final double defaultPropertyValue;
  private AdjacencyList inProperties;
  private AdjacencyList outProperties;
  private AdjacencyOffsets inPropertyOffsets;
  private AdjacencyOffsets outPropertyOffsets;
  private AdjacencyList.DecompressingCursor emptyAdjacencyCursor;
  private AdjacencyList.DecompressingCursor inCache;
  private AdjacencyList.DecompressingCursor outCache;
  private boolean canRelease = true;
  private final boolean hasRelationshipProperty;
  private final boolean isUndirected;
  
  public static HugeGraph create(AllocationTracker tracker, IdMap idMapping, Map<String, NodeProperties> nodeProperties, long relationshipCount, AdjacencyList inAdjacency, AdjacencyList outAdjacency, AdjacencyOffsets inOffsets, AdjacencyOffsets outOffsets, Optional<Double> defaultPropertyValue, Optional<AdjacencyList> inProperties, Optional<AdjacencyList> outProperties, Optional<AdjacencyOffsets> inPropertyOffsets, Optional<AdjacencyOffsets> outPropertyOffsets, boolean isUndirected) {
    return new HugeGraph(tracker, idMapping, nodeProperties, relationshipCount, inAdjacency, outAdjacency, inOffsets, outOffsets, (inProperties







        
        .isPresent() || outProperties.isPresent()), ((Double)defaultPropertyValue
        .orElse(Double.valueOf(NaND))).doubleValue(), (AdjacencyList)inProperties
        .orElse(null), (AdjacencyList)outProperties
        .orElse(null), (AdjacencyOffsets)inPropertyOffsets
        .orElse(null), (AdjacencyOffsets)outPropertyOffsets
        .orElse(null), isUndirected);
  }



















  
  public HugeGraph(AllocationTracker tracker, IdMap idMapping, Map<String, NodeProperties> nodeProperties, long relationshipCount, AdjacencyList inAdjacency, AdjacencyList outAdjacency, AdjacencyOffsets inOffsets, AdjacencyOffsets outOffsets, boolean hasRelationshipProperty, double defaultPropertyValue, AdjacencyList inProperties, AdjacencyList outProperties, AdjacencyOffsets inPropertyOffsets, AdjacencyOffsets outPropertyOffsets, boolean isUndirected) {
    this.idMapping = idMapping;
    this.tracker = tracker;
    this.nodeProperties = nodeProperties;
    this.relationshipCount = relationshipCount;
    this.inAdjacency = inAdjacency;
    this.outAdjacency = outAdjacency;
    this.inOffsets = inOffsets;
    this.outOffsets = outOffsets;
    this.defaultPropertyValue = defaultPropertyValue;
    this.inProperties = inProperties;
    this.outProperties = outProperties;
    this.inPropertyOffsets = inPropertyOffsets;
    this.outPropertyOffsets = outPropertyOffsets;
    this.isUndirected = isUndirected;
    this.hasRelationshipProperty = hasRelationshipProperty;
    this.inCache = newAdjacencyCursor(this.inAdjacency);
    this.outCache = newAdjacencyCursor(this.outAdjacency);
    this.emptyAdjacencyCursor = (this.inCache == null) ? newAdjacencyCursor(this.outAdjacency) : newAdjacencyCursor(this.inAdjacency);
  }


  
  public long nodeCount() { return this.idMapping.nodeCount(); }



  
  public long relationshipCount() { return this.relationshipCount; }



  
  public Collection<PrimitiveLongIterable> batchIterables(int batchSize) { return this.idMapping.batchIterables(batchSize); }



  
  public void forEachNode(LongPredicate consumer) { this.idMapping.forEachNode(consumer); }



  
  public PrimitiveLongIterator nodeIterator() { return this.idMapping.nodeIterator(); }



  
  public double relationshipProperty(long sourceNodeId, long targetNodeId) { return relationshipProperty(sourceNodeId, targetNodeId, this.defaultPropertyValue); }


  
  public double relationshipProperty(long sourceNodeId, long targetNodeId, double fallbackValue) {
    if (!this.hasRelationshipProperty) {
      return fallbackValue;
    }


    
    if (this.outProperties != null) {
      double maybeValue = findPropertyValue(sourceNodeId, targetNodeId, this.outProperties, this.outPropertyOffsets, this.outAdjacency, this.outOffsets);





      
      if (!Double.isNaN(maybeValue)) {
        return maybeValue;
      }
    } 
    
    if (this.inProperties != null) {
      double maybeValue = findPropertyValue(targetNodeId, sourceNodeId, this.inProperties, this.inPropertyOffsets, this.inAdjacency, this.inOffsets);

      
      if (!Double.isNaN(maybeValue)) {
        return maybeValue;
      }
    } 
    
    return this.defaultPropertyValue;
  }







  
  private double findPropertyValue(long fromId, long toId, AdjacencyList properties, AdjacencyOffsets propertyOffsets, AdjacencyList adjacencies, AdjacencyOffsets adjacencyOffsets) {
    long relOffset = adjacencyOffsets.get(fromId);
    if (relOffset == 0L) {
      return NaND;
    }
    long propertyOffset = propertyOffsets.get(fromId);
    
    AdjacencyList.DecompressingCursor relDecompressingCursor = adjacencies.decompressingCursor(relOffset);
    AdjacencyList.Cursor propertyCursor = properties.cursor(propertyOffset);
    
    while (relDecompressingCursor.hasNextVLong() && propertyCursor.hasNextLong() && relDecompressingCursor.nextVLong() != toId) {
      propertyCursor.nextLong();
    }
    
    if (!propertyCursor.hasNextLong()) {
      return NaND;
    }
    
    long doubleBits = propertyCursor.nextLong();
    return Double.longBitsToDouble(doubleBits);
  }


  
  public NodeProperties nodeProperties(String type) { return this.nodeProperties.get(type); }



  
  public Set<String> availableNodeProperties() { return this.nodeProperties.keySet(); }


  
  public void forEachRelationship(long nodeId, Direction direction, RelationshipConsumer consumer) {
    switch (direction) {
      case INCOMING:
        runForEach(nodeId, Direction.INCOMING, consumer, true);
        return;
      
      case OUTGOING:
        runForEach(nodeId, Direction.OUTGOING, consumer, true);
        return;
    } 
    
    runForEach(nodeId, Direction.OUTGOING, consumer, true);
    runForEach(nodeId, Direction.INCOMING, consumer, true);
  }








  
  public void forEachRelationship(long nodeId, Direction direction, double fallbackValue, RelationshipWithPropertyConsumer consumer) {
    switch (direction) {
      case INCOMING:
        runForEachWithProperty(nodeId, Direction.INCOMING, fallbackValue, consumer);
        return;
      
      case OUTGOING:
        runForEachWithProperty(nodeId, Direction.OUTGOING, fallbackValue, consumer);
        return;
    } 
    
    runForEachWithProperty(nodeId, Direction.OUTGOING, fallbackValue, consumer);
    runForEachWithProperty(nodeId, Direction.INCOMING, fallbackValue, consumer);
  }





  
  public int degree(long node, Direction direction) {
    switch (direction) {
      case INCOMING:
        return degree(node, this.inOffsets, this.inAdjacency);
      
      case OUTGOING:
        return degree(node, this.outOffsets, this.outAdjacency);
      
      case BOTH:
        return degree(node, this.inOffsets, this.inAdjacency) + 
          degree(node, this.outOffsets, this.outAdjacency);
    } 
    
    throw new IllegalArgumentException(direction + "");
  }



  
  public long toMappedNodeId(long nodeId) { return this.idMapping.toMappedNodeId(nodeId); }



  
  public long toOriginalNodeId(long nodeId) { return this.idMapping.toOriginalNodeId(nodeId); }



  
  public boolean contains(long nodeId) { return this.idMapping.contains(nodeId); }



  
  public void forEachIncoming(long node, RelationshipConsumer consumer) { runForEach(node, Direction.INCOMING, consumer, true); }



  
  public void forEachOutgoing(long node, RelationshipConsumer consumer) { runForEach(node, Direction.OUTGOING, consumer, true); }



  
  public HugeGraph concurrentCopy() { return new HugeGraph(this.tracker, this.idMapping, this.nodeProperties, this.relationshipCount, this.inAdjacency, this.outAdjacency, this.inOffsets, this.outOffsets, this.hasRelationshipProperty, this.defaultPropertyValue, this.inProperties, this.outProperties, this.inPropertyOffsets, this.outPropertyOffsets, this.isUndirected); }


















  
  public RelationshipIntersect intersection() { return new HugeGraphIntersectImpl(this.outAdjacency, this.outOffsets); }





  
  public boolean exists(long sourceNodeId, long targetNodeId, Direction direction) {
    ExistsConsumer consumer = new ExistsConsumer(targetNodeId);
    runForEach(sourceNodeId, direction, consumer, false);

    
    return consumer.found;
  }




  
  public long getTarget(long sourceNodeId, long index, Direction direction) {
    GetTargetConsumer consumer = new GetTargetConsumer(index);
    runForEach(sourceNodeId, direction, consumer, false);

    
    return consumer.target;
  }






  
  private void runForEach(long sourceNodeId, Direction direction, RelationshipConsumer consumer, boolean reuseCursor) {
    if (direction == Direction.BOTH) {
      runForEach(sourceNodeId, Direction.OUTGOING, consumer, reuseCursor);
      runForEach(sourceNodeId, Direction.INCOMING, consumer, reuseCursor);
      
      return;
    } 
    AdjacencyList.DecompressingCursor adjacencyCursor = adjacencyCursorForIteration(sourceNodeId, direction, reuseCursor);


    
    consumeAdjacentNodes(sourceNodeId, adjacencyCursor, consumer);
  }






  
  private void runForEachWithProperty(long sourceNodeId, Direction direction, double fallbackValue, RelationshipWithPropertyConsumer consumer) {
    if (direction == Direction.BOTH) {
      runForEachWithProperty(sourceNodeId, Direction.OUTGOING, fallbackValue, consumer);
      runForEachWithProperty(sourceNodeId, Direction.INCOMING, fallbackValue, consumer);
      
      return;
    } 
    if (!hasRelationshipProperty()) {
      runForEach(sourceNodeId, direction, (s, t) -> consumer.accept(s, t, fallbackValue), false);
    } else {
      AdjacencyList.DecompressingCursor adjacencyCursor = adjacencyCursorForIteration(sourceNodeId, direction, false);




      
      AdjacencyList.Cursor propertyCursor = propertyCursorForIteration(sourceNodeId, direction);
      consumeAdjacentNodesWithProperty(sourceNodeId, adjacencyCursor, propertyCursor, consumer);
    } 
  }




  
  private AdjacencyList.DecompressingCursor adjacencyCursorForIteration(long sourceNodeId, Direction direction, boolean reuseCursor) {
    if (direction == Direction.OUTGOING) {
      return adjacencyCursor(sourceNodeId, reuseCursor ? this.outCache : this.outAdjacency
          
          .rawDecompressingCursor(), this.outOffsets, this.outAdjacency);
    }

    
    return adjacencyCursor(sourceNodeId, reuseCursor ? this.inCache : this.inAdjacency
        
        .rawDecompressingCursor(), this.inOffsets, this.inAdjacency);
  }



  
  private AdjacencyList.Cursor propertyCursorForIteration(long sourceNodeId, Direction direction) {
    if (direction == Direction.OUTGOING) {
      return propertyCursor(sourceNodeId, this.outPropertyOffsets, this.outProperties);
    }


    
    return propertyCursor(sourceNodeId, this.inPropertyOffsets, this.inProperties);
  }






  
  public void canRelease(boolean canRelease) { this.canRelease = canRelease; }


  
  public void releaseTopology() {
    if (!this.canRelease)
      return;  if (this.inAdjacency != null) {
      this.tracker.remove(this.inAdjacency.release());
      this.tracker.remove(this.inOffsets.release());
      this.inAdjacency = null;
      this.inProperties = null;
      this.inOffsets = null;
      this.inPropertyOffsets = null;
    } 
    if (this.outAdjacency != null) {
      this.tracker.remove(this.outAdjacency.release());
      this.tracker.remove(this.outOffsets.release());
      this.outAdjacency = null;
      this.outProperties = null;
      this.outOffsets = null;
      this.outPropertyOffsets = null;
    } 
    this.emptyAdjacencyCursor = null;
    this.inCache = null;
    this.outCache = null;
  }

  
  public void releaseProperties() {
    if (this.canRelease) {
      for (NodeProperties nodeMapping : this.nodeProperties.values()) {
        this.tracker.remove(nodeMapping.release());
      }
    }
  }


  
  public boolean isUndirected() { return this.isUndirected; }



  
  public boolean hasRelationshipProperty() { return this.hasRelationshipProperty; }


  
  public Direction getLoadDirection() {
    if (this.inOffsets != null && this.outOffsets != null)
      return Direction.BOTH; 
    if (this.inOffsets != null) {
      return Direction.INCOMING;
    }
    assert this.outOffsets != null;
    return Direction.OUTGOING;
  }


  
  private AdjacencyList.DecompressingCursor newAdjacencyCursor(AdjacencyList adjacency) { return (adjacency != null) ? adjacency.rawDecompressingCursor() : null; }

  
  private int degree(long node, AdjacencyOffsets offsets, AdjacencyList array) {
    long offset = offsets.get(node);
    if (offset == 0L) {
      return 0;
    }
    return array.getDegree(offset);
  }





  
  private AdjacencyList.DecompressingCursor adjacencyCursor(long node, AdjacencyList.DecompressingCursor adjacencyCursor, AdjacencyOffsets offsets, AdjacencyList adjacencyList) {
    if (offsets == null) {
      return this.emptyAdjacencyCursor;
    }
    long offset = offsets.get(node);
    if (offset == 0L) {
      return this.emptyAdjacencyCursor;
    }
    return adjacencyList.decompressingCursor(adjacencyCursor, offset);
  }




  
  private AdjacencyList.Cursor propertyCursor(long node, AdjacencyOffsets offsets, AdjacencyList properties) {
    if (!hasRelationshipProperty()) {
      throw new UnsupportedOperationException("Can not create property cursor on a graph without relationship property");
    }

    
    long offset = offsets.get(node);
    if (offset == 0L) {
      return AdjacencyList.Cursor.EMPTY;
    }
    return properties.cursor(offset);
  }


  
  private void consumeAdjacentNodes(long startNode, AdjacencyList.DecompressingCursor adjacencyCursor, RelationshipConsumer consumer) {
    do {
    
    } while (adjacencyCursor.hasNextVLong() && 
      consumer.accept(startNode, adjacencyCursor.nextVLong()));
  }









  
  private void consumeAdjacentNodesWithProperty(long startNode, AdjacencyList.DecompressingCursor adjacencyCursor, AdjacencyList.Cursor propertyCursor, RelationshipWithPropertyConsumer consumer) {
    while (adjacencyCursor.hasNextVLong()) {
      long targetNodeId = adjacencyCursor.nextVLong();
      
      long propertyBits = propertyCursor.nextLong();
      double property = Double.longBitsToDouble(propertyBits);
      
      if (!consumer.accept(startNode, targetNodeId, property))
        break; 
    } 
  }
  
  static class GetTargetConsumer
    implements RelationshipConsumer
  {
    static final long TARGET_NOT_FOUND = -1L;
    private long count;
    private long target = -1L;

    
    GetTargetConsumer(long count) { this.count = count; }


    
    public boolean accept(long s, long t) {
      if (this.count-- == 0L) {
        this.target = t;
        return false;
      } 
      return true;
    }
  }
  
  private static class ExistsConsumer
    implements RelationshipConsumer {
    private final long targetNodeId;
    private boolean found = false;
    
    ExistsConsumer(long targetNodeId) { this.targetNodeId = targetNodeId; }


    
    public boolean accept(long s, long t) {
      if (t == this.targetNodeId) {
        this.found = true;
        return false;
      } 
      return true;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\huge\HugeGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */