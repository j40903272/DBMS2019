package org.petitparser.context;



public class Success
  extends Result
{
  private final Object result;
  
  public Success(String buffer, int position, Object result) {
    super(buffer, position);
    this.result = result;
  }


  
  public boolean isSuccess() { return true; }




  
  public <T> T get() { return (T)this.result; }



  
  public String toString() { return super.toString() + ": " + this.result; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\context\Success.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */