package org.neo4j.graphalgo.core.utils;

import com.carrotsearch.hppc.sorting.IndirectComparator;




















public class AscendingLongComparator
  implements IndirectComparator
{
  private final long[] array;
  
  public AscendingLongComparator(long[] array) { this.array = array; }

  
  public int compare(int indexA, int indexB) {
    long a = this.array[indexA];
    long b = this.array[indexB];
    if (a < b) {
      return -1;
    }
    return (a > b) ? 1 : 0;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\AscendingLongComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */