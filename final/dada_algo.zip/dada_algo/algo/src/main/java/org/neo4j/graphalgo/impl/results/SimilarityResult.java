package org.neo4j.graphalgo.impl.results;

import java.util.Comparator;
import java.util.Objects;
import org.HdrHistogram.DoubleHistogram;




















public class SimilarityResult
  implements Comparable<SimilarityResult>
{
  public final long item1;
  public final long item2;
  public final long count1;
  public final long count2;
  public final long intersection;
  public double similarity;
  public final boolean bidirectional;
  public final boolean reversed;
  public static SimilarityResult TOMB = new SimilarityResult(-1L, -1L, -1L, -1L, -1L, -1.0D);








  
  public SimilarityResult(long item1, long item2, long count1, long count2, long intersection, double similarity, boolean bidirectional, boolean reversed) {
    this.item1 = item1;
    this.item2 = item2;
    this.count1 = count1;
    this.count2 = count2;
    this.intersection = intersection;
    this.similarity = similarity;
    this.bidirectional = bidirectional;
    this.reversed = reversed;
  }

  
  public SimilarityResult(long item1, long item2, long count1, long count2, long intersection, double similarity) { this(item1, item2, count1, count2, intersection, similarity, true, false); }


  
  public boolean equals(Object o) {
    if (this == o) return true; 
    if (o == null || getClass() != o.getClass()) return false; 
    SimilarityResult that = (SimilarityResult)o;
    return (this.item1 == that.item1 && this.item2 == that.item2 && this.count1 == that.count1 && this.count2 == that.count2 && this.intersection == that.intersection && 



      
      Double.compare(that.similarity, this.similarity) == 0 && this.bidirectional == that.bidirectional && this.reversed == that.reversed);
  }




  
  public boolean sameItems(SimilarityResult that) { return (this.item1 == that.item1 && this.item2 == that.item2); }



  
  public int hashCode() { return Objects.hash(new Object[] { Long.valueOf(this.item1), Long.valueOf(this.item2), Long.valueOf(this.count1), Long.valueOf(this.count2), Long.valueOf(this.intersection), Double.valueOf(this.similarity), Boolean.valueOf(this.bidirectional), Boolean.valueOf(this.reversed) }); }






  
  public int compareTo(SimilarityResult o) { return Double.compare(o.similarity, this.similarity); }


  
  public SimilarityResult reverse() { return new SimilarityResult(this.item2, this.item1, this.count2, this.count1, this.intersection, this.similarity, this.bidirectional, !this.reversed); }

  
  public SimilarityResult squareRooted() {
    this.similarity = Math.sqrt(this.similarity);
    return this;
  }
  
  public void record(DoubleHistogram histogram) {
    try {
      histogram.recordValue(this.similarity);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {}
  }

  
  public static Comparator<SimilarityResult> ASCENDING = (o1, o2) -> -o1.compareTo(o2);
  public static Comparator<SimilarityResult> DESCENDING = SimilarityResult::compareTo;


  
  public String toString() { return "SimilarityResult{item1=" + this.item1 + ", item2=" + this.item2 + ", count1=" + this.count1 + ", count2=" + this.count2 + ", intersection=" + this.intersection + ", similarity=" + this.similarity + ", bidirectional=" + this.bidirectional + ", reversed=" + this.reversed + '}'; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\results\SimilarityResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */