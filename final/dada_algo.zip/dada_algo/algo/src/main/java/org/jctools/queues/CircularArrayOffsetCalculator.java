package org.jctools.queues;

import org.jctools.util.UnsafeRefArrayAccess;








public final class CircularArrayOffsetCalculator
{
  public static <E> E[] allocate(int capacity) { return (E[])new Object[capacity]; }








  
  public static long calcElementOffset(long index, long mask) { return UnsafeRefArrayAccess.REF_ARRAY_BASE + ((index & mask) << UnsafeRefArrayAccess.REF_ELEMENT_SHIFT); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\jctools\queues\CircularArrayOffsetCalculator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */