package org.HdrHistogram;

import java.util.Iterator;

















public class LogarithmicIterator
  extends AbstractHistogramIterator
  implements Iterator<HistogramIterationValue>
{
  long valueUnitsInFirstBucket;
  double logBase;
  double nextValueReportingLevel;
  long currentStepHighestValueReportingLevel;
  long currentStepLowestValueReportingLevel;
  
  public void reset(long valueUnitsInFirstBucket, double logBase) { reset(this.histogram, valueUnitsInFirstBucket, logBase); }

  
  private void reset(AbstractHistogram histogram, long valueUnitsInFirstBucket, double logBase) {
    resetIterator(histogram);
    this.logBase = logBase;
    this.valueUnitsInFirstBucket = valueUnitsInFirstBucket;
    this.nextValueReportingLevel = valueUnitsInFirstBucket;
    this.currentStepHighestValueReportingLevel = (long)this.nextValueReportingLevel - 1L;
    this.currentStepLowestValueReportingLevel = histogram.lowestEquivalentValue(this.currentStepHighestValueReportingLevel);
  }






  
  public LogarithmicIterator(AbstractHistogram histogram, long valueUnitsInFirstBucket, double logBase) { reset(histogram, valueUnitsInFirstBucket, logBase); }


  
  public boolean hasNext() {
    if (super.hasNext()) {
      return true;
    }



    
    return (this.histogram.lowestEquivalentValue((long)this.nextValueReportingLevel) < this.nextValueAtIndex);
  }

  
  void incrementIterationLevel() {
    this.nextValueReportingLevel *= this.logBase;
    this.currentStepHighestValueReportingLevel = (long)this.nextValueReportingLevel - 1L;
    this.currentStepLowestValueReportingLevel = this.histogram.lowestEquivalentValue(this.currentStepHighestValueReportingLevel);
  }


  
  long getValueIteratedTo() { return this.currentStepHighestValueReportingLevel; }



  
  boolean reachedIterationLevel() { return (this.currentValueAtIndex >= this.currentStepLowestValueReportingLevel || this.currentIndex >= this.histogram.countsArrayLength - 1); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\LogarithmicIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */