package org.petitparser.parser.repeating;

import java.util.ArrayList;
import java.util.List;
import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.parser.Parser;
import org.petitparser.parser.combinators.DelegateParser;




public class PossessiveRepeatingParser
  extends RepeatingParser
{
  public PossessiveRepeatingParser(Parser delegate, int min, int max) { super(delegate, min, max); }


  
  public Result parseOn(Context context) {
    Object object = context;
    List<Object> elements = new ArrayList();
    while (elements.size() < this.min) {
      Result result = this.delegate.parseOn((Context)object);
      if (result.isFailure()) {
        return result;
      }
      elements.add(result.get());
      object = result;
    } 
    while (this.max == -1 || elements.size() < this.max) {
      Result result = this.delegate.parseOn((Context)object);
      if (result.isFailure()) {
        return (Result)object.success(elements);
      }
      elements.add(result.get());
      object = result;
    } 
    return (Result)object.success(elements);
  }


  
  public PossessiveRepeatingParser copy() { return new PossessiveRepeatingParser(this.delegate, this.min, this.max); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\repeating\PossessiveRepeatingParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */