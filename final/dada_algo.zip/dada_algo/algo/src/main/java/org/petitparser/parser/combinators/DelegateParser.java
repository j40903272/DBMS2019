package org.petitparser.parser.combinators;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.parser.Parser;





public class DelegateParser
  extends Parser
{
  protected Parser delegate;
  
  public DelegateParser(Parser delegate) { this.delegate = Objects.requireNonNull(delegate, "Undefined delegate parser"); }



  
  public Result parseOn(Context context) { return this.delegate.parseOn(context); }


  
  public void replace(Parser source, Parser target) {
    super.replace(source, target);
    if (this.delegate == source) {
      this.delegate = target;
    }
  }


  
  public List<Parser> getChildren() { return Collections.singletonList(this.delegate); }



  
  public DelegateParser copy() { return new DelegateParser(this.delegate); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\combinators\DelegateParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */