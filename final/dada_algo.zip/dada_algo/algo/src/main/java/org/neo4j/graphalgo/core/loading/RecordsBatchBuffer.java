package org.neo4j.graphalgo.core.loading;

import org.neo4j.kernel.impl.store.record.AbstractBaseRecord;























abstract class RecordsBatchBuffer<Record extends AbstractBaseRecord>
  implements AbstractStorePageCacheScanner.RecordConsumer<Record>
{
  static final int DEFAULT_BUFFER_SIZE = 100000;
  final long[] buffer;
  int length;
  
  RecordsBatchBuffer(int capacity) { this.buffer = new long[capacity]; }

  
  boolean scan(AbstractStorePageCacheScanner<Record>.Cursor cursor) {
    reset();
    return cursor.bulkNext(this);
  }

  
  int length() { return this.length; }


  
  int capacity() { return this.buffer.length; }


  
  public boolean isFull() { return (this.length >= this.buffer.length); }


  
  public void reset() { this.length = 0; }


  
  long[] batch() { return this.buffer; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\RecordsBatchBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */