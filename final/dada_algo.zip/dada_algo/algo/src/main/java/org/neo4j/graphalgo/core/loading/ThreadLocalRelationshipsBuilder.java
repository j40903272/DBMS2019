package org.neo4j.graphalgo.core.loading;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.concurrent.locks.ReentrantLock;
import org.apache.lucene.util.LongsRef;
import org.neo4j.graphalgo.core.DeduplicationStrategy;




























class ThreadLocalRelationshipsBuilder
{
  private final ReentrantLock lock;
  private final DeduplicationStrategy[] deduplicationStrategies;
  private final AdjacencyListBuilder.Allocator adjacencyAllocator;
  private final AdjacencyListBuilder.Allocator[] propertiesAllocators;
  private final long[] adjacencyOffsets;
  private final long[][] weightOffsets;
  private final boolean noDeduplication;
  
  ThreadLocalRelationshipsBuilder(DeduplicationStrategy[] deduplicationStrategies, AdjacencyListBuilder.Allocator adjacencyAllocator, AdjacencyListBuilder.Allocator[] propertiesAllocators, long[] adjacencyOffsets, long[][] weightOffsets) {
    if (deduplicationStrategies.length == 0) {
      throw new IllegalArgumentException("Needs at least one deduplication strategy");
    }
    this.deduplicationStrategies = deduplicationStrategies;
    this.noDeduplication = Arrays.stream(deduplicationStrategies).allMatch(d -> (d == DeduplicationStrategy.NONE));
    this.adjacencyAllocator = adjacencyAllocator;
    this.propertiesAllocators = propertiesAllocators;
    this.adjacencyOffsets = adjacencyOffsets;
    this.weightOffsets = weightOffsets;
    this.lock = new ReentrantLock();
  }
  
  final void prepare() {
    this.adjacencyAllocator.prepare();
    
    for (AdjacencyListBuilder.Allocator weightsAllocator : this.propertiesAllocators) {
      if (weightsAllocator != null) {
        weightsAllocator.prepare();
      }
    } 
  }

  
  final void lock() { this.lock.lock(); }


  
  final void unlock() { this.lock.unlock(); }





  
  int applyVariableDeltaEncoding(CompressedLongArray array, LongsRef buffer, int localId) {
    if (array.hasWeights()) {
      return applyVariableDeltaEncodingWithWeights(array, buffer, localId);
    }
    return applyVariableDeltaEncodingWithoutWeights(array, buffer, localId);
  }




  
  private int applyVariableDeltaEncodingWithoutWeights(CompressedLongArray array, LongsRef buffer, int localId) {
    byte[] storage = array.storage();
    AdjacencyCompression.copyFrom(buffer, array);
    int degree = AdjacencyCompression.applyDeltaEncoding(buffer, this.deduplicationStrategies[0]);
    int requiredBytes = AdjacencyCompression.compress(buffer, storage);
    long address = copyIds(storage, requiredBytes, degree);
    this.adjacencyOffsets[localId] = address;
    array.release();
    return degree;
  }



  
  private int applyVariableDeltaEncodingWithWeights(CompressedLongArray array, LongsRef buffer, int localId) {
    byte[] storage = array.storage();
    long[][] weights = array.weights();
    AdjacencyCompression.copyFrom(buffer, array);
    int degree = AdjacencyCompression.applyDeltaEncoding(buffer, weights, this.deduplicationStrategies, this.noDeduplication);
    int requiredBytes = AdjacencyCompression.compress(buffer, storage);
    
    this.adjacencyOffsets[localId] = copyIds(storage, requiredBytes, degree);
    copyProperties(weights, degree, localId, this.weightOffsets);
    
    array.release();
    return degree;
  }

  
  private long copyIds(byte[] targets, int requiredBytes, int degree) {
    long address = this.adjacencyAllocator.allocate(4 + requiredBytes);
    int offset = this.adjacencyAllocator.offset;
    offset = AdjacencyCompression.writeDegree(this.adjacencyAllocator.page, offset, degree);
    System.arraycopy(targets, 0, this.adjacencyAllocator.page, offset, requiredBytes);
    this.adjacencyAllocator.offset = offset + requiredBytes;
    return address;
  }
  
  private void copyProperties(long[][] properties, int degree, int localId, long[][] offsets) {
    for (int i = 0; i < properties.length; i++) {
      long[] property = properties[i];
      AdjacencyListBuilder.Allocator propertiesAllocator = this.propertiesAllocators[i];
      long address = copyProperties(property, degree, propertiesAllocator);
      offsets[i][localId] = address;
    } 
  }
  
  private long copyProperties(long[] properties, int degree, AdjacencyListBuilder.Allocator propertiesAllocator) {
    int requiredBytes = degree * 8;
    long address = propertiesAllocator.allocate(4 + requiredBytes);
    int offset = propertiesAllocator.offset;
    offset = AdjacencyCompression.writeDegree(propertiesAllocator.page, offset, degree);
    
    ByteBuffer.wrap(propertiesAllocator.page, offset, requiredBytes)
      .order(ByteOrder.LITTLE_ENDIAN)
      .asLongBuffer()
      .put(properties, 0, degree);
    propertiesAllocator.offset = offset + requiredBytes;
    return address;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\ThreadLocalRelationshipsBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */