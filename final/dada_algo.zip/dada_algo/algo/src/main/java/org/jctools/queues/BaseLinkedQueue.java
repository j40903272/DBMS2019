package org.jctools.queues;

import java.util.Iterator;






























































































































abstract class BaseLinkedQueue<E>
  extends BaseLinkedQueuePad2<E>
{
  public final Iterator<E> iterator() { throw new UnsupportedOperationException(); }




  
  public String toString() { return getClass().getName(); }



  
  protected final LinkedQueueNode<E> newNode() { return new LinkedQueueNode<E>(); }



  
  protected final LinkedQueueNode<E> newNode(E e) { return new LinkedQueueNode<E>(e); }















  
  public final int size() {
    LinkedQueueNode<E> chaserNode = lvConsumerNode();
    LinkedQueueNode<E> producerNode = lvProducerNode();
    int size = 0;
    
    while (chaserNode != producerNode && chaserNode != null && size < Integer.MAX_VALUE) {



      
      LinkedQueueNode<E> next = chaserNode.lvNext();
      
      if (next == chaserNode)
      {
        return size;
      }
      chaserNode = next;
      size++;
    } 
    return size;
  }













  
  public final boolean isEmpty() { return (lvConsumerNode() == lvProducerNode()); }



  
  protected E getSingleConsumerNodeValue(LinkedQueueNode<E> currConsumerNode, LinkedQueueNode<E> nextNode) {
    E nextValue = nextNode.getAndNullValue();



    
    currConsumerNode.soNext(currConsumerNode);
    spConsumerNode(nextNode);
    
    return nextValue;
  }


  
  public E relaxedPoll() {
    LinkedQueueNode<E> currConsumerNode = lpConsumerNode();
    LinkedQueueNode<E> nextNode = currConsumerNode.lvNext();
    if (nextNode != null)
    {
      return getSingleConsumerNodeValue(currConsumerNode, nextNode);
    }
    return null;
  }


  
  public E relaxedPeek() {
    LinkedQueueNode<E> nextNode = lpConsumerNode().lvNext();
    if (nextNode != null)
    {
      return nextNode.lpValue();
    }
    return null;
  }



  
  public boolean relaxedOffer(E e) { return offer(e); }


  
  public int drain(MessagePassingQueue.Consumer<E> c) {
    int drained;
    long result = 0L;

    
    do {
      drained = drain(c, 4096);
      result += drained;
    }
    while (drained == 4096 && result <= 2147479551L);
    return (int)result;
  }


  
  public int drain(MessagePassingQueue.Consumer<E> c, int limit) {
    LinkedQueueNode<E> chaserNode = this.consumerNode;
    for (int i = 0; i < limit; i++) {
      
      LinkedQueueNode<E> nextNode = chaserNode.lvNext();
      
      if (nextNode == null)
      {
        return i;
      }
      
      E nextValue = getSingleConsumerNodeValue(chaserNode, nextNode);
      chaserNode = nextNode;
      c.accept(nextValue);
    } 
    return limit;
  }


  
  public void drain(MessagePassingQueue.Consumer<E> c, MessagePassingQueue.WaitStrategy wait, MessagePassingQueue.ExitCondition exit) {
    LinkedQueueNode<E> chaserNode = this.consumerNode;
    int idleCounter = 0;
    while (exit.keepRunning()) {
      
      for (int i = 0; i < 4096; i++) {
        
        LinkedQueueNode<E> nextNode = chaserNode.lvNext();
        if (nextNode == null) {
          
          idleCounter = wait.idle(idleCounter);
        }
        else {
          
          idleCounter = 0;
          
          E nextValue = getSingleConsumerNodeValue(chaserNode, nextNode);
          chaserNode = nextNode;
          c.accept(nextValue);
        } 
      } 
    } 
  }


  
  public int capacity() { return -1; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\jctools\queues\BaseLinkedQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */