package org.neo4j.graphalgo.impl.similarity;

import java.util.Arrays;
import java.util.Comparator;
import java.util.function.ToIntFunction;
import java.util.stream.Stream;
import org.neo4j.graphalgo.impl.results.SimilarityResult;



















public class AnnTopKConsumer
  implements ToIntFunction<SimilarityResult>
{
  private final int topK;
  private final SimilarityResult[] heap;
  private final Comparator<SimilarityResult> comparator;
  private int count;
  private SimilarityResult minValue;
  private SimilarityResult maxValue;
  
  public AnnTopKConsumer(int topK, Comparator<SimilarityResult> comparator) {
    this.topK = topK;
    this.heap = new SimilarityResult[topK];
    this.comparator = comparator;
    this.count = 0;
    this.minValue = null;
    this.maxValue = null;
  }
  
  public static AnnTopKConsumer[] initializeTopKConsumers(int length, int initialTopK) {
    int topK = initialTopK;
    Comparator<SimilarityResult> comparator = (topK > 0) ? SimilarityResult.DESCENDING : SimilarityResult.ASCENDING;
    topK = Math.abs(topK);
    
    AnnTopKConsumer[] results = new AnnTopKConsumer[length];
    for (int i = 0; i < results.length; ) { results[i] = new AnnTopKConsumer(topK, comparator); i++; }
     return results;
  }

  
  public Stream<SimilarityResult> stream() { return (this.count < this.topK) ? Arrays.stream(this.heap, 0, this.count) : Arrays.stream(this.heap); }

  
  public int apply(AnnTopKConsumer other) {
    int changes = 0;
    if (this.minValue == null || this.count < this.topK || (other.maxValue != null && this.comparator.compare(other.maxValue, this.minValue) < 0)) {
      for (int i = 0; i < other.count; i++) {
        changes += applyAsInt(other.heap[i]);
      }
    }
    return changes;
  }

  
  public int applyAsInt(SimilarityResult item) {
    if (this.count < this.topK || this.minValue == null || this.comparator.compare(item, this.minValue) < 0) {
      if (heapAlreadyHasItem(item)) {
        return 0;
      }
      
      int idx = Arrays.binarySearch(this.heap, 0, this.count, item, this.comparator);
      idx = (idx < 0) ? -idx : (idx + 1);
      
      int length = this.topK - idx;
      if (length > 0 && idx < this.topK) System.arraycopy(this.heap, idx - 1, this.heap, idx, length); 
      this.heap[idx - 1] = item;
      if (this.count < this.topK) this.count++; 
      this.minValue = this.heap[this.count - 1];
      this.maxValue = this.heap[0];
      return 1;
    } 
    return 0;
  }
  
  private boolean heapAlreadyHasItem(SimilarityResult item) {
    for (int i = 0; i < this.count; i++) {
      if (this.heap[i].sameItems(item)) {
        return true;
      }
    } 

    
    return false;
  }

  
  public String toString() {
    return "AnnTopKConsumer{heap=" + 
      Arrays.toString((Object[])this.heap) + '}';
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\similarity\AnnTopKConsumer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */