package org.petitparser.parser.combinators;

import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.parser.Parser;





public class AndParser
  extends DelegateParser
{
  public AndParser(Parser delegate) { super(delegate); }


  
  public Result parseOn(Context context) {
    Result result = this.delegate.parseOn(context);
    if (result.isSuccess()) {
      return (Result)context.success(result.get());
    }
    return result;
  }



  
  public AndParser copy() { return new AndParser(this.delegate); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\combinators\AndParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */