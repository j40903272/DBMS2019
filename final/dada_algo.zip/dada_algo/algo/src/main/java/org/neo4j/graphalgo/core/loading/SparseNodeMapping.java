package org.neo4j.graphalgo.core.loading;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.locks.ReentrantLock;
import org.neo4j.graphalgo.core.utils.mem.MemoryRange;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.PageUtil;






















public final class SparseNodeMapping
{
  private static final long NOT_FOUND = -1L;
  private static final int PAGE_SHIFT = 12;
  private static final int PAGE_SIZE = 4096;
  private static final int PAGE_MASK = 4095;
  private static final long PAGE_SIZE_IN_BYTES = MemoryUsage.sizeOfLongArray(4096);
  
  private final long capacity;
  private final long[][] pages;
  
  private SparseNodeMapping(long capacity, long[][] pages) {
    this.capacity = capacity;
    this.pages = pages;
  }





  
  public static MemoryRange memoryEstimation(long maxId, long maxEntries) {
    assert maxEntries <= maxId;
    int numPagesForSize = PageUtil.numPagesFor(maxId, 12, 4095L);
    int numPagesForMaxEntriesBestCase = PageUtil.numPagesFor(maxEntries, 12, 4095L);

    
    long maxEntriesForWorstCase = Math.min(maxId, maxEntries * 4096L);
    int numPagesForMaxEntriesWorstCase = PageUtil.numPagesFor(maxEntriesForWorstCase, 12, 4095L);
    
    long classSize = MemoryUsage.sizeOfInstance(SparseNodeMapping.class);
    long pagesSize = MemoryUsage.sizeOfObjectArray(numPagesForSize);
    long minRequirements = numPagesForMaxEntriesBestCase * PAGE_SIZE_IN_BYTES;
    long maxRequirements = numPagesForMaxEntriesWorstCase * PAGE_SIZE_IN_BYTES;
    return MemoryRange.of(classSize + pagesSize).add(MemoryRange.of(minRequirements, maxRequirements));
  }

  
  public long getCapacity() { return this.capacity; }

  
  public long get(long index) {
    int pageIndex = pageIndex(index);
    if (pageIndex < this.pages.length) {
      long[] page = this.pages[pageIndex];
      if (page != null) {
        return page[indexInPage(index)];
      }
    } 
    return -1L;
  }
  
  public boolean contains(long index) {
    int pageIndex = pageIndex(index);
    if (pageIndex < this.pages.length) {
      long[] page = this.pages[pageIndex];
      if (page != null) {
        return (page[indexInPage(index)] != -1L);
      }
    } 
    return false;
  }

  
  private static int pageIndex(long index) { return (int)(index >>> 12L); }


  
  private static int indexInPage(long index) { return (int)(index & 0xFFFL); }

  
  public static final class Builder
  {
    private final long capacity;
    
    private final AtomicReferenceArray<long[]> pages;
    private final AllocationTracker tracker;
    private final ReentrantLock newPageLock;
    
    public static Builder create(long size, AllocationTracker tracker) {
      int numPages = PageUtil.numPagesFor(size, 12, 4095L);
      long capacity = PageUtil.capacityFor(numPages, 12);
      AtomicReferenceArray<long[]> pages = (AtomicReferenceArray)new AtomicReferenceArray<>(numPages);
      tracker.add(MemoryUsage.sizeOfObjectArray(numPages));
      return new Builder(capacity, pages, tracker);
    }
    
    private Builder(long capacity, AtomicReferenceArray<long[]> pages, AllocationTracker tracker) {
      this.capacity = capacity;
      this.pages = pages;
      this.tracker = tracker;
      this.newPageLock = new ReentrantLock(true);
    }
    
    public void set(long index, long value) {
      assert index < this.capacity;
      int pageIndex = SparseNodeMapping.pageIndex(index);
      int indexInPage = SparseNodeMapping.indexInPage(index);
      long[] page = this.pages.get(pageIndex);
      if (page == null) {
        page = allocateNewPage(pageIndex);
      }
      page[indexInPage] = value;
    }
    
    public SparseNodeMapping build() {
      int numPages = this.pages.length();
      long capacity = PageUtil.capacityFor(numPages, 12);
      long[][] pages = new long[numPages][];
      Arrays.setAll(pages, this.pages::get);
      return new SparseNodeMapping(capacity, pages, null);
    }

    
    private long[] allocateNewPage(int pageIndex) {
      this.newPageLock.lock();
      try {
        long[] page = this.pages.get(pageIndex);
        if (page != null) {
          return page;
        }
        this.tracker.add(PAGE_SIZE_IN_BYTES);
        page = new long[4096];
        Arrays.fill(page, -1L);
        this.pages.set(pageIndex, page);
        return page;
      } finally {
        this.newPageLock.unlock();
      } 
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\SparseNodeMapping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */