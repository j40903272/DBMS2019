package org.neo4j.graphalgo.core.huge;

import java.util.Arrays;
import org.neo4j.graphalgo.core.loading.MutableIntValue;






























final class AdjacencyDecompressingReader
{
  private static final int CHUNK_SIZE = 64;
  private final long[] block = new long[64];
  private int pos;
  private byte[] array;
  private int offset;
  
  static int readInt(byte[] array, int offset) { return array[offset] & 0xFF | (array[1 + offset] & 0xFF) << 8 | (array[2 + offset] & 0xFF) << 16 | (array[3 + offset] & 0xFF) << 24; }







  
  static long readLong(byte[] array, int offset) { return array[offset] & 0xFFL | (array[1 + offset] & 0xFFL) << 8L | (array[2 + offset] & 0xFFL) << 16L | (array[3 + offset] & 0xFFL) << 24L | (array[4 + offset] & 0xFFL) << 32L | (array[5 + offset] & 0xFFL) << 40L | (array[6 + offset] & 0xFFL) << 48L | (array[7 + offset] & 0xFFL) << 56L; }









  
  void copyFrom(AdjacencyDecompressingReader other) {
    System.arraycopy(other.block, 0, this.block, 0, 64);
    this.pos = other.pos;
    this.array = other.array;
    this.offset = other.offset;
  }
  
  int reset(byte[] adjacencyPage, int offset) {
    this.array = adjacencyPage;
    int numAdjacencies = readInt(adjacencyPage, offset);
    this.offset = VarLongDecoding.decodeDeltaVLongs(0L, adjacencyPage, 4 + offset, Math.min(numAdjacencies, 64), this.block);
    this.pos = 0;
    return numAdjacencies;
  }
  
  long next(int remaining) {
    int pos = this.pos++;
    if (pos < 64) {
      return this.block[pos];
    }
    return readNextBlock(remaining);
  }
  
  private long readNextBlock(int remaining) {
    this.pos = 1;
    this.offset = VarLongDecoding.decodeDeltaVLongs(this.block[63], this.array, this.offset, Math.min(remaining, 64), this.block);
    return this.block[0];
  }
  
  long skipUntil(long target, int remaining, MutableIntValue consumed) {
    int pos = this.pos;
    long[] block = this.block;
    int available = remaining;

    
    while (available > 64 - pos && block[63] <= target) {
      int skippedInThisBlock = 64 - pos;
      int needToDecode = Math.min(64, available - skippedInThisBlock);
      this.offset = VarLongDecoding.decodeDeltaVLongs(block[63], this.array, this.offset, needToDecode, block);
      available -= skippedInThisBlock;
      pos = 0;
    } 

    
    int targetPos = findPosStrictlyGreaterInBlock(target, pos, Math.min(pos + available, 64), block);
    
    available -= 1 + targetPos - pos;
    consumed.value = remaining - available;
    this.pos = 1 + targetPos;
    return block[targetPos];
  }
  
  long advance(long target, int remaining, MutableIntValue consumed) {
    int pos = this.pos;
    long[] block = this.block;
    int available = remaining;

    
    while (available > 64 - pos && block[63] < target) {
      int skippedInThisBlock = 64 - pos;
      int needToDecode = Math.min(64, available - skippedInThisBlock);
      this.offset = VarLongDecoding.decodeDeltaVLongs(block[63], this.array, this.offset, needToDecode, block);
      available -= skippedInThisBlock;
      pos = 0;
    } 

    
    int targetPos = findPosInBlock(target, pos, Math.min(pos + available, 64), block);
    
    available -= 1 + targetPos - pos;
    consumed.value = remaining - available;
    this.pos = 1 + targetPos;
    return block[targetPos];
  }

  
  private int findPosStrictlyGreaterInBlock(long target, int pos, int limit, long[] block) { return findPosInBlock(1L + target, pos, limit, block); }

  
  private int findPosInBlock(long target, int pos, int limit, long[] block) {
    int targetPos = Arrays.binarySearch(block, pos, limit, target);
    if (targetPos < 0) {
      targetPos = Math.min(-1 - targetPos, -1 + limit);
    }
    return targetPos;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\huge\AdjacencyDecompressingReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */