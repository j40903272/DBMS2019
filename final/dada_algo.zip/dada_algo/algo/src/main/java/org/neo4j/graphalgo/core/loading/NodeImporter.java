package org.neo4j.graphalgo.core.loading;

import com.carrotsearch.hppc.IntObjectHashMap;
import com.carrotsearch.hppc.IntObjectMap;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import org.neo4j.graphalgo.core.utils.RawValues;
import org.neo4j.graphalgo.core.utils.paged.HugeArrayBuilder;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArrayBuilder;
import org.neo4j.internal.kernel.api.CursorFactory;
import org.neo4j.internal.kernel.api.PropertyCursor;
import org.neo4j.internal.kernel.api.Read;
import org.neo4j.values.storable.Value;

























public class NodeImporter
{
  private final HugeLongArrayBuilder idMapBuilder;
  private final IntObjectMap<NodePropertiesBuilder> buildersByPropertyId;
  private final Collection<NodePropertiesBuilder> nodePropertyBuilders;
  
  public NodeImporter(HugeLongArrayBuilder idMapBuilder, Collection<NodePropertiesBuilder> nodePropertyBuilders) {
    this.idMapBuilder = idMapBuilder;
    this.buildersByPropertyId = mapBuildersByPropertyId(nodePropertyBuilders);
    this.nodePropertyBuilders = nodePropertyBuilders;
  }

  
  boolean readsProperties() { return (this.buildersByPropertyId != null); }

  
  long importNodes(NodesBatchBuffer buffer, Read read, CursorFactory cursors) {
    return importNodes(buffer, (nodeReference, propertiesReference, internalId) -> 
        readProperty(nodeReference, propertiesReference, this.buildersByPropertyId, internalId, cursors, read));
  }
  
  long importCypherNodes(NodesBatchBuffer buffer, List<Map<String, Number>> cypherNodeProperties) {
    return importNodes(buffer, (nodeReference, propertiesReference, internalId) -> 
        readCypherProperty(propertiesReference, internalId, cypherNodeProperties));
  }
  
  public long importNodes(NodesBatchBuffer buffer, PropertyReader reader) {
    int batchLength = buffer.length();
    if (batchLength == 0) {
      return 0L;
    }
    
    HugeArrayBuilder.BulkAdder<long[]> adder = this.idMapBuilder.allocate(batchLength);
    if (adder == null) {
      return 0L;
    }
    
    int importedProperties = 0;
    
    long[] batch = buffer.batch();
    long[] properties = buffer.properties();
    int batchOffset = 0;
    while (adder.nextBuffer()) {
      int length = adder.length;
      System.arraycopy(batch, batchOffset, adder.buffer, adder.offset, length);
      
      if (properties != null) {
        long start = adder.start;
        for (int i = 0; i < length; i++) {
          long localIndex = start + i;
          int batchIndex = batchOffset + i;
          importedProperties += reader.readProperty(batch[batchIndex], properties[batchIndex], localIndex);
        } 
      } 



      
      batchOffset += length;
    } 
    return RawValues.combineIntInt(batchLength, importedProperties);
  }






  
  private int readProperty(long nodeReference, long propertiesReference, IntObjectMap<NodePropertiesBuilder> nodeProperties, long internalId, CursorFactory cursors, Read read) {
    try (PropertyCursor pc = cursors.allocatePropertyCursor()) {
      read.nodeProperties(nodeReference, propertiesReference, pc);
      int nodePropertiesRead = 0;
      while (pc.next()) {
        NodePropertiesBuilder props = (NodePropertiesBuilder)nodeProperties.get(pc.propertyKey());
        if (props != null) {
          Value value = pc.propertyValue();
          double defaultValue = props.defaultValue();
          double propertyValue = ReadHelper.extractValue(value, defaultValue);
          props.set(internalId, propertyValue);
          nodePropertiesRead++;
        } 
      } 
      return nodePropertiesRead;
    } 
  }



  
  private int readCypherProperty(long propertiesReference, long internalId, List<Map<String, Number>> cypherNodeProperties) {
    Map<String, Number> properties = cypherNodeProperties.get((int)propertiesReference);
    int nodePropertiesRead = 0;
    for (NodePropertiesBuilder props : this.nodePropertyBuilders) {
      Number propertyValue = properties.get(props.propertyKey());
      if (propertyValue != null) {
        props.set(internalId, propertyValue.doubleValue());
        nodePropertiesRead++;
      } 
    } 
    return nodePropertiesRead;
  }

  
  private IntObjectMap<NodePropertiesBuilder> mapBuildersByPropertyId(Collection<NodePropertiesBuilder> builders) {
    if (builders == null) {
      return null;
    }
    IntObjectHashMap intObjectHashMap = new IntObjectHashMap(builders.size());
    builders.stream().filter(builder -> (builder.propertyId() >= 0)).forEach(builder -> (NodePropertiesBuilder)map.put(builder.propertyId(), builder));
    return intObjectHashMap.isEmpty() ? null : (IntObjectMap<NodePropertiesBuilder>)intObjectHashMap;
  }
  
  static interface PropertyReader {
    int readProperty(long param1Long1, long param1Long2, long param1Long3);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\NodeImporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */