package org.petitparser.parser.primitive;

import java.util.Objects;
import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.parser.Parser;






public class FailureParser
  extends Parser
{
  private final String message;
  
  public static Parser withMessage(String message) { return new FailureParser(message); }




  
  private FailureParser(String message) { this.message = Objects.requireNonNull(message, "Undefined message"); }



  
  public Result parseOn(Context context) { return (Result)context.failure(this.message); }


  
  protected boolean hasEqualProperties(Parser other) {
    return (super.hasEqualProperties(other) && 
      Objects.equals(this.message, ((FailureParser)other).message));
  }


  
  public FailureParser copy() { return new FailureParser(this.message); }



  
  public String toString() { return super.toString() + "[" + this.message + "]"; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\primitive\FailureParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */