package org.neo4j.graphalgo.core.utils.container;

import java.util.Arrays;
import java.util.function.IntPredicate;


























public class Buckets
{
  private final int[] buckets;
  
  public Buckets(int capacity) {
    this.buckets = new int[capacity];
    reset();
  }




  
  public void reset() { Arrays.fill(this.buckets, -1); }






  
  public boolean isEmpty() {
    for (int i = 0; i < this.buckets.length; i++) {
      if (this.buckets[i] != -1) {
        return false;
      }
    } 
    return true;
  }







  
  public void set(int nodeId, int bucket) { this.buckets[nodeId] = bucket; }






  
  public int nextNonEmptyBucket() {
    int min = Integer.MAX_VALUE;
    for (int i = 0; i < this.buckets.length; i++) {
      int bucket = this.buckets[i];
      if (bucket != -1)
      {
        
        if (bucket < min)
          min = bucket; 
      }
    } 
    return min;
  }







  
  public void forEachInBucket(int bucket, IntPredicate consumer) {
    for (int nodeId = 0; nodeId < this.buckets.length; nodeId++) {
      int tb = this.buckets[nodeId];
      if (tb == bucket) {
        this.buckets[nodeId] = -1;
        if (!consumer.test(nodeId))
          return; 
      } 
    } 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\container\Buckets.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */