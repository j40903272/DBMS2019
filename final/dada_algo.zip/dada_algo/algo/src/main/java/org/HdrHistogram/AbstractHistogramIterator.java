package org.HdrHistogram;

import java.util.ConcurrentModificationException;
import java.util.Iterator;















abstract class AbstractHistogramIterator
  implements Iterator<HistogramIterationValue>
{
  AbstractHistogram histogram;
  long savedHistogramTotalRawCount;
  int currentIndex;
  long currentValueAtIndex;
  long nextValueAtIndex;
  long prevValueIteratedTo;
  long totalCountToPrevIndex;
  long totalCountToCurrentIndex;
  long totalValueToCurrentIndex;
  long arrayTotalCount;
  long countAtThisValue;
  private boolean freshSubBucket;
  final HistogramIterationValue currentIterationValue = new HistogramIterationValue();
  
  private double integerToDoubleValueConversionRatio;
  
  void resetIterator(AbstractHistogram histogram) {
    this.histogram = histogram;
    this.savedHistogramTotalRawCount = histogram.getTotalCount();
    this.arrayTotalCount = histogram.getTotalCount();
    this.integerToDoubleValueConversionRatio = histogram.getIntegerToDoubleValueConversionRatio();
    this.currentIndex = 0;
    this.currentValueAtIndex = 0L;
    this.nextValueAtIndex = (1 << histogram.unitMagnitude);
    this.prevValueIteratedTo = 0L;
    this.totalCountToPrevIndex = 0L;
    this.totalCountToCurrentIndex = 0L;
    this.totalValueToCurrentIndex = 0L;
    this.countAtThisValue = 0L;
    this.freshSubBucket = true;
    this.currentIterationValue.reset();
  }







  
  public boolean hasNext() {
    if (this.histogram.getTotalCount() != this.savedHistogramTotalRawCount) {
      throw new ConcurrentModificationException();
    }
    return (this.totalCountToCurrentIndex < this.arrayTotalCount);
  }







  
  public HistogramIterationValue next() {
    while (!exhaustedSubBuckets()) {
      this.countAtThisValue = this.histogram.getCountAtIndex(this.currentIndex);
      if (this.freshSubBucket) {
        this.totalCountToCurrentIndex += this.countAtThisValue;
        this.totalValueToCurrentIndex += this.countAtThisValue * this.histogram.highestEquivalentValue(this.currentValueAtIndex);
        this.freshSubBucket = false;
      } 
      if (reachedIterationLevel()) {
        long valueIteratedTo = getValueIteratedTo();
        this.currentIterationValue.set(valueIteratedTo, this.prevValueIteratedTo, this.countAtThisValue, this.totalCountToCurrentIndex - this.totalCountToPrevIndex, this.totalCountToCurrentIndex, this.totalValueToCurrentIndex, 100.0D * this.totalCountToCurrentIndex / this.arrayTotalCount, 

            
            getPercentileIteratedTo(), this.integerToDoubleValueConversionRatio);
        this.prevValueIteratedTo = valueIteratedTo;
        this.totalCountToPrevIndex = this.totalCountToCurrentIndex;
        
        incrementIterationLevel();
        if (this.histogram.getTotalCount() != this.savedHistogramTotalRawCount) {
          throw new ConcurrentModificationException();
        }
        return this.currentIterationValue;
      } 
      incrementSubBucket();
    } 
    
    throw new ArrayIndexOutOfBoundsException();
  }





  
  public void remove() { throw new UnsupportedOperationException(); }









  
  double getPercentileIteratedTo() { return 100.0D * this.totalCountToCurrentIndex / this.arrayTotalCount; }


  
  double getPercentileIteratedFrom() { return 100.0D * this.totalCountToPrevIndex / this.arrayTotalCount; }


  
  long getValueIteratedTo() { return this.histogram.highestEquivalentValue(this.currentValueAtIndex); }


  
  private boolean exhaustedSubBuckets() { return (this.currentIndex >= this.histogram.countsArrayLength); }

  
  void incrementSubBucket() {
    this.freshSubBucket = true;
    
    this.currentIndex++;
    this.currentValueAtIndex = this.histogram.valueFromIndex(this.currentIndex);
    
    this.nextValueAtIndex = this.histogram.valueFromIndex(this.currentIndex + 1);
  }
  
  abstract void incrementIterationLevel();
  
  abstract boolean reachedIterationLevel();
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\AbstractHistogramIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */