package org.neo4j.graphalgo.core.utils;

import java.util.function.DoubleUnaryOperator;
import java.util.function.IntUnaryOperator;
import java.util.function.LongUnaryOperator;
import java.util.function.UnaryOperator;






















public final class Pointer
{
  public static class BoolPointer
  {
    public boolean v;
    
    public BoolPointer(boolean v) { this.v = v; }

    
    public BoolPointer map(Pointer.BooleanUnaryOperator function) {
      this.v = function.applyAsBoolean(this.v);
      return this;
    }
  }
  
  @FunctionalInterface
  public static interface BooleanUnaryOperator
  {
    boolean applyAsBoolean(boolean param1Boolean);
  }
  
  public static class IntPointer {
    public int v;
    
    public IntPointer(int v) { this.v = v; }

    
    public IntPointer map(IntUnaryOperator function) {
      this.v = function.applyAsInt(this.v);
      return this;
    }
  }
  
  public static class LongPointer
  {
    public long v;
    
    public LongPointer(long v) { this.v = v; }

    
    public LongPointer map(LongUnaryOperator function) {
      this.v = function.applyAsLong(this.v);
      return this;
    }
  }
  
  public static class DoublePointer
  {
    public double v;
    
    public DoublePointer(double v) { this.v = v; }

    
    public DoublePointer map(DoubleUnaryOperator function) {
      this.v = function.applyAsDouble(this.v);
      return this;
    }
  }
  
  public static class GenericPointer<G>
  {
    public G v;
    
    public GenericPointer(G v) { this.v = v; }

    
    public GenericPointer<G> map(UnaryOperator<G> function) {
      this.v = function.apply(this.v);
      return this;
    }
  }

  
  public static BoolPointer wrap(boolean v) { return new BoolPointer(v); }


  
  public static IntPointer wrap(int v) { return new IntPointer(v); }


  
  public static LongPointer wrap(long v) { return new LongPointer(v); }


  
  public static DoublePointer wrap(double v) { return new DoublePointer(v); }


  
  public static <T> GenericPointer<T> wrap(T v) { return new GenericPointer<>(v); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\Pointer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */