package org.neo4j.graphalgo.core.utils;

import java.util.function.Consumer;
import java.util.function.Function;
import org.neo4j.graphdb.Transaction;
import org.neo4j.kernel.api.KernelTransaction;
import org.neo4j.kernel.impl.core.ThreadToStatementContextBridge;
import org.neo4j.kernel.internal.GraphDatabaseAPI;

































public final class TransactionWrapper
{
  private final GraphDatabaseAPI db;
  private final ThreadToStatementContextBridge bridge;
  
  public TransactionWrapper(GraphDatabaseAPI db) { this(db, (ThreadToStatementContextBridge)db.getDependencyResolver().resolveDependency(ThreadToStatementContextBridge.class)); }



  
  public TransactionWrapper(GraphDatabaseAPI db, ThreadToStatementContextBridge bridge) {
    this.db = db;
    this.bridge = bridge;
  }
  
  public void accept(Consumer<KernelTransaction> block) {
    try (Transaction tx = this.db.beginTx()) {
      KernelTransaction transaction = this.bridge.getKernelTransactionBoundToThisThread(true);
      block.accept(transaction);
      tx.success();
    } 
  }
  
  public <T> T apply(Function<KernelTransaction, T> block) {
    try (Transaction tx = this.db.beginTx()) {
      KernelTransaction transaction = this.bridge.getKernelTransactionBoundToThisThread(true);
      T result = block.apply(transaction);
      tx.success();
      return result;
    } 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\TransactionWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */