package org.neo4j.graphalgo.core.loading;

import java.util.Arrays;





















public final class RadixSort
{
  private static final int RADIX = 8;
  private static final int HIST_SIZE = 256;
  
  public static int[] newHistogram(int length) { return new int[Math.max(length, 257)]; }


  
  public static long[] newCopy(long[] data) { return new long[data.length]; }


  
  public static void radixSort(long[] data, long[] copy, int[] histogram, int length) { radixSort(data, copy, histogram, length, 0); }

  
  private static void radixSort(long[] data, long[] copy, int[] histogram, int length, int shift) {
    int hlen = Math.min(256, histogram.length - 1);
    int dlen = Math.min(length, Math.min(data.length, copy.length));
    
    long loMask = 255L << shift, hiMask = -(256L << shift);

    
    while (shift < 64) {
      Arrays.fill(histogram, 0, 1 + hlen, 0);
      int maxHistIndex = 0;
      long hiBits = 0L;
      
      for (int i = 0; i < dlen; i += 4) {
        hiBits |= data[i] & hiMask;
        int histIndex = (int)((data[i] & loMask) >>> shift);
        maxHistIndex |= histIndex;
        histogram[1 + histIndex] = histogram[1 + histIndex] + 4;
      } 
      
      if (hiBits == 0L && maxHistIndex == 0) {
        return;
      }
      
      if (maxHistIndex != 0) {
        for (int i = 0; i < hlen; i++) {
          histogram[i + 1] = histogram[i + 1] + histogram[i];
        }
        
        for (int i = 0; i < dlen; i += 4) {
          int out = histogram[(int)((data[i] & loMask) >>> shift)] = histogram[(int)((data[i] & loMask) >>> shift)] + 4;
          copy[out - 4] = data[i];
          copy[out - 3] = data[1 + i];
          copy[out - 2] = data[2 + i];
          copy[out - 1] = data[3 + i];
        } 
        
        System.arraycopy(copy, 0, data, 0, dlen);
      } 
      
      shift += 8;
      loMask <<= 8L;
      hiMask <<= 8L;
    } 
  }

  
  public static void radixSort2(long[] data, long[] copy, int[] histogram, int length) { radixSort2(data, copy, histogram, length, 0); }

  
  private static void radixSort2(long[] data, long[] copy, int[] histogram, int length, int shift) {
    int hlen = Math.min(256, histogram.length - 1);
    int dlen = Math.min(length, Math.min(data.length, copy.length));
    Arrays.fill(histogram, 0, hlen, 0);
    
    long loMask = 255L << shift;
    for (int i = 0; i < dlen; i += 4) {
      histogram[1 + (int)((data[1 + i] & loMask) >>> shift)] = histogram[1 + (int)((data[1 + i] & loMask) >>> shift)] + 4;
    }
    
    for (int i = 0; i < hlen; i++) {
      histogram[i + 1] = histogram[i + 1] + histogram[i];
    }

    
    for (int i = 0; i < dlen; i += 4) {
      int out = histogram[(int)((data[1 + i] & loMask) >>> shift)] = histogram[(int)((data[1 + i] & loMask) >>> shift)] + 4;
      copy[out - 4] = data[1 + i];
      copy[out - 3] = data[i];
      copy[out - 2] = data[2 + i];
      copy[out - 1] = data[3 + i];
    } 
    
    System.arraycopy(copy, 0, data, 0, dlen);
    radixSort(data, copy, histogram, length, shift + 8);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\RadixSort.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */