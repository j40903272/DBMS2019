package org.neo4j.graphalgo;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Stream;
import org.neo4j.graphalgo.core.ProcedureConfiguration;
import org.neo4j.graphalgo.impl.nn.ApproxNearestNeighbors;
import org.neo4j.graphalgo.impl.results.ApproxSimilaritySummaryResult;
import org.neo4j.graphalgo.impl.results.SimilarityResult;
import org.neo4j.graphalgo.impl.similarity.AnnTopKConsumer;
import org.neo4j.graphalgo.impl.similarity.Computations;
import org.neo4j.graphalgo.impl.similarity.RleDecoder;
import org.neo4j.graphalgo.impl.similarity.SimilarityComputer;
import org.neo4j.graphalgo.impl.similarity.SimilarityInput;
import org.neo4j.graphalgo.impl.similarity.SimilarityRecorder;
import org.neo4j.graphalgo.similarity.CosineAlgorithm;
import org.neo4j.graphalgo.similarity.EuclideanAlgorithm;
import org.neo4j.graphalgo.similarity.JaccardAlgorithm;
import org.neo4j.graphalgo.similarity.PearsonAlgorithm;
import org.neo4j.graphalgo.similarity.SimilarityAlgorithm;
import org.neo4j.procedure.Description;
import org.neo4j.procedure.Mode;
import org.neo4j.procedure.Name;
import org.neo4j.procedure.Procedure;

























public class ApproxNearestNeighborsProc
  extends SimilarityProc
{
  @Procedure(name = "algo.labs.ml.ann.stream", mode = Mode.READ)
  @Description("CALL algo.labs.ml.ann.stream('jaccard|cosine|pearson|euclidean', [{item:id, weights:[weights]} or {item:id, categories:[ids]}], {similarityCutoff:-1,degreeCutoff:0}) YIELD item1, item2, count1, count2, intersection, similarity - computes nearest neighbors")
  public Stream<SimilarityResult> stream(@Name(value = "algorithm", defaultValue = "null") String algorithmName, @Name(value = "data", defaultValue = "null") Object rawData, @Name(value = "config", defaultValue = "{}") Map<String, Object> config) throws Exception {
    ProcedureConfiguration configuration = ProcedureConfiguration.create(config);
    Double skipValue = configuration.getSkipValue(Double.valueOf(NaND));
    
    SimilarityAlgorithm<SimilarityInput> algorithm = selectAlgorithm(algorithmName, configuration);
    
    SimilarityInput[] inputs = algorithm.prepareInputs(rawData, skipValue);
    
    if (inputs.length == 0) {
      return Stream.empty();
    }
    
    int topN = getTopN(configuration);
    Supplier<RleDecoder> decoderFactory = algorithm.createDecoderFactory(inputs[0]);
    
    double similarityCutoff = algorithm.similarityCutoff();
    SimilarityComputer<SimilarityInput> computer = algorithm.similarityComputer(skipValue);






    
    ApproxNearestNeighbors<SimilarityInput> approxNearestNeighbors = new ApproxNearestNeighbors(configuration, inputs, similarityCutoff, decoderFactory, computer, algorithm.topK(), this.log);
    
    approxNearestNeighbors.compute();
    
    AnnTopKConsumer[] topKConsumers = approxNearestNeighbors.result();
    
    return topN(Arrays.stream(topKConsumers).flatMap(AnnTopKConsumer::stream), topN).map(algorithm::postProcess);
  }




  
  @Procedure(name = "algo.labs.ml.ann", mode = Mode.WRITE)
  @Description("CALL algo.labs.ml.ann('jaccard|cosine|pearson|euclidean', [{item:id, weights:[weights]} or {item:id, categories:[ids]}], {similarityCutoff:-1,degreeCutoff:0}) YIELD item1, item2, count1, count2, intersection, similarity - computes nearest neighbors")
  public Stream<ApproxSimilaritySummaryResult> write(@Name(value = "algorithm", defaultValue = "null") String algorithmName, @Name(value = "data", defaultValue = "null") Object rawData, @Name(value = "config", defaultValue = "{}") Map<String, Object> config) throws Exception {
    ProcedureConfiguration configuration = ProcedureConfiguration.create(config);
    Double skipValue = configuration.getSkipValue(Double.valueOf(NaND));
    
    SimilarityAlgorithm<SimilarityInput> algorithm = selectAlgorithm(algorithmName, configuration);
    
    SimilarityInput[] inputs = algorithm.prepareInputs(rawData, skipValue);
    
    String writeRelationshipType = (String)configuration.get("writeRelationshipType", "SIMILAR");
    String writeProperty = configuration.getWriteProperty("score");
    if (inputs.length == 0) {
      return Stream.empty();
    }
    
    int topN = getTopN(configuration);
    Supplier<RleDecoder> decoderFactory = algorithm.createDecoderFactory(inputs[0]);
    
    double similarityCutoff = algorithm.similarityCutoff();
    SimilarityRecorder<SimilarityInput> recorder = algorithm.similarityRecorder(algorithm.similarityComputer(skipValue), configuration);






    
    ApproxNearestNeighbors<SimilarityInput> approxNearestNeighbors = new ApproxNearestNeighbors(configuration, inputs, similarityCutoff, decoderFactory, (SimilarityComputer)recorder, algorithm.topK(), this.log);
    
    try {
      approxNearestNeighbors.compute();
      
      AnnTopKConsumer[] topKConsumers = approxNearestNeighbors.result();
      
      Stream<SimilarityResult> stream = topN(Arrays.stream(topKConsumers).flatMap(AnnTopKConsumer::stream), topN).map(algorithm::postProcess);

      
      boolean write = configuration.isWriteFlag(false);
      
      return writeAndAggregateApproxResults(stream, inputs.length, configuration, write, writeRelationshipType, writeProperty, approxNearestNeighbors





          
          .iterations(), (Computations)recorder);
    }
    catch (Exception e) {
      e.printStackTrace();
      return Stream.empty();
    } 
  }

  
  private SimilarityAlgorithm selectAlgorithm(String algorithm, ProcedureConfiguration configuration) {
    switch (algorithm) {
      case "cosine":
        return (SimilarityAlgorithm)new CosineAlgorithm(this.api, configuration);
      case "pearson":
        return (SimilarityAlgorithm)new PearsonAlgorithm(this.api, configuration);
      case "jaccard":
        return (SimilarityAlgorithm)new JaccardAlgorithm(configuration);
      case "euclidean":
        return (SimilarityAlgorithm)new EuclideanAlgorithm(this.api, configuration);
    } 
    throw new IllegalArgumentException("Unknown algorithm: " + algorithm);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\ApproxNearestNeighborsProc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */