package org.roaringbitmap;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.nio.LongBuffer;
import java.util.Arrays;
import java.util.Iterator;
import org.roaringbitmap.buffer.MappeableBitmapContainer;
import org.roaringbitmap.buffer.MappeableContainer;






















public final class BitmapContainer
  extends Container
  implements Cloneable
{
  protected static final int MAX_CAPACITY = 65536;
  private static final long serialVersionUID = 2L;
  private static final int BLOCKSIZE = 128;
  public static final boolean USE_BRANCHLESS = true;
  final long[] bitmap;
  int cardinality;
  
  public static ShortIterator getReverseShortIterator(long[] bitmap) { return new ReverseBitmapContainerShortIterator(bitmap); }








  
  public static PeekableShortIterator getShortIterator(long[] bitmap) { return new BitmapContainerShortIterator(bitmap); }



  
  protected static int serializedSizeInBytes(int unusedCardinality) { return 8192; }







  
  private final int MAXRUNS = (getArraySizeInBytes() - 2) / 4;




  
  public BitmapContainer() {
    this.cardinality = 0;
    this.bitmap = new long[1024];
  }









  
  public BitmapContainer(int firstOfRun, int lastOfRun) {
    this.cardinality = lastOfRun - firstOfRun;
    this.bitmap = new long[1024];
    Util.setBitmapRange(this.bitmap, firstOfRun, lastOfRun);
  }
  
  private BitmapContainer(int newCardinality, long[] newBitmap) {
    this.cardinality = newCardinality;
    this.bitmap = Arrays.copyOf(newBitmap, newBitmap.length);
  }






  
  public BitmapContainer(long[] newBitmap, int newCardinality) {
    this.cardinality = newCardinality;
    this.bitmap = newBitmap;
  }







  
  public BitmapContainer(MappeableBitmapContainer bc) {
    this.cardinality = bc.getCardinality();
    this.bitmap = bc.toLongArray();
  }



  
  public Container add(int begin, int end) {
    if (end == begin) {
      return clone();
    }
    if (begin > end || end > 65536) {
      throw new IllegalArgumentException("Invalid range [" + begin + "," + end + ")");
    }
    BitmapContainer answer = clone();
    int prevOnesInRange = answer.cardinalityInRange(begin, end);
    Util.setBitmapRange(answer.bitmap, begin, end);
    answer.updateCardinality(prevOnesInRange, end - begin);
    return answer;
  }



  
  public Container add(short i) {
    int x = Util.toIntUnsigned(i);
    long previous = this.bitmap[x / 64];
    long newval = previous | 1L << x;
    this.bitmap[x / 64] = newval;
    
    this.cardinality = (int)(this.cardinality + ((previous ^ newval) >>> x));


    
    return this;
  }

  
  public ArrayContainer and(ArrayContainer value2) {
    ArrayContainer answer = new ArrayContainer(value2.content.length);
    int c = value2.cardinality;
    for (int k = 0; k < c; k++) {
      short v = value2.content[k];
      answer.content[answer.cardinality] = v;
      answer.cardinality = (int)(answer.cardinality + bitValue(v));
    } 
    return answer;
  }

  
  public Container and(BitmapContainer value2) {
    int newCardinality = 0;
    for (int k = 0; k < this.bitmap.length; k++) {
      newCardinality += Long.bitCount(this.bitmap[k] & value2.bitmap[k]);
    }
    if (newCardinality > 4096) {
      BitmapContainer answer = new BitmapContainer();
      for (int k = 0; k < answer.bitmap.length; k++) {
        answer.bitmap[k] = this.bitmap[k] & value2.bitmap[k];
      }
      answer.cardinality = newCardinality;
      return answer;
    } 
    ArrayContainer ac = new ArrayContainer(newCardinality);
    Util.fillArrayAND(ac.content, this.bitmap, value2.bitmap);
    ac.cardinality = newCardinality;
    return ac;
  }


  
  public Container and(RunContainer x) { return x.and(this); }


  
  public int andCardinality(ArrayContainer value2) {
    int answer = 0;
    int c = value2.cardinality;
    for (int k = 0; k < c; k++) {
      short v = value2.content[k];
      answer = (int)(answer + bitValue(v));
    } 
    return answer;
  }

  
  public int andCardinality(BitmapContainer value2) {
    int newCardinality = 0;
    for (int k = 0; k < this.bitmap.length; k++) {
      newCardinality += Long.bitCount(this.bitmap[k] & value2.bitmap[k]);
    }
    return newCardinality;
  }


  
  public int andCardinality(RunContainer x) { return x.andCardinality(this); }


  
  public Container andNot(ArrayContainer value2) {
    BitmapContainer answer = clone();
    int c = value2.cardinality;
    for (int k = 0; k < c; k++) {
      short v = value2.content[k];
      int i = Util.toIntUnsigned(v) >>> 6;
      long w = answer.bitmap[i];
      long aft = w & (1L << v ^ 0xFFFFFFFFFFFFFFFFL);
      answer.bitmap[i] = aft;
      answer.cardinality = (int)(answer.cardinality - ((w ^ aft) >>> v));
    } 
    if (answer.cardinality <= 4096) {
      return answer.toArrayContainer();
    }
    return answer;
  }

  
  public Container andNot(BitmapContainer value2) {
    int newCardinality = 0;
    for (int k = 0; k < this.bitmap.length; k++) {
      newCardinality += Long.bitCount(this.bitmap[k] & (value2.bitmap[k] ^ 0xFFFFFFFFFFFFFFFFL));
    }
    if (newCardinality > 4096) {
      BitmapContainer answer = new BitmapContainer();
      for (int k = 0; k < answer.bitmap.length; k++) {
        answer.bitmap[k] = this.bitmap[k] & (value2.bitmap[k] ^ 0xFFFFFFFFFFFFFFFFL);
      }
      answer.cardinality = newCardinality;
      return answer;
    } 
    ArrayContainer ac = new ArrayContainer(newCardinality);
    Util.fillArrayANDNOT(ac.content, this.bitmap, value2.bitmap);
    ac.cardinality = newCardinality;
    return ac;
  }


  
  public Container andNot(RunContainer x) {
    BitmapContainer answer = clone();
    for (int rlepos = 0; rlepos < x.nbrruns; rlepos++) {
      int start = Util.toIntUnsigned(x.getValue(rlepos));
      int end = start + Util.toIntUnsigned(x.getLength(rlepos)) + 1;
      int prevOnesInRange = answer.cardinalityInRange(start, end);
      Util.resetBitmapRange(answer.bitmap, start, end);
      answer.updateCardinality(prevOnesInRange, 0);
    } 
    if (answer.getCardinality() > 4096) {
      return answer;
    }
    return answer.toArrayContainer();
  }


  
  public void clear() {
    if (this.cardinality != 0) {
      this.cardinality = 0;
      Arrays.fill(this.bitmap, 0L);
    } 
  }


  
  public BitmapContainer clone() { return new BitmapContainer(this.cardinality, this.bitmap); }



  
  public boolean isEmpty() { return (this.cardinality == 0); }




  
  protected void computeCardinality() {
    this.cardinality = 0;
    for (int k = 0; k < this.bitmap.length; k++) {
      this.cardinality += Long.bitCount(this.bitmap[k]);
    }
  }
  
  protected int cardinalityInRange(int start, int end) {
    assert this.cardinality != -1;
    if (end - start > 32768) {
      int before = Util.cardinalityInBitmapRange(this.bitmap, 0, start);
      int after = Util.cardinalityInBitmapRange(this.bitmap, end, 65536);
      return this.cardinality - before - after;
    } 
    return Util.cardinalityInBitmapRange(this.bitmap, start, end);
  }
  
  protected void updateCardinality(int prevOnes, int newOnes) {
    int oldCardinality = this.cardinality;
    this.cardinality = oldCardinality - prevOnes + newOnes;
  }

  
  public boolean contains(short i) {
    int x = Util.toIntUnsigned(i);
    return ((this.bitmap[x / 64] & 1L << x) != 0L);
  }

  
  public boolean contains(int minimum, int supremum) {
    int start = minimum >>> 6;
    int end = supremum >>> 6;
    long first = (1L << minimum) - 1L ^ 0xFFFFFFFFFFFFFFFFL;
    long last = (1L << supremum) - 1L;
    if (start == end) {
      return ((this.bitmap[end] & first & last) == (first & last));
    }
    if ((this.bitmap[start] & first) != first) {
      return false;
    }
    if (end < this.bitmap.length && (this.bitmap[end] & last) != last) {
      return false;
    }
    for (int i = start + 1; i < this.bitmap.length && i < end; i++) {
      if (this.bitmap[i] != -1L) {
        return false;
      }
    } 
    return true;
  }

  
  protected boolean contains(BitmapContainer bitmapContainer) {
    if (this.cardinality != -1 && bitmapContainer.cardinality != -1 && 
      this.cardinality < bitmapContainer.cardinality) {
      return false;
    }
    
    for (int i = 0; i < bitmapContainer.bitmap.length; i++) {
      if ((this.bitmap[i] & bitmapContainer.bitmap[i]) != bitmapContainer.bitmap[i]) {
        return false;
      }
    } 
    return true;
  }

  
  protected boolean contains(RunContainer runContainer) {
    int runCardinality = runContainer.getCardinality();
    if (this.cardinality != -1) {
      if (this.cardinality < runCardinality) {
        return false;
      }
    } else {
      int card = this.cardinality;
      if (card < runCardinality) {
        return false;
      }
    } 
    for (int i = 0; i < runContainer.numberOfRuns(); i++) {
      int start = Util.toIntUnsigned(runContainer.getValue(i));
      int length = Util.toIntUnsigned(runContainer.getLength(i));
      if (!contains(start, start + length)) {
        return false;
      }
    } 
    return true;
  }

  
  protected boolean contains(ArrayContainer arrayContainer) {
    if (arrayContainer.cardinality != -1 && 
      this.cardinality < arrayContainer.cardinality) {
      return false;
    }
    
    for (int i = 0; i < arrayContainer.cardinality; i++) {
      if (!contains(arrayContainer.content[i])) {
        return false;
      }
    } 
    return true;
  }

  
  protected long bitValue(short i) {
    int x = Util.toIntUnsigned(i);
    return this.bitmap[x / 64] >>> x & 0x1L;
  }



  
  public void deserialize(DataInput in) throws IOException {
    this.cardinality = 0;
    for (int k = 0; k < this.bitmap.length; k++) {
      long w = Long.reverseBytes(in.readLong());
      this.bitmap[k] = w;
      this.cardinality += Long.bitCount(w);
    } 
  }

  
  public boolean equals(Object o) {
    if (o instanceof BitmapContainer) {
      BitmapContainer srb = (BitmapContainer)o;
      if (srb.cardinality != this.cardinality) {
        return false;
      }
      return Arrays.equals(this.bitmap, srb.bitmap);
    }  if (o instanceof RunContainer) {
      return o.equals(this);
    }
    return false;
  }






  
  protected void fillArray(short[] array) {
    int pos = 0;
    int base = 0;
    for (int k = 0; k < this.bitmap.length; k++) {
      long bitset = this.bitmap[k];
      while (bitset != 0L) {
        array[pos++] = (short)(base + Long.numberOfTrailingZeros(bitset));
        bitset &= bitset - 1L;
      } 
      base += 64;
    } 
  }

  
  public void fillLeastSignificant16bits(int[] x, int i, int mask) {
    int pos = i;
    int base = mask;
    for (int k = 0; k < this.bitmap.length; k++) {
      long bitset = this.bitmap[k];
      while (bitset != 0L) {
        x[pos++] = base + Long.numberOfTrailingZeros(bitset);
        bitset &= bitset - 1L;
      } 
      base += 64;
    } 
  }


  
  public Container flip(short i) {
    int x = Util.toIntUnsigned(i);
    int index = x / 64;
    long bef = this.bitmap[index];
    long mask = 1L << x;
    if (this.cardinality == 4097)
    {

      
      if ((bef & mask) != 0L) {
        this.cardinality--;
        this.bitmap[index] = this.bitmap[index] & (mask ^ 0xFFFFFFFFFFFFFFFFL);
        return toArrayContainer();
      } 
    }
    
    this.cardinality = (int)(this.cardinality + 1L - 2L * ((bef & mask) >>> x));
    this.bitmap[index] = this.bitmap[index] ^ mask;
    return this;
  }


  
  protected int getArraySizeInBytes() { return 8192; }



  
  public int getCardinality() { return this.cardinality; }



  
  public ShortIterator getReverseShortIterator() { return new ReverseBitmapContainerShortIterator(this.bitmap); }



  
  public PeekableShortIterator getShortIterator() { return new BitmapContainerShortIterator(this.bitmap); }



  
  public PeekableShortRankIterator getShortRankIterator() { return new BitmapContainerShortRankIterator(this.bitmap); }



  
  public ContainerBatchIterator getBatchIterator() { return new BitmapBatchIterator(this); }



  
  public int getSizeInBytes() { return this.bitmap.length * 8; }



  
  public int hashCode() { return Arrays.hashCode(this.bitmap); }



  
  public Container iadd(int begin, int end) {
    if (end == begin) {
      return this;
    }
    if (begin > end || end > 65536) {
      throw new IllegalArgumentException("Invalid range [" + begin + "," + end + ")");
    }
    int prevOnesInRange = cardinalityInRange(begin, end);
    Util.setBitmapRange(this.bitmap, begin, end);
    updateCardinality(prevOnesInRange, end - begin);
    return this;
  }


  
  public Container iand(ArrayContainer b2) { return b2.and(this); }


  
  public Container iand(BitmapContainer b2) {
    int newCardinality = 0;
    for (int k = 0; k < this.bitmap.length; k++) {
      newCardinality += Long.bitCount(this.bitmap[k] & b2.bitmap[k]);
    }
    if (newCardinality > 4096) {
      for (int k = 0; k < this.bitmap.length; k++) {
        this.bitmap[k] = this.bitmap[k] & b2.bitmap[k];
      }
      this.cardinality = newCardinality;
      return this;
    } 
    ArrayContainer ac = new ArrayContainer(newCardinality);
    Util.fillArrayAND(ac.content, this.bitmap, b2.bitmap);
    ac.cardinality = newCardinality;
    return ac;
  }


  
  public Container iand(RunContainer x) {
    int card = x.getCardinality();
    if (card <= 4096) {
      
      ArrayContainer answer = new ArrayContainer(card);
      answer.cardinality = 0;
      for (int rlepos = 0; rlepos < x.nbrruns; rlepos++) {
        int runStart = Util.toIntUnsigned(x.getValue(rlepos));
        int runEnd = runStart + Util.toIntUnsigned(x.getLength(rlepos));
        for (int runValue = runStart; runValue <= runEnd; runValue++) {
          answer.content[answer.cardinality] = (short)runValue;
          answer.cardinality = (int)(answer.cardinality + bitValue((short)runValue));
        } 
      } 
      return answer;
    } 
    int start = 0;
    for (int rlepos = 0; rlepos < x.nbrruns; rlepos++) {
      int end = Util.toIntUnsigned(x.getValue(rlepos));
      int prevOnes = cardinalityInRange(start, end);
      Util.resetBitmapRange(this.bitmap, start, end);
      updateCardinality(prevOnes, 0);
      start = end + Util.toIntUnsigned(x.getLength(rlepos)) + 1;
    } 
    int ones = cardinalityInRange(start, 65536);
    Util.resetBitmapRange(this.bitmap, start, 65536);
    updateCardinality(ones, 0);
    if (getCardinality() > 4096) {
      return this;
    }
    return toArrayContainer();
  }


  
  public Container iandNot(ArrayContainer b2) {
    for (int k = 0; k < b2.cardinality; k++) {
      remove(b2.content[k]);
    }
    if (this.cardinality <= 4096) {
      return toArrayContainer();
    }
    return this;
  }

  
  public Container iandNot(BitmapContainer b2) {
    int newCardinality = 0;
    for (int k = 0; k < this.bitmap.length; k++) {
      newCardinality += Long.bitCount(this.bitmap[k] & (b2.bitmap[k] ^ 0xFFFFFFFFFFFFFFFFL));
    }
    if (newCardinality > 4096) {
      for (int k = 0; k < this.bitmap.length; k++) {
        this.bitmap[k] = this.bitmap[k] & (b2.bitmap[k] ^ 0xFFFFFFFFFFFFFFFFL);
      }
      this.cardinality = newCardinality;
      return this;
    } 
    ArrayContainer ac = new ArrayContainer(newCardinality);
    Util.fillArrayANDNOT(ac.content, this.bitmap, b2.bitmap);
    ac.cardinality = newCardinality;
    return ac;
  }


  
  public Container iandNot(RunContainer x) {
    for (int rlepos = 0; rlepos < x.nbrruns; rlepos++) {
      int start = Util.toIntUnsigned(x.getValue(rlepos));
      int end = start + Util.toIntUnsigned(x.getLength(rlepos)) + 1;
      int prevOnesInRange = cardinalityInRange(start, end);
      Util.resetBitmapRange(this.bitmap, start, end);
      updateCardinality(prevOnesInRange, 0);
    } 
    if (getCardinality() > 4096) {
      return this;
    }
    return toArrayContainer();
  }

  
  protected Container ilazyor(ArrayContainer value2) {
    this.cardinality = -1;
    int c = value2.cardinality;
    for (int k = 0; k < c; k++) {
      short v = value2.content[k];
      int i = Util.toIntUnsigned(v) >>> 6;
      this.bitmap[i] = this.bitmap[i] | 1L << v;
    } 
    return this;
  }
  
  protected Container ilazyor(BitmapContainer x) {
    this.cardinality = -1;
    for (int k = 0; k < this.bitmap.length; k++) {
      this.bitmap[k] = this.bitmap[k] | x.bitmap[k];
    }
    return this;
  }

  
  protected Container ilazyor(RunContainer x) {
    this.cardinality = -1;
    for (int rlepos = 0; rlepos < x.nbrruns; rlepos++) {
      int start = Util.toIntUnsigned(x.getValue(rlepos));
      int end = start + Util.toIntUnsigned(x.getLength(rlepos)) + 1;
      Util.setBitmapRange(this.bitmap, start, end);
    } 
    return this;
  }

  
  public Container inot(int firstOfRange, int lastOfRange) {
    int prevOnes = cardinalityInRange(firstOfRange, lastOfRange);
    Util.flipBitmapRange(this.bitmap, firstOfRange, lastOfRange);
    updateCardinality(prevOnes, lastOfRange - firstOfRange - prevOnes);
    if (this.cardinality <= 4096) {
      return toArrayContainer();
    }
    return this;
  }

  
  public boolean intersects(ArrayContainer value2) {
    int c = value2.cardinality;
    for (int k = 0; k < c; k++) {
      if (contains(value2.content[k])) {
        return true;
      }
    } 
    return false;
  }

  
  public boolean intersects(BitmapContainer value2) {
    for (int k = 0; k < this.bitmap.length; k++) {
      if ((this.bitmap[k] & value2.bitmap[k]) != 0L) {
        return true;
      }
    } 
    return false;
  }


  
  public boolean intersects(RunContainer x) { return x.intersects(this); }


  
  public boolean intersects(int minimum, int supremum) {
    int start = minimum >>> 6;
    int end = supremum >>> 6;
    if (start == end) {
      return ((this.bitmap[end] & ((1L << minimum) - 1L ^ 0xFFFFFFFFFFFFFFFFL) & (1L << supremum) - 1L) != 0L);
    }
    if ((this.bitmap[start] & ((1L << minimum) - 1L ^ 0xFFFFFFFFFFFFFFFFL)) != 0L) {
      return true;
    }
    if (end < this.bitmap.length && (this.bitmap[end] & (1L << supremum) - 1L) != 0L) {
      return true;
    }
    for (int i = 1 + start; i < end && i < this.bitmap.length; i++) {
      if (this.bitmap[i] != 0L) {
        return true;
      }
    } 
    return false;
  }

  
  public BitmapContainer ior(ArrayContainer value2) {
    int c = value2.cardinality;
    for (int k = 0; k < c; k++) {
      int i = Util.toIntUnsigned(value2.content[k]) >>> 6;
      
      long bef = this.bitmap[i];
      long aft = bef | 1L << value2.content[k];
      this.bitmap[i] = aft;
      
      this.cardinality = (int)(this.cardinality + (bef - aft >>> 63L));
    } 




    
    return this;
  }

  
  public Container ior(BitmapContainer b2) {
    this.cardinality = 0;
    for (int k = 0; k < this.bitmap.length; k++) {
      long w = this.bitmap[k] | b2.bitmap[k];
      this.bitmap[k] = w;
      this.cardinality += Long.bitCount(w);
    } 
    if (isFull()) {
      return RunContainer.full();
    }
    return this;
  }


  
  public Container ior(RunContainer x) {
    for (int rlepos = 0; rlepos < x.nbrruns; rlepos++) {
      int start = Util.toIntUnsigned(x.getValue(rlepos));
      int end = start + Util.toIntUnsigned(x.getLength(rlepos)) + 1;
      int prevOnesInRange = cardinalityInRange(start, end);
      Util.setBitmapRange(this.bitmap, start, end);
      updateCardinality(prevOnesInRange, end - start);
    } 
    if (isFull()) {
      return RunContainer.full();
    }
    return this;
  }

  
  public Container iremove(int begin, int end) {
    if (end == begin) {
      return this;
    }
    if (begin > end || end > 65536) {
      throw new IllegalArgumentException("Invalid range [" + begin + "," + end + ")");
    }
    int prevOnesInRange = cardinalityInRange(begin, end);
    Util.resetBitmapRange(this.bitmap, begin, end);
    updateCardinality(prevOnesInRange, 0);
    if (getCardinality() <= 4096) {
      return toArrayContainer();
    }
    return this;
  }

  
  public Iterator<Short> iterator() {
    return new Iterator<Short>() {
        final ShortIterator si = BitmapContainer.this.getShortIterator();


        
        public boolean hasNext() { return this.si.hasNext(); }



        
        public Short next() { return Short.valueOf(this.si.next()); }




        
        public void remove() { throw new RuntimeException("unsupported operation: remove"); }
      };
  }


  
  public Container ixor(ArrayContainer value2) {
    int c = value2.cardinality;
    for (int k = 0; k < c; k++) {
      short vc = value2.content[k];
      long mask = 1L << vc;
      int index = Util.toIntUnsigned(vc) >>> 6;
      long ba = this.bitmap[index];
      
      this.cardinality = (int)(this.cardinality + 1L - 2L * ((ba & mask) >>> vc));
      this.bitmap[index] = ba ^ mask;
    } 
    if (this.cardinality <= 4096) {
      return toArrayContainer();
    }
    return this;
  }


  
  public Container ixor(BitmapContainer b2) {
    int newCardinality = 0;
    for (int k = 0; k < this.bitmap.length; k++) {
      newCardinality += Long.bitCount(this.bitmap[k] ^ b2.bitmap[k]);
    }
    if (newCardinality > 4096) {
      for (int k = 0; k < this.bitmap.length; k++) {
        this.bitmap[k] = this.bitmap[k] ^ b2.bitmap[k];
      }
      this.cardinality = newCardinality;
      return this;
    } 
    ArrayContainer ac = new ArrayContainer(newCardinality);
    Util.fillArrayXOR(ac.content, this.bitmap, b2.bitmap);
    ac.cardinality = newCardinality;
    return ac;
  }


  
  public Container ixor(RunContainer x) {
    for (int rlepos = 0; rlepos < x.nbrruns; rlepos++) {
      int start = Util.toIntUnsigned(x.getValue(rlepos));
      int end = start + Util.toIntUnsigned(x.getLength(rlepos)) + 1;
      int prevOnes = cardinalityInRange(start, end);
      Util.flipBitmapRange(this.bitmap, start, end);
      updateCardinality(prevOnes, end - start - prevOnes);
    } 
    if (getCardinality() > 4096) {
      return this;
    }
    return toArrayContainer();
  }

  
  protected Container lazyor(ArrayContainer value2) {
    BitmapContainer answer = clone();
    answer.cardinality = -1;
    int c = value2.cardinality;
    for (int k = 0; k < c; k++) {
      short v = value2.content[k];
      int i = Util.toIntUnsigned(v) >>> 6;
      answer.bitmap[i] = answer.bitmap[i] | 1L << v;
    } 
    return answer;
  }
  
  protected Container lazyor(BitmapContainer x) {
    BitmapContainer answer = new BitmapContainer();
    answer.cardinality = -1;
    for (int k = 0; k < this.bitmap.length; k++) {
      answer.bitmap[k] = this.bitmap[k] | x.bitmap[k];
    }
    return answer;
  }

  
  protected Container lazyor(RunContainer x) {
    BitmapContainer bc = clone();
    bc.cardinality = -1;
    for (int rlepos = 0; rlepos < x.nbrruns; rlepos++) {
      int start = Util.toIntUnsigned(x.getValue(rlepos));
      int end = start + Util.toIntUnsigned(x.getLength(rlepos)) + 1;
      Util.setBitmapRange(bc.bitmap, start, end);
    } 
    return bc;
  }

  
  public Container limit(int maxcardinality) {
    if (maxcardinality >= this.cardinality) {
      return clone();
    }
    if (maxcardinality <= 4096) {
      ArrayContainer ac = new ArrayContainer(maxcardinality);
      int pos = 0;
      for (int k = 0; ac.cardinality < maxcardinality && k < this.bitmap.length; k++) {
        long bitset = this.bitmap[k];
        while (ac.cardinality < maxcardinality && bitset != 0L) {
          ac.content[pos++] = (short)(k * 64 + Long.numberOfTrailingZeros(bitset));
          ac.cardinality++;
          bitset &= bitset - 1L;
        } 
      } 
      return ac;
    } 
    BitmapContainer bc = new BitmapContainer(maxcardinality, this.bitmap);
    int s = Util.toIntUnsigned(select(maxcardinality));
    int usedwords = (s + 63) / 64;
    int todelete = this.bitmap.length - usedwords;
    for (int k = 0; k < todelete; k++) {
      bc.bitmap[bc.bitmap.length - 1 - k] = 0L;
    }
    int lastword = s % 64;
    if (lastword != 0) {
      bc.bitmap[s / 64] = bc.bitmap[s / 64] & -1L >>> 64 - lastword;
    }
    return bc;
  }
  
  protected void loadData(ArrayContainer arrayContainer) {
    this.cardinality = arrayContainer.cardinality;
    for (int k = 0; k < arrayContainer.cardinality; k++) {
      short x = arrayContainer.content[k];
      this.bitmap[Util.toIntUnsigned(x) / 64] = this.bitmap[Util.toIntUnsigned(x) / 64] | 1L << x;
    } 
  }






  
  public int nextSetBit(int i) {
    int x = i >> 6;
    long w = this.bitmap[x];
    w >>>= i;
    if (w != 0L) {
      return i + Long.numberOfTrailingZeros(w);
    }
    for (; ++x < this.bitmap.length; x++) {
      if (this.bitmap[x] != 0L) {
        return x * 64 + Long.numberOfTrailingZeros(this.bitmap[x]);
      }
    } 
    return -1;
  }






  
  public int nextClearBit(int i) {
    int x = i >> 6;
    long w = this.bitmap[x] ^ 0xFFFFFFFFFFFFFFFFL;
    w >>>= i;
    if (w != 0L) {
      return i + Long.numberOfTrailingZeros(w);
    }
    for (; ++x < this.bitmap.length; x++) {
      long map = this.bitmap[x] ^ 0xFFFFFFFFFFFFFFFFL;
      if (map != 0L) {
        return x * 64 + Long.numberOfTrailingZeros(map);
      }
    } 
    return 65536;
  }


  
  public Container not(int firstOfRange, int lastOfRange) {
    BitmapContainer answer = clone();
    return answer.inot(firstOfRange, lastOfRange);
  }

  
  int numberOfRuns() {
    int numRuns = 0;
    long nextWord = this.bitmap[0];
    
    for (int i = 0; i < this.bitmap.length - 1; i++) {
      long word = nextWord;
      nextWord = this.bitmap[i + 1];
      numRuns = (int)(numRuns + Long.bitCount((word ^ 0xFFFFFFFFFFFFFFFFL) & word << 1L) + (word >>> 63L & (nextWord ^ 0xFFFFFFFFFFFFFFFFL)));
    } 
    
    long word = nextWord;
    numRuns += Long.bitCount((word ^ 0xFFFFFFFFFFFFFFFFL) & word << 1L);
    if ((word & Long.MIN_VALUE) != 0L) {
      numRuns++;
    }
    
    return numRuns;
  }





  
  public int numberOfRunsAdjustment() {
    int ans = 0;
    long nextWord = this.bitmap[0];
    for (int i = 0; i < this.bitmap.length - 1; i++) {
      long word = nextWord;
      
      nextWord = this.bitmap[i + 1];
      ans = (int)(ans + (word >>> 63L & (nextWord ^ 0xFFFFFFFFFFFFFFFFL)));
    } 
    long word = nextWord;
    
    if ((word & Long.MIN_VALUE) != 0L) {
      ans++;
    }
    return ans;
  }






  
  public int numberOfRunsLowerBound(int mustNotExceed) {
    int numRuns = 0;
    
    for (int blockOffset = 0; blockOffset < this.bitmap.length; blockOffset += 128) {
      
      for (int i = blockOffset; i < blockOffset + 128; i++) {
        long word = this.bitmap[i];
        numRuns += Long.bitCount((word ^ 0xFFFFFFFFFFFFFFFFL) & word << 1L);
      } 
      if (numRuns > mustNotExceed) {
        return numRuns;
      }
    } 
    return numRuns;
  }

  
  public Container or(ArrayContainer value2) {
    BitmapContainer answer = clone();
    int c = value2.cardinality;
    for (int k = 0; k < c; k++) {
      short v = value2.content[k];
      int i = Util.toIntUnsigned(v) >>> 6;
      long w = answer.bitmap[i];
      long aft = w | 1L << v;
      answer.bitmap[i] = aft;
      
      answer.cardinality = (int)(answer.cardinality + (w - aft >>> 63L));
    } 




    
    if (answer.isFull()) {
      return RunContainer.full();
    }
    return answer;
  }

  
  protected boolean isFull() { return (this.cardinality == 65536); }


  
  public Container or(BitmapContainer value2) {
    BitmapContainer value1 = clone();
    return value1.ior(value2);
  }


  
  public Container or(RunContainer x) { return x.or(this); }







  
  public int prevSetBit(int i) {
    int x = i >> 6;
    long w = this.bitmap[x];
    w <<= 64 - i - 1;
    if (w != 0L) {
      return i - Long.numberOfLeadingZeros(w);
    }
    for (; --x >= 0; x--) {
      if (this.bitmap[x] != 0L) {
        return x * 64 + 63 - Long.numberOfLeadingZeros(this.bitmap[x]);
      }
    } 
    return -1;
  }






  
  public int prevClearBit(int i) {
    int x = i >> 6;
    long w = this.bitmap[x] ^ 0xFFFFFFFFFFFFFFFFL;
    w <<= 64 - i + 1;
    if (w != 0L) {
      return i - Long.numberOfLeadingZeros(w);
    }
    for (; --x >= 0; x--) {
      long map = this.bitmap[x] ^ 0xFFFFFFFFFFFFFFFFL;
      if (map != 0L) {
        return x * 64 + 63 - Long.numberOfLeadingZeros(map);
      }
    } 
    return -1;
  }

  
  public int rank(short lowbits) {
    int x = Util.toIntUnsigned(lowbits);
    int leftover = x + 1 & 0x3F;
    int answer = 0;
    for (int k = 0; k < (x + 1) / 64; k++) {
      answer += Long.bitCount(this.bitmap[k]);
    }
    if (leftover != 0) {
      answer += Long.bitCount(this.bitmap[(x + 1) / 64] << 64 - leftover);
    }
    return answer;
  }


  
  public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException { deserialize(in); }



  
  public Container remove(int begin, int end) {
    if (end == begin) {
      return clone();
    }
    if (begin > end || end > 65536) {
      throw new IllegalArgumentException("Invalid range [" + begin + "," + end + ")");
    }
    BitmapContainer answer = clone();
    int prevOnesInRange = answer.cardinalityInRange(begin, end);
    Util.resetBitmapRange(answer.bitmap, begin, end);
    answer.updateCardinality(prevOnesInRange, 0);
    if (answer.getCardinality() <= 4096) {
      return answer.toArrayContainer();
    }
    return answer;
  }

  
  public Container remove(short i) {
    int x = Util.toIntUnsigned(i);
    int index = x / 64;
    long bef = this.bitmap[index];
    long mask = 1L << x;
    if (this.cardinality == 4097)
    {

      
      if ((bef & mask) != 0L) {
        this.cardinality--;
        this.bitmap[x / 64] = bef & (mask ^ 0xFFFFFFFFFFFFFFFFL);
        return toArrayContainer();
      } 
    }
    long aft = bef & (mask ^ 0xFFFFFFFFFFFFFFFFL);
    this.cardinality = (int)(this.cardinality - (aft - bef >>> 63L));
    this.bitmap[index] = aft;
    return this;
  }

  
  public Container repairAfterLazy() {
    if (getCardinality() < 0) {
      computeCardinality();
      if (getCardinality() <= 4096)
        return toArrayContainer(); 
      if (isFull()) {
        return RunContainer.full();
      }
    } 
    return this;
  }

  
  public Container runOptimize() {
    int numRuns = numberOfRunsLowerBound(this.MAXRUNS);
    
    int sizeAsRunContainerLowerBound = RunContainer.serializedSizeInBytes(numRuns);
    
    if (sizeAsRunContainerLowerBound >= getArraySizeInBytes()) {
      return this;
    }


    
    numRuns += numberOfRunsAdjustment();
    int sizeAsRunContainer = RunContainer.serializedSizeInBytes(numRuns);
    
    if (getArraySizeInBytes() > sizeAsRunContainer) {
      return new RunContainer(this, numRuns);
    }
    return this;
  }


  
  public short select(int j) {
    int leftover = j;
    for (int k = 0; k < this.bitmap.length; k++) {
      int w = Long.bitCount(this.bitmap[k]);
      if (w > leftover) {
        return (short)(k * 64 + Util.select(this.bitmap[k], leftover));
      }
      leftover -= w;
    } 
    throw new IllegalArgumentException("Insufficient cardinality.");
  }


  
  public void serialize(DataOutput out) throws IOException {
    for (long w : this.bitmap) {
      out.writeLong(Long.reverseBytes(w));
    }
  }


  
  public int serializedSizeInBytes() { return serializedSizeInBytes(0); }






  
  public ArrayContainer toArrayContainer() {
    ArrayContainer ac = new ArrayContainer(this.cardinality);
    ac.loadData(this);
    if (ac.getCardinality() != this.cardinality) {
      throw new RuntimeException("Internal error.");
    }
    return ac;
  }






  
  public LongBuffer toLongBuffer() {
    LongBuffer lb = LongBuffer.allocate(this.bitmap.length);
    lb.put(this.bitmap);
    return lb;
  }


  
  public MappeableContainer toMappeableContainer() { return (MappeableContainer)new MappeableBitmapContainer(this); }


  
  public String toString() {
    StringBuilder sb = new StringBuilder();
    ShortIterator i = getShortIterator();
    sb.append("{");
    while (i.hasNext()) {
      sb.append(Util.toIntUnsigned(i.next()));
      if (i.hasNext()) {
        sb.append(",");
      }
    } 
    sb.append("}");
    return sb.toString();
  }


  
  public void trim() {}

  
  protected void writeArray(DataOutput out) throws IOException { serialize(out); }



  
  public void writeExternal(ObjectOutput out) throws IOException { serialize(out); }


  
  public Container xor(ArrayContainer value2) {
    BitmapContainer answer = clone();
    int c = value2.cardinality;
    for (int k = 0; k < c; k++) {
      short vc = value2.content[k];
      int index = Util.toIntUnsigned(vc) >>> 6;
      long mask = 1L << vc;
      long val = answer.bitmap[index];
      
      answer.cardinality = (int)(answer.cardinality + 1L - 2L * ((val & mask) >>> vc));
      answer.bitmap[index] = val ^ mask;
    } 
    if (answer.cardinality <= 4096) {
      return answer.toArrayContainer();
    }
    return answer;
  }

  
  public Container xor(BitmapContainer value2) {
    int newCardinality = 0;
    for (int k = 0; k < this.bitmap.length; k++) {
      newCardinality += Long.bitCount(this.bitmap[k] ^ value2.bitmap[k]);
    }
    if (newCardinality > 4096) {
      BitmapContainer answer = new BitmapContainer();
      for (int k = 0; k < answer.bitmap.length; k++) {
        answer.bitmap[k] = this.bitmap[k] ^ value2.bitmap[k];
      }
      answer.cardinality = newCardinality;
      return answer;
    } 
    ArrayContainer ac = new ArrayContainer(newCardinality);
    Util.fillArrayXOR(ac.content, this.bitmap, value2.bitmap);
    ac.cardinality = newCardinality;
    return ac;
  }


  
  public Container xor(RunContainer x) { return x.xor(this); }


  
  public void forEach(short msb, IntConsumer ic) {
    int high = msb << 16;
    for (int x = 0; x < this.bitmap.length; x++) {
      long w = this.bitmap[x];
      while (w != 0L) {
        ic.accept(x * 64 + Long.numberOfTrailingZeros(w) | high);
        w &= w - 1L;
      } 
    } 
  }


  
  public BitmapContainer toBitmapContainer() { return this; }



  
  public int nextValue(short fromValue) { return nextSetBit(Util.toIntUnsigned(fromValue)); }



  
  public int previousValue(short fromValue) { return prevSetBit(Util.toIntUnsigned(fromValue)); }



  
  public int nextAbsentValue(short fromValue) { return nextClearBit(Util.toIntUnsigned(fromValue)); }



  
  public int previousAbsentValue(short fromValue) { return prevClearBit(Util.toIntUnsigned(fromValue)); }


  
  public int first() {
    assertNonEmpty((this.cardinality == 0));
    int i = 0;
    while (i < this.bitmap.length - 1 && this.bitmap[i] == 0L) {
      i++;
    }
    
    return i * 64 + Long.numberOfTrailingZeros(this.bitmap[i]);
  }

  
  public int last() {
    assertNonEmpty((this.cardinality == 0));
    int i = this.bitmap.length - 1;
    while (i > 0 && this.bitmap[i] == 0L) {
      i--;
    }
    
    return (i + 1) * 64 - Long.numberOfLeadingZeros(this.bitmap[i]) - 1;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\roaringbitmap\BitmapContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */