package org.neo4j.graphalgo.core;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.neo4j.graphalgo.PropertyMappings;
import org.neo4j.graphalgo.api.GraphFactory;
import org.neo4j.graphalgo.core.loading.CypherGraphFactory;
import org.neo4j.graphalgo.core.loading.GraphLoadFactory;
import org.neo4j.graphalgo.core.loading.HugeGraphFactory;
import org.neo4j.graphalgo.core.utils.Directions;
import org.neo4j.graphalgo.core.utils.Pools;
import org.neo4j.graphdb.Direction;
import org.neo4j.graphdb.RelationshipType;
































public class ProcedureConfiguration
{
  private final Map<String, Object> config;
  
  public ProcedureConfiguration(Map<String, Object> config) { this.config = new HashMap<>(config); }








  
  public boolean containsKey(String key) { return this.config.containsKey(key); }









  
  public ProcedureConfiguration setNodeLabelOrQuery(String nodeLabelOrQuery) {
    this.config.put("nodeQuery", nodeLabelOrQuery);
    return this;
  }








  
  public ProcedureConfiguration setRelationshipTypeOrQuery(String relationshipTypeOrQuery) {
    this.config.put("relationshipQuery", relationshipTypeOrQuery);
    return this;
  }







  
  public ProcedureConfiguration setDirection(String direction) {
    this.config.put("direction", direction);
    return this;
  }







  
  public ProcedureConfiguration setDirection(Direction direction) {
    this.config.put("direction", direction.name());
    return this;
  }






  
  public String getNodeLabelOrQuery() { return getString("nodeQuery", null); }









  
  public String getNodeLabelOrQuery(String defaultValue) { return getString("nodeQuery", defaultValue); }


  
  public String getRelationshipOrQuery() { return getString("relationshipQuery", null); }







  
  public String getWriteProperty() { return getWriteProperty("writeValue"); }








  
  public String getWriteProperty(String defaultValue) { return getString("writeProperty", defaultValue); }









  
  public String getRelationshipOrQuery(String defaultValue) { return getString("relationshipQuery", defaultValue); }







  
  public boolean isWriteFlag() { return isWriteFlag(true); }







  
  public boolean isStatsFlag() { return isStatsFlag(false); }








  
  public boolean isWriteFlag(boolean defaultValue) { return ((Boolean)get("write", Boolean.valueOf(defaultValue))).booleanValue(); }


  
  public boolean isStatsFlag(boolean defaultValue) { return ((Boolean)get("stats", Boolean.valueOf(defaultValue))).booleanValue(); }


  
  public boolean hasWeightProperty() { return containsKey("weightProperty"); }


  
  public String getWeightProperty() { return getString("weightProperty", null); }


  
  public PropertyMappings getNodeProperties() { return getPropertyMappings("nodeProperties"); }


  
  public PropertyMappings getRelationshipProperties() { return getPropertyMappings("relationshipProperties"); }

  
  private PropertyMappings getPropertyMappings(String paramKey) {
    Object propertyMappings = get(paramKey, null);
    if (propertyMappings != null) {
      return PropertyMappings.fromObject(propertyMappings);
    }
    return PropertyMappings.EMPTY;
  }

  
  public double getWeightPropertyDefaultValue(double defaultValue) { return getNumber("defaultValue", Double.valueOf(defaultValue)).doubleValue(); }








  
  public int getIterations(int defaultValue) { return getNumber("iterations", Integer.valueOf(defaultValue)).intValue(); }







  
  public int getBatchSize() { return getNumber("batchSize", Integer.valueOf(10000)).intValue(); }


  
  public int getConcurrency() { return getConcurrency(Pools.DEFAULT_CONCURRENCY); }

  
  public int getConcurrency(int defaultValue) {
    int requestedConcurrency = getNumber("concurrency", Integer.valueOf(defaultValue)).intValue();
    return Pools.allowedConcurrency(requestedConcurrency);
  }

  
  public int getReadConcurrency() { return getReadConcurrency(Pools.DEFAULT_CONCURRENCY); }

  
  public int getReadConcurrency(int defaultValue) {
    Number readConcurrency = getNumber("readConcurrency", "concurrency", 

        
        Integer.valueOf(defaultValue));
    int requestedConcurrency = readConcurrency.intValue();
    return Pools.allowedConcurrency(requestedConcurrency);
  }

  
  public int getWriteConcurrency() { return getWriteConcurrency(Pools.DEFAULT_CONCURRENCY); }

  
  public int getWriteConcurrency(int defaultValue) {
    Number writeConcurrency = getNumber("writeConcurrency", "concurrency", 

        
        Integer.valueOf(defaultValue));
    int requestedConcurrency = writeConcurrency.intValue();
    return Pools.allowedConcurrency(requestedConcurrency);
  }

  
  public String getDirectionName(String defaultDirection) { return get("direction", defaultDirection); }


  
  public Direction getDirection(Direction defaultDirection) { return Directions.fromString(getDirectionName(defaultDirection.name())); }


  
  public RelationshipType getRelationship() { return (getRelationshipOrQuery() == null) ? null : RelationshipType.withName(getRelationshipOrQuery()); }


  
  public String getGraphName(String defaultValue) { return getString("graph", defaultValue); }


  
  public Class<? extends GraphFactory> getGraphImpl() { return getGraphImpl("huge"); }




  
  public Class<? extends GraphFactory> getGraphImpl(String defaultGraphImpl) {
    String graphImpl = getGraphName(defaultGraphImpl);
    switch (graphImpl.toLowerCase(Locale.ROOT)) {
      case "cypher":
        return (Class)CypherGraphFactory.class;
      case "light":
      case "heavy":
      case "huge":
        return (Class)HugeGraphFactory.class;
    } 
    if (validCustomName(graphImpl) && GraphLoadFactory.exists(graphImpl)) {
      return (Class)GraphLoadFactory.class;
    }
    throw new IllegalArgumentException("Unknown impl: " + graphImpl);
  }

  
  private static final Set<String> RESERVED = new HashSet<>(Arrays.asList(new String[] { "cypher", "light", "huge", "heavy" }));





  
  public static boolean validCustomName(String name) { return (name != null && !name.trim().isEmpty() && !RESERVED.contains(name.trim().toLowerCase())); }



  
  public final Class<? extends GraphFactory> getGraphImpl(String defaultImpl, String... alloweds) {
    String graphName = getGraphName(defaultImpl);
    List<String> allowedNames = Arrays.asList(alloweds);
    if (allowedNames.contains(graphName) || allowedNames.contains(GraphLoadFactory.getType(graphName))) {
      return getGraphImpl(defaultImpl);
    }
    throw new IllegalArgumentException("The graph algorithm only supports these graph types; " + allowedNames);
  }









  
  public String getString(String key, String defaultValue) {
    String value = (String)this.config.getOrDefault(key, defaultValue);
    return (null == value || "".equals(value)) ? defaultValue : value;
  }

  
  public String getString(String key, String oldKey, String defaultValue) { return getChecked(key, oldKey, defaultValue, String.class); }

  
  public Optional<String> getString(String key) {
    if (this.config.containsKey(key))
    {
      
      return Optional.of((String)getChecked(key, null, (Class)String.class));
    }
    return Optional.empty();
  }
  
  public Optional<String> getStringWithFallback(String key, String oldKey) {
    Optional<String> value = getString(key);

    
    if (!value.isPresent()) {
      value = getString(oldKey);
    }
    return value;
  }

  
  public Object get(String key) { return this.config.get(key); }


  
  public Boolean getBool(String key, boolean defaultValue) { return getChecked(key, Boolean.valueOf(defaultValue), Boolean.class); }


  
  public Number getNumber(String key, Number defaultValue) { return getChecked(key, defaultValue, Number.class); }

  
  public Number getNumber(String key, String oldKey, Number defaultValue) {
    Object value = get(key, oldKey, defaultValue);
    if (null == value) {
      return defaultValue;
    }
    if (!(value instanceof Number)) {
      throw new IllegalArgumentException("The value of " + key + " must be a Number type");
    }
    return (Number)value;
  }
  
  public int getInt(String key, int defaultValue) {
    Number value = (Number)this.config.get(key);
    if (null == value) {
      return defaultValue;
    }
    return value.intValue();
  }

  
  public <V> V get(String key, V defaultValue) {
    Object value = this.config.get(key);
    if (null == value) {
      return defaultValue;
    }
    return (V)value;
  }
  
  public Double getSkipValue(Double defaultValue) {
    String key = "skipValue";
    if (!this.config.containsKey(key)) {
      return defaultValue;
    }
    Object value = this.config.get(key);
    
    if (value == null) {
      return null;
    }
    
    return Double.valueOf(((Number)typedValue(key, Number.class, value)).doubleValue());
  }







  
  public <V> V getChecked(String key, V defaultValue, Class<V> expectedType) {
    Object value = this.config.get(key);
    return checkValue(key, defaultValue, expectedType, value);
  }

  
  public <V> V get(String newKey, String oldKey, V defaultValue) {
    Object value = this.config.get(newKey);
    if (null == value) {
      value = this.config.get(oldKey);
    }
    return (null == value) ? defaultValue : (V)value;
  }
  
  public <V> V getChecked(String key, String oldKey, V defaultValue, Class<V> expectedType) {
    Object value = get(key, oldKey, null);
    return checkValue(key, defaultValue, expectedType, value);
  }
  
  private <V> V checkValue(String key, V defaultValue, Class<V> expectedType, Object value) {
    if (null == value) {
      return defaultValue;
    }
    return typedValue(key, expectedType, value);
  }
  
  private <V> V typedValue(String key, Class<V> expectedType, Object value) {
    if (!expectedType.isInstance(value)) {
      String template = "The value of %s must be a %s.";
      String message = String.format(template, new Object[] { key, expectedType.getSimpleName() });
      throw new IllegalArgumentException(message);
    } 
    return expectedType.cast(value);
  }

  
  public static ProcedureConfiguration create(Map<String, Object> config) { return new ProcedureConfiguration(config); }


  
  public static ProcedureConfiguration empty() { return new ProcedureConfiguration(Collections.emptyMap()); }


  
  public Map<String, Object> getParams() { return (Map<String, Object>)this.config.getOrDefault("params", Collections.emptyMap()); }

  
  public DeduplicationStrategy getDeduplicationStrategy() {
    String strategy = (String)get("duplicateRelationships", null);
    return (strategy != null) ? DeduplicationStrategy.lookup(strategy.toUpperCase()) : DeduplicationStrategy.DEFAULT;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\ProcedureConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */