package org.neo4j.graphalgo.core.loading;

import java.util.OptionalLong;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.paged.PagedLongDoubleMap;





















final class NodePropertyMap
  implements NodeProperties
{
  private static final MemoryEstimation MEMORY_ESTIMATION = MemoryEstimations.builder(NodePropertyMap.class)
    .add("properties", PagedLongDoubleMap.memoryEstimation())
    .build();
  
  private PagedLongDoubleMap properties;
  
  private final double defaultValue;
  
  static MemoryEstimation memoryEstimation() { return MEMORY_ESTIMATION; }

  
  NodePropertyMap(PagedLongDoubleMap properties, double defaultValue) {
    this.properties = properties;
    this.defaultValue = defaultValue;
  }


  
  public double nodeProperty(long nodeId) { return this.properties.getOrDefault(nodeId, this.defaultValue); }



  
  public double nodeProperty(long nodeId, double defaultValue) { return this.properties.getOrDefault(nodeId, defaultValue); }



  
  public OptionalLong getMaxPropertyValue() { return this.properties.getMaxValue(); }


  
  public long release() {
    if (this.properties != null) {
      long freed = this.properties.release();
      this.properties = null;
      return freed;
    } 
    return 0L;
  }


  
  public long size() { return this.properties.size(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\NodePropertyMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */