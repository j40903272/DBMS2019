package org.roaringbitmap;














public class ArraysShim
{
  public static boolean equals(short[] x, int xmin, int xmax, short[] y, int ymin, int ymax) {
    int xlen = xmax - xmin;
    int ylen = ymax - ymin;
    if (xlen != ylen) {
      return false;
    }
    for (int i = xmin, j = ymin; i < xmax && j < ymax; i++, j++) {
      if (x[i] != y[j]) {
        return false;
      }
    } 
    return true;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\roaringbitmap\ArraysShim.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */