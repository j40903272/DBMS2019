package org.neo4j.graphalgo.core.loading;

import java.util.Collection;
import java.util.Collections;
import org.neo4j.graphalgo.core.utils.RawValues;
import org.neo4j.graphalgo.core.utils.StatementAction;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.internal.kernel.api.CursorFactory;
import org.neo4j.internal.kernel.api.Read;
import org.neo4j.kernel.api.KernelTransaction;
import org.neo4j.kernel.impl.store.NodeStore;
import org.neo4j.kernel.impl.store.record.NodeRecord;
import org.neo4j.kernel.internal.GraphDatabaseAPI;
















final class NodesScanner
  extends StatementAction
  implements RecordScanner
{
  private final TerminationFlag terminationFlag;
  private final NodeStore nodeStore;
  private final AbstractStorePageCacheScanner<NodeRecord> scanner;
  private final int label;
  private final int scannerIndex;
  private final ImportProgress progress;
  private final NodeImporter importer;
  private long propertiesImported;
  private long nodesImported;
  
  static InternalImporter.CreateScanner of(GraphDatabaseAPI api, AbstractStorePageCacheScanner<NodeRecord> scanner, int label, ImportProgress progress, NodeImporter importer, TerminationFlag terminationFlag) { return new Creator(api, scanner, label, progress, importer, terminationFlag); }


  
  static final class Creator
    implements InternalImporter.CreateScanner
  {
    private final GraphDatabaseAPI api;

    
    private final AbstractStorePageCacheScanner<NodeRecord> scanner;

    
    private final int label;

    
    private final ImportProgress progress;
    
    private final NodeImporter importer;
    
    private final TerminationFlag terminationFlag;

    
    Creator(GraphDatabaseAPI api, AbstractStorePageCacheScanner<NodeRecord> scanner, int label, ImportProgress progress, NodeImporter importer, TerminationFlag terminationFlag) {
      this.api = api;
      this.scanner = scanner;
      this.label = label;
      this.progress = progress;
      this.importer = importer;
      this.terminationFlag = terminationFlag;
    }


    
    public RecordScanner create(int index) { return new NodesScanner(this.api, this.terminationFlag, this.scanner, this.label, index, this.progress, this.importer, null); }











    
    public Collection<Runnable> flushTasks() { return Collections.emptyList(); }
  }



















  
  private NodesScanner(GraphDatabaseAPI api, TerminationFlag terminationFlag, AbstractStorePageCacheScanner<NodeRecord> scanner, int label, int threadIndex, ImportProgress progress, NodeImporter importer) {
    super(api);
    this.terminationFlag = terminationFlag;
    this.nodeStore = (NodeStore)scanner.store();
    this.scanner = scanner;
    this.label = label;
    this.scannerIndex = threadIndex;
    this.progress = progress;
    this.importer = importer;
  }


  
  public String threadName() { return "node-store-scan-" + this.scannerIndex; }


  
  public void accept(KernelTransaction transaction) {
    Read read = transaction.dataRead();
    CursorFactory cursors = transaction.cursors();
    try (AbstractStorePageCacheScanner<NodeRecord>.Cursor cursor = this.scanner.getCursor()) {



      
      NodesBatchBuffer batches = new NodesBatchBuffer(this.nodeStore, this.label, cursor.bulkSize(), this.importer.readsProperties());
      ImportProgress progress = this.progress;
      while (batches.scan(cursor)) {
        this.terminationFlag.assertRunning();
        long imported = this.importer.importNodes(batches, read, cursors);
        int batchImportedNodes = RawValues.getHead(imported);
        int batchImportedProperties = RawValues.getTail(imported);
        progress.nodesImported(batchImportedNodes);
        this.nodesImported += batchImportedNodes;
        this.propertiesImported += batchImportedProperties;
      } 
    } 
  }


  
  public long propertiesImported() { return this.propertiesImported; }



  
  public long recordsImported() { return this.nodesImported; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\NodesScanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */