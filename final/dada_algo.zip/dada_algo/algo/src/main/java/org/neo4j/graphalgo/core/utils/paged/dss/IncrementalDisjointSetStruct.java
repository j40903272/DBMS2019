package org.neo4j.graphalgo.core.utils.paged.dss;

import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;
import org.neo4j.graphalgo.core.utils.paged.HugeLongLongMap;



























@Deprecated
public final class IncrementalDisjointSetStruct
  extends SequentialDisjointSetStruct
{
  private static final MemoryEstimation MEMORY_ESTIMATION = MemoryEstimations.builder(IncrementalDisjointSetStruct.class)
    
    .perNode("parent", HugeLongArray::memoryEstimation)
    .add("internalToProvidedIds", HugeLongLongMap.memoryEstimation())
    .build();
  
  private final HugeLongArray parent;
  
  private final HugeLongLongMap internalToProvidedIds;
  private final NodeProperties communityMapping;
  private final long size;
  private long maxCommunity;
  
  public static MemoryEstimation memoryEstimation() { return MEMORY_ESTIMATION; }









  
  public IncrementalDisjointSetStruct(long size, NodeProperties communityMapping, AllocationTracker tracker) {
    this.parent = HugeLongArray.newArray(size, tracker);
    this.internalToProvidedIds = new HugeLongLongMap(size, tracker);
    this.communityMapping = communityMapping;
    this.size = size;
    init(tracker);
  }


  
  public HugeLongArray parent() { return this.parent; }




  
  private void init(AllocationTracker tracker) {
    this.maxCommunity = this.communityMapping.getMaxPropertyValue().orElse(-1L);
    
    HugeLongLongMap internalMapping = new HugeLongLongMap(this.size, tracker);
    
    this.parent.setAll(nodeId -> {
          long parentValue = -1L;
          double communityIdValue = this.communityMapping.nodeProperty(nodeId, NaND);
          
          if (!Double.isNaN(communityIdValue)) {
            long communityId = (long)communityIdValue;
            
            long internalCommunityId = internalMapping.getOrDefault(communityId, -1L);
            if (internalCommunityId != -1L) {
              parentValue = internalCommunityId;
            } else {
              this.internalToProvidedIds.addTo(nodeId, communityId);
              internalMapping.addTo(communityId, nodeId);
            } 
          } else {
            this.internalToProvidedIds.addTo(nodeId, ++this.maxCommunity);
          } 
          return parentValue;
        });
  }







  
  public long size() { return this.size; }








  
  public long find(long nodeId) {
    long p = nodeId;
    long np;
    while ((np = this.parent.get(p)) != -1L) {
      p = np;
    }
    return p;
  }

  
  public long setIdOf(long nodeId) {
    long setId = find(nodeId);
    return setIdOfRoot(setId);
  }

  
  long setIdOfRoot(long rootId) {
    long setId = this.internalToProvidedIds.getOrDefault(rootId, -1L);
    assert setId != -1L;
    return setId;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\dss\IncrementalDisjointSetStruct.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */