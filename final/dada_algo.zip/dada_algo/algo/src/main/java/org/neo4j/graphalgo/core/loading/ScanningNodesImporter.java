package org.neo4j.graphalgo.core.loading;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import org.neo4j.graphalgo.PropertyMapping;
import org.neo4j.graphalgo.PropertyMappings;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.core.GraphDimensions;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArrayBuilder;
import org.neo4j.kernel.impl.store.record.NodeRecord;
import org.neo4j.kernel.internal.GraphDatabaseAPI;






























final class ScanningNodesImporter
  extends ScanningRecordsImporter<NodeRecord, IdsAndProperties>
{
  private final ImportProgress progress;
  private final AllocationTracker tracker;
  private final TerminationFlag terminationFlag;
  private final PropertyMappings propertyMappings;
  private Map<String, NodePropertiesBuilder> builders;
  private HugeLongArrayBuilder idMapBuilder;
  
  ScanningNodesImporter(GraphDatabaseAPI api, GraphDimensions dimensions, ImportProgress progress, AllocationTracker tracker, TerminationFlag terminationFlag, ExecutorService threadPool, int concurrency, PropertyMappings propertyMappings) {
    super(NodeStoreScanner.NODE_ACCESS, "Node", api, dimensions, threadPool, concurrency);
    this.progress = progress;
    this.tracker = tracker;
    this.terminationFlag = terminationFlag;
    this.propertyMappings = propertyMappings;
  }




  
  InternalImporter.CreateScanner creator(long nodeCount, ImportSizing sizing, AbstractStorePageCacheScanner<NodeRecord> scanner) {
    this.idMapBuilder = HugeLongArrayBuilder.of(nodeCount, this.tracker);
    this.builders = propertyBuilders(nodeCount);
    return NodesScanner.of(this.api, scanner, this.dimensions

        
        .labelId(), this.progress, new NodeImporter(this.idMapBuilder, this.builders
          
          .values()), this.terminationFlag);
  }



  
  IdsAndProperties build() {
    IdMap hugeIdMap = IdMapBuilder.build(this.idMapBuilder, this.dimensions
        
        .highestNeoId(), this.concurrency, this.tracker);

    
    Map<String, NodeProperties> nodeProperties = new HashMap<>();
    for (PropertyMapping propertyMapping : this.propertyMappings) {
      NodePropertiesBuilder builder = this.builders.get(propertyMapping.propertyKey());
      NodeProperties props = (builder != null) ? builder.build() : new NullPropertyMap(propertyMapping.defaultValue());
      nodeProperties.put(propertyMapping.propertyKey(), props);
    } 
    return new IdsAndProperties(hugeIdMap, Collections.unmodifiableMap(nodeProperties));
  }
  
  private Map<String, NodePropertiesBuilder> propertyBuilders(long nodeCount) {
    Map<String, NodePropertiesBuilder> builders = new HashMap<>();
    for (PropertyMapping propertyMapping : this.dimensions.nodeProperties()) {
      if (propertyMapping.exists()) {
        NodePropertiesBuilder builder = NodePropertiesBuilder.of(nodeCount, this.tracker, propertyMapping

            
            .defaultValue(), propertyMapping
            .propertyKeyId(), propertyMapping
            .propertyKey());
        builders.put(propertyMapping.propertyKey(), builder);
      } 
    } 
    return builders;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\ScanningNodesImporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */