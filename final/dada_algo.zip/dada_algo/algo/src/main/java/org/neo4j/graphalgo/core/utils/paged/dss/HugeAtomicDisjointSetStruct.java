package org.neo4j.graphalgo.core.utils.paged.dss;

import java.util.concurrent.atomic.AtomicLong;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeAtomicLongArray;





















































public final class HugeAtomicDisjointSetStruct
  implements DisjointSetStruct
{
  private static final int NO_SUCH_SEED_VALUE = 0;
  private final HugeAtomicLongArray parent;
  private final HugeAtomicLongArray communities;
  private final AtomicLong maxCommunityId;
  
  public static MemoryEstimation memoryEstimation(boolean incremental) {
    MemoryEstimations.Builder builder = MemoryEstimations.builder(HugeAtomicDisjointSetStruct.class).perNode("data", HugeAtomicLongArray::memoryEstimation);
    if (incremental) {
      builder.perNode("seeding information", HugeAtomicLongArray::memoryEstimation);
    }
    return builder.build();
  }




  
  public HugeAtomicDisjointSetStruct(long capacity, AllocationTracker tracker) {
    this.parent = HugeAtomicLongArray.newArray(capacity, i -> i, tracker);
    this.communities = null;
    this.maxCommunityId = null;
  }
  
  public HugeAtomicDisjointSetStruct(long capacity, NodeProperties communityMapping, AllocationTracker tracker) {
    this.parent = HugeAtomicLongArray.newArray(capacity, i -> i, tracker);
    this.communities = HugeAtomicLongArray.newArray(capacity, nodeId -> {
          double communityIdValue = communityMapping.nodeProperty(nodeId, NaND);
          return Double.isNaN(communityIdValue) ? -1L : (long)communityIdValue;
        }tracker);
    this.maxCommunityId = new AtomicLong(communityMapping.getMaxPropertyValue().orElse(0L));
  }

  
  private long parent(long id) { return this.parent.get(id); }

  
  private long find(long id) {
    long parent;
    while (id != (parent = parent(id))) {
      long grandParent = parent(parent);
      if (parent != grandParent)
      {





        
        this.parent.compareAndSet(id, parent, grandParent);
      }
      id = grandParent;
    } 
    return id;
  }

  
  public long setIdOf(long nodeId) {
    long newSetId, providedSetId, setId = find(nodeId);
    if (this.communities == null) {
      return setId;
    }
    
    do {
      providedSetId = this.communities.get(setId);
      if (providedSetId >= 0L) {
        return providedSetId;
      }
      newSetId = this.maxCommunityId.incrementAndGet();
    } while (!this.communities.compareAndSet(setId, providedSetId, newSetId));
    return newSetId;
  }



  
  public boolean sameSet(long id1, long id2) {
    do {
      id1 = find(id1);
      id2 = find(id2);
      if (id1 == id2) {
        return true;
      }
    } while (parent(id1) != id1);
    return false;
  }



  
  public void union(long id1, long id2) {
    while (true) {
      id1 = find(id1);
      id2 = find(id2);
      
      if (id1 == id2) {
        return;
      }




      
      if (id1 < id2) {
        long tmp = id2;
        id2 = id1;
        id1 = tmp;
      } 
      
      long oldEntry = id1;
      long newEntry = id2;
      
      if (!this.parent.compareAndSet(id1, oldEntry, newEntry)) {
        continue;
      }
      break;
    } 
  }



  
  public long size() { return this.parent.size(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\dss\HugeAtomicDisjointSetStruct.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */