package org.neo4j.graphalgo.core.utils.paged;

import com.carrotsearch.hppc.HashOrderMixing;
import com.carrotsearch.hppc.IntDoubleHashMap;
import com.carrotsearch.hppc.OpenHashContainers;
import com.carrotsearch.hppc.cursors.DoubleCursor;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.LongFunction;
import java.util.stream.DoubleStream;
import java.util.stream.StreamSupport;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.mem.MemoryRange;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
























final class TrackingIntDoubleHashMap
  extends IntDoubleHashMap
{
  private static final MemoryEstimation MEMORY_ESTIMATION = MemoryEstimations.builder(TrackingIntDoubleHashMap.class)
    .rangePerNode("map buffers", nodeCount -> {
        int minBufferSize = OpenHashContainers.emptyBufferSize();
        int maxBufferSize = OpenHashContainers.expectedBufferSize((int)Math.min(16384L, nodeCount));
        long min = MemoryUsage.sizeOfIntArray(minBufferSize) + MemoryUsage.sizeOfDoubleArray(minBufferSize);
        long max = MemoryUsage.sizeOfIntArray(maxBufferSize) + MemoryUsage.sizeOfDoubleArray(maxBufferSize);
        return (LongFunction)MemoryRange.of(min, max);
      
      }).build();
  
  private final AllocationTracker tracker;
  
  private final LongAdder instanceSize;
  
  static MemoryEstimation memoryEstimation() { return MEMORY_ESTIMATION; }

  
  public TrackingIntDoubleHashMap(AllocationTracker tracker) {
    super(4, 0.75D, HashOrderMixing.defaultStrategy());
    this.tracker = tracker;
    this.instanceSize = new LongAdder();
    trackUsage(bufferUsage(this.keys.length));
  }


  
  protected void allocateBuffers(int arraySize) {
    if (!AllocationTracker.isTracking(this.tracker)) {
      super.allocateBuffers(arraySize);
      return;
    } 
    int lengthBefore = this.keys.length;
    super.allocateBuffers(arraySize);
    int lengthAfter = this.keys.length;
    long addedMemory = bufferUsage(lengthAfter) - bufferUsage(lengthBefore);
    trackUsage(addedMemory);
  }

  
  public DoubleStream getValuesAsStream() { return 
      StreamSupport.stream(values().spliterator(), false)
      .mapToDouble(c -> c.value); }


  
  private long bufferUsage(int length) { return MemoryUsage.sizeOfIntArray(length) + MemoryUsage.sizeOfDoubleArray(length); }

  
  private void trackUsage(long addedMemory) {
    this.tracker.add(addedMemory);
    this.instanceSize.add(addedMemory);
  }

  
  public long instanceSize() { return this.instanceSize.sum(); }


  
  public synchronized void putSync(int key, double value) { put(key, value); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\TrackingIntDoubleHashMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */