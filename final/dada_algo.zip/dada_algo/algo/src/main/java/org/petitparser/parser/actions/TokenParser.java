package org.petitparser.parser.actions;

import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.context.Token;
import org.petitparser.parser.Parser;
import org.petitparser.parser.combinators.DelegateParser;




public class TokenParser
  extends DelegateParser
{
  public TokenParser(Parser delegate) { super(delegate); }


  
  public Result parseOn(Context context) {
    Result result = this.delegate.parseOn(context);
    if (result.isSuccess()) {
      
      Token token = new Token(context.getBuffer(), context.getPosition(), result.getPosition(), result.get());
      return (Result)result.success(token);
    } 
    return result;
  }



  
  public TokenParser copy() { return new TokenParser(this.delegate); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\actions\TokenParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */