package org.neo4j.graphalgo.core.utils.paged;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.function.LongFunction;
import java.util.function.Supplier;
import org.neo4j.graphalgo.core.utils.ArrayUtil;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;




































































































































public abstract class HugeObjectArray<T>
  extends HugeArray<T[], T, HugeObjectArray<T>>
{
  final T boxedGet(long index) { return get(index); }






  
  final void boxedSet(long index, T value) { set(index, value); }






  
  final void boxedSetAll(LongFunction<T> gen) { setAll(gen); }






  
  final void boxedFill(T value) { fill(value); }










  
  public static <T> HugeObjectArray<T> newArray(Class<T> componentClass, long size, AllocationTracker tracker)
  {
    if (size <= ArrayUtil.MAX_ARRAY_LENGTH) {
      return 


















        
        SingleHugeObjectArray.of(componentClass, size, tracker);
    }






























































































































    
    return PagedHugeObjectArray.of(componentClass, size, tracker); } @SafeVarargs public static <T> HugeObjectArray<T> of(T... values) { return new SingleHugeObjectArray<>(values.length, (Object[])values); } static <T> HugeObjectArray<T> newSingleArray(Class<T> componentClass, int size, AllocationTracker tracker) { return SingleHugeObjectArray.of(componentClass, size, tracker); } public abstract T get(long paramLong); public abstract void set(long paramLong, T paramT); public abstract T putIfAbsent(long paramLong, Supplier<T> paramSupplier); public abstract void setAll(LongFunction<T> paramLongFunction); public abstract void fill(T paramT); public abstract long size(); static <T> HugeObjectArray<T> newPagedArray(Class<T> componentClass, long size, AllocationTracker tracker) { return PagedHugeObjectArray.of(componentClass, size, tracker); }
  public abstract long sizeOf(); public abstract long release(); public abstract HugeCursor<T[]> newCursor(); public abstract void copyTo(HugeObjectArray<T> paramHugeObjectArray, long paramLong); public abstract HugeObjectArray<T> copyOf(long paramLong, AllocationTracker paramAllocationTracker); public abstract T[] toArray(); private static final class SingleHugeObjectArray<T> extends HugeObjectArray<T> {
    private final int size; private T[] page; private static <T> HugeObjectArray<T> of(Class<T> componentClass, long size, AllocationTracker tracker) { assert size <= ArrayUtil.MAX_ARRAY_LENGTH; int intSize = (int)size; T[] page = (T[])Array.newInstance(componentClass, intSize); tracker.add(MemoryUsage.sizeOfObjectArray(intSize)); return new SingleHugeObjectArray<>(intSize, page); } private SingleHugeObjectArray(int size, T[] page) { this.size = size; this.page = page; } public T get(long index) { assert index < this.size; return this.page[(int)index]; } public void set(long index, T value) { assert index < this.size; this.page[(int)index] = value; } public T putIfAbsent(long index, Supplier<T> supplier) { assert index < this.size; T value; if ((value = this.page[(int)index]) == null && (value = supplier.get()) != null) this.page[(int)index] = value;  return value; } public void setAll(LongFunction<T> gen) { Arrays.setAll(this.page, gen::apply); } public void fill(T value) { Arrays.fill((Object[])this.page, value); } public void copyTo(HugeObjectArray<T> dest, long length) { if (length > this.size) length = this.size;  if (length > dest.size()) length = dest.size();  if (dest instanceof SingleHugeObjectArray) { SingleHugeObjectArray<T> dst = (SingleHugeObjectArray<T>)dest; System.arraycopy(this.page, 0, dst.page, 0, (int)length); Arrays.fill((Object[])dst.page, (int)length, dst.size, null); } else if (dest instanceof HugeObjectArray.PagedHugeObjectArray) { HugeObjectArray.PagedHugeObjectArray<T> dst = (HugeObjectArray.PagedHugeObjectArray<T>)dest; int start = 0; int remaining = (int)length; for (Object[] dstPage : dst.pages) { int toCopy = Math.min(remaining, dstPage.length); if (toCopy == 0) { Arrays.fill((Object[])this.page, null); } else { System.arraycopy(this.page, start, dstPage, 0, toCopy); if (toCopy < dstPage.length) Arrays.fill(dstPage, toCopy, dstPage.length, null);  start += toCopy; remaining -= toCopy; }  }  }  } public HugeObjectArray<T> copyOf(long newLength, AllocationTracker tracker) { Class<T> tCls = (Class)this.page.getClass().getComponentType(); HugeObjectArray<T> copy = HugeObjectArray.newArray(tCls, newLength, tracker); copyTo(copy, newLength); return copy; } public long size() { return this.size; } public long sizeOf() { return MemoryUsage.sizeOfObjectArray(this.size); } public long release() { if (this.page != null) { this.page = null; return MemoryUsage.sizeOfObjectArray(this.size); }  return 0L; } public HugeCursor<T[]> newCursor() { return new HugeCursor.SinglePageCursor<>(this.page); } public T[] toArray() { return this.page; } public String toString() { return Arrays.toString((Object[])this.page); }
  } private static final class PagedHugeObjectArray<T> extends HugeObjectArray<T> {
    private static <T> HugeObjectArray<T> of(Class<T> componentClass, long size, AllocationTracker tracker) { int numPages = HugeArrays.numberOfPages(size);
      T[][] pages = (T[][])Array.newInstance(componentClass, new int[] { numPages, 16384 });
      
      long memoryUsed = MemoryUsage.sizeOfObjectArray(numPages);
      long pageBytes = MemoryUsage.sizeOfObjectArray(16384);
      memoryUsed += (numPages - 1) * pageBytes;
      int lastPageSize = HugeArrays.exclusiveIndexOfPage(size);
      pages[numPages - 1] = (T[])Array.newInstance(componentClass, lastPageSize);
      memoryUsed += MemoryUsage.sizeOfObjectArray(lastPageSize);
      tracker.add(memoryUsed);
      
      return new PagedHugeObjectArray<>(size, pages, memoryUsed); }

    
    private final long size;
    private T[][] pages;
    private final long memoryUsed;
    
    private PagedHugeObjectArray(long size, T[][] pages, long memoryUsed) {
      this.size = size;
      this.pages = pages;
      this.memoryUsed = memoryUsed;
    }

    
    public T get(long index) {
      assert index < this.size;
      int pageIndex = HugeArrays.pageIndex(index);
      int indexInPage = HugeArrays.indexInPage(index);
      return this.pages[pageIndex][indexInPage];
    }

    
    public void set(long index, T value) {
      assert index < this.size;
      int pageIndex = HugeArrays.pageIndex(index);
      int indexInPage = HugeArrays.indexInPage(index);
      this.pages[pageIndex][indexInPage] = value;
    }

    
    public T putIfAbsent(long index, Supplier<T> supplier) {
      assert index < this.size;
      int pageIndex = HugeArrays.pageIndex(index);
      int indexInPage = HugeArrays.indexInPage(index);
      T[] page = this.pages[pageIndex];
      T value;
      if ((value = page[indexInPage]) == null && (
        value = supplier.get()) != null) {
        page[indexInPage] = value;
      }
      
      return value;
    }

    
    public void setAll(LongFunction<T> gen) {
      for (int i = 0; i < this.pages.length; i++) {
        long t = i << 14L;
        Arrays.setAll(this.pages[i], j -> gen.apply(t + j));
      } 
    }

    
    public void fill(T value) {
      for (T[] page : this.pages) {
        Arrays.fill((Object[])page, value);
      }
    }

    
    public void copyTo(HugeObjectArray<T> dest, long length) {
      if (length > this.size) {
        length = this.size;
      }
      if (length > dest.size()) {
        length = dest.size();
      }
      if (dest instanceof HugeObjectArray.SingleHugeObjectArray) {
        HugeObjectArray.SingleHugeObjectArray<T> dst = (HugeObjectArray.SingleHugeObjectArray<T>)dest;
        int start = 0;
        int remaining = (int)length;
        for (T[] page : this.pages) {
          int toCopy = Math.min(remaining, page.length);
          if (toCopy == 0) {
            break;
          }
          System.arraycopy(page, 0, dst.page, start, toCopy);
          start += toCopy;
          remaining -= toCopy;
        } 
        Arrays.fill((Object[])dst.page, start, dst.size, null);
      } else if (dest instanceof PagedHugeObjectArray) {
        PagedHugeObjectArray<T> dst = (PagedHugeObjectArray<T>)dest;
        int pageLen = Math.min(this.pages.length, dst.pages.length);
        int lastPage = pageLen - 1;
        long remaining = length;
        for (int i = 0; i < lastPage; i++) {
          T[] page = this.pages[i];
          T[] arrayOfT = dst.pages[i];
          System.arraycopy(page, 0, arrayOfT, 0, page.length);
          remaining -= page.length;
        } 
        if (remaining > 0L) {
          System.arraycopy(this.pages[lastPage], 0, dst.pages[lastPage], 0, (int)remaining);
          Arrays.fill((Object[])dst.pages[lastPage], (int)remaining, (dst.pages[lastPage]).length, null);
        } 
        for (int i = pageLen; i < dst.pages.length; i++) {
          Arrays.fill((Object[])dst.pages[i], null);
        }
      } 
    }

    
    public HugeObjectArray<T> copyOf(long newLength, AllocationTracker tracker) {
      Class<T> tCls = (Class)this.pages.getClass().getComponentType().getComponentType();
      HugeObjectArray<T> copy = HugeObjectArray.newArray(tCls, newLength, tracker);
      copyTo(copy, newLength);
      return copy;
    }


    
    public long size() { return this.size; }



    
    public long sizeOf() { return this.memoryUsed; }


    
    public long release() {
      if (this.pages != null) {
        this.pages = (T[][])null;
        return this.memoryUsed;
      } 
      return 0L;
    }


    
    public HugeCursor<T[]> newCursor() { return new HugeCursor.PagedCursor<>(this.size, this.pages); }




    
    public T[] toArray() { return dumpToArray((Class)this.pages.getClass().getComponentType()); }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\HugeObjectArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */