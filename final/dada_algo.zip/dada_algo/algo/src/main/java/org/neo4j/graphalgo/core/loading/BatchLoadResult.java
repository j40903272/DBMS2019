package org.neo4j.graphalgo.core.loading;

























class BatchLoadResult
{
  private final long offset;
  private final long rows;
  private final long maxId;
  private final long count;
  
  BatchLoadResult(long offset, long rows, long maxId, long count) {
    this.offset = offset;
    this.rows = rows;
    this.maxId = maxId;
    this.count = count;
  }

  
  long offset() { return this.offset; }


  
  long rows() { return this.rows; }


  
  long maxId() { return this.maxId; }


  
  long count() { return this.count; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\BatchLoadResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */