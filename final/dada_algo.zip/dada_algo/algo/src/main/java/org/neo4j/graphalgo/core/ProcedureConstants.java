package org.neo4j.graphalgo.core;



















































public final class ProcedureConstants
{
  public static final String NODE_LABEL_QUERY_KEY = "nodeQuery";
  public static final String RELATIONSHIP_QUERY_KEY = "relationshipQuery";
  public static final String DEFAULT_VALUE_KEY = "defaultValue";
  public static final double DEFAULT_VALUE_DEFAULT = 1.0D;
  public static final String NODE_PROPERTIES_KEY = "nodeProperties";
  public static final String RELATIONSHIP_WEIGHT_KEY = "relationshipWeight";
  public static final String RELATIONSHIP_PROPERTIES_KEY = "relationshipProperties";
  public static final String RELATIONSHIP_PROPERTIES_PROPERTY_KEY = "property";
  public static final String RELATIONSHIP_PROPERTIES_AGGREGATION_KEY = "aggregation";
  public static final String RELATIONSHIP_PROPERTIES_DEFAULT_VALUE_KEY = "defaultValue";
  public static final String RELATIONSHIP_PROPERTY_KEY = "relationshipProperty";
  public static final String RELATIONSHIP_DISTRIBUTION_KEY = "relationshipDistribution";
  public static final String RELATIONSHIP_PROPERTY_NAME_KEY = "name";
  public static final String RELATIONSHIP_PROPERTY_TYPE_KEY = "type";
  public static final String RELATIONSHIP_PROPERTY_MIN_KEY = "min";
  public static final String RELATIONSHIP_PROPERTY_MAX_KEY = "max";
  public static final String RELATIONSHIP_PROPERTY_VALUE_KEY = "value";
  public static final String GRAPH_IMPL_KEY = "graph";
  public static final String GRAPH_IMPL_DEFAULT = "huge";
  public static final String DIRECTION_KEY = "direction";
  public static final String UNDIRECTED_KEY = "undirected";
  public static final String SORTED_KEY = "sorted";
  public static final String CYPHER_QUERY_KEY = "cypher";
  public static final String WRITE_FLAG_KEY = "write";
  public static final String WRITE_PROPERTY_KEY = "writeProperty";
  public static final String WRITE_PROPERTY_DEFAULT = "writeValue";
  public static final String BATCH_SIZE_KEY = "batchSize";
  public static final String CONCURRENCY_KEY = "concurrency";
  public static final String READ_CONCURRENCY_KEY = "readConcurrency";
  public static final String WRITE_CONCURRENCY_KEY = "writeConcurrency";
  public static final String ITERATIONS_KEY = "iterations";
  @Deprecated
  public static final String DEPRECATED_RELATIONSHIP_PROPERTY_KEY = "weightProperty";
  public static final String STATS_FLAG_KEY = "stats";
  public static final String SKIP_VALUE_KEY = "skipValue";
  public static final String DAMPING_FACTOR_KEY = "dampingFactor";
  public static final Double DAMPING_FACTOR_DEFAULT = Double.valueOf(0.85D);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\ProcedureConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */