package org.roaringbitmap;






















public interface BatchIterator
  extends Cloneable
{
  int nextBatch(int[] paramArrayOfint);
  
  boolean hasNext();
  
  BatchIterator clone();
  
  default IntIterator asIntIterator(int[] buffer) { return new BatchIntIterator(this, buffer); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\roaringbitmap\BatchIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */