package org.neo4j.graphalgo.core.utils;

import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Supplier;
import org.neo4j.logging.Log;

























public class ProgressLoggerAdapter
  implements ProgressLogger
{
  private final Log log;
  private final String task;
  private int logIntervalMillis = 10000;
  
  private AtomicLong lastLog = new AtomicLong(0L);
  
  public ProgressLoggerAdapter(Log log, String task) {
    this.log = log;
    this.task = task;
  }

  
  public void logProgress(double percentDone, Supplier<String> msgFactory) {
    long currentTime = System.currentTimeMillis();
    long lastLogTime = this.lastLog.get();
    if (currentTime > lastLogTime + this.logIntervalMillis && this.lastLog.compareAndSet(lastLogTime, currentTime)) {
      doLog((int)(percentDone * 100.0D), msgFactory);
    }
  }


  
  public void log(Supplier<String> msgFactory) { doLog(100, msgFactory); }


  
  public void withLogIntervalMillis(int logIntervalMillis) { this.logIntervalMillis = logIntervalMillis; }

  
  private void doLog(int percent, Supplier<String> msgFactory) {
    String message = (msgFactory != ProgressLogger.NO_MESSAGE) ? msgFactory.get() : null;
    if (message == null || message.isEmpty()) {
      this.log.info("[%s] %s %d%%", new Object[] { Thread.currentThread().getName(), this.task, Integer.valueOf(percent) });
    } else {
      this.log.info("[%s] %s %d%% %s", new Object[] { Thread.currentThread().getName(), this.task, Integer.valueOf(percent), message });
    } 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\ProgressLoggerAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */