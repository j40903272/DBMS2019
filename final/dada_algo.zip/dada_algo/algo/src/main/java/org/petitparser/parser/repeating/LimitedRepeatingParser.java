package org.petitparser.parser.repeating;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import org.petitparser.parser.Parser;






public abstract class LimitedRepeatingParser
  extends RepeatingParser
{
  protected Parser limit;
  
  public LimitedRepeatingParser(Parser delegate, Parser limit, int min, int max) {
    super(delegate, min, max);
    this.limit = Objects.requireNonNull(limit, "Undefined limit parser");
  }


  
  public List<Parser> getChildren() { return Arrays.asList(new Parser[] { this.delegate, this.limit }); }


  
  public void replace(Parser source, Parser target) {
    super.replace(source, target);
    if (this.limit == source)
      this.limit = target; 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\repeating\LimitedRepeatingParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */