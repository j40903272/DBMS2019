package org.neo4j.graphalgo.core.loading;
import java.util.Collection;
final class InternalImporter { private final int numberOfThreads; private final CreateScanner createScanner;
  InternalImporter(int numberOfThreads, CreateScanner createScanner) {
    this.numberOfThreads = numberOfThreads;
    this.createScanner = createScanner;
  }
  ImportResult runImport(ExecutorService pool) {
    Collection<RecordScanner> tasks = new ArrayList<>(this.numberOfThreads);
    for (int i = 0; i < this.numberOfThreads; i++)
      tasks.add(this.createScanner.create(i)); 
    long scannerStart = System.nanoTime();
    ParallelUtil.run(tasks, pool);
    ParallelUtil.run(this.createScanner.flushTasks(), pool);
    long took = System.nanoTime() - scannerStart;
    long importedRecords = 0L;
    long importedProperties = 0L;
    for (RecordScanner task : tasks) {
      importedRecords += task.recordsImported();
      importedProperties += task.propertiesImported();
    } 
    return new ImportResult(took, importedRecords, importedProperties);
  }
  static interface CreateScanner { RecordScanner create(int param1Int);
    
    Collection<Runnable> flushTasks(); }
  
  static final class ImportResult { final long tookNanos;
    final long recordsImported;
    final long propertiesImported;
    
    ImportResult(long tookNanos, long recordsImported, long propertiesImported) {
      this.tookNanos = tookNanos;
      this.recordsImported = recordsImported;
      this.propertiesImported = propertiesImported;
    } }
  
  static CreateScanner createEmptyScanner() { return 











































      
      INSTANCE; }
  private static final class NoRecordsScanner implements RecordScanner, CreateScanner { private static final NoRecordsScanner INSTANCE = new NoRecordsScanner();


    
    public long propertiesImported() { return 0L; }



    
    public long recordsImported() { return 0L; }



    
    public void run() {}


    
    public RecordScanner create(int index) { return this; }



    
    public Collection<Runnable> flushTasks() { return Collections.emptyList(); } }
   }


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\InternalImporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */