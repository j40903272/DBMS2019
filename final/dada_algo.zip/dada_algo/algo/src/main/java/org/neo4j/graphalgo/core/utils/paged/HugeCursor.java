package org.neo4j.graphalgo.core.utils.paged;

import java.lang.reflect.Array;


































































public abstract class HugeCursor<Array>
  implements AutoCloseable
{
  public long base;
  public Array array;
  public int offset;
  public int limit;
  
  public abstract boolean next();
  
  public abstract void close();
  
  abstract void setRange();
  
  abstract void setRange(long paramLong1, long paramLong2);
  
  static final class SinglePageCursor<Array>
    extends HugeCursor<Array>
  {
    private boolean exhausted;
    
    SinglePageCursor(Array page) {
      this.array = page;
      this.base = 0L;
    }


    
    void setRange() { setRange(0, Array.getLength(this.array)); }



    
    void setRange(long start, long end) { setRange((int)start, (int)end); }

    
    private void setRange(int start, int end) {
      this.exhausted = false;
      this.offset = start;
      this.limit = end;
    }

    
    public final boolean next() {
      if (this.exhausted) {
        return false;
      }
      this.exhausted = true;
      return true;
    }

    
    public void close() {
      this.array = null;
      this.limit = 0;
      this.exhausted = true;
    }
  }
  
  static final class PagedCursor<Array>
    extends HugeCursor<Array>
  {
    private Array[] pages;
    private int pageIndex;
    private int fromPage;
    private int maxPage;
    private long capacity;
    private long end;
    
    PagedCursor(long capacity, Array[] pages) {
      this.capacity = capacity;
      this.pages = pages;
    }


    
    void setRange() { setRange(0L, this.capacity); }


    
    void setRange(long start, long end) {
      this.fromPage = HugeArrays.pageIndex(start);
      this.maxPage = HugeArrays.pageIndex(end - 1L);
      this.pageIndex = this.fromPage - 1;
      this.end = end;
      this.base = this.fromPage << 14L;
      this.offset = HugeArrays.indexInPage(start);
      this.limit = (this.fromPage == this.maxPage) ? HugeArrays.exclusiveIndexOfPage(end) : 16384;
    }

    
    public final boolean next() {
      int current = ++this.pageIndex;
      if (current > this.maxPage) {
        return false;
      }
      this.array = this.pages[current];
      if (current == this.fromPage) {
        return true;
      }
      this.base += 16384L;
      this.offset = 0;
      this.limit = (current == this.maxPage) ? HugeArrays.exclusiveIndexOfPage(this.end) : Array.getLength(this.array);
      return true;
    }

    
    public void close() {
      this.array = null;
      this.pages = null;
      this.base = 0L;
      this.end = 0L;
      this.limit = 0;
      this.capacity = 0L;
      this.maxPage = -1;
      this.fromPage = -1;
      this.pageIndex = -1;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\HugeCursor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */