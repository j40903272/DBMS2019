package org.HdrHistogram;

import java.nio.ByteBuffer;
import java.util.zip.DataFormatException;





























public abstract class EncodableHistogram
{
  public abstract int getNeededByteBufferCapacity();
  
  public abstract int encodeIntoCompressedByteBuffer(ByteBuffer paramByteBuffer, int paramInt);
  
  public abstract long getStartTimeStamp();
  
  public abstract void setStartTimeStamp(long paramLong);
  
  public abstract long getEndTimeStamp();
  
  public abstract void setEndTimeStamp(long paramLong);
  
  public abstract String getTag();
  
  public abstract void setTag(String paramString);
  
  public abstract double getMaxValueAsDouble();
  
  static EncodableHistogram decodeFromCompressedByteBuffer(ByteBuffer buffer, long minBarForHighestTrackableValue) throws DataFormatException {
    int cookie = buffer.getInt(buffer.position());
    if (DoubleHistogram.isDoubleHistogramCookie(cookie)) {
      return DoubleHistogram.decodeFromCompressedByteBuffer(buffer, minBarForHighestTrackableValue);
    }
    return Histogram.decodeFromCompressedByteBuffer(buffer, minBarForHighestTrackableValue);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\EncodableHistogram.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */