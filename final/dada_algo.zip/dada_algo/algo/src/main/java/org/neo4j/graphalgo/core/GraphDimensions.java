package org.neo4j.graphalgo.core;

import java.util.stream.Collectors;
import org.neo4j.graphalgo.PropertyMapping;
import org.neo4j.graphalgo.PropertyMappings;
import org.neo4j.graphalgo.RelationshipTypeMapping;
import org.neo4j.graphalgo.RelationshipTypeMappings;
import org.neo4j.graphalgo.api.GraphSetup;































public final class GraphDimensions
{
  private long nodeCount;
  private final long highestNeoId;
  private long maxRelCount;
  private final int labelId;
  private final PropertyMappings nodeProperties;
  private final RelationshipTypeMappings relTypeMappings;
  private final PropertyMappings relProperties;
  
  public GraphDimensions(long nodeCount, long highestNeoId, long maxRelCount, int labelId, PropertyMappings nodeProperties, RelationshipTypeMappings relTypeMappings, PropertyMappings relProperties) {
    this.nodeCount = nodeCount;
    this.highestNeoId = highestNeoId;
    this.maxRelCount = maxRelCount;
    this.labelId = labelId;
    this.nodeProperties = nodeProperties;
    this.relTypeMappings = relTypeMappings;
    this.relProperties = relProperties;
  }

  
  public long nodeCount() { return this.nodeCount; }


  
  public void nodeCount(long nodeCount) { this.nodeCount = nodeCount; }


  
  public long highestNeoId() { return this.highestNeoId; }


  
  public long maxRelCount() { return this.maxRelCount; }


  
  public void maxRelCount(long maxRelCount) { this.maxRelCount = maxRelCount; }


  
  public int labelId() { return this.labelId; }


  
  public PropertyMappings nodeProperties() { return this.nodeProperties; }


  
  public RelationshipTypeMappings relationshipTypeMappings() { return this.relTypeMappings; }


  
  public PropertyMappings relProperties() { return this.relProperties; }

  
  public void checkValidNodePredicate(GraphSetup setup) {
    if (nonEmpty(setup.startLabel) && labelId() == -1) {
      throw new IllegalArgumentException(String.format("Node label not found: '%s'", new Object[] { setup.startLabel }));
    }
  }
  
  public void checkValidRelationshipTypePredicate(GraphSetup setup) {
    if (nonEmpty(setup.relationshipType)) {



      
      String missingTypes = this.relTypeMappings.stream().filter(m -> !m.doesExist()).map(RelationshipTypeMapping::typeName).collect(Collectors.joining("', '"));
      if (!missingTypes.isEmpty()) {
        throw new IllegalArgumentException(String.format("Relationship type(s) not found: '%s'", new Object[] { missingTypes }));
      }
    } 
  }



  
  public void checkValidNodeProperties() { checkValidProperties("Node", this.nodeProperties); }


  
  public void checkValidRelationshipProperty() { checkValidProperties("Relationship", this.relProperties); }









  
  private void checkValidProperties(String recordType, PropertyMappings mappings) {
    String missingProperties = mappings.stream().filter(mapping -> { int id = mapping.propertyKeyId(); String propertyKey = mapping.neoPropertyKey(); return (nonEmpty(propertyKey) && id == -1); }).map(PropertyMapping::neoPropertyKey).collect(Collectors.joining("', '"));
    if (!missingProperties.isEmpty()) {
      throw new IllegalArgumentException(String.format("%s properties not found: '%s'", new Object[] { recordType, missingProperties }));
    }
  }




  
  private static boolean nonEmpty(String s) { return (s != null && !s.isEmpty()); }
  
  public static class Builder
  {
    private long nodeCount;
    private long highestNeoId;
    private long maxRelCount;
    private int labelId;
    private PropertyMappings nodeProperties;
    private RelationshipTypeMappings relationshipTypeMappings;
    private PropertyMappings relProperties;
    
    public Builder setNodeCount(long nodeCount) {
      this.nodeCount = nodeCount;
      return this;
    }
    
    public Builder setHighestNeoId(long highestNeoId) {
      this.highestNeoId = highestNeoId;
      return this;
    }
    
    public Builder setMaxRelCount(long maxRelCount) {
      this.maxRelCount = maxRelCount;
      return this;
    }
    
    public Builder setLabelId(int labelId) {
      this.labelId = labelId;
      return this;
    }
    
    public Builder setNodeProperties(PropertyMappings nodeProperties) {
      this.nodeProperties = nodeProperties;
      return this;
    }
    
    public Builder setRelationshipTypeMappings(RelationshipTypeMappings relationshipTypeMappings) {
      this.relationshipTypeMappings = relationshipTypeMappings;
      return this;
    }
    
    public Builder setRelationshipProperties(PropertyMappings relProperties) {
      this.relProperties = relProperties;
      return this;
    }

    
    public GraphDimensions build() { return new GraphDimensions(this.nodeCount, this.highestNeoId, this.maxRelCount, this.labelId, this.nodeProperties, this.relationshipTypeMappings, this.relProperties); }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\GraphDimensions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */