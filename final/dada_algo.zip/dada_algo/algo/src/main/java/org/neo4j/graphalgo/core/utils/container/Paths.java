package org.neo4j.graphalgo.core.utils.container;

import com.carrotsearch.hppc.IntObjectMap;
import com.carrotsearch.hppc.IntObjectScatterMap;
import com.carrotsearch.hppc.cursors.IntObjectCursor;
import java.util.function.IntPredicate;
































public class Paths
{
  public static final int INITIAL_PATH_CAPACITY = 100;
  private final IntObjectMap<Path> paths;
  
  public Paths() { this(10000); }


  
  public Paths(int expectedElements) { this.paths = (IntObjectMap<Path>)new IntObjectScatterMap(expectedElements); }


  
  public void append(int pathId, int nodeId) {
    Path path;
    if (!this.paths.containsKey(pathId)) {
      path = new Path(100);
      this.paths.put(pathId, path);
    } else {
      path = (Path)this.paths.get(pathId);
    } 
    path.append(nodeId);
  }

  
  public int size(int pathId) { return this.paths.containsKey(pathId) ? ((Path)this.paths.get(pathId)).size() : 0; }

  
  public void forEach(int pathId, IntPredicate consumer) {
    if (this.paths.containsKey(pathId)) {
      ((Path)this.paths.get(pathId)).forEach(consumer);
    }
  }

  
  public void clear() { this.paths.forEach(p -> ((Path)p.value).clear()); }

  
  public void clear(int pathId) {
    Path path = (Path)this.paths.get(pathId);
    if (null != path)
      path.clear(); 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\container\Paths.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */