package org.petitparser.parser.primitive;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.petitparser.parser.Parser;









@FunctionalInterface
public interface CharacterPredicate
{
  static CharacterPredicate any() { return value -> true; }






  
  static CharacterPredicate anyOf(String string) {
    List<CharacterRange> ranges = (List<CharacterRange>)string.chars().mapToObj(value -> new CharacterRange((char)value, (char)value)).collect(Collectors.toList());
    return CharacterRange.toCharacterPredicate(ranges);
  }




  
  static CharacterPredicate none() { return value -> false; }






  
  static CharacterPredicate noneOf(String string) {
    List<CharacterRange> ranges = (List<CharacterRange>)string.chars().mapToObj(value -> new CharacterRange((char)value, (char)value)).collect(Collectors.toList());
    return CharacterRange.toCharacterPredicate(ranges).not();
  }




  
  static CharacterPredicate of(char character) { return value -> (value == character); }






  
  static CharacterPredicate range(char start, char stop) { return value -> (start <= value && value <= stop); }





  
  static CharacterPredicate ranges(char[] starts, char[] stops) {
    if (starts.length != stops.length) {
      throw new IllegalArgumentException("Invalid range sizes.");
    }
    for (int i = 0; i < starts.length; i++) {
      if (starts[i] > stops[i]) {
        throw new IllegalArgumentException("Invalid range: " + starts[i] + "-" + stops[i]);
      }
      if (i + 1 < starts.length && starts[i + 1] <= stops[i]) {
        throw new IllegalArgumentException("Invalid sequence.");
      }
    } 
    return value -> {
        int index = Arrays.binarySearch(starts, value);
        return (index >= 0 || (index < -1 && value <= stops[-index - 2]));
      };
  }




  
  static CharacterPredicate pattern(String pattern) { return (CharacterPredicate)PatternParser.PATTERN.parse(pattern).get(); }
  
  public static class PatternParser
  {
    static final Parser PATTERN_SIMPLE = CharacterParser.any()
      .map(value -> new CharacterRange(value.charValue(), value.charValue()));
    static final Parser PATTERN_RANGE = CharacterParser.any()
      .seq(new Parser[] { CharacterParser.of('-')
        }).seq(new Parser[] { CharacterParser.any()
        }).map(values -> new CharacterRange(((Character)values.get(0)).charValue(), ((Character)values.get(2)).charValue()));
    static final Parser PATTERN_POSITIVE = PATTERN_RANGE
      .or(new Parser[] { PATTERN_SIMPLE }).star()
      .map(CharacterRange::toCharacterPredicate);
    static final Parser PATTERN = CharacterParser.of('^').optional()
      .seq(new Parser[] { PATTERN_POSITIVE
        }).map(predicate -> 
        (predicate.get(0) == null) ? predicate.get(1) : ((CharacterPredicate)predicate.get(1)).not())
      .end();
  }









  
  default CharacterPredicate not() { return new NotCharacterPredicate(this); }

  
  boolean test(char paramChar);

  
  public static class NotCharacterPredicate
    implements CharacterPredicate
  {
    private final CharacterPredicate predicate;
    
    public NotCharacterPredicate(CharacterPredicate predicate) { this.predicate = predicate; }



    
    public boolean test(char value) { return !this.predicate.test(value); }



    
    public CharacterPredicate not() { return this.predicate; }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\primitive\CharacterPredicate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */