package org.neo4j.graphalgo.core.utils;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.lang3.StringUtils;
import org.petitparser.context.Result;
import org.petitparser.parser.Parser;
import org.petitparser.parser.combinators.ChoiceParser;
import org.petitparser.parser.primitive.CharacterParser;
import org.petitparser.utils.Functions;

























public final class RelationshipTypes
{
  private static final Parser PARSER;
  
  static  {
    CharacterParser characterParser1 = CharacterParser.of('_');
    CharacterParser characterParser2 = CharacterParser.of('`');
    CharacterParser characterParser3 = CharacterParser.of('|');
    CharacterParser characterParser4 = CharacterParser.of(':');
    ChoiceParser choiceParser = CharacterParser.letter().or(new Parser[] { (Parser)characterParser1, (Parser)CharacterParser.digit("expected letter, digit, or underscore") });
    Parser unescapedIdentifier = choiceParser.plus().flatten();
    Parser escapedIdentifier = characterParser2.seq(new Parser[] { characterParser2.neg().plus().flatten() }).seq(new Parser[] { (Parser)characterParser2 }).pick(1);
    Parser identifier = characterParser4.optional().seq(new Parser[] { (Parser)escapedIdentifier.or(new Parser[] { unescapedIdentifier }) }).pick(1);
    PARSER = identifier.separatedBy(characterParser3.trim()).map(Functions.withoutSeparators()).end("expected letter, digit, or underscore");
  }
  
  public static Set<String> parse(String relTypes) {
    if (relTypes == null || relTypes.isEmpty()) {
      return Collections.emptySet();
    }
    Result result = PARSER.parse(relTypes);
    if (result.isSuccess()) {
      List<String> types = (List<String>)result.get();
      return new LinkedHashSet<>(types);
    } 
    int errorPos = result.getPosition();
    String errorPointer = "^";
    errorPointer = StringUtils.leftPad(errorPointer, errorPos + 1, '~');
    errorPointer = StringUtils.rightPad(errorPointer, relTypes.length(), '~');
    
    throw new IllegalArgumentException(String.format("Could not parse relationship types: %s (at position %d):%n%s%n%s", new Object[] { result
            
            .getMessage(), Integer.valueOf(errorPos), relTypes, errorPointer }));
  }

  
  private RelationshipTypes() { throw new UnsupportedOperationException("No instances"); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\RelationshipTypes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */