package org.neo4j.graphalgo.core.utils.paged;





















final class HugeArrays
{
  static final int PAGE_SHIFT = 14;
  static final int PAGE_SIZE = 16384;
  private static final long PAGE_MASK = 16383L;
  
  static int pageIndex(long index) { return (int)(index >>> 14L); }


  
  static int indexInPage(long index) { return (int)(index & 0x3FFFL); }


  
  static int exclusiveIndexOfPage(long index) { return 1 + (int)(index - 1L & 0x3FFFL); }

  
  static int numberOfPages(long capacity) {
    long numPages = capacity + 16383L >>> 14L;
    assert numPages <= 2147483647L : "pageSize=16384 is too small for capacity: " + capacity;
    return (int)numPages;
  }

  
  private HugeArrays() { throw new UnsupportedOperationException("No instances"); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\HugeArrays.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */