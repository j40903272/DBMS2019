package org.neo4j.graphalgo.core.utils.paged;

import java.lang.reflect.Array;
import java.util.function.Supplier;
import org.neo4j.graphalgo.core.utils.BitUtil;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;































public abstract class PageAllocator<T>
{
  public final long estimateMemoryUsage(long size) {
    long numPages = PageUtil.numPagesFor(size, pageSize());
    return numPages * bytesPerPage();
  }





  
  public static <T> Factory<T> of(int pageSize, long bytesPerPage, Supplier<T> newPage, T[] emptyPages) { return new Factory<>(pageSize, bytesPerPage, pageFactory(newPage, bytesPerPage), (Object[])emptyPages); }






  
  public static <T> Factory<T> of(int pageSize, long bytesPerPage, PageFactory<T> newPage, T[] emptyPages) { return new Factory<>(pageSize, bytesPerPage, newPage, (Object[])emptyPages); }


  
  public static <T> Factory<T> ofArray(Class<T> arrayClass) {
    Class<?> componentType = arrayClass.getComponentType();
    assert componentType != null && componentType.isPrimitive();
    
    long bytesPerElement = MemoryUsage.sizeOfInstance(componentType);
    int pageSize = PageUtil.pageSizeFor((int)bytesPerElement);
    
    long bytesPerPage = MemoryUsage.sizeOfArray(pageSize, bytesPerElement);
    
    T[] emptyPages = (T[])Array.newInstance(componentType, new int[] { 0, 0 });
    PageFactory<T> newPage = tracker -> {
        tracker.add(bytesPerPage);
        return Array.newInstance(componentType, pageSize);
      };
    
    return of(pageSize, bytesPerPage, newPage, emptyPages);
  }

  
  public static <T> Factory<T> ofArray(Class<T> arrayClass, int pageSize) {
    Class<?> componentType = arrayClass.getComponentType();
    assert componentType != null && componentType.isPrimitive();
    
    long bytesPerElement = MemoryUsage.sizeOfInstance(componentType);
    long bytesPerPage = MemoryUsage.sizeOfArray(pageSize, bytesPerElement);
    
    T[] emptyPages = (T[])Array.newInstance(componentType, new int[] { 0, 0 });
    PageFactory<T> newPage = tracker -> {
        tracker.add(bytesPerPage);
        return Array.newInstance(componentType, pageSize);
      };
    
    return of(pageSize, bytesPerPage, newPage, emptyPages);
  }

  
  public static final class Factory<T>
  {
    private final int pageSize;
    
    private final long bytesPerPage;
    
    private final PageAllocator.PageFactory<T> newPage;
    
    private final T[] emptyPages;
    
    private Factory(int pageSize, long bytesPerPage, PageAllocator.PageFactory<T> newPage, T[] emptyPages) {
      this.pageSize = pageSize;
      this.bytesPerPage = bytesPerPage;
      this.newPage = newPage;
      this.emptyPages = emptyPages;
    }
    
    public long estimateMemoryUsage(long size) {
      long numPages = PageUtil.numPagesFor(size, this.pageSize);
      return numPages * this.bytesPerPage;
    }

    
    public long estimateMemoryUsage(long size, Class<?> container) { return MemoryUsage.sizeOfInstance(container) + estimateMemoryUsage(size); }


    
    int pageSize() { return this.pageSize; }

    
    PageAllocator<T> newAllocator(AllocationTracker tracker) {
      if (AllocationTracker.isTracking(tracker)) {
        return new PageAllocator.TrackingAllocator<>(this.newPage, (Object[])this.emptyPages, this.pageSize, this.bytesPerPage, tracker);
      }




      
      return new PageAllocator.DirectAllocator<>(this.newPage, (Object[])this.emptyPages, this.pageSize, this.bytesPerPage);
    }
  }
  
  @FunctionalInterface
  public static interface PageFactory<T>
  {
    T newPage(AllocationTracker param1AllocationTracker);
    
    default T newPage() { return newPage(AllocationTracker.EMPTY); }
  }

  
  private static <T> PageFactory<T> pageFactory(Supplier<T> newPage, long bytesPerPage) {
    return tracker -> {
        tracker.add(bytesPerPage);
        return newPage.get();
      };
  }
  
  public abstract T newPage();
  
  public abstract int pageSize();
  
  public abstract T[] emptyPages();
  
  public abstract long bytesPerPage();
  
  private static final class TrackingAllocator<T>
    extends PageAllocator<T> {
    private final PageAllocator.PageFactory<T> newPage;
    private final T[] emptyPages;
    
    private TrackingAllocator(PageAllocator.PageFactory<T> newPage, T[] emptyPages, int pageSize, long bytesPerPage, AllocationTracker tracker) {
      this.emptyPages = emptyPages;
      assert BitUtil.isPowerOfTwo(pageSize);
      this.newPage = newPage;
      this.pageSize = pageSize;
      this.bytesPerPage = bytesPerPage;
      this.tracker = tracker;
    }
    private final int pageSize; private final long bytesPerPage;
    private final AllocationTracker tracker;
    
    public T newPage() { return this.newPage.newPage(this.tracker); }



    
    public int pageSize() { return this.pageSize; }



    
    public long bytesPerPage() { return this.bytesPerPage; }



    
    public T[] emptyPages() { return this.emptyPages; }
  }

  
  private static final class DirectAllocator<T>
    extends PageAllocator<T>
  {
    private final PageAllocator.PageFactory<T> newPage;
    
    private final T[] emptyPages;
    
    private final int pageSize;
    
    private final long bytesPerPage;
    
    private DirectAllocator(PageAllocator.PageFactory<T> newPage, T[] emptyPages, int pageSize, long bytesPerPage) {
      assert BitUtil.isPowerOfTwo(pageSize);
      this.emptyPages = emptyPages;
      this.newPage = newPage;
      this.pageSize = pageSize;
      this.bytesPerPage = bytesPerPage;
    }


    
    public T newPage() { return this.newPage.newPage(); }



    
    public int pageSize() { return this.pageSize; }



    
    public long bytesPerPage() { return this.bytesPerPage; }



    
    public T[] emptyPages() { return this.emptyPages; }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\PageAllocator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */