package org.neo4j.graphalgo.core.utils.paged;

import java.util.concurrent.atomic.AtomicLong;




















abstract class HugeArrayBuilder<Array, Huge extends HugeArray<Array, ?, Huge>>
{
  private final Huge array;
  private final long length;
  private final AtomicLong allocationIndex;
  private final ThreadLocal<BulkAdder<Array>> adders;
  
  HugeArrayBuilder(Huge array, long length) {
    this.array = array;
    this.length = length;
    this.allocationIndex = new AtomicLong();
    this.adders = ThreadLocal.withInitial(this::newBulkAdder);
  }

  
  private BulkAdder<Array> newBulkAdder() { return new BulkAdder<>((HugeArray)this.array, this.array.newCursor()); }

  
  public final BulkAdder<Array> allocate(long nodes) {
    long startIndex = this.allocationIndex.getAndAccumulate(nodes, this::upperAllocation);
    if (startIndex == this.length) {
      return null;
    }
    BulkAdder<Array> adder = this.adders.get();
    adder.reset(startIndex, upperAllocation(startIndex, nodes));
    return adder;
  }

  
  private long upperAllocation(long lower, long nodes) { return Math.min(this.length, lower + nodes); }


  
  public final Huge build() { return this.array; }


  
  public final long size() { return this.allocationIndex.get(); }

  
  public static final class BulkAdder<Array>
  {
    public Array buffer;
    
    public int offset;
    public int length;
    public long start;
    private final HugeArray<Array, ?, ?> array;
    private final HugeCursor<Array> cursor;
    
    private BulkAdder(HugeArray<Array, ?, ?> array, HugeCursor<Array> cursor) {
      this.array = array;
      this.cursor = cursor;
    }
    
    private void reset(long start, long end) {
      this.array.initCursor(this.cursor, start, end);
      this.start = start;
      this.buffer = null;
      this.offset = 0;
      this.length = 0;
    }
    
    public boolean nextBuffer() {
      if (!this.cursor.next()) {
        return false;
      }
      this.start += this.length;
      this.buffer = this.cursor.array;
      this.offset = this.cursor.offset;
      this.length = this.cursor.limit - this.cursor.offset;
      return true;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\HugeArrayBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */