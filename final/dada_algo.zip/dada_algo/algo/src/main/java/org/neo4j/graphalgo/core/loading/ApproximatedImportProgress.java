package org.neo4j.graphalgo.core.loading;

import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Supplier;
import org.neo4j.graphalgo.core.utils.BitUtil;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;























public final class ApproximatedImportProgress
  implements ImportProgress
{
  private final ProgressLogger progressLogger;
  private final AllocationTracker tracker;
  private final AtomicLong progress;
  private final long mask;
  private final long operations;
  
  public ApproximatedImportProgress(ProgressLogger progressLogger, AllocationTracker tracker, long expectedNodeOperations, long expectedRelationshipOperations) {
    this.progressLogger = progressLogger;
    this.tracker = tracker;
    this.operations = expectedNodeOperations + expectedRelationshipOperations;
    this.mask = (BitUtil.nearbyPowerOfTwo(this.operations) >>> 6L) - 1L;
    this.progress = new AtomicLong();
  }

  
  public void singleNodeImported() {
    long ops = this.progress.incrementAndGet();
    if ((ops & this.mask) == 0L) {
      this.progressLogger.logProgress(ops, this.operations, (Supplier)this.tracker);
    }
  }


  
  public void nodesImported(int numImported) { trackProgress(numImported); }



  
  public void relationshipsImported(int numImported) { trackProgress(numImported); }

  
  private void trackProgress(int numImported) {
    long opsBefore = this.progress.getAndAdd(numImported);
    long opsAfter = opsBefore + numImported;
    if ((opsAfter & this.mask) < (opsBefore & this.mask))
      this.progressLogger.logProgress(opsAfter, this.operations, (Supplier)this.tracker); 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\ApproximatedImportProgress.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */