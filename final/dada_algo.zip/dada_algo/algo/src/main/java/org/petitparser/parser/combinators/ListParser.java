package org.petitparser.parser.combinators;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import org.petitparser.parser.Parser;





public abstract class ListParser
  extends Parser
{
  protected final Parser[] parsers;
  
  public ListParser(Parser... parsers) { this.parsers = Objects.requireNonNull(parsers, "Undefined parser list"); }


  
  public void replace(Parser source, Parser target) {
    super.replace(source, target);
    for (int i = 0; i < this.parsers.length; i++) {
      if (this.parsers[i] == source) {
        this.parsers[i] = target;
      }
    } 
  }


  
  public List<Parser> getChildren() { return Arrays.asList(this.parsers); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\combinators\ListParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */