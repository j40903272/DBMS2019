package org.neo4j.graphalgo.core.loading;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import org.neo4j.graphalgo.PropertyMapping;
import org.neo4j.graphalgo.api.GraphSetup;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArrayBuilder;
import org.neo4j.kernel.internal.GraphDatabaseAPI;




















class CypherNodeLoader
  extends CypherRecordLoader<IdsAndProperties>
{
  private final HugeLongArrayBuilder builder;
  private final NodeImporter importer;
  private final Map<PropertyMapping, NodePropertiesBuilder> nodePropertyBuilders;
  private long maxNodeId;
  
  CypherNodeLoader(long nodeCount, GraphDatabaseAPI api, GraphSetup setup) {
    super(setup.startLabel, nodeCount, api, setup);
    this.maxNodeId = 0L;
    this.nodePropertyBuilders = nodeProperties(nodeCount, setup);
    this.builder = HugeLongArrayBuilder.of(nodeCount, setup.tracker);
    this.importer = new NodeImporter(this.builder, this.nodePropertyBuilders.values());
  }

  
  BatchLoadResult loadOneBatch(long offset, int batchSize, int bufferSize) {
    NodesBatchBuffer buffer = new NodesBatchBuffer(null, -1, bufferSize, true);
    NodeRowVisitor visitor = new NodeRowVisitor(this.nodePropertyBuilders, buffer, this.importer);
    runLoadingQuery(offset, batchSize, visitor);
    visitor.flush();
    return new BatchLoadResult(offset, visitor.rows(), visitor.maxId(), visitor.rows());
  }

  
  void updateCounts(BatchLoadResult result) {
    if (result.maxId() > this.maxNodeId) {
      this.maxNodeId = result.maxId();
    }
  }

  
  IdsAndProperties result() {
    IdMap idMap = IdMapBuilder.build(this.builder, this.maxNodeId, this.setup.concurrency, this.setup.tracker);
    
    Map<String, NodeProperties> nodeProperties = (Map<String, NodeProperties>)this.nodePropertyBuilders.entrySet().stream().collect(Collectors.toMap(e -> ((PropertyMapping)e.getKey()).propertyKey(), e -> ((NodePropertiesBuilder)e.getValue()).build()));
    return new IdsAndProperties(idMap, nodeProperties);
  }
  
  private Map<PropertyMapping, NodePropertiesBuilder> nodeProperties(long capacity, GraphSetup setup) {
    Map<PropertyMapping, NodePropertiesBuilder> nodeProperties = new HashMap<>();
    for (PropertyMapping propertyMapping : setup.nodePropertyMappings) {
      nodeProperties.put(propertyMapping, 
          
          NodePropertiesBuilder.of(capacity, AllocationTracker.EMPTY, propertyMapping

            
            .defaultValue(), -2, propertyMapping
            
            .propertyKey()));
    }
    return nodeProperties;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\CypherNodeLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */