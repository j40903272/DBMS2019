package org.petitparser.parser.actions;

import java.util.Objects;
import java.util.function.Function;
import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.parser.Parser;
import org.petitparser.parser.combinators.DelegateParser;










public class ContinuationParser
  extends DelegateParser
{
  private final ContinuationHandler handler;
  
  public ContinuationParser(Parser delegate, ContinuationHandler handler) {
    super(delegate);
    this.handler = Objects.requireNonNull(handler, "Undefined handler");
  }


  
  public Result parseOn(Context context) { return this.handler.apply(x$0 -> super.parseOn(x$0), context); }


  
  protected boolean hasEqualProperties(Parser other) {
    return (super.hasEqualProperties(other) && 
      Objects.equals(this.handler, ((ContinuationParser)other).handler));
  }


  
  public ContinuationParser copy() { return new ContinuationParser(this.delegate, this.handler); }
  
  @FunctionalInterface
  public static interface ContinuationHandler {
    Result apply(Function<Context, Result> param1Function, Context param1Context);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\actions\ContinuationParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */