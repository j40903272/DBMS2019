package org.jctools.queues;

import java.lang.reflect.Field;
import org.jctools.util.UnsafeAccess;









































































abstract class BaseLinkedQueueConsumerNodeRef<E>
  extends BaseLinkedQueuePad1<E>
{
  protected static final long C_NODE_OFFSET;
  protected LinkedQueueNode<E> consumerNode;
  
  static  {
    try {
      Field cNodeField = BaseLinkedQueueConsumerNodeRef.class.getDeclaredField("consumerNode");
      C_NODE_OFFSET = UnsafeAccess.UNSAFE.objectFieldOffset(cNodeField);
    }
    catch (NoSuchFieldException e) {
      
      throw new RuntimeException(e);
    } 
  }




  
  protected final void spConsumerNode(LinkedQueueNode<E> newValue) { this.consumerNode = newValue; }




  
  protected final LinkedQueueNode<E> lvConsumerNode() { return (LinkedQueueNode<E>)UnsafeAccess.UNSAFE.getObjectVolatile(this, C_NODE_OFFSET); }



  
  protected final LinkedQueueNode<E> lpConsumerNode() { return this.consumerNode; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\jctools\queues\BaseLinkedQueueConsumerNodeRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */