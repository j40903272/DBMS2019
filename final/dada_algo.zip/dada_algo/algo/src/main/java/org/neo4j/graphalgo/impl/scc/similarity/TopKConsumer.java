package org.neo4j.graphalgo.impl.similarity;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Stream;
import org.neo4j.graphalgo.impl.results.SimilarityResult;



















public class TopKConsumer<T>
  implements Function<T, Integer>
{
  private final int topK;
  private final T[] heap;
  private Comparator<T> comparator;
  private int count;
  private T minValue;
  private T maxValue;
  
  public TopKConsumer(int topK, Comparator<T> comparator) {
    this.topK = topK;
    this.heap = (T[])new Object[topK];
    this.comparator = comparator;
    this.count = 0;
    this.minValue = null;
    this.maxValue = null;
  }
  
  public static <T> List<T> topK(List<T> items, int topK, Comparator<T> comparator) {
    TopKConsumer<T> consumer = new TopKConsumer<>(topK, comparator);
    items.forEach(consumer::apply);
    return consumer.list();
  }
  
  public static <T> Stream<T> topK(Stream<T> items, int topK, Comparator<T> comparator) {
    TopKConsumer<T> consumer = new TopKConsumer<>(topK, comparator);
    items.forEach(consumer::apply);
    return consumer.stream();
  }
  
  public static TopKConsumer<SimilarityResult>[] initializeTopKConsumers(int length, int topK) {
    Comparator<SimilarityResult> comparator = (topK > 0) ? SimilarityResult.DESCENDING : SimilarityResult.ASCENDING;
    topK = Math.abs(topK);
    
    TopKConsumer[] arrayOfTopKConsumer = new TopKConsumer[length];
    for (int i = 0; i < arrayOfTopKConsumer.length; ) { arrayOfTopKConsumer[i] = new TopKConsumer<>(topK, comparator); i++; }
     return (TopKConsumer<SimilarityResult>[])arrayOfTopKConsumer;
  }
  
  static SimilarityConsumer assignSimilarityPairs(TopKConsumer<SimilarityResult>[] topKConsumers) {
    return (s, t, result) -> {
        
        int selectedIndex = result.reversed ? t : s;
        topKConsumers[selectedIndex].apply(result);
        
        if (result.bidirectional) {
          SimilarityResult reverse = result.reverse();
          topKConsumers[reverse.reversed ? t : s].apply(reverse);
        } 
      };
  }

  
  public Stream<T> stream() { return (this.count < this.topK) ? Arrays.stream(this.heap, 0, this.count) : Arrays.stream(this.heap); }

  
  public List<T> list() {
    List<T> list = Arrays.asList(this.heap);
    return (this.count < this.topK) ? list.subList(0, this.count) : list;
  }
  
  public int apply(TopKConsumer<T> other) {
    int changes = 0;
    if (this.minValue == null || this.count < this.topK || (other.maxValue != null && this.comparator.compare(other.maxValue, this.minValue) < 0)) {
      for (int i = 0; i < other.count; i++) {
        changes += apply(other.heap[i]).intValue();
      }
    }
    return changes;
  }

  
  public Integer apply(T item) {
    if (this.count < this.topK || this.minValue == null || this.comparator.compare(item, this.minValue) < 0) {
      int idx = Arrays.binarySearch(this.heap, 0, this.count, item, this.comparator);
      idx = (idx < 0) ? -idx : (idx + 1);
      
      int length = this.topK - idx;
      if (length > 0 && idx < this.topK) System.arraycopy(this.heap, idx - 1, this.heap, idx, length); 
      this.heap[idx - 1] = item;
      if (this.count < this.topK) this.count++; 
      this.minValue = this.heap[this.count - 1];
      this.maxValue = this.heap[0];
      return Integer.valueOf(1);
    } 
    return Integer.valueOf(0);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\similarity\TopKConsumer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */