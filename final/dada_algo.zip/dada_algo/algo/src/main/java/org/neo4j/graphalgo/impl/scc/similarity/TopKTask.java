package org.neo4j.graphalgo.impl.similarity;

import org.neo4j.graphalgo.impl.results.SimilarityResult;





















class TopKTask<T>
  implements Runnable
{
  private final int batchSize;
  private final int taskOffset;
  private final int multiplier;
  private final int length;
  private final T[] ids;
  private final double similiarityCutoff;
  private final SimilarityComputer<T> computer;
  private RleDecoder decoder;
  private final TopKConsumer<SimilarityResult>[] topKConsumers;
  
  TopKTask(int batchSize, int taskOffset, int multiplier, int length, T[] ids, double similiarityCutoff, int topK, SimilarityComputer<T> computer, RleDecoder decoder) {
    this.batchSize = batchSize;
    this.taskOffset = taskOffset;
    this.multiplier = multiplier;
    this.length = length;
    this.ids = ids;
    this.similiarityCutoff = similiarityCutoff;
    this.computer = computer;
    this.decoder = decoder;
    this.topKConsumers = TopKConsumer.initializeTopKConsumers(length, topK);
  }

  
  public void run() {
    SimilarityConsumer consumer = assignSimilarityPairs(this.topKConsumers);
    
    for (int offset = 0; offset < this.batchSize; offset++) {
      int sourceId = this.taskOffset * this.multiplier + offset;
      if (sourceId < this.length)
      {
        SimilarityStreamGenerator.computeSimilarityForSourceIndex(sourceId, this.ids, this.length, this.similiarityCutoff, consumer, this.computer, this.decoder);
      }
    } 
  }
  
  void mergeInto(TopKConsumer<SimilarityResult>[] target) {
    for (int i = 0; i < target.length; i++) {
      target[i].apply(this.topKConsumers[i]);
    }
  }
  
  public static SimilarityConsumer assignSimilarityPairs(TopKConsumer<SimilarityResult>[] topKConsumers) {
    return (s, t, result) -> {
        topKConsumers[result.reversed ? t : s].apply(result);
        
        if (result.bidirectional) {
          SimilarityResult reverse = result.reverse();
          topKConsumers[reverse.reversed ? t : s].apply(reverse);
        } 
      };
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\similarity\TopKTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */