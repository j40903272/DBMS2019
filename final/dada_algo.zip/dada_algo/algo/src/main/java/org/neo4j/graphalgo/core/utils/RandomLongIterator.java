package org.neo4j.graphalgo.core.utils;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import org.neo4j.collection.primitive.PrimitiveLongIterator;


































public final class RandomLongIterator
  implements PrimitiveLongIterator
{
  private static final long multiplier = 25214903917L;
  private static final long addend = 11L;
  private final long base;
  private final long range;
  private final long mask;
  private final long seed;
  private boolean hasNext;
  private long next;
  
  public RandomLongIterator(long start, long end) { this(start, end, ThreadLocalRandom.current()); }






  
  public RandomLongIterator(long end, Random random) { this(0L, end, random); }






  
  public RandomLongIterator(long start, long end, Random random) {
    long range = end - start;
    if (range < 0L || range > 4611686018427387904L) {
      throw new IndexOutOfBoundsException("[start, end) must not be negative or larger than 4611686018427387904");
    }
    long modulus = BitUtil.nextHighestPowerOfTwo(range);
    
    this.range = range;
    this.base = start;
    this.mask = modulus - 1L;
    this.seed = random.nextInt((int)Math.min(range, 2147483647L));
    this.next = this.seed;
    this.hasNext = true;
  }


  
  public boolean hasNext() { return this.hasNext; }


  
  public long next() {
    this.next = internalNext(this.next, this.mask, this.range);
    if (this.next == this.seed) {
      this.hasNext = false;
    }
    return this.next + this.base;
  }



  
  public void reset() {
    this.next = this.seed;
    this.hasNext = true;
  }
  
  private long internalNext(long next, long mask, long range) {
    next = next * 25214903917L + 11L & mask;
    while (next >= range) {
      next = next * 25214903917L + 11L & mask;
    }
    return next;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\RandomLongIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */