package org.neo4j.graphalgo.core.loading;





















public final class VarLongEncoding
{
  static int encodeVLongs(long[] values, int limit, byte[] out, int into) { return encodeVLongs(values, 0, limit, out, into); }

  
  static int encodeVLongs(long[] values, int offset, int end, byte[] out, int into) {
    for (int i = offset; i < end; i++) {
      into = encodeVLong(out, values[i], into);
    }
    return into;
  }

  
  private static int encodeVLong(byte[] buffer, long val, int output) {
    if (val < 128L) {
      buffer[output] = (byte)(int)(val | 0x80L);
      return 1 + output;
    }  if (val < 16384L) {
      buffer[output] = (byte)(int)(val & 0x7FL);
      buffer[1 + output] = (byte)(int)(val >> 7L | 0x80L);
      return 2 + output;
    }  if (val < 2097152L) {
      buffer[output] = (byte)(int)(val & 0x7FL);
      buffer[1 + output] = (byte)(int)(val >> 7L & 0x7FL);
      buffer[2 + output] = (byte)(int)(val >> 14L | 0x80L);
      return 3 + output;
    }  if (val < 268435456L) {
      buffer[output] = (byte)(int)(val & 0x7FL);
      buffer[1 + output] = (byte)(int)(val >> 7L & 0x7FL);
      buffer[2 + output] = (byte)(int)(val >> 14L & 0x7FL);
      buffer[3 + output] = (byte)(int)(val >> 21L | 0x80L);
      return 4 + output;
    }  if (val < 34359738368L) {
      buffer[output] = (byte)(int)(val & 0x7FL);
      buffer[1 + output] = (byte)(int)(val >> 7L & 0x7FL);
      buffer[2 + output] = (byte)(int)(val >> 14L & 0x7FL);
      buffer[3 + output] = (byte)(int)(val >> 21L & 0x7FL);
      buffer[4 + output] = (byte)(int)(val >> 28L | 0x80L);
      return 5 + output;
    }  if (val < 4398046511104L) {
      buffer[output] = (byte)(int)(val & 0x7FL);
      buffer[1 + output] = (byte)(int)(val >> 7L & 0x7FL);
      buffer[2 + output] = (byte)(int)(val >> 14L & 0x7FL);
      buffer[3 + output] = (byte)(int)(val >> 21L & 0x7FL);
      buffer[4 + output] = (byte)(int)(val >> 28L & 0x7FL);
      buffer[5 + output] = (byte)(int)(val >> 35L | 0x80L);
      return 6 + output;
    }  if (val < 562949953421312L) {
      buffer[output] = (byte)(int)(val & 0x7FL);
      buffer[1 + output] = (byte)(int)(val >> 7L & 0x7FL);
      buffer[2 + output] = (byte)(int)(val >> 14L & 0x7FL);
      buffer[3 + output] = (byte)(int)(val >> 21L & 0x7FL);
      buffer[4 + output] = (byte)(int)(val >> 28L & 0x7FL);
      buffer[5 + output] = (byte)(int)(val >> 35L & 0x7FL);
      buffer[6 + output] = (byte)(int)(val >> 42L | 0x80L);
      return 7 + output;
    }  if (val < 72057594037927936L) {
      buffer[output] = (byte)(int)(val & 0x7FL);
      buffer[1 + output] = (byte)(int)(val >> 7L & 0x7FL);
      buffer[2 + output] = (byte)(int)(val >> 14L & 0x7FL);
      buffer[3 + output] = (byte)(int)(val >> 21L & 0x7FL);
      buffer[4 + output] = (byte)(int)(val >> 28L & 0x7FL);
      buffer[5 + output] = (byte)(int)(val >> 35L & 0x7FL);
      buffer[6 + output] = (byte)(int)(val >> 42L & 0x7FL);
      buffer[7 + output] = (byte)(int)(val >> 49L | 0x80L);
      return 8 + output;
    } 
    buffer[output] = (byte)(int)(val & 0x7FL);
    buffer[1 + output] = (byte)(int)(val >> 7L & 0x7FL);
    buffer[2 + output] = (byte)(int)(val >> 14L & 0x7FL);
    buffer[3 + output] = (byte)(int)(val >> 21L & 0x7FL);
    buffer[4 + output] = (byte)(int)(val >> 28L & 0x7FL);
    buffer[5 + output] = (byte)(int)(val >> 35L & 0x7FL);
    buffer[6 + output] = (byte)(int)(val >> 42L & 0x7FL);
    buffer[7 + output] = (byte)(int)(val >> 49L & 0x7FL);
    buffer[8 + output] = (byte)(int)(val >> 56L | 0x80L);
    return 9 + output;
  }






  
  public static int encodedVLongSize(long val) {
    if (val < 128L)
      return 1; 
    if (val < 16384L)
      return 2; 
    if (val < 2097152L)
      return 3; 
    if (val < 268435456L)
      return 4; 
    if (val < 34359738368L)
      return 5; 
    if (val < 4398046511104L)
      return 6; 
    if (val < 562949953421312L)
      return 7; 
    if (val < 72057594037927936L) {
      return 8;
    }
    return 9;
  }


  
  static long zigZag(long value) { return value >> 63L ^ value << 1L; }


  
  private VarLongEncoding() { throw new UnsupportedOperationException("No instances"); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\VarLongEncoding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */