package org.petitparser.parser.combinators;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.parser.Parser;





public class SequenceParser
  extends ListParser
{
  public SequenceParser(Parser... parsers) { super(parsers); }


  
  public Result parseOn(Context context) {
    Object object = context;
    List<Object> elements = new ArrayList(this.parsers.length);
    for (Parser parser : this.parsers) {
      Result result = parser.parseOn((Context)object);
      if (result.isFailure()) {
        return result;
      }
      elements.add(result.get());
      object = result;
    } 
    return (Result)object.success(elements);
  }

  
  public SequenceParser seq(Parser... others) {
    Parser[] array = Arrays.copyOf(this.parsers, this.parsers.length + others.length);
    System.arraycopy(others, 0, array, this.parsers.length, others.length);
    return new SequenceParser(array);
  }


  
  public SequenceParser copy() { return new SequenceParser(Arrays.copyOf(this.parsers, this.parsers.length)); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\combinators\SequenceParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */