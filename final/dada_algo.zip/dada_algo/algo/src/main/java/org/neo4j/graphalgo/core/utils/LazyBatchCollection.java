package org.neo4j.graphalgo.core.utils;

import com.carrotsearch.hppc.AbstractIterator;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;





















public final class LazyBatchCollection<T>
  extends AbstractCollection<T>
{
  private final boolean saveResults;
  private final BatchSupplier<T> supplier;
  private final long nodeCount;
  private final long batchSize;
  private final int numberOfBatches;
  private List<T> batches;
  
  public static <T> Collection<T> of(long nodeCount, long batchSize, BatchSupplier<T> supplier) { return new LazyBatchCollection<>(batchSize, nodeCount, false, supplier); }













  
  private LazyBatchCollection(long batchSize, long nodeCount, boolean saveResults, BatchSupplier<T> supplier) {
    this.saveResults = saveResults;
    this.supplier = supplier;
    this.nodeCount = nodeCount;
    this.batchSize = batchSize;
    this.numberOfBatches = Math.toIntExact(ParallelUtil.threadCount(batchSize, nodeCount));
  }

  
  public Iterator<T> iterator() {
    if (this.batches != null) {
      return this.batches.iterator();
    }
    if (this.saveResults) {
      this.batches = new ArrayList<>(this.numberOfBatches);
    }
    return (Iterator<T>)new AbstractIterator<T>()
      {
        private int i;
        private long start;
        
        protected T fetch() {
          int i = this.i++;
          if (i >= LazyBatchCollection.this.numberOfBatches) {
            return (T)done();
          }
          long start = this.start;
          this.start += LazyBatchCollection.this.batchSize;
          long length = Math.min(LazyBatchCollection.this.batchSize, LazyBatchCollection.this.nodeCount - start);
          T t = LazyBatchCollection.this.supplier.newBatch(start, length);
          if (LazyBatchCollection.this.batches != null) {
            LazyBatchCollection.this.batches.add(t);
          }
          return t;
        }
      };
  }

  
  public int size() {
    if (this.batches != null) {
      return this.batches.size();
    }
    return this.numberOfBatches;
  }
  
  public static interface BatchSupplier<T> {
    T newBatch(long param1Long1, long param1Long2);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\LazyBatchCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */