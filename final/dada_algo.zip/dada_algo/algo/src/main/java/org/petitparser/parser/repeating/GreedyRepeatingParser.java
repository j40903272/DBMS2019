package org.petitparser.parser.repeating;

import java.util.ArrayList;
import java.util.List;
import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.parser.Parser;
import org.petitparser.parser.combinators.DelegateParser;





public class GreedyRepeatingParser
  extends LimitedRepeatingParser
{
  public GreedyRepeatingParser(Parser delegate, Parser limit, int min, int max) { super(delegate, limit, min, max); }

  
  public Result parseOn(Context context) {
    Result stop;
    Object object = context;
    List<Object> elements = new ArrayList();
    while (elements.size() < this.min) {
      Result result = this.delegate.parseOn((Context)object);
      if (result.isFailure()) {
        return result;
      }
      elements.add(result.get());
      object = result;
    } 
    List<Context> contexts = new ArrayList<>();
    contexts.add(object);
    while (this.max == -1 || elements.size() < this.max) {
      stop = this.delegate.parseOn((Context)object);
      if (stop.isFailure()) {
        break;
      }
      elements.add(stop.get());
      contexts.add(object = stop);
    } 
    do {
      stop = this.limit.parseOn(contexts.get(contexts.size() - 1));
      if (stop.isSuccess()) {
        return (Result)((Context)contexts.get(contexts.size() - 1)).success(elements);
      }
      if (elements.isEmpty()) {
        return stop;
      }
      contexts.remove(contexts.size() - 1);
      elements.remove(elements.size() - 1);
    } while (!contexts.isEmpty());
    return stop;
  }




  
  public GreedyRepeatingParser copy() { return new GreedyRepeatingParser(this.delegate, this.limit, this.min, this.max); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\repeating\GreedyRepeatingParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */