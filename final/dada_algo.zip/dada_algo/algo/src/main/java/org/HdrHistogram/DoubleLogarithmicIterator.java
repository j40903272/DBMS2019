package org.HdrHistogram;

import java.util.Iterator;


















public class DoubleLogarithmicIterator
  implements Iterator<DoubleHistogramIterationValue>
{
  private final LogarithmicIterator integerLogarithmicIterator;
  private final DoubleHistogramIterationValue iterationValue;
  DoubleHistogram histogram;
  
  public void reset(double valueUnitsInFirstBucket, double logBase) { this.integerLogarithmicIterator.reset((long)(valueUnitsInFirstBucket * this.histogram.doubleToIntegerValueConversionRatio), logBase); }










  
  public DoubleLogarithmicIterator(DoubleHistogram histogram, double valueUnitsInFirstBucket, double logBase) {
    this.histogram = histogram;
    this.integerLogarithmicIterator = new LogarithmicIterator(histogram.integerValuesHistogram, (long)(valueUnitsInFirstBucket * histogram.doubleToIntegerValueConversionRatio), logBase);



    
    this.iterationValue = new DoubleHistogramIterationValue(this.integerLogarithmicIterator.currentIterationValue);
  }


  
  public boolean hasNext() { return this.integerLogarithmicIterator.hasNext(); }


  
  public DoubleHistogramIterationValue next() {
    this.integerLogarithmicIterator.next();
    return this.iterationValue;
  }


  
  public void remove() { this.integerLogarithmicIterator.remove(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\DoubleLogarithmicIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */