package org.HdrHistogram;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicLong;

























abstract class AbstractHistogramBase
  extends EncodableHistogram
{
  static AtomicLong constructionIdentityCount = new AtomicLong(0L);
  
  long identity;
  
  volatile boolean autoResize = false;
  
  long highestTrackableValue;
  
  long lowestDiscernibleValue;
  
  int numberOfSignificantValueDigits;
  
  int bucketCount;
  
  int subBucketCount;
  
  int countsArrayLength;
  
  int wordSizeInBytes;
  long startTimeStampMsec = Long.MAX_VALUE;
  long endTimeStampMsec = 0L;
  String tag = null;
  
  double integerToDoubleValueConversionRatio = 1.0D;
  
  PercentileIterator percentileIterator;
  
  RecordedValuesIterator recordedValuesIterator;
  ByteBuffer intermediateUncompressedByteBuffer = null;
  byte[] intermediateUncompressedByteArray = null;

  
  double getIntegerToDoubleValueConversionRatio() { return this.integerToDoubleValueConversionRatio; }


  
  void setIntegerToDoubleValueConversionRatio(double integerToDoubleValueConversionRatio) { this.integerToDoubleValueConversionRatio = integerToDoubleValueConversionRatio; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\AbstractHistogramBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */