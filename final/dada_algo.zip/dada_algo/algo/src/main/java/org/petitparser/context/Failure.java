package org.petitparser.context;



public class Failure
  extends Result
{
  private final String message;
  
  public Failure(String buffer, int position, String message) {
    super(buffer, position);
    this.message = message;
  }


  
  public String getMessage() { return this.message; }



  
  public boolean isFailure() { return true; }



  
  public <T> T get() { throw new ParseError(this); }



  
  public String toString() { return super.toString() + ": " + this.message; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\context\Failure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */