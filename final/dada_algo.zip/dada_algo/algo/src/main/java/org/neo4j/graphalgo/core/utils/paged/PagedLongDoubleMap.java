package org.neo4j.graphalgo.core.utils.paged;

import com.carrotsearch.hppc.IntDoubleHashMap;
import java.util.Arrays;
import java.util.Objects;
import java.util.OptionalLong;
import java.util.function.Function;
import java.util.stream.Stream;
import org.neo4j.graphalgo.core.GraphDimensions;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.mem.MemoryRange;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;





















public final class PagedLongDoubleMap
{
  private static final int PAGE_SHIFT = 14;
  static final int PAGE_SIZE = 16384;
  private static final long PAGE_MASK = 16383L;
  private static final MemoryEstimation MEMORY_REQUIREMENTS = MemoryEstimations.builder(PagedLongDoubleMap.class)
    .add(MemoryEstimations.setup("pages[]", dimensions -> {
          int numPages = PageUtil.numPagesFor(dimensions.nodeCount(), 14, 16383L);
          long pagesArraySize = MemoryUsage.sizeOfObjectArray(numPages);
          MemoryEstimation pagesSize = MemoryEstimations.andThen(
              TrackingIntDoubleHashMap.memoryEstimation(), ());
          
          return 

            
            (Function)MemoryEstimations.builder().add(pagesSize).fixed("pages wrapper", pagesArraySize).build();
        })).build();
  
  public static PagedLongDoubleMap of(long size, AllocationTracker tracker) {
    int numPages = PageUtil.numPagesFor(size, 14, 16383L);
    tracker.add(MemoryUsage.sizeOfObjectArray(numPages));
    TrackingIntDoubleHashMap[] pages = new TrackingIntDoubleHashMap[numPages];
    return new PagedLongDoubleMap(pages, tracker);
  }

  
  private final AllocationTracker tracker;
  private TrackingIntDoubleHashMap[] pages;
  
  public static MemoryEstimation memoryEstimation() { return MEMORY_REQUIREMENTS; }



  
  private PagedLongDoubleMap(TrackingIntDoubleHashMap[] pages, AllocationTracker tracker) {
    this.pages = pages;
    this.tracker = tracker;
  }

  
  public long size() { return ((Long)ParallelUtil.parallelStream(Arrays.stream(this.pages), stream -> Long.valueOf(stream
          .filter(Objects::nonNull)
          .mapToLong(IntDoubleHashMap::size)
          .sum()))).longValue(); }

  
  public double getOrDefault(long index, double defaultValue) {
    int pageIndex = pageIndex(index);
    if (pageIndex < this.pages.length) {
      TrackingIntDoubleHashMap trackingIntDoubleHashMap = this.pages[pageIndex];
      if (trackingIntDoubleHashMap != null) {
        int indexInPage = indexInPage(index);
        return trackingIntDoubleHashMap.getOrDefault(indexInPage, defaultValue);
      } 
    } 
    return defaultValue;
  }
  
  public void put(long index, double value) {
    int pageIndex = pageIndex(index);
    TrackingIntDoubleHashMap subMap = subMap(pageIndex);
    int indexInPage = indexInPage(index);
    subMap.putSync(indexInPage, value);
  }
  
  private TrackingIntDoubleHashMap subMap(int pageIndex) {
    if (pageIndex >= this.pages.length) {
      return growNewSubMap(pageIndex);
    }
    TrackingIntDoubleHashMap subMap = this.pages[pageIndex];
    if (subMap != null) {
      return subMap;
    }
    return forceNewSubMap(pageIndex);
  }
  
  private synchronized TrackingIntDoubleHashMap growNewSubMap(int pageIndex) {
    if (pageIndex >= this.pages.length) {
      long allocated = MemoryUsage.sizeOfObjectArray(1 + pageIndex) - MemoryUsage.sizeOfObjectArray(this.pages.length);
      this.tracker.add(allocated);
      this.pages = Arrays.copyOf(this.pages, 1 + pageIndex);
    } 
    return forceNewSubMap(pageIndex);
  }
  
  private synchronized TrackingIntDoubleHashMap forceNewSubMap(int pageIndex) {
    TrackingIntDoubleHashMap subMap = this.pages[pageIndex];
    if (subMap == null) {
      subMap = new TrackingIntDoubleHashMap(this.tracker);
      this.pages[pageIndex] = subMap;
    } 
    return subMap;
  }
  
  public OptionalLong getMaxValue() {
    return (OptionalLong)ParallelUtil.parallelStream(Arrays.stream(this.pages), stream -> stream
        .filter(Objects::nonNull)
        .flatMapToDouble(TrackingIntDoubleHashMap::getValuesAsStream)
        .mapToLong(())
        .max());
  }
  
  public long release() {
    if (this.pages != null) {
      TrackingIntDoubleHashMap[] pages = this.pages;
      this.pages = null;
      long released = MemoryUsage.sizeOfObjectArray(pages.length);
      for (TrackingIntDoubleHashMap page : pages) {
        if (page != null) {
          released += page.instanceSize();
        }
      } 
      this.tracker.remove(released);
      return released;
    } 
    return 0L;
  }

  
  private static int pageIndex(long index) { return (int)(index >>> 14L); }


  
  private static int indexInPage(long index) { return (int)(index & 0x3FFFL); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\PagedLongDoubleMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */