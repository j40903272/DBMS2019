package org.neo4j.graphalgo.core.utils;

import org.neo4j.internal.kernel.api.exceptions.KernelException;
import org.neo4j.kernel.api.exceptions.Status;





























public final class ExceptionUtil
{
  public static Throwable rootCause(Throwable caughtException) {
    if (null == caughtException) {
      throw new IllegalArgumentException("Cannot obtain rootCause from (null)");
    }
    Throwable root = caughtException;
    while (root.getCause() != null) {
      root = root.getCause();
    }
    return root;
  }





  
  public static <T extends Throwable> T chain(T initial, T current) {
    if (initial == null) {
      return current;
    }
    
    if (current != null) {
      initial.addSuppressed((Throwable)current);
    }
    return initial;
  }
  
  public static RuntimeException asUnchecked(Throwable exception) {
    if (exception instanceof RuntimeException) {
      return (RuntimeException)exception;
    }
    if (exception instanceof Error) {
      throw (Error)exception;
    }
    return new RuntimeException(exception);
  }
  public static <T> T throwKernelException(KernelException e) {
    String newMessage;
    Status status = e.status();
    String codeString = status.code().serialize();
    String message = e.getMessage();
    
    if (message == null || message.isEmpty()) {
      newMessage = codeString;
    } else {
      newMessage = codeString + ": " + message;
    } 
    throw new RuntimeException(newMessage, (Throwable)e);
  }

  
  private ExceptionUtil() { throw new UnsupportedOperationException("No instances"); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\ExceptionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */