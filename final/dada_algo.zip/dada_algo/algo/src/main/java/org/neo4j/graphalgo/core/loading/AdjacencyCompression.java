package org.neo4j.graphalgo.core.loading;

import com.carrotsearch.hppc.sorting.IndirectComparator;
import com.carrotsearch.hppc.sorting.IndirectSort;
import java.util.Arrays;
import org.apache.lucene.util.LongsRef;
import org.neo4j.graphalgo.core.DeduplicationStrategy;
import org.neo4j.graphalgo.core.utils.AscendingLongComparator;






















final class AdjacencyCompression
{
  private static long[] growWithDestroy(long[] values, int newLength) {
    if (values.length < newLength) {




      
      int newSize = Math.max(32, 1 + newLength);
      return new long[newSize];
    } 
    return values;
  }
  
  static void copyFrom(LongsRef into, CompressedLongArray array) {
    into.longs = growWithDestroy(into.longs, array.length());
    into.length = array.uncompress(into.longs);
  }
  
  static int applyDeltaEncoding(LongsRef data, DeduplicationStrategy deduplicationStrategy) {
    Arrays.sort(data.longs, 0, data.length);
    return data.length = applyDelta(data.longs, data.length, deduplicationStrategy);
  }

  
  static int applyDeltaEncoding(LongsRef data, long[][] weights, DeduplicationStrategy[] deduplicationStrategies, boolean noDeduplication) {
    int[] order = IndirectSort.mergesort(0, data.length, (IndirectComparator)new AscendingLongComparator(data.longs));
    
    long[] sortedValues = new long[data.length];
    long[][] sortedWeights = new long[weights.length][data.length];
    
    data.length = applyDelta(order, data.longs, sortedValues, weights, sortedWeights, data.length, deduplicationStrategies, noDeduplication);









    
    System.arraycopy(sortedValues, 0, data.longs, 0, data.length);
    for (int i = 0; i < sortedWeights.length; i++) {
      long[] sortedWeight = sortedWeights[i];
      System.arraycopy(sortedWeight, 0, weights[i], 0, data.length);
    } 
    
    return data.length;
  }

  
  static int compress(LongsRef data, byte[] out) { return compress(data.longs, out, data.length); }


  
  static int compress(long[] data, byte[] out, int length) { return VarLongEncoding.encodeVLongs(data, length, out, 0); }


  
  static int writeDegree(byte[] out, int offset, int degree) {
    out[offset] = (byte)degree;
    out[1 + offset] = (byte)(degree >>> 8);
    out[2 + offset] = (byte)(degree >>> 16);
    out[3 + offset] = (byte)(degree >>> 24);
    return 4 + offset;
  }

  
  private static int applyDelta(long[] values, int length, DeduplicationStrategy deduplicationStrategy) {
    long value = values[0];
    int in = 1, out = 1;
    for (; in < length; in++) {
      long delta = values[in] - value;
      value = values[in];
      if (delta > 0L || deduplicationStrategy == DeduplicationStrategy.NONE) {
        values[out++] = delta;
      }
    } 
    return out;
  }














  
  private static int applyDelta(int[] order, long[] values, long[] outValues, long[][] weights, long[][] outWeights, int length, DeduplicationStrategy[] deduplicationStrategies, boolean noDeduplication) {
    int firstSortIdx = order[0];
    long value = values[firstSortIdx];

    
    outValues[0] = values[firstSortIdx];
    for (int i = 0; i < weights.length; i++) {
      outWeights[i][0] = weights[i][firstSortIdx];
    }
    
    int in = 1, out = 1;
    for (; in < length; in++) {
      int sortIdx = order[in];
      long delta = values[sortIdx] - value;
      value = values[sortIdx];
      
      if (delta > 0L || noDeduplication) {
        for (int i = 0; i < weights.length; i++) {
          outWeights[i][out] = weights[i][sortIdx];
        }
        outValues[out++] = delta;
      } else {
        for (int i = 0; i < weights.length; i++) {
          DeduplicationStrategy deduplicationStrategy = deduplicationStrategies[i];
          int existingIdx = out - 1;
          long[] outWeight = outWeights[i];
          double existingWeight = Double.longBitsToDouble(outWeight[existingIdx]);
          double newWeight = Double.longBitsToDouble(weights[i][sortIdx]);
          newWeight = deduplicationStrategy.merge(existingWeight, newWeight);
          outWeight[existingIdx] = Double.doubleToLongBits(newWeight);
        } 
      } 
    } 
    return out;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\AdjacencyCompression.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */