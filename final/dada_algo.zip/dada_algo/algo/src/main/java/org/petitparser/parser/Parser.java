package org.petitparser.parser;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.parser.actions.ActionParser;
import org.petitparser.parser.actions.ContinuationParser;
import org.petitparser.parser.actions.FlattenParser;
import org.petitparser.parser.actions.TokenParser;
import org.petitparser.parser.actions.TrimmingParser;
import org.petitparser.parser.combinators.AndParser;
import org.petitparser.parser.combinators.ChoiceParser;
import org.petitparser.parser.combinators.EndOfInputParser;
import org.petitparser.parser.combinators.NotParser;
import org.petitparser.parser.combinators.OptionalParser;
import org.petitparser.parser.combinators.SequenceParser;
import org.petitparser.parser.combinators.SettableParser;
import org.petitparser.parser.primitive.CharacterParser;
import org.petitparser.parser.repeating.GreedyRepeatingParser;
import org.petitparser.parser.repeating.LazyRepeatingParser;
import org.petitparser.parser.repeating.PossessiveRepeatingParser;
import org.petitparser.utils.Functions;

















public abstract class Parser
{
  public Result parse(String input) { return parseOn(new Context(input, 0)); }





  
  public boolean accept(String input) { return parse(input).isSuccess(); }





  
  public <T> List<T> matches(String input) {
    List<Object> list = new ArrayList();
    Objects.requireNonNull(list); and().map(list::add).seq(new Parser[] { (Parser)CharacterParser.any() }).or(new Parser[] { (Parser)CharacterParser.any() }).star().parse(input);
    return (List)list;
  }




  
  public <T> List<T> matchesSkipping(String input) {
    List<Object> list = new ArrayList();
    Objects.requireNonNull(list); map(list::add).or(new Parser[] { (Parser)CharacterParser.any() }).star().parse(input);
    return (List)list;
  }





  
  public Parser optional() { return optional(null); }






  
  public Parser optional(Object otherwise) { return (Parser)new OptionalParser(this, otherwise); }









  
  public Parser star() { return repeat(0, -1); }







  
  public Parser starGreedy(Parser limit) { return repeatGreedy(limit, 0, -1); }







  
  public Parser starLazy(Parser limit) { return repeatLazy(limit, 0, -1); }









  
  public Parser plus() { return repeat(1, -1); }







  
  public Parser plusGreedy(Parser limit) { return repeatGreedy(limit, 1, -1); }







  
  public Parser plusLazy(Parser limit) { return repeatLazy(limit, 1, -1); }









  
  public Parser repeat(int min, int max) { return (Parser)new PossessiveRepeatingParser(this, min, max); }







  
  public Parser repeatGreedy(Parser limit, int min, int max) { return (Parser)new GreedyRepeatingParser(this, limit, min, max); }







  
  public Parser repeatLazy(Parser limit, int min, int max) { return (Parser)new LazyRepeatingParser(this, limit, min, max); }






  
  public Parser times(int count) { return repeat(count, count); }







  
  public SequenceParser seq(Parser... others) {
    Parser[] parsers = new Parser[1 + others.length];
    parsers[0] = this;
    System.arraycopy(others, 0, parsers, 1, others.length);
    return new SequenceParser(parsers);
  }





  
  public ChoiceParser or(Parser... others) {
    Parser[] parsers = new Parser[1 + others.length];
    parsers[0] = this;
    System.arraycopy(others, 0, parsers, 1, others.length);
    return new ChoiceParser(parsers);
  }





  
  public Parser and() { return (Parser)new AndParser(this); }





  
  public Parser callCC(ContinuationParser.ContinuationHandler handler) { return (Parser)new ContinuationParser(this, handler); }






  
  public Parser not() { return not("unexpected"); }






  
  public Parser not(String message) { return (Parser)new NotParser(this, message); }





  
  public Parser neg() { return neg(this + " not expected"); }





  
  public Parser neg(String message) { return not(message).seq(new Parser[] { (Parser)CharacterParser.any() }).pick(1); }






  
  public Parser flatten() { return (Parser)new FlattenParser(this); }







  
  public Parser token() { return (Parser)new TokenParser(this); }





  
  public Parser trim() { return trim((Parser)CharacterParser.whitespace()); }





  
  public Parser trim(Parser both) { return trim(both, both); }





  
  public Parser trim(Parser before, Parser after) { return (Parser)new TrimmingParser(this, before, after); }





  
  public Parser end() { return end("end of input expected"); }






  
  public Parser end(String message) { return (Parser)new EndOfInputParser(this, message); }






  
  public SettableParser settable() { return SettableParser.with(this); }






  
  public <A, B> Parser map(Function<A, B> function) { return (Parser)new ActionParser(this, function); }







  
  public Parser pick(int index) { return map(Functions.nthOfList(index)); }







  
  public Parser permute(int... indexes) { return map(Functions.permutationOfList(indexes)); }





  
  public Parser separatedBy(Parser separator) {
    return (new SequenceParser(new Parser[] { this, (new SequenceParser(new Parser[] { separator, this })).star()
        })).map(input -> {
          List<Object> result = new ArrayList();
          result.add(input.get(0));
          Objects.requireNonNull(result); ((List)input.get(1)).forEach(result::addAll);
          return result;
        });
  }




  
  public Parser delimitedBy(Parser separator) {
    return separatedBy(separator)
      .seq(new Parser[] { separator.optional()
        }).map(input -> {
          List<Object> result = new ArrayList(input.get(0));
          if (input.get(1) != null) {
            result.add(input.get(1));
          }
          return result;
        });
  }












  
  public boolean isEqualTo(Parser other) { return isEqualTo(other, new HashSet<>()); }




  
  protected boolean isEqualTo(Parser other, Set<Parser> seen) {
    if (equals(other) || seen.contains(this)) {
      return true;
    }
    seen.add(this);
    return (Objects.equals(getClass(), other.getClass()) && 
      hasEqualProperties(other) && 
      hasEqualChildren(other, seen));
  }






  
  protected boolean hasEqualProperties(Parser other) { return true; }






  
  protected boolean hasEqualChildren(Parser other, Set<Parser> seen) {
    List<Parser> thisChildren = getChildren();
    List<Parser> otherChildren = other.getChildren();
    if (thisChildren.size() != otherChildren.size()) {
      return false;
    }
    for (int i = 0; i < thisChildren.size(); i++) {
      if (!((Parser)thisChildren.get(i)).isEqualTo(otherChildren.get(i), seen)) {
        return false;
      }
    } 
    return true;
  }




  
  public List<Parser> getChildren() { return Collections.emptyList(); }






  
  public void replace(Parser source, Parser target) {}





  
  public String toString() { return getClass().getSimpleName(); }
  
  public abstract Result parseOn(Context paramContext);
  
  public abstract Parser copy();
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\Parser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */