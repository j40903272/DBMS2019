package org.petitparser.parser.combinators;

import org.petitparser.parser.Parser;
import org.petitparser.parser.primitive.FailureParser;







public class SettableParser
  extends DelegateParser
{
  public static SettableParser undefined() { return undefined("Undefined parser"); }






  
  public static SettableParser undefined(String message) { return with(FailureParser.withMessage(message)); }





  
  public static SettableParser with(Parser parser) { return new SettableParser(parser); }


  
  public SettableParser(Parser delegate) { super(delegate); }





  
  public Parser get() { return this.delegate; }





  
  public void set(Parser delegate) { this.delegate = delegate; }



  
  public SettableParser copy() { return new SettableParser(this.delegate); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\combinators\SettableParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */