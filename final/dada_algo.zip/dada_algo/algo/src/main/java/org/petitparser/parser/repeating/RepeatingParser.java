package org.petitparser.parser.repeating;

import java.util.Objects;
import org.petitparser.parser.Parser;
import org.petitparser.parser.combinators.DelegateParser;





public abstract class RepeatingParser
  extends DelegateParser
{
  public static final int UNBOUNDED = -1;
  protected final int min;
  protected final int max;
  
  public RepeatingParser(Parser delegate, int min, int max) {
    super(delegate);
    this.min = min;
    this.max = max;
    if (min < 0) {
      throw new IllegalArgumentException("Invalid min repetitions: " + getRange());
    }
    if (max != -1 && min > max) {
      throw new IllegalArgumentException("Invalid max repetitions: " + getRange());
    }
  }

  
  public boolean hasEqualProperties(Parser other) {
    return (super.hasEqualProperties(other) && 
      Objects.equals(Integer.valueOf(this.min), Integer.valueOf(((RepeatingParser)other).min)) && 
      Objects.equals(Integer.valueOf(this.max), Integer.valueOf(((RepeatingParser)other).max)));
  }


  
  public String toString() { return super.toString() + "[" + getRange() + "]"; }


  
  private String getRange() { return this.min + ".." + ((this.max == -1) ? "*" : (String)Integer.valueOf(this.max)); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\repeating\RepeatingParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */