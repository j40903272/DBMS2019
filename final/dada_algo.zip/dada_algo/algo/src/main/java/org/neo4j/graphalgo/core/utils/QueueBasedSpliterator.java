package org.neo4j.graphalgo.core.utils;

import java.util.Spliterator;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;























public class QueueBasedSpliterator<T>
  implements Spliterator<T>
{
  private final BlockingQueue<T> queue;
  private T tombstone;
  private T entry;
  private TerminationFlag terminationGuard;
  private final int timeout;
  
  public QueueBasedSpliterator(BlockingQueue<T> queue, T tombstone, TerminationFlag terminationGuard, int timeout) {
    this.queue = queue;
    this.tombstone = tombstone;
    this.terminationGuard = terminationGuard;
    this.timeout = timeout;
    this.entry = poll();
  }

  
  public boolean tryAdvance(Consumer<? super T> action) {
    if (isEnd()) {
      return false;
    }
    this.terminationGuard.assertRunning();
    action.accept(this.entry);
    this.entry = poll();
    return !isEnd();
  }

  
  private boolean isEnd() { return (this.entry == null || this.entry == this.tombstone); }

  
  private T poll() {
    try {
      return this.queue.poll(this.timeout, TimeUnit.SECONDS);
    } catch (InterruptedException e) {
      return null;
    } 
  }

  
  public Spliterator<T> trySplit() { return null; }


  
  public long estimateSize() { return Long.MAX_VALUE; }


  
  public int characteristics() { return 256; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\QueueBasedSpliterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */