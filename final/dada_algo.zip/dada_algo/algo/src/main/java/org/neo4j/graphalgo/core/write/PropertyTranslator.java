package org.neo4j.graphalgo.core.write;

import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.values.storable.Value;
import org.neo4j.values.storable.Values;























public interface PropertyTranslator<T>
{
  Value toProperty(int paramInt, T paramT, long paramLong);
  
  public static interface OfDouble<T>
    extends PropertyTranslator<T>
  {
    double toDouble(T param1T, long param1Long);
    
    default Value toProperty(int propertyId, T data, long nodeId) { return (Value)Values.doubleValue(toDouble(data, nodeId)); }
  }


  
  public static interface OfOptionalDouble<T>
    extends PropertyTranslator<T>
  {
    double toDouble(T param1T, long param1Long);

    
    default Value toProperty(int propertyId, T data, long nodeId) {
      double value = toDouble(data, nodeId);
      if (value >= 0.0D) {
        return (Value)Values.doubleValue(value);
      }
      return null;
    }
  }

  
  public static interface OfInt<T>
    extends PropertyTranslator<T>
  {
    int toInt(T param1T, long param1Long);

    
    default Value toProperty(int propertyId, T data, long nodeId) {
      int value = toInt(data, nodeId);
      return (Value)Values.intValue(value);
    }
  }

  
  public static interface OfOptionalInt<T>
    extends PropertyTranslator<T>
  {
    int toInt(T param1T, long param1Long);

    
    default Value toProperty(int propertyId, T data, long nodeId) {
      int value = toInt(data, nodeId);
      if (value >= 0) {
        return (Value)Values.intValue(value);
      }
      return null;
    }
  }

  
  public static interface OfLong<T>
    extends PropertyTranslator<T>
  {
    long toLong(T param1T, long param1Long);

    
    default Value toProperty(int propertyId, T data, long nodeId) {
      long value = toLong(data, nodeId);
      return (Value)Values.longValue(value);
    }
  }
  
  @FunctionalInterface
  public static interface SeededDataAccessFunction<T>
  {
    long getValue(T param1T, long param1Long);
  }
  
  public static final class OfLongIfChanged<T>
    implements PropertyTranslator<T>
  {
    private final NodeProperties currentProperties;
    private final PropertyTranslator.SeededDataAccessFunction<T> newPropertiesFn;
    
    public OfLongIfChanged(NodeProperties currentProperties, PropertyTranslator.SeededDataAccessFunction<T> newPropertiesFn) {
      this.currentProperties = currentProperties;
      this.newPropertiesFn = newPropertiesFn;
    }

    
    public Value toProperty(int propertyId, T data, long nodeId) {
      double seedValue = this.currentProperties.nodeProperty(nodeId, NaND);
      long computedValue = this.newPropertiesFn.getValue(data, nodeId);
      return (Double.isNaN(seedValue) || (long)seedValue != computedValue) ? (Value)Values.longValue(computedValue) : null;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\write\PropertyTranslator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */