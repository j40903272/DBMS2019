package org.petitparser.parser.actions;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.parser.Parser;
import org.petitparser.parser.combinators.DelegateParser;




public class TrimmingParser
  extends DelegateParser
{
  private Parser left;
  private Parser right;
  
  public TrimmingParser(Parser delegate, Parser left, Parser right) {
    super(delegate);
    this.left = Objects.requireNonNull(left, "Undefined left trimming parser");
    this.right = Objects.requireNonNull(right, "Undefined right trimming parser");
  }

  
  public Result parseOn(Context context) {
    Result leftResult = consume(this.left, context);
    Result delegateResult = this.delegate.parseOn((Context)leftResult);
    if (delegateResult.isFailure()) {
      return delegateResult;
    }
    Result rightResult = consume(this.right, (Context)delegateResult);
    return (Result)rightResult.success(delegateResult.get());
  }
  
  private Result consume(Parser parser, Context context) {
    Result result = parser.parseOn(context);
    while (result.isSuccess()) {
      result = parser.parseOn((Context)result);
    }
    return result;
  }

  
  public void replace(Parser source, Parser target) {
    super.replace(source, target);
    if (this.left == source) {
      this.left = target;
    }
    if (this.right == source) {
      this.right = target;
    }
  }


  
  public List<Parser> getChildren() { return Arrays.asList(new Parser[] { this.delegate, this.left, this.right }); }



  
  public TrimmingParser copy() { return new TrimmingParser(this.delegate, this.left, this.right); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\actions\TrimmingParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */