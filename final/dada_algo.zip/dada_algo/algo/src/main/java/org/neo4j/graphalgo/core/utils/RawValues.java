package org.neo4j.graphalgo.core.utils;

import org.neo4j.graphdb.Direction;































public final class RawValues
{
  public static long combineIntInt(int head, int tail) { return head << 32L | tail & 0xFFFFFFFFL; }

  
  public static long combineIntInt(Direction direction, int head, int tail) {
    if (direction == Direction.INCOMING) {
      return combineIntInt(tail, head);
    }
    return combineIntInt(head, tail);
  }







  
  public static int getHead(long combinedValue) { return (int)(combinedValue >> 32L); }








  
  public static int getTail(long combinedValue) { return (int)combinedValue; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\RawValues.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */