package org.neo4j.graphalgo.core.utils.queue;

import com.carrotsearch.hppc.IntDoubleScatterMap;
import java.util.Arrays;
import org.apache.lucene.util.ArrayUtil;
import org.neo4j.collection.primitive.PrimitiveIntIterable;
import org.neo4j.collection.primitive.PrimitiveIntIterator;
































public abstract class IntPriorityQueue
  implements PrimitiveIntIterable
{
  public static final int DEFAULT_CAPACITY = 14;
  private static final int[] EMPTY_INT = new int[0];
  
  private int[] heap;
  private int size = 0;





  
  IntPriorityQueue(int initialCapacity) {
    if (0 == initialCapacity) {
      
      heapSize = 2;
    }
    else {
      
      heapSize = initialCapacity + 1;
    } 
    this.heap = new int[ArrayUtil.oversize(heapSize, 4)];
  }

































  
  public final void add(int element, double cost) {
    addCost(element, cost);
    this.size++;
    ensureCapacityForInsert();
    this.heap[this.size] = element;
    upHeap(this.size);
  }
  
  private void add(int element) {
    this.size++;
    ensureCapacityForInsert();
    this.heap[this.size] = element;
    upHeap(this.size);
  }







  
  public final int top() { return this.heap[1]; }






  
  public final int pop() {
    if (this.size > 0) {
      int result = this.heap[1];
      this.heap[1] = this.heap[this.size];
      this.size--;
      downHeap(1);
      removeCost(result);
      return result;
    } 
    return -1;
  }





  
  public final int size() { return this.size; }





  
  public final boolean isEmpty() { return (this.size == 0); }





  
  public void clear() { this.size = 0; }





  
  public final void update(int element) {
    int pos = findElementPosition(element);
    if (pos != 0 && 
      !upHeap(pos) && pos < this.size) {
      downHeap(pos);
    }
  }

  
  public final void set(int element, double cost) {
    if (addCost(element, cost)) {
      update(element);
    } else {
      add(element);
    } 
  }
  
  private int findElementPosition(int element) {
    int limit = this.size + 1;
    int[] data = this.heap;
    int i = 1;
    for (; i <= limit - 4; i += 4) {
      if (data[i] == element) return i; 
      if (data[i + 1] == element) return i + 1; 
      if (data[i + 2] == element) return i + 2; 
      if (data[i + 3] == element) return i + 3; 
    } 
    for (; i < limit; i++) {
      if (data[i] == element) return i; 
    } 
    return 0;
  }




  
  public void release() {
    this.size = 0;
    this.heap = null;
  }
  
  private boolean upHeap(int origPos) {
    int i = origPos;
    int node = this.heap[i];
    int j = i >>> 1;
    while (j > 0 && lessThan(node, this.heap[j])) {
      this.heap[i] = this.heap[j];
      i = j;
      j >>>= 1;
    } 
    this.heap[i] = node;
    return (i != origPos);
  }
  
  private void downHeap(int i) {
    int node = this.heap[i];
    int j = i << 1;
    int k = j + 1;
    if (k <= this.size && lessThan(this.heap[k], this.heap[j])) {
      j = k;
    }
    while (j <= this.size && lessThan(this.heap[j], node)) {
      this.heap[i] = this.heap[j];
      i = j;
      j = i << 1;
      k = j + 1;
      if (k <= this.size && lessThan(this.heap[k], this.heap[j])) {
        j = k;
      }
    } 
    this.heap[i] = node;
  }
  
  private void ensureCapacityForInsert() {
    if (this.size >= this.heap.length) {
      int oversize = ArrayUtil.oversize(this.size + 1, 4);
      this.heap = Arrays.copyOf(this.heap, oversize);
    } 
  }



  
  public PrimitiveIntIterator iterator() {
    return new PrimitiveIntIterator()
      {
        int i = 1;


        
        public boolean hasNext() { return (this.i <= IntPriorityQueue.this.size); }






        
        public int next() { return IntPriorityQueue.this.heap[this.i++]; }
      };
  }

  
  public static IntPriorityQueue min(int capacity) {
    return new AbstractPriorityQueue(capacity)
      {
        protected boolean lessThan(int a, int b) {
          return (this.costs.get(a) < this.costs.get(b));
        }
      };
  }
  
  public static IntPriorityQueue max(int capacity) {
    return new AbstractPriorityQueue(capacity)
      {
        protected boolean lessThan(int a, int b) {
          return (this.costs.get(a) > this.costs.get(b));
        }
      };
  }

  
  public static IntPriorityQueue min() { return min(14); }
  
  protected abstract boolean lessThan(int paramInt1, int paramInt2);
  
  public static IntPriorityQueue max() { return max(14); }
  protected abstract boolean addCost(int paramInt, double paramDouble);
  
  protected abstract void removeCost(int paramInt);
  
  protected abstract double cost(int paramInt);
  
  private static abstract class AbstractPriorityQueue extends IntPriorityQueue { public AbstractPriorityQueue(int initialCapacity) {
      super(initialCapacity);
      this.costs = new IntDoubleScatterMap(initialCapacity);
    }
    
    protected final IntDoubleScatterMap costs;
    
    protected boolean addCost(int element, double cost) { return (this.costs.put(element, cost) != 0.0D); }



    
    protected void removeCost(int element) { this.costs.remove(element); }



    
    protected double cost(int element) { return this.costs.get(element); }


    
    public void clear() {
      super.clear();
      this.costs.clear();
    }

    
    public void release() {
      super.release();
      this.costs.keys = EMPTY_INT;
      this.costs.clear();
      this.costs.keys = null;
      this.costs.values = null;
    } }

}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\queue\IntPriorityQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */