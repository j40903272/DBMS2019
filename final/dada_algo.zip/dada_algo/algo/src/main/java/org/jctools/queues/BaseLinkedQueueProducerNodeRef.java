package org.jctools.queues;

import java.lang.reflect.Field;
import org.jctools.util.UnsafeAccess;
























abstract class BaseLinkedQueueProducerNodeRef<E>
  extends BaseLinkedQueuePad0<E>
{
  protected static final long P_NODE_OFFSET;
  protected LinkedQueueNode<E> producerNode;
  
  static  {
    try {
      Field pNodeField = BaseLinkedQueueProducerNodeRef.class.getDeclaredField("producerNode");
      P_NODE_OFFSET = UnsafeAccess.UNSAFE.objectFieldOffset(pNodeField);
    }
    catch (NoSuchFieldException e) {
      
      throw new RuntimeException(e);
    } 
  }




  
  protected final void spProducerNode(LinkedQueueNode<E> newValue) { this.producerNode = newValue; }




  
  protected final LinkedQueueNode<E> lvProducerNode() { return (LinkedQueueNode<E>)UnsafeAccess.UNSAFE.getObjectVolatile(this, P_NODE_OFFSET); }




  
  protected final boolean casProducerNode(LinkedQueueNode<E> expect, LinkedQueueNode<E> newValue) { return UnsafeAccess.UNSAFE.compareAndSwapObject(this, P_NODE_OFFSET, expect, newValue); }



  
  protected final LinkedQueueNode<E> lpProducerNode() { return this.producerNode; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\jctools\queues\BaseLinkedQueueProducerNodeRef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */