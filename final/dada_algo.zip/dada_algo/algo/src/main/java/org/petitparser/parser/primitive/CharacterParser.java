package org.petitparser.parser.primitive;

import java.util.Objects;
import org.petitparser.context.Context;
import org.petitparser.context.Result;
import org.petitparser.parser.Parser;





public class CharacterParser
  extends Parser
{
  private final CharacterPredicate matcher;
  private final String message;
  
  public static CharacterParser of(CharacterPredicate predicate, String message) { return new CharacterParser(predicate, message); }





  
  public static CharacterParser of(char character) { return of(character, "'" + character + "' expected"); }


  
  public static CharacterParser of(char character, String message) { return of(CharacterPredicate.of(character), message); }





  
  public static CharacterParser any() { return any("any character expected"); }


  
  public static CharacterParser any(String message) { return of(CharacterPredicate.any(), message); }





  
  public static CharacterParser anyOf(String chars) { return anyOf(chars, "any of '" + chars + "' expected"); }


  
  public static CharacterParser anyOf(String chars, String message) { return of(CharacterPredicate.anyOf(chars), message); }





  
  public static CharacterParser none() { return none("no character expected"); }


  
  public static CharacterParser none(String message) { return of(CharacterPredicate.none(), message); }





  
  public static CharacterParser noneOf(String chars) { return noneOf(chars, "none of '" + chars + "' expected"); }


  
  public static CharacterParser noneOf(String chars, String message) { return of(CharacterPredicate.noneOf(chars), message); }





  
  public static CharacterParser digit() { return digit("digit expected"); }


  
  public static CharacterParser digit(String message) { return new CharacterParser(Character::isDigit, message); }





  
  public static CharacterParser letter() { return letter("letter expected"); }


  
  public static CharacterParser letter(String message) { return of(Character::isLetter, message); }





  
  public static CharacterParser lowerCase() { return lowerCase("lowercase letter expected"); }


  
  public static CharacterParser lowerCase(String message) { return of(Character::isLowerCase, message); }








  
  public static CharacterParser pattern(String pattern) { return pattern(pattern, "[" + pattern + "] expected"); }


  
  public static CharacterParser pattern(String pattern, String message) { return of(CharacterPredicate.pattern(pattern), message); }





  
  public static CharacterParser range(char start, char stop) { return range(start, stop, start + ".." + stop + " expected"); }


  
  public static CharacterParser range(char start, char stop, String message) { return of(CharacterPredicate.range(start, stop), message); }





  
  public static CharacterParser upperCase() { return upperCase("uppercase letter expected"); }


  
  public static CharacterParser upperCase(String message) { return of(Character::isUpperCase, message); }





  
  public static CharacterParser whitespace() { return whitespace("whitespace expected"); }


  
  public static CharacterParser whitespace(String message) { return of(Character::isWhitespace, message); }





  
  public static CharacterParser word() { return word("letter or digit expected"); }


  
  public static CharacterParser word(String message) { return of(Character::isLetterOrDigit, message); }




  
  private CharacterParser(CharacterPredicate matcher, String message) {
    this.matcher = Objects.requireNonNull(matcher, "Undefined matcher");
    this.message = Objects.requireNonNull(message, "Undefined message");
  }

  
  public Result parseOn(Context context) {
    String buffer = context.getBuffer();
    int position = context.getPosition();
    if (position < buffer.length()) {
      char result = buffer.charAt(position);
      if (this.matcher.test(result)) {
        return (Result)context.success(Character.valueOf(result), position + 1);
      }
    } 
    return (Result)context.failure(this.message);
  }



  
  public CharacterParser neg(String message) { return of(this.matcher.not(), message); }


  
  protected boolean hasEqualProperties(Parser other) {
    return (super.hasEqualProperties(other) && 
      Objects.equals(this.matcher, ((CharacterParser)other).matcher) && 
      Objects.equals(this.message, ((CharacterParser)other).message));
  }


  
  public CharacterParser copy() { return of(this.matcher, this.message); }



  
  public String toString() { return super.toString() + "[" + this.message + "]"; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\petitparser\parser\primitive\CharacterParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */