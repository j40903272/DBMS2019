package org.neo4j.graphalgo.core.utils.queue;

import com.carrotsearch.hppc.IntDoubleMap;







































public abstract class SharedIntPriorityQueue
  extends IntPriorityQueue
{
  protected final IntDoubleMap costs;
  protected final double defaultCost;
  
  public SharedIntPriorityQueue(int initialCapacity, IntDoubleMap costs, double defaultCost) {
    super(initialCapacity);
    this.costs = costs;
    this.defaultCost = defaultCost;
  }


  
  protected double cost(int element) { return this.costs.getOrDefault(element, this.defaultCost); }




  
  protected boolean addCost(int element, double cost) { return false; }


  
  protected void removeCost(int element) {}


  
  public static SharedIntPriorityQueue min(int capacity, IntDoubleMap costs, double defaultCost) {
    return new SharedIntPriorityQueue(capacity, costs, defaultCost)
      {
        protected boolean lessThan(int a, int b) {
          return (this.costs.get(a) < this.costs.get(b));
        }
      };
  }
  
  public static SharedIntPriorityQueue max(int capacity, IntDoubleMap costs, double defaultCost) {
    return new SharedIntPriorityQueue(capacity, costs, defaultCost)
      {
        protected boolean lessThan(int a, int b) {
          return (this.costs.get(a) > this.costs.get(b));
        }
      };
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\queue\SharedIntPriorityQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */