package org.neo4j.graphalgo.core.utils.mem;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

































public interface MemoryTree
{
  String description();
  
  MemoryRange memoryUsage();
  
  default Collection<MemoryTree> components() { return Collections.emptyList(); }

  
  default Map<String, Object> renderMap() {
    Map<String, Object> root = new HashMap<>();
    root.put("name", description());
    root.put("memoryUsage", memoryUsage().toString());


    
    List<Map<String, Object>> components = (List<Map<String, Object>>)components().stream().map(MemoryTree::renderMap).collect(Collectors.toList());
    if (!components.isEmpty()) {
      root.put("components", components);
    }
    return root;
  }



  
  default String render() {
    StringBuilder sb = new StringBuilder();
    render(sb, this, 0);
    return sb.toString();
  }



  
  static void render(StringBuilder sb, MemoryTree estimation, int depth) {
    for (int i = 1; i < depth; i++) {
      sb.append("    ");
    }
    
    if (depth > 0) {
      sb.append("|-- ");
    }
    
    sb.append(estimation.description());
    sb.append(": ");
    sb.append(estimation.memoryUsage());
    sb.append(System.lineSeparator());
    
    for (MemoryTree component : estimation.components()) {
      render(sb, component, depth + 1);
    }
  }

  
  static MemoryTree empty() { return NULL_TREE; }

  
  public static final MemoryTree NULL_TREE = new MemoryTree()
    {
      public String description() {
        return "";
      }


      
      public MemoryRange memoryUsage() { return MemoryRange.empty(); }
    };
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\mem\MemoryTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */