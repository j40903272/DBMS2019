package org.neo4j.graphalgo.core.utils.paged;

import java.util.concurrent.atomic.AtomicIntegerArray;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
import org.neo4j.graphalgo.core.write.PropertyTranslator;






















public final class PagedAtomicIntegerArray
  extends PagedDataStructure<AtomicIntegerArray>
{
  private static final PageAllocator.Factory<AtomicIntegerArray> ALLOCATOR_FACTORY;
  
  static  {
    int pageSize = PageUtil.pageSizeFor(4);
    long pageUsage = MemoryUsage.sizeOfInstance(AtomicIntegerArray.class) + MemoryUsage.sizeOfIntArray(pageSize);
    
    ALLOCATOR_FACTORY = PageAllocator.of(pageSize, pageUsage, () -> 

        
        new AtomicIntegerArray(pageSize), new AtomicIntegerArray[0]);
  }



  
  public static PagedAtomicIntegerArray newArray(long size, AllocationTracker tracker) { return new PagedAtomicIntegerArray(size, ALLOCATOR_FACTORY.newAllocator(tracker)); }




  
  private PagedAtomicIntegerArray(long size, PageAllocator<AtomicIntegerArray> allocator) { super(size, allocator); }

  
  public int get(long index) {
    assert index < capacity();
    int pageIndex = pageIndex(index);
    int indexInPage = indexInPage(index);
    return this.pages[pageIndex].get(indexInPage);
  }
  
  public void set(long index, int value) {
    assert index < capacity();
    int pageIndex = pageIndex(index);
    int indexInPage = indexInPage(index);
    this.pages[pageIndex].set(indexInPage, value);
  }
  
  public void add(long index, int delta) {
    assert index < capacity();
    int pageIndex = pageIndex(index);
    int indexInPage = indexInPage(index);
    this.pages[pageIndex].addAndGet(indexInPage, delta);
  }
  
  public boolean cas(long index, int expected, int update) {
    assert index < capacity();
    int pageIndex = pageIndex(index);
    int indexInPage = indexInPage(index);
    return this.pages[pageIndex].compareAndSet(indexInPage, expected, update);
  }
  
  public static class Translator
    implements PropertyTranslator.OfInt<PagedAtomicIntegerArray> {
    public static final Translator INSTANCE = new Translator();


    
    public int toInt(PagedAtomicIntegerArray data, long nodeId) { return data.get((int)nodeId); }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\PagedAtomicIntegerArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */