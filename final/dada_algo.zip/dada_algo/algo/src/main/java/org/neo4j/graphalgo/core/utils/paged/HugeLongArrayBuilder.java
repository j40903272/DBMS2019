package org.neo4j.graphalgo.core.utils.paged;



















public final class HugeLongArrayBuilder
  extends HugeArrayBuilder<long[], HugeLongArray>
{
  public static HugeLongArrayBuilder of(long length, AllocationTracker tracker) {
    HugeLongArray array = HugeLongArray.newArray(length, tracker);
    return new HugeLongArrayBuilder(array, length);
  }

  
  private HugeLongArrayBuilder(HugeLongArray array, long length) { super(array, length); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\HugeLongArrayBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */