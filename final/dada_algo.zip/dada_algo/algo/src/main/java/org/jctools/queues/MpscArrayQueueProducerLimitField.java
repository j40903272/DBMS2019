package org.jctools.queues;

import org.jctools.util.UnsafeAccess;














































































abstract class MpscArrayQueueProducerLimitField<E>
  extends MpscArrayQueueMidPad<E>
{
  private static final long P_LIMIT_OFFSET;
  private volatile long producerLimit;
  
  static  {
    try {
      P_LIMIT_OFFSET = UnsafeAccess.UNSAFE.objectFieldOffset(MpscArrayQueueProducerLimitField.class.getDeclaredField("producerLimit"));
    }
    catch (NoSuchFieldException e) {
      
      throw new RuntimeException(e);
    } 
  }




  
  public MpscArrayQueueProducerLimitField(int capacity) {
    super(capacity);
    this.producerLimit = capacity;
  }


  
  protected final long lvProducerLimit() { return this.producerLimit; }



  
  protected final void soProducerLimit(long newValue) { UnsafeAccess.UNSAFE.putOrderedLong(this, P_LIMIT_OFFSET, newValue); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\jctools\queues\MpscArrayQueueProducerLimitField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */