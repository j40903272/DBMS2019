package org.HdrHistogram;

import java.util.Iterator;















public class DoubleAllValuesIterator
  implements Iterator<DoubleHistogramIterationValue>
{
  private final AllValuesIterator integerAllValuesIterator;
  private final DoubleHistogramIterationValue iterationValue;
  DoubleHistogram histogram;
  
  public void reset() { this.integerAllValuesIterator.reset(); }




  
  public DoubleAllValuesIterator(DoubleHistogram histogram) {
    this.histogram = histogram;
    this.integerAllValuesIterator = new AllValuesIterator(histogram.integerValuesHistogram);
    this.iterationValue = new DoubleHistogramIterationValue(this.integerAllValuesIterator.currentIterationValue);
  }


  
  public boolean hasNext() { return this.integerAllValuesIterator.hasNext(); }


  
  public DoubleHistogramIterationValue next() {
    this.integerAllValuesIterator.next();
    return this.iterationValue;
  }


  
  public void remove() { this.integerAllValuesIterator.remove(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\DoubleAllValuesIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */