package org.HdrHistogram;

import java.nio.ByteBuffer;





























class ZigZagEncoding
{
  static void putLong(ByteBuffer buffer, long value) {
    value = value << 1L ^ value >> 63L;
    if (value >>> 7L == 0L) {
      buffer.put((byte)(int)value);
    } else {
      buffer.put((byte)(int)(value & 0x7FL | 0x80L));
      if (value >>> 14L == 0L) {
        buffer.put((byte)(int)(value >>> 7L));
      } else {
        buffer.put((byte)(int)(value >>> 7L | 0x80L));
        if (value >>> 21L == 0L) {
          buffer.put((byte)(int)(value >>> 14L));
        } else {
          buffer.put((byte)(int)(value >>> 14L | 0x80L));
          if (value >>> 28L == 0L) {
            buffer.put((byte)(int)(value >>> 21L));
          } else {
            buffer.put((byte)(int)(value >>> 21L | 0x80L));
            if (value >>> 35L == 0L) {
              buffer.put((byte)(int)(value >>> 28L));
            } else {
              buffer.put((byte)(int)(value >>> 28L | 0x80L));
              if (value >>> 42L == 0L) {
                buffer.put((byte)(int)(value >>> 35L));
              } else {
                buffer.put((byte)(int)(value >>> 35L | 0x80L));
                if (value >>> 49L == 0L) {
                  buffer.put((byte)(int)(value >>> 42L));
                } else {
                  buffer.put((byte)(int)(value >>> 42L | 0x80L));
                  if (value >>> 56L == 0L) {
                    buffer.put((byte)(int)(value >>> 49L));
                  } else {
                    buffer.put((byte)(int)(value >>> 49L | 0x80L));
                    buffer.put((byte)(int)(value >>> 56L));
                  } 
                } 
              } 
            } 
          } 
        } 
      } 
    } 
  }





  
  static void putInt(ByteBuffer buffer, int value) {
    value = value << 1 ^ value >> 31;
    if (value >>> 7 == 0) {
      buffer.put((byte)value);
    } else {
      buffer.put((byte)(value & 0x7F | 0x80));
      if (value >>> 14 == 0) {
        buffer.put((byte)(value >>> 7));
      } else {
        buffer.put((byte)(value >>> 7 | 0x80));
        if (value >>> 21 == 0) {
          buffer.put((byte)(value >>> 14));
        } else {
          buffer.put((byte)(value >>> 14 | 0x80));
          if (value >>> 28 == 0) {
            buffer.put((byte)(value >>> 21));
          } else {
            buffer.put((byte)(value >>> 21 | 0x80));
            buffer.put((byte)(value >>> 28));
          } 
        } 
      } 
    } 
  }





  
  static long getLong(ByteBuffer buffer) {
    long v = buffer.get();
    long value = v & 0x7FL;
    if ((v & 0x80L) != 0L) {
      v = buffer.get();
      value |= (v & 0x7FL) << 7L;
      if ((v & 0x80L) != 0L) {
        v = buffer.get();
        value |= (v & 0x7FL) << 14L;
        if ((v & 0x80L) != 0L) {
          v = buffer.get();
          value |= (v & 0x7FL) << 21L;
          if ((v & 0x80L) != 0L) {
            v = buffer.get();
            value |= (v & 0x7FL) << 28L;
            if ((v & 0x80L) != 0L) {
              v = buffer.get();
              value |= (v & 0x7FL) << 35L;
              if ((v & 0x80L) != 0L) {
                v = buffer.get();
                value |= (v & 0x7FL) << 42L;
                if ((v & 0x80L) != 0L) {
                  v = buffer.get();
                  value |= (v & 0x7FL) << 49L;
                  if ((v & 0x80L) != 0L) {
                    v = buffer.get();
                    value |= v << 56L;
                  } 
                } 
              } 
            } 
          } 
        } 
      } 
    } 
    value = value >>> 1L ^ -(value & 0x1L);
    return value;
  }





  
  static int getInt(ByteBuffer buffer) {
    int v = buffer.get();
    int value = v & 0x7F;
    if ((v & 0x80) != 0) {
      v = buffer.get();
      value |= (v & 0x7F) << 7;
      if ((v & 0x80) != 0) {
        v = buffer.get();
        value |= (v & 0x7F) << 14;
        if ((v & 0x80) != 0) {
          v = buffer.get();
          value |= (v & 0x7F) << 21;
          if ((v & 0x80) != 0) {
            v = buffer.get();
            value |= (v & 0x7F) << 28;
          } 
        } 
      } 
    } 
    value = value >>> 1 ^ -(value & 0x1);
    return value;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\ZigZagEncoding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */