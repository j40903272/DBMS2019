package org.HdrHistogram;

import java.util.Iterator;

















public class DoubleLinearIterator
  implements Iterator<DoubleHistogramIterationValue>
{
  private final LinearIterator integerLinearIterator;
  private final DoubleHistogramIterationValue iterationValue;
  DoubleHistogram histogram;
  
  public void reset(double valueUnitsPerBucket) { this.integerLinearIterator.reset((long)(valueUnitsPerBucket * this.histogram.doubleToIntegerValueConversionRatio)); }





  
  public DoubleLinearIterator(DoubleHistogram histogram, double valueUnitsPerBucket) {
    this.histogram = histogram;
    this.integerLinearIterator = new LinearIterator(histogram.integerValuesHistogram, (long)(valueUnitsPerBucket * histogram.doubleToIntegerValueConversionRatio));


    
    this.iterationValue = new DoubleHistogramIterationValue(this.integerLinearIterator.currentIterationValue);
  }


  
  public boolean hasNext() { return this.integerLinearIterator.hasNext(); }


  
  public DoubleHistogramIterationValue next() {
    this.integerLinearIterator.next();
    return this.iterationValue;
  }


  
  public void remove() { this.integerLinearIterator.remove(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\DoubleLinearIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */