package org.HdrHistogram;


































public class DoubleHistogramIterationValue
{
  private final HistogramIterationValue integerHistogramIterationValue;
  
  void reset() { this.integerHistogramIterationValue.reset(); }


  
  DoubleHistogramIterationValue(HistogramIterationValue integerHistogramIterationValue) { this.integerHistogramIterationValue = integerHistogramIterationValue; }

  
  public String toString() {
    return "valueIteratedTo:" + getValueIteratedTo() + ", prevValueIteratedTo:" + 
      getValueIteratedFrom() + ", countAtValueIteratedTo:" + 
      getCountAtValueIteratedTo() + ", countAddedInThisIterationStep:" + 
      getCountAddedInThisIterationStep() + ", totalCountToThisValue:" + 
      getTotalCountToThisValue() + ", totalValueToThisValue:" + 
      getTotalValueToThisValue() + ", percentile:" + 
      getPercentile() + ", percentileLevelIteratedTo:" + 
      getPercentileLevelIteratedTo();
  }


  
  public double getValueIteratedTo() { return this.integerHistogramIterationValue.getValueIteratedTo() * this.integerHistogramIterationValue.getIntegerToDoubleValueConversionRatio(); }



  
  public double getValueIteratedFrom() { return this.integerHistogramIterationValue.getValueIteratedFrom() * this.integerHistogramIterationValue.getIntegerToDoubleValueConversionRatio(); }


  
  public long getCountAtValueIteratedTo() { return this.integerHistogramIterationValue.getCountAtValueIteratedTo(); }


  
  public long getCountAddedInThisIterationStep() { return this.integerHistogramIterationValue.getCountAddedInThisIterationStep(); }


  
  public long getTotalCountToThisValue() { return this.integerHistogramIterationValue.getTotalCountToThisValue(); }



  
  public double getTotalValueToThisValue() { return this.integerHistogramIterationValue.getTotalValueToThisValue() * this.integerHistogramIterationValue.getIntegerToDoubleValueConversionRatio(); }


  
  public double getPercentile() { return this.integerHistogramIterationValue.getPercentile(); }


  
  public double getPercentileLevelIteratedTo() { return this.integerHistogramIterationValue.getPercentileLevelIteratedTo(); }


  
  public HistogramIterationValue getIntegerHistogramIterationValue() { return this.integerHistogramIterationValue; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\DoubleHistogramIterationValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */