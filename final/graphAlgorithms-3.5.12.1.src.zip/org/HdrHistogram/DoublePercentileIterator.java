package org.HdrHistogram;

import java.util.Iterator;


















public class DoublePercentileIterator
  implements Iterator<DoubleHistogramIterationValue>
{
  private final PercentileIterator integerPercentileIterator;
  private final DoubleHistogramIterationValue iterationValue;
  DoubleHistogram histogram;
  
  public void reset(int percentileTicksPerHalfDistance) { this.integerPercentileIterator.reset(percentileTicksPerHalfDistance); }





  
  public DoublePercentileIterator(DoubleHistogram histogram, int percentileTicksPerHalfDistance) {
    this.histogram = histogram;
    this.integerPercentileIterator = new PercentileIterator(histogram.integerValuesHistogram, percentileTicksPerHalfDistance);


    
    this.iterationValue = new DoubleHistogramIterationValue(this.integerPercentileIterator.currentIterationValue);
  }


  
  public boolean hasNext() { return this.integerPercentileIterator.hasNext(); }


  
  public DoubleHistogramIterationValue next() {
    this.integerPercentileIterator.next();
    return this.iterationValue;
  }


  
  public void remove() { this.integerPercentileIterator.remove(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\DoublePercentileIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */