package org.HdrHistogram;

import java.util.Iterator;
















public class LinearIterator
  extends AbstractHistogramIterator
  implements Iterator<HistogramIterationValue>
{
  private long valueUnitsPerBucket;
  private long currentStepHighestValueReportingLevel;
  private long currentStepLowestValueReportingLevel;
  
  public void reset(long valueUnitsPerBucket) { reset(this.histogram, valueUnitsPerBucket); }

  
  private void reset(AbstractHistogram histogram, long valueUnitsPerBucket) {
    resetIterator(histogram);
    this.valueUnitsPerBucket = valueUnitsPerBucket;
    this.currentStepHighestValueReportingLevel = valueUnitsPerBucket - 1L;
    this.currentStepLowestValueReportingLevel = histogram.lowestEquivalentValue(this.currentStepHighestValueReportingLevel);
  }





  
  public LinearIterator(AbstractHistogram histogram, long valueUnitsPerBucket) { reset(histogram, valueUnitsPerBucket); }


  
  public boolean hasNext() {
    if (super.hasNext()) {
      return true;
    }



    
    return (this.currentStepHighestValueReportingLevel + 1L < this.nextValueAtIndex);
  }

  
  void incrementIterationLevel() {
    this.currentStepHighestValueReportingLevel += this.valueUnitsPerBucket;
    this.currentStepLowestValueReportingLevel = this.histogram.lowestEquivalentValue(this.currentStepHighestValueReportingLevel);
  }


  
  long getValueIteratedTo() { return this.currentStepHighestValueReportingLevel; }



  
  boolean reachedIterationLevel() { return (this.currentValueAtIndex >= this.currentStepLowestValueReportingLevel || this.currentIndex >= this.histogram.countsArrayLength - 1); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\LinearIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */