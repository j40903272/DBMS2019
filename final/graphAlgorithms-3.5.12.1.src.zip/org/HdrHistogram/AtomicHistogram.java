package org.HdrHistogram;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.ByteBuffer;
import java.nio.LongBuffer;
import java.util.concurrent.atomic.AtomicLongArray;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.zip.DataFormatException;
























public class AtomicHistogram
  extends Histogram
{
  static final AtomicLongFieldUpdater<AtomicHistogram> totalCountUpdater = AtomicLongFieldUpdater.newUpdater(AtomicHistogram.class, "totalCount");
  
  volatile long totalCount;
  
  volatile AtomicLongArray counts;
  
  long getCountAtIndex(int index) { return this.counts.get(index); }



  
  long getCountAtNormalizedIndex(int index) { return this.counts.get(index); }



  
  void incrementCountAtIndex(int index) { this.counts.getAndIncrement(index); }



  
  void addToCountAtIndex(int index, long value) { this.counts.getAndAdd(index, value); }



  
  void setCountAtIndex(int index, long value) { this.counts.lazySet(index, value); }



  
  void setCountAtNormalizedIndex(int index, long value) { this.counts.lazySet(index, value); }



  
  int getNormalizingIndexOffset() { return 0; }


  
  void setNormalizingIndexOffset(int normalizingIndexOffset) {
    if (normalizingIndexOffset != 0) {
      throw new IllegalStateException("AtomicHistogram does not support non-zero normalizing index settings. Use ConcurrentHistogram Instead.");
    }
  }




  
  void shiftNormalizingIndexByOffset(int offsetToAdd, boolean lowestHalfBucketPopulated) { throw new IllegalStateException("AtomicHistogram does not support Shifting operations. Use ConcurrentHistogram Instead."); }





  
  void resize(long newHighestTrackableValue) { throw new IllegalStateException("AtomicHistogram does not support resizing operations. Use ConcurrentHistogram Instead."); }





  
  public void setAutoResize(boolean autoResize) { throw new IllegalStateException("AtomicHistogram does not support AutoResize operation. Use ConcurrentHistogram Instead."); }




  
  void clearCounts() {
    for (int i = 0; i < this.counts.length(); i++) {
      this.counts.lazySet(i, 0L);
    }
    totalCountUpdater.set(this, 0L);
  }

  
  public AtomicHistogram copy() {
    AtomicHistogram copy = new AtomicHistogram(this);
    copy.add(this);
    return copy;
  }

  
  public AtomicHistogram copyCorrectedForCoordinatedOmission(long expectedIntervalBetweenValueSamples) {
    AtomicHistogram toHistogram = new AtomicHistogram(this);
    toHistogram.addWhileCorrectingForCoordinatedOmission(this, expectedIntervalBetweenValueSamples);
    return toHistogram;
  }


  
  public long getTotalCount() { return totalCountUpdater.get(this); }



  
  void setTotalCount(long totalCount) { totalCountUpdater.set(this, totalCount); }



  
  void incrementTotalCount() { totalCountUpdater.incrementAndGet(this); }



  
  void addToTotalCount(long value) { totalCountUpdater.addAndGet(this, value); }



  
  int _getEstimatedFootprintInBytes() { return 512 + 8 * this.counts.length(); }












  
  public AtomicHistogram(long highestTrackableValue, int numberOfSignificantValueDigits) { this(1L, highestTrackableValue, numberOfSignificantValueDigits); }

















  
  public AtomicHistogram(long lowestDiscernibleValue, long highestTrackableValue, int numberOfSignificantValueDigits) {
    super(lowestDiscernibleValue, highestTrackableValue, numberOfSignificantValueDigits, false);
    this.counts = new AtomicLongArray(this.countsArrayLength);
    this.wordSizeInBytes = 8;
  }





  
  public AtomicHistogram(AbstractHistogram source) {
    super(source, false);
    this.counts = new AtomicLongArray(this.countsArrayLength);
    this.wordSizeInBytes = 8;
  }








  
  public static AtomicHistogram decodeFromByteBuffer(ByteBuffer buffer, long minBarForHighestTrackableValue) { return decodeFromByteBuffer(buffer, AtomicHistogram.class, minBarForHighestTrackableValue); }











  
  public static AtomicHistogram decodeFromCompressedByteBuffer(ByteBuffer buffer, long minBarForHighestTrackableValue) throws DataFormatException { return decodeFromCompressedByteBuffer(buffer, AtomicHistogram.class, minBarForHighestTrackableValue); }



  
  private void readObject(ObjectInputStream o) throws IOException, ClassNotFoundException { o.defaultReadObject(); }


  
  synchronized void fillCountsArrayFromBuffer(ByteBuffer buffer, int length) {
    LongBuffer logbuffer = buffer.asLongBuffer();
    for (int i = 0; i < length; i++)
      this.counts.lazySet(i, logbuffer.get()); 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\AtomicHistogram.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */