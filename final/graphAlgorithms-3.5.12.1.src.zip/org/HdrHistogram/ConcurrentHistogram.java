package org.HdrHistogram;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.ByteBuffer;
import java.nio.LongBuffer;
import java.util.concurrent.atomic.AtomicLongArray;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.zip.DataFormatException;































public class ConcurrentHistogram
  extends Histogram
{
  static final AtomicLongFieldUpdater<ConcurrentHistogram> totalCountUpdater = AtomicLongFieldUpdater.newUpdater(ConcurrentHistogram.class, "totalCount");
  
  volatile long totalCount;
  volatile AtomicLongArrayWithNormalizingOffset activeCounts;
  volatile AtomicLongArrayWithNormalizingOffset inactiveCounts;
  transient WriterReaderPhaser wrp = new WriterReaderPhaser();

  
  long getCountAtIndex(int index) {
    try {
      this.wrp.readerLock();
      assert this.countsArrayLength == this.activeCounts.length();
      assert this.countsArrayLength == this.inactiveCounts.length();
      long activeCount = this.activeCounts.get(
          normalizeIndex(index, this.activeCounts.getNormalizingIndexOffset(), this.activeCounts.length()));
      long inactiveCount = this.inactiveCounts.get(
          normalizeIndex(index, this.inactiveCounts.getNormalizingIndexOffset(), this.inactiveCounts.length()));
      return activeCount + inactiveCount;
    } finally {
      this.wrp.readerUnlock();
    } 
  }

  
  long getCountAtNormalizedIndex(int index) {
    try {
      this.wrp.readerLock();
      assert this.countsArrayLength == this.activeCounts.length();
      assert this.countsArrayLength == this.inactiveCounts.length();
      long activeCount = this.activeCounts.get(index);
      long inactiveCount = this.inactiveCounts.get(index);
      return activeCount + inactiveCount;
    } finally {
      this.wrp.readerUnlock();
    } 
  }

  
  void incrementCountAtIndex(int index) {
    long criticalValue = this.wrp.writerCriticalSectionEnter();
    try {
      this.activeCounts.incrementAndGet(
          normalizeIndex(index, this.activeCounts.getNormalizingIndexOffset(), this.activeCounts.length()));
    } finally {
      this.wrp.writerCriticalSectionExit(criticalValue);
    } 
  }

  
  void addToCountAtIndex(int index, long value) {
    long criticalValue = this.wrp.writerCriticalSectionEnter();
    try {
      this.activeCounts.addAndGet(
          normalizeIndex(index, this.activeCounts.getNormalizingIndexOffset(), this.activeCounts.length()), value);
    } finally {
      this.wrp.writerCriticalSectionExit(criticalValue);
    } 
  }

  
  void setCountAtIndex(int index, long value) {
    try {
      this.wrp.readerLock();
      assert this.countsArrayLength == this.activeCounts.length();
      assert this.countsArrayLength == this.inactiveCounts.length();
      this.activeCounts.lazySet(
          normalizeIndex(index, this.activeCounts.getNormalizingIndexOffset(), this.activeCounts.length()), value);
      this.inactiveCounts.lazySet(
          normalizeIndex(index, this.inactiveCounts.getNormalizingIndexOffset(), this.inactiveCounts.length()), 0L);
    } finally {
      this.wrp.readerUnlock();
    } 
  }

  
  void setCountAtNormalizedIndex(int index, long value) {
    try {
      this.wrp.readerLock();
      assert this.countsArrayLength == this.activeCounts.length();
      assert this.countsArrayLength == this.inactiveCounts.length();
      this.inactiveCounts.lazySet(index, value);
      this.activeCounts.lazySet(index, 0L);
    } finally {
      this.wrp.readerUnlock();
    } 
  }



  
  int getNormalizingIndexOffset() { return this.activeCounts.getNormalizingIndexOffset(); }



  
  void setNormalizingIndexOffset(int normalizingIndexOffset) { setNormalizingIndexOffset(normalizingIndexOffset, 0, false); }




  
  private void setNormalizingIndexOffset(int normalizingIndexOffset, int shiftedAmount, boolean lowestHalfBucketPopulated) {
    try {
      this.wrp.readerLock();
      
      assert this.countsArrayLength == this.activeCounts.length();
      assert this.countsArrayLength == this.inactiveCounts.length();
      
      if (normalizingIndexOffset == this.activeCounts.getNormalizingIndexOffset()) {
        return;
      }

      
      int zeroIndex = normalizeIndex(0, this.inactiveCounts.getNormalizingIndexOffset(), this.inactiveCounts.length());
      long inactiveZeroValueCount = this.inactiveCounts.get(zeroIndex);
      this.inactiveCounts.lazySet(zeroIndex, 0L);

      
      this.inactiveCounts.setNormalizingIndexOffset(normalizingIndexOffset);

      
      if (shiftedAmount > 0 && lowestHalfBucketPopulated) {
        shiftLowestInactiveHalfBucketContentsLeft(shiftedAmount);
      }

      
      zeroIndex = normalizeIndex(0, this.inactiveCounts.getNormalizingIndexOffset(), this.inactiveCounts.length());
      this.inactiveCounts.lazySet(zeroIndex, inactiveZeroValueCount);

      
      AtomicLongArrayWithNormalizingOffset tmp = this.activeCounts;
      this.activeCounts = this.inactiveCounts;
      this.inactiveCounts = tmp;
      
      this.wrp.flipPhase();

      
      zeroIndex = normalizeIndex(0, this.inactiveCounts.getNormalizingIndexOffset(), this.inactiveCounts.length());
      inactiveZeroValueCount = this.inactiveCounts.get(zeroIndex);
      this.inactiveCounts.lazySet(zeroIndex, 0L);

      
      this.inactiveCounts.setNormalizingIndexOffset(normalizingIndexOffset);

      
      if (shiftedAmount > 0 && lowestHalfBucketPopulated) {
        shiftLowestInactiveHalfBucketContentsLeft(shiftedAmount);
      }

      
      zeroIndex = normalizeIndex(0, this.inactiveCounts.getNormalizingIndexOffset(), this.inactiveCounts.length());
      this.inactiveCounts.lazySet(zeroIndex, inactiveZeroValueCount);

      
      tmp = this.activeCounts;
      this.activeCounts = this.inactiveCounts;
      this.inactiveCounts = tmp;
      
      this.wrp.flipPhase();
    
    }
    finally {

      
      this.wrp.readerUnlock();
    } 
  }
  
  private void shiftLowestInactiveHalfBucketContentsLeft(int shiftAmount) {
    int numberOfBinaryOrdersOfMagnitude = shiftAmount >> this.subBucketHalfCountMagnitude;















    
    for (int fromIndex = 1; fromIndex < this.subBucketHalfCount; fromIndex++) {
      long toValue = valueFromIndex(fromIndex) << numberOfBinaryOrdersOfMagnitude;
      int toIndex = countsArrayIndex(toValue);
      
      int normalizedToIndex = normalizeIndex(toIndex, this.inactiveCounts.getNormalizingIndexOffset(), this.inactiveCounts.length());
      long countAtFromIndex = this.inactiveCounts.get(fromIndex);
      this.inactiveCounts.lazySet(normalizedToIndex, countAtFromIndex);
      this.inactiveCounts.lazySet(fromIndex, 0L);
    } 
  }






  
  void shiftNormalizingIndexByOffset(int offsetToAdd, boolean lowestHalfBucketPopulated) {
    try {
      this.wrp.readerLock();
      assert this.countsArrayLength == this.activeCounts.length();
      assert this.countsArrayLength == this.inactiveCounts.length();
      int newNormalizingIndexOffset = getNormalizingIndexOffset() + offsetToAdd;
      setNormalizingIndexOffset(newNormalizingIndexOffset, offsetToAdd, lowestHalfBucketPopulated);
    } finally {
      this.wrp.readerUnlock();
    } 
  }

  
  void resize(long newHighestTrackableValue) {
    try {
      this.wrp.readerLock();
      
      assert this.countsArrayLength == this.activeCounts.length();
      assert this.countsArrayLength == this.inactiveCounts.length();
      
      int newArrayLength = determineArrayLengthNeeded(newHighestTrackableValue);
      int countsDelta = newArrayLength - this.countsArrayLength;
      
      if (countsDelta <= 0) {
        return;
      }


      
      int oldNormalizedZeroIndex = normalizeIndex(0, this.inactiveCounts.getNormalizingIndexOffset(), this.inactiveCounts.length());

      
      AtomicLongArray oldInactiveCounts = this.inactiveCounts;
      this

        
        .inactiveCounts = new AtomicLongArrayWithNormalizingOffset(newArrayLength, this.inactiveCounts.getNormalizingIndexOffset());

      
      for (int i = 0; i < oldInactiveCounts.length(); i++) {
        this.inactiveCounts.lazySet(i, oldInactiveCounts.get(i));
      }
      if (oldNormalizedZeroIndex != 0) {
        
        int newNormalizedZeroIndex = oldNormalizedZeroIndex + countsDelta;
        int lengthToCopy = newArrayLength - countsDelta - oldNormalizedZeroIndex;
        
        int src = oldNormalizedZeroIndex, dst = newNormalizedZeroIndex;
        for (; src < oldNormalizedZeroIndex + lengthToCopy; 
          src++, dst++) {
          this.inactiveCounts.lazySet(dst, oldInactiveCounts.get(src));
        }
        for (dst = oldNormalizedZeroIndex; dst < newNormalizedZeroIndex; dst++) {
          this.inactiveCounts.lazySet(dst, 0L);
        }
      } 

      
      AtomicLongArrayWithNormalizingOffset tmp = this.activeCounts;
      this.activeCounts = this.inactiveCounts;
      this.inactiveCounts = tmp;
      
      this.wrp.flipPhase();

      
      oldInactiveCounts = this.inactiveCounts;
      this

        
        .inactiveCounts = new AtomicLongArrayWithNormalizingOffset(newArrayLength, this.inactiveCounts.getNormalizingIndexOffset());

      
      for (int i = 0; i < oldInactiveCounts.length(); i++) {
        this.inactiveCounts.lazySet(i, oldInactiveCounts.get(i));
      }
      if (oldNormalizedZeroIndex != 0) {
        
        int newNormalizedZeroIndex = oldNormalizedZeroIndex + countsDelta;
        int lengthToCopy = newArrayLength - countsDelta - oldNormalizedZeroIndex;
        
        int src = oldNormalizedZeroIndex, dst = newNormalizedZeroIndex;
        for (; src < oldNormalizedZeroIndex + lengthToCopy; 
          src++, dst++) {
          this.inactiveCounts.lazySet(dst, oldInactiveCounts.get(src));
        }
        for (dst = oldNormalizedZeroIndex; dst < newNormalizedZeroIndex; dst++) {
          this.inactiveCounts.lazySet(dst, 0L);
        }
      } 

      
      tmp = this.activeCounts;
      this.activeCounts = this.inactiveCounts;
      this.inactiveCounts = tmp;
      
      this.wrp.flipPhase();




      
      establishSize(newHighestTrackableValue);
      
      assert this.countsArrayLength == this.activeCounts.length();
      assert this.countsArrayLength == this.inactiveCounts.length();
    } finally {
      
      this.wrp.readerUnlock();
    } 
  }


  
  public void setAutoResize(boolean autoResize) { this.autoResize = true; }


  
  void clearCounts() {
    try {
      this.wrp.readerLock();
      assert this.countsArrayLength == this.activeCounts.length();
      assert this.countsArrayLength == this.inactiveCounts.length();
      for (int i = 0; i < this.activeCounts.length(); i++) {
        this.activeCounts.lazySet(i, 0L);
        this.inactiveCounts.lazySet(i, 0L);
      } 
      totalCountUpdater.set(this, 0L);
    } finally {
      this.wrp.readerUnlock();
    } 
  }

  
  public ConcurrentHistogram copy() {
    ConcurrentHistogram copy = new ConcurrentHistogram(this);
    copy.add(this);
    return copy;
  }

  
  public ConcurrentHistogram copyCorrectedForCoordinatedOmission(long expectedIntervalBetweenValueSamples) {
    ConcurrentHistogram toHistogram = new ConcurrentHistogram(this);
    toHistogram.addWhileCorrectingForCoordinatedOmission(this, expectedIntervalBetweenValueSamples);
    return toHistogram;
  }


  
  public long getTotalCount() { return totalCountUpdater.get(this); }



  
  void setTotalCount(long totalCount) { totalCountUpdater.set(this, totalCount); }



  
  void incrementTotalCount() { totalCountUpdater.incrementAndGet(this); }



  
  void addToTotalCount(long value) { totalCountUpdater.addAndGet(this, value); }



  
  int _getEstimatedFootprintInBytes() { return 512 + 16 * this.activeCounts.length(); }









  
  public ConcurrentHistogram(int numberOfSignificantValueDigits) {
    this(1L, 2L, numberOfSignificantValueDigits);
    setAutoResize(true);
  }











  
  public ConcurrentHistogram(long highestTrackableValue, int numberOfSignificantValueDigits) { this(1L, highestTrackableValue, numberOfSignificantValueDigits); }


















  
  public ConcurrentHistogram(long lowestDiscernibleValue, long highestTrackableValue, int numberOfSignificantValueDigits) {
    super(lowestDiscernibleValue, highestTrackableValue, numberOfSignificantValueDigits, false);
    this.activeCounts = new AtomicLongArrayWithNormalizingOffset(this.countsArrayLength, 0);
    this.inactiveCounts = new AtomicLongArrayWithNormalizingOffset(this.countsArrayLength, 0);
    this.wordSizeInBytes = 8;
  }





  
  public ConcurrentHistogram(AbstractHistogram source) {
    super(source, false);
    this.activeCounts = new AtomicLongArrayWithNormalizingOffset(this.countsArrayLength, 0);
    this.inactiveCounts = new AtomicLongArrayWithNormalizingOffset(this.countsArrayLength, 0);
    this.wordSizeInBytes = 8;
  }








  
  public static ConcurrentHistogram decodeFromByteBuffer(ByteBuffer buffer, long minBarForHighestTrackableValue) { return decodeFromByteBuffer(buffer, ConcurrentHistogram.class, minBarForHighestTrackableValue); }











  
  public static ConcurrentHistogram decodeFromCompressedByteBuffer(ByteBuffer buffer, long minBarForHighestTrackableValue) throws DataFormatException { return decodeFromCompressedByteBuffer(buffer, ConcurrentHistogram.class, minBarForHighestTrackableValue); }



  
  private void readObject(ObjectInputStream o) throws IOException, ClassNotFoundException {
    o.defaultReadObject();
    this.wrp = new WriterReaderPhaser();
  }

  
  synchronized void fillCountsArrayFromBuffer(ByteBuffer buffer, int length) {
    LongBuffer logbuffer = buffer.asLongBuffer();
    for (int i = 0; i < length; i++) {
      this.inactiveCounts.lazySet(i, logbuffer.get());
      this.activeCounts.lazySet(i, 0L);
    } 
  }

  
  synchronized void fillBufferFromCountsArray(ByteBuffer buffer) {
    try {
      this.wrp.readerLock();
      super.fillBufferFromCountsArray(buffer);
    } finally {
      this.wrp.readerUnlock();
    } 
  }
  
  static class AtomicLongArrayWithNormalizingOffset
    extends AtomicLongArray {
    private int normalizingIndexOffset;
    
    AtomicLongArrayWithNormalizingOffset(int length, int normalizingIndexOffset) {
      super(length);
      this.normalizingIndexOffset = normalizingIndexOffset;
    }

    
    public int getNormalizingIndexOffset() { return this.normalizingIndexOffset; }


    
    public void setNormalizingIndexOffset(int normalizingIndexOffset) { this.normalizingIndexOffset = normalizingIndexOffset; }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\ConcurrentHistogram.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */