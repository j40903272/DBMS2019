package org.HdrHistogram;

import java.util.ConcurrentModificationException;
import java.util.Iterator;















public class AllValuesIterator
  extends AbstractHistogramIterator
  implements Iterator<HistogramIterationValue>
{
  int visitedIndex;
  
  public void reset() { reset(this.histogram); }

  
  private void reset(AbstractHistogram histogram) {
    resetIterator(histogram);
    this.visitedIndex = -1;
  }




  
  public AllValuesIterator(AbstractHistogram histogram) { reset(histogram); }



  
  void incrementIterationLevel() { this.visitedIndex = this.currentIndex; }



  
  boolean reachedIterationLevel() { return (this.visitedIndex != this.currentIndex); }


  
  public boolean hasNext() {
    if (this.histogram.getTotalCount() != this.savedHistogramTotalRawCount) {
      throw new ConcurrentModificationException();
    }
    
    return (this.currentIndex < this.histogram.countsArrayLength - 1);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\HdrHistogram\AllValuesIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */