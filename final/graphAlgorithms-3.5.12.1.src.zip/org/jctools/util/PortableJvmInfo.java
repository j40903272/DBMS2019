package org.jctools.util;




public interface PortableJvmInfo
{
  public static final int CACHE_LINE_SIZE = Integer.getInteger("jctools.cacheLineSize", 64).intValue();
  public static final int CPUs = Runtime.getRuntime().availableProcessors();
  public static final int RECOMENDED_OFFER_BATCH = CPUs * 4;
  public static final int RECOMENDED_POLL_BATCH = CPUs * 4;
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\jctool\\util\PortableJvmInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */