package org.jctools.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import sun.misc.Unsafe;
































public class UnsafeAccess
{
  public static final boolean SUPPORTS_GET_AND_SET;
  public static final Unsafe UNSAFE;
  
  static  {
    Unsafe instance;
    try {
      Field field = Unsafe.class.getDeclaredField("theUnsafe");
      field.setAccessible(true);
      instance = (Unsafe)field.get(null);
    }
    catch (Exception ignored) {

      
      try {



        
        Constructor<Unsafe> c = Unsafe.class.getDeclaredConstructor(new Class[0]);
        c.setAccessible(true);
        instance = c.newInstance(new Object[0]);
      }
      catch (Exception e) {
        
        SUPPORTS_GET_AND_SET = false;
        throw new RuntimeException(e);
      } 
    } 
    
    boolean getAndSetSupport = false;
    
    try {
      Unsafe.class.getMethod("getAndSetObject", new Class[] { Object.class, long.class, Object.class });
      getAndSetSupport = true;
    }
    catch (Exception exception) {}


    
    UNSAFE = instance;
    SUPPORTS_GET_AND_SET = getAndSetSupport;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\jctool\\util\UnsafeAccess.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */