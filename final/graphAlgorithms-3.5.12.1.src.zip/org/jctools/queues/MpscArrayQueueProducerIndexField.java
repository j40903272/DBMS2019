package org.jctools.queues;

import org.jctools.util.UnsafeAccess;






























abstract class MpscArrayQueueProducerIndexField<E>
  extends MpscArrayQueueL1Pad<E>
{
  private static final long P_INDEX_OFFSET;
  private volatile long producerIndex;
  
  static  {
    try {
      P_INDEX_OFFSET = UnsafeAccess.UNSAFE.objectFieldOffset(MpscArrayQueueProducerIndexField.class.getDeclaredField("producerIndex"));
    }
    catch (NoSuchFieldException e) {
      
      throw new RuntimeException(e);
    } 
  }




  
  public MpscArrayQueueProducerIndexField(int capacity) { super(capacity); }




  
  public final long lvProducerIndex() { return this.producerIndex; }



  
  protected final boolean casProducerIndex(long expect, long newValue) { return UnsafeAccess.UNSAFE.compareAndSwapLong(this, P_INDEX_OFFSET, expect, newValue); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\jctools\queues\MpscArrayQueueProducerIndexField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */