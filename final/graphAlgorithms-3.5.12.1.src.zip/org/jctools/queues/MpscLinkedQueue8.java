package org.jctools.queues;

import org.jctools.util.UnsafeAccess;





















public class MpscLinkedQueue8<E>
  extends MpscLinkedQueue<E>
{
  protected final LinkedQueueNode<E> xchgProducerNode(LinkedQueueNode<E> newVal) { return (LinkedQueueNode<E>)UnsafeAccess.UNSAFE.getAndSetObject(this, P_NODE_OFFSET, newVal); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\jctools\queues\MpscLinkedQueue8.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */