package org.jctools.queues;
























public final class IndexedQueueSizeUtil
{
  public static int size(IndexedQueue iq) {
    long currentProducerIndex, before, after = iq.lvConsumerIndex();

    
    do {
      before = after;
      currentProducerIndex = iq.lvProducerIndex();
      after = iq.lvConsumerIndex();
    } while (before != after);
    
    long size = currentProducerIndex - after;




    
    if (size > 2147483647L)
    {
      return Integer.MAX_VALUE;
    }

    
    return (int)size;
  }







  
  public static boolean isEmpty(IndexedQueue iq) { return (iq.lvConsumerIndex() == iq.lvProducerIndex()); }
  
  public static interface IndexedQueue {
    long lvConsumerIndex();
    
    long lvProducerIndex();
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\jctools\queues\IndexedQueueSizeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */