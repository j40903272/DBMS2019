package org.jctools.queues;

import org.jctools.util.UnsafeAccess;



































public abstract class MpscLinkedQueue<E>
  extends BaseLinkedQueue<E>
{
  public static <E> MpscLinkedQueue<E> newMpscLinkedQueue() {
    if (UnsafeAccess.SUPPORTS_GET_AND_SET)
    {
      return new MpscLinkedQueue8<E>();
    }

    
    return new MpscLinkedQueue7<E>();
  }


  
  protected MpscLinkedQueue() {
    LinkedQueueNode<E> node = newNode();
    spConsumerNode(node);
    xchgProducerNode(node);
  }


















  
  public final boolean offer(E e) {
    if (null == e)
    {
      throw new NullPointerException();
    }
    LinkedQueueNode<E> nextNode = newNode(e);
    LinkedQueueNode<E> prevProducerNode = xchgProducerNode(nextNode);

    
    prevProducerNode.soNext(nextNode);
    return true;
  }



















  
  public final E poll() {
    LinkedQueueNode<E> currConsumerNode = lpConsumerNode();
    LinkedQueueNode<E> nextNode = currConsumerNode.lvNext();
    if (nextNode != null)
    {
      return getSingleConsumerNodeValue(currConsumerNode, nextNode);
    }
    if (currConsumerNode != lvProducerNode()) {
      
      nextNode = spinWaitForNextNode(currConsumerNode);
      
      return getSingleConsumerNodeValue(currConsumerNode, nextNode);
    } 
    return null;
  }


  
  public final E peek() {
    LinkedQueueNode<E> currConsumerNode = lpConsumerNode();
    LinkedQueueNode<E> nextNode = currConsumerNode.lvNext();
    if (nextNode != null)
    {
      return nextNode.lpValue();
    }
    if (currConsumerNode != lvProducerNode()) {
      
      nextNode = spinWaitForNextNode(currConsumerNode);
      
      return nextNode.lpValue();
    } 
    return null;
  }








  
  public final boolean remove(Object o) {
    if (null == o)
    {
      return false;
    }
    
    LinkedQueueNode<E> originalConsumerNode = lpConsumerNode();
    LinkedQueueNode<E> prevConsumerNode = originalConsumerNode;
    LinkedQueueNode<E> currConsumerNode = getNextConsumerNode(originalConsumerNode);
    while (currConsumerNode != null) {
      
      if (o.equals(currConsumerNode.lpValue())) {
        
        LinkedQueueNode<E> nextNode = getNextConsumerNode(currConsumerNode);
        
        if (nextNode != null) {

          
          prevConsumerNode.soNext(nextNode);


        
        }
        else {



          
          prevConsumerNode.soNext(null);
          if (!casProducerNode(currConsumerNode, prevConsumerNode)) {

            
            nextNode = spinWaitForNextNode(currConsumerNode);
            prevConsumerNode.soNext(nextNode);
          } 
        } 

        
        currConsumerNode.soNext(null);
        currConsumerNode.spValue(null);
        
        return true;
      } 
      prevConsumerNode = currConsumerNode;
      currConsumerNode = getNextConsumerNode(currConsumerNode);
    } 
    return false;
  }


  
  public int fill(MessagePassingQueue.Supplier<E> s) {
    long result = 0L;
    
    do {
      fill(s, 4096);
      result += 4096L;
    }
    while (result <= 2147479551L);
    return (int)result;
  }


  
  public int fill(MessagePassingQueue.Supplier<E> s, int limit) {
    if (limit == 0)
    {
      return 0;
    }
    LinkedQueueNode<E> tail = newNode(s.get());
    LinkedQueueNode<E> head = tail;
    for (int i = 1; i < limit; i++) {
      
      LinkedQueueNode<E> temp = newNode(s.get());
      tail.soNext(temp);
      tail = temp;
    } 
    LinkedQueueNode<E> oldPNode = xchgProducerNode(tail);
    oldPNode.soNext(head);
    return limit;
  }


  
  public void fill(MessagePassingQueue.Supplier<E> s, MessagePassingQueue.WaitStrategy wait, MessagePassingQueue.ExitCondition exit) {
    while (exit.keepRunning())
    {
      fill(s, 4096);
    }
  }




  
  private LinkedQueueNode<E> getNextConsumerNode(LinkedQueueNode<E> currConsumerNode) {
    LinkedQueueNode<E> nextNode = currConsumerNode.lvNext();
    if (nextNode == null && currConsumerNode != lvProducerNode())
    {
      nextNode = spinWaitForNextNode(currConsumerNode);
    }
    return nextNode;
  }

  
  private LinkedQueueNode<E> spinWaitForNextNode(LinkedQueueNode<E> currNode) {
    LinkedQueueNode<E> nextNode;
    while ((nextNode = currNode.lvNext()) == null);


    
    return nextNode;
  }
  
  protected abstract LinkedQueueNode<E> xchgProducerNode(LinkedQueueNode<E> paramLinkedQueueNode);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\jctools\queues\MpscLinkedQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.2
 */