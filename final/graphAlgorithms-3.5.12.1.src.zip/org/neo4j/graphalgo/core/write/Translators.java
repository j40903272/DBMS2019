package org.neo4j.graphalgo.core.write;

import com.carrotsearch.hppc.IntDoubleMap;
import java.util.concurrent.atomic.AtomicIntegerArray;
import org.neo4j.graphalgo.core.utils.AtomicDoubleArray;






















public class Translators
{
  public static final PropertyTranslator.OfDouble<AtomicDoubleArray> ATOMIC_DOUBLE_ARRAY_TRANSLATOR = (data, nodeId) -> data.get((int)nodeId);

  
  public static final PropertyTranslator.OfInt<AtomicIntegerArray> ATOMIC_INTEGER_ARRAY_TRANSLATOR = (data, nodeId) -> data.get((int)nodeId);

  
  public static final PropertyTranslator.OfDouble<double[]> DOUBLE_ARRAY_TRANSLATOR = (data, nodeId) -> data[(int)nodeId];

  
  public static final PropertyTranslator.OfInt<int[]> INT_ARRAY_TRANSLATOR = (data, nodeId) -> data[(int)nodeId];

  
  public static final PropertyTranslator.OfDouble<IntDoubleMap> INT_DOUBLE_MAP_TRANSLATOR = (data, nodeId) -> data.get((int)nodeId);

  
  public static final PropertyTranslator.OfOptionalInt<int[]> OPTIONAL_INT_ARRAY_TRANSLATOR = (data, nodeId) -> data[(int)nodeId];
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\write\Translators.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */