package org.neo4j.graphalgo.core.loading;

import java.util.Collection;
import java.util.function.LongPredicate;
import org.neo4j.collection.primitive.PrimitiveLongIterable;
import org.neo4j.collection.primitive.PrimitiveLongIterator;
import org.neo4j.graphalgo.api.BatchNodeIterable;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.api.NodeIterator;
import org.neo4j.graphalgo.core.GraphDimensions;
import org.neo4j.graphalgo.core.utils.LazyBatchCollection;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.mem.MemoryRange;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;























public final class IdMap
  implements IdMapping, NodeIterator, BatchNodeIterable
{
  private static final MemoryEstimation ESTIMATION = MemoryEstimations.builder(IdMap.class)
    .perNode("Neo4j identifiers", HugeLongArray::memoryEstimation)
    .rangePerGraphDimension("Mapping from Neo4j identifiers to internal identifiers", graphDimension -> 
      
      SparseNodeMapping.memoryEstimation(graphDimension.highestNeoId(), graphDimension.nodeCount()))
    .build();
  
  private long nodeCount;
  
  private HugeLongArray graphIds;
  private SparseNodeMapping nodeToGraphIds;
  
  public static MemoryEstimation memoryEstimation() { return ESTIMATION; }




  
  public IdMap(HugeLongArray graphIds, SparseNodeMapping nodeToGraphIds, long nodeCount) {
    this.nodeCount = nodeCount;
    this.graphIds = graphIds;
    this.nodeToGraphIds = nodeToGraphIds;
  }


  
  public long toMappedNodeId(long nodeId) { return this.nodeToGraphIds.get(nodeId); }



  
  public long toOriginalNodeId(long nodeId) { return this.graphIds.get(nodeId); }



  
  public boolean contains(long nodeId) { return this.nodeToGraphIds.contains(nodeId); }



  
  public long nodeCount() { return this.nodeCount; }


  
  public void forEachNode(LongPredicate consumer) {
    long count = nodeCount(); long i;
    for (i = 0L; i < count; i++) {
      if (!consumer.test(i)) {
        return;
      }
    } 
  }


  
  public PrimitiveLongIterator nodeIterator() { return new IdIterator(nodeCount()); }


  
  public Collection<PrimitiveLongIterable> batchIterables(int batchSize) {
    return LazyBatchCollection.of(
        nodeCount(), batchSize, IdIterable::new);
  }
  
  public static final class IdIterable
    implements PrimitiveLongIterable
  {
    private final long start;
    private final long length;
    
    public IdIterable(long start, long length) {
      this.start = start;
      this.length = length;
    }


    
    public PrimitiveLongIterator iterator() { return new IdMap.IdIterator(this.start, this.length); }
  }
  
  public static final class IdIterator
    implements PrimitiveLongIterator
  {
    private long current;
    private long limit;
    
    public IdIterator(long length) {
      this.current = 0L;
      this.limit = length;
    }
    
    private IdIterator(long start, long length) {
      this.current = start;
      this.limit = start + length;
    }


    
    public boolean hasNext() { return (this.current < this.limit); }



    
    public long next() { return this.current++; }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\IdMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */