package org.neo4j.graphalgo.core.loading;

import java.util.Optional;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.GraphFactory;
import org.neo4j.graphalgo.api.GraphSetup;
import org.neo4j.graphalgo.core.huge.HugeGraph;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphdb.NotInTransactionException;
import org.neo4j.internal.kernel.api.security.AccessMode;
import org.neo4j.internal.kernel.api.security.AuthSubject;
import org.neo4j.internal.kernel.api.security.SecurityContext;
import org.neo4j.kernel.api.KernelTransaction;
import org.neo4j.kernel.impl.core.ThreadToStatementContextBridge;
import org.neo4j.kernel.internal.GraphDatabaseAPI;
























public class CypherGraphFactory
  extends GraphFactory
{
  public static final String TYPE = "cypher";
  static final String LIMIT = "limit";
  static final String SKIP = "skip";
  private final GraphDatabaseAPI api;
  private final GraphSetup setup;
  
  public CypherGraphFactory(GraphDatabaseAPI api, GraphSetup setup) {
    super(api, setup, false);
    this.api = api;
    this.setup = setup;
  }

  
  protected void validateTokens() {}
  
  public final MemoryEstimation memoryEstimation() {
    BatchLoadResult nodeCount = (new CountingCypherRecordLoader(this.setup.startLabel, this.api, this.setup)).load();
    this.dimensions.nodeCount(nodeCount.rows());
    
    BatchLoadResult relCount = (new CountingCypherRecordLoader(this.setup.relationshipType, this.api, this.setup)).load();
    this.dimensions.maxRelCount(relCount.rows());
    
    return HugeGraphFactory.getMemoryEstimation(this.setup, this.dimensions);
  }


  
  public Graph importGraph() {
    try (KernelTransaction.Revertable revertable = setReadOnlySecurityContext()) {
      BatchLoadResult nodeCount = (new CountingCypherRecordLoader(this.setup.startLabel, this.api, this.setup)).load();
      IdsAndProperties nodes = (new CypherNodeLoader(nodeCount.rows(), this.api, this.setup)).load();
      Relationships relationships = (new CypherRelationshipLoader(nodes.idMap(), this.api, this.setup)).load();
      
      return (Graph)HugeGraph.create(this.setup.tracker, nodes
          
          .idMap(), nodes
          .properties(), relationships
          .relationshipCount(), relationships
          .inAdjacency(), relationships
          .outAdjacency(), relationships
          .inOffsets(), relationships
          .outOffsets(), relationships
          .maybeDefaultRelProperty(), 
          Optional.ofNullable(relationships.inRelProperties()), 
          Optional.ofNullable(relationships.outRelProperties()), 
          Optional.ofNullable(relationships.inRelPropertyOffsets()), 
          Optional.ofNullable(relationships.outRelPropertyOffsets()), this.setup.loadAsUndirected);
    } 
  }




  
  private KernelTransaction.Revertable setReadOnlySecurityContext() {
    try {
      KernelTransaction kernelTransaction = ((ThreadToStatementContextBridge)this.api.getDependencyResolver().resolveDependency(ThreadToStatementContextBridge.class)).getKernelTransactionBoundToThisThread(true);
      AuthSubject subject = kernelTransaction.securityContext().subject();
      SecurityContext securityContext = new SecurityContext(subject, (AccessMode)AccessMode.Static.READ);
      return kernelTransaction.overrideWith(securityContext);
    } catch (NotInTransactionException ex) {
      
      throw new IllegalStateException("Must run in a transaction.", (Throwable)ex);
    } 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\CypherGraphFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */