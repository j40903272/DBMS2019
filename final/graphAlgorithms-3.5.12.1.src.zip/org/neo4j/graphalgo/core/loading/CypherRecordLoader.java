package org.neo4j.graphalgo.core.loading;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import org.neo4j.graphalgo.api.GraphSetup;
import org.neo4j.graphalgo.core.utils.ArrayUtil;
import org.neo4j.graphalgo.core.utils.BitUtil;
import org.neo4j.graphdb.Result;
import org.neo4j.graphdb.security.AuthorizationViolationException;
import org.neo4j.kernel.internal.GraphDatabaseAPI;






















abstract class CypherRecordLoader<R>
{
  static final long NO_COUNT = -1L;
  private final String loadQuery;
  private final long recordCount;
  private final GraphDatabaseAPI api;
  final GraphSetup setup;
  
  CypherRecordLoader(String loadQuery, long recordCount, GraphDatabaseAPI api, GraphSetup setup) {
    this.loadQuery = loadQuery;
    this.recordCount = recordCount;
    this.api = api;
    this.setup = setup;
  }
  
  final R load() {
    try {
      if (loadsInParallel()) {
        parallelLoad();
      } else {
        nonParallelLoad();
      } 
      return result();
    } catch (AuthorizationViolationException ex) {
      throw new IllegalArgumentException(String.format("Query must be read only. Query: [%s]", new Object[] { this.loadQuery }));
    } 
  }











  
  private boolean loadsInParallel() { return CypherLoadingUtils.canBatchLoad(this.setup.concurrency(), this.loadQuery); }
  
  private void parallelLoad() {
    int bufferSize, batchSize, threads;
    ExecutorService pool = this.setup.executor;





    
    if (this.recordCount == -1L) {
      threads = this.setup.concurrency();
      batchSize = ArrayUtil.MAX_ARRAY_LENGTH;
      bufferSize = 100000;
    } else {
      long optimalNumberOfThreads = BitUtil.ceilDiv(this.recordCount, ArrayUtil.MAX_ARRAY_LENGTH);
      threads = (int)Math.min(this.setup.concurrency(), optimalNumberOfThreads);
      long optimalBatchSize = BitUtil.ceilDiv(this.recordCount, threads);
      batchSize = (int)Math.min(optimalBatchSize, ArrayUtil.MAX_ARRAY_LENGTH);
      bufferSize = Math.min(100000, batchSize);
    } 
    
    long offset = 0L;
    long lastOffset = 0L;
    Deque<Future<BatchLoadResult>> futures = new ArrayDeque<>(threads);
    boolean working = true;
    do {
      long skip = offset;
      futures.add(pool.submit(() -> loadOneBatch(skip, batchSize, bufferSize)));
      offset += batchSize;
      if (futures.size() < threads)
        continue;  Future<BatchLoadResult> oldestTask = futures.removeFirst();
      BatchLoadResult result = CypherLoadingUtils.get("Error during loading relationships offset: " + (lastOffset + batchSize), oldestTask);

      
      updateCounts(result);
      lastOffset = result.offset();
      working = (result.rows() > 0L);
    }
    while (working);
    futures.forEach(f -> f.cancel(false));
  }
  
  private void nonParallelLoad() {
    int bufferSize = (int)Math.min(this.recordCount, 100000L);
    BatchLoadResult result = loadOneBatch(0L, -1, bufferSize);
    updateCounts(result);
  }






  
  final void runLoadingQuery(long offset, int batchSize, Result.ResultVisitor<RuntimeException> visitor) {
    Map<String, Object> parameters = (batchSize == -1) ? this.setup.params : CypherLoadingUtils.params(this.setup.params, offset, batchSize);
    this.api.execute(this.loadQuery, parameters).accept(visitor);
  }
  
  abstract BatchLoadResult loadOneBatch(long paramLong, int paramInt1, int paramInt2);
  
  abstract void updateCounts(BatchLoadResult paramBatchLoadResult);
  
  abstract R result();
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\CypherRecordLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */