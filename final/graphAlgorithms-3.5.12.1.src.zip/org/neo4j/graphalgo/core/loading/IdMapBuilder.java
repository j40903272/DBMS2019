package org.neo4j.graphalgo.core.loading;

import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.Pools;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeCursor;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArrayBuilder;

























public final class IdMapBuilder
{
  private static IdMap build(HugeLongArray graphIds, long nodeCount, long highestNodeId, int concurrency, AllocationTracker tracker) {
    SparseNodeMapping.Builder nodeMappingBuilder = SparseNodeMapping.Builder.create((highestNodeId == 0L) ? 1L : highestNodeId, tracker);
    ParallelUtil.readParallel(concurrency, graphIds
        
        .size(), Pools.DEFAULT, (start, end) -> {

          
          try (HugeCursor<long[]> cursor = graphIds.initCursor(graphIds.newCursor(), start, end)) {
            while (cursor.next()) {
              long[] array = (long[])cursor.array;
              int offset = cursor.offset;
              int limit = cursor.limit;
              long internalId = cursor.base + offset;
              for (int i = offset; i < limit; i++, internalId++) {
                nodeMappingBuilder.set(array[i], internalId);
              }
            } 
          } 
        });

    
    SparseNodeMapping nodeToGraphIds = nodeMappingBuilder.build();
    return new IdMap(graphIds, nodeToGraphIds, nodeCount);
  }





  
  public static IdMap build(HugeLongArrayBuilder idMapBuilder, long highestNodeId, int concurrency, AllocationTracker tracker) { return build((HugeLongArray)idMapBuilder.build(), idMapBuilder.size(), highestNodeId, concurrency, tracker); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\IdMapBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */