package org.neo4j.graphalgo.core.loading;

import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;























public class NullPropertyMap
  implements NodeProperties
{
  static final MemoryEstimation MEMORY_USAGE = MemoryEstimations.of(NullPropertyMap.class);
  
  private final double defaultValue;

  
  public NullPropertyMap(double defaultValue) { this.defaultValue = defaultValue; }



  
  public double nodeProperty(long nodeId) { return this.defaultValue; }



  
  public double nodeProperty(long nodeId, double defaultValue) { return defaultValue; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\NullPropertyMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */