package org.neo4j.graphalgo.core.loading;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicLong;
import org.neo4j.graphalgo.core.utils.BitUtil;
import org.neo4j.graphalgo.core.utils.paged.PaddedAtomicLong;
import org.neo4j.graphdb.DependencyResolver;
import org.neo4j.io.pagecache.PageCache;
import org.neo4j.io.pagecache.PageCursor;
import org.neo4j.io.pagecache.PagedFile;
import org.neo4j.kernel.impl.storageengine.impl.recordstorage.RecordStorageEngine;
import org.neo4j.kernel.impl.store.NeoStores;
import org.neo4j.kernel.impl.store.RecordPageLocationCalculator;
import org.neo4j.kernel.impl.store.RecordStore;
import org.neo4j.kernel.impl.store.UnderlyingStorageException;
import org.neo4j.kernel.impl.store.format.RecordFormat;
import org.neo4j.kernel.impl.store.format.RecordFormats;
import org.neo4j.kernel.impl.store.record.AbstractBaseRecord;
import org.neo4j.kernel.impl.store.record.RecordLoad;
import org.neo4j.kernel.internal.GraphDatabaseAPI;






















































public class AbstractStorePageCacheScanner<Record extends AbstractBaseRecord>
{
  public static final int DEFAULT_PREFETCH_SIZE = 100;
  private final int prefetchSize;
  private final AtomicLong nextPageId;
  private final ThreadLocal<Cursor> cursors;
  private final int recordSize;
  private final int recordsPerPage;
  private final long maxId;
  private final int pageSize;
  private final RecordFormat<Record> recordFormat;
  private final RecordStore<Record> store;
  private final PagedFile pagedFile;
  
  public final class Cursor
    implements AutoCloseable
  {
    private final long lastPage;
    private final int lastOffset;
    private PageCursor pageCursor;
    private Record record;
    private long recordId;
    private long currentPage;
    private long fetchedUntilPage;
    private int offset;
    
    Cursor(PageCursor pageCursor, Record record) {
      this.lastOffset = RecordPageLocationCalculator.offsetForId(AbstractStorePageCacheScanner.this.maxId, AbstractStorePageCacheScanner.this.pageSize, AbstractStorePageCacheScanner.this.recordSize);
      this.lastPage = calculateLastPageId(AbstractStorePageCacheScanner.this.maxId, AbstractStorePageCacheScanner.this.recordsPerPage, this.lastOffset);
      this.pageCursor = pageCursor;
      this.record = record;
      this.offset = AbstractStorePageCacheScanner.this.pageSize;
      this.currentPage = -1L;
    }

    
    int bulkSize() { return AbstractStorePageCacheScanner.this.prefetchSize * AbstractStorePageCacheScanner.this.recordsPerPage; }

    
    private long calculateLastPageId(long maxId, long recordsPerPage, int lastPageOffset) {
      long lastPageId = BitUtil.ceilDiv(maxId, recordsPerPage) - 1L;
      lastPageId = Math.max(lastPageId, 0L);
      if (lastPageOffset == 0) {
        lastPageId++;
      }
      return lastPageId;
    }
    
    boolean bulkNext(AbstractStorePageCacheScanner.RecordConsumer<Record> consumer) {
      try {
        return bulkNext0(consumer);
      } catch (IOException e) {
        throw new UnderlyingStorageException(e);
      } 
    } private boolean bulkNext0(AbstractStorePageCacheScanner.RecordConsumer<Record> consumer) throws IOException {
      long endPage, page;
      int endOffset;
      if (this.recordId == -1L) {
        return false;
      }



      
      if (this.currentPage < this.lastPage) {
        preFetchPages();
      }
      if (this.currentPage == this.lastPage)
      { page = this.lastPage;
        endOffset = this.lastOffset;
        endPage = 1L + page; }
      else { if (this.currentPage > this.lastPage) {
          this.recordId = -1L;
          return false;
        } 
        page = this.currentPage;
        endPage = this.fetchedUntilPage;
        endOffset = AbstractStorePageCacheScanner.this.pageSize; }

      
      int offset = this.offset;
      long recordId = page * AbstractStorePageCacheScanner.this.recordsPerPage;
      int recordSize = AbstractStorePageCacheScanner.this.recordSize;
      PageCursor pageCursor = this.pageCursor;
      Record record = this.record;
      
      while (page < endPage && 
        pageCursor.next(page++)) {

        
        offset = 0;
        
        while (offset < endOffset) {
          record.setId(recordId++);
          loadAtOffset(offset);
          offset += recordSize;
          if (record.inUse()) {
            consumer.offer(record);
          }
        } 
      } 
      
      this.currentPage = page;
      this.offset = offset;
      this.recordId = recordId;
      
      return true;
    }
    
    private void preFetchPages() throws IOException {
      PageCursor pageCursor = this.pageCursor;
      long prefetchSize = AbstractStorePageCacheScanner.this.prefetchSize;
      long startPage = AbstractStorePageCacheScanner.this.nextPageId.getAndAdd(prefetchSize);
      long endPage = Math.min(this.lastPage, startPage + prefetchSize);
      long preFetchedPage = startPage;
      while (preFetchedPage < endPage && 
        pageCursor.next(preFetchedPage))
      {
        
        preFetchedPage++;
      }
      this.currentPage = startPage;
      this.fetchedUntilPage = preFetchedPage;
    }
    
    private void loadAtOffset(int offset) throws IOException {
      do {
        this.record.setInUse(false);
        this.pageCursor.setOffset(offset);
        AbstractStorePageCacheScanner.this.recordFormat.read((AbstractBaseRecord)this.record, this.pageCursor, RecordLoad.CHECK, AbstractStorePageCacheScanner.this.recordSize);
      } while (this.pageCursor.shouldRetry());
      verifyLoad();
    }

    
    private void verifyLoad() { this.pageCursor.checkAndClearBoundsFlag(); }


    
    public void close() {
      if (this.pageCursor != null) {
        this.pageCursor.close();
        this.pageCursor = null;
        this.record = null;
        
        Cursor localCursor = AbstractStorePageCacheScanner.access$700(AbstractStorePageCacheScanner.this).get();
        
        if (localCursor == this) {
          AbstractStorePageCacheScanner.access$700(AbstractStorePageCacheScanner.this).remove();
        }
      } 
    }
  }























  
  AbstractStorePageCacheScanner(int prefetchSize, GraphDatabaseAPI api, Access<Record> access) {
    DependencyResolver resolver = api.getDependencyResolver();

    
    NeoStores neoStores = ((RecordStorageEngine)resolver.resolveDependency(RecordStorageEngine.class, DependencyResolver.SelectionStrategy.ONLY)).testAccessNeoStores();
    
    RecordStore<Record> store = access.store(neoStores);
    int recordSize = store.getRecordSize();
    int recordsPerPage = store.getRecordsPerPage();
    int pageSize = recordsPerPage * recordSize;
    
    PagedFile pagedFile = null;
    PageCache pageCache = (PageCache)resolver.resolveDependency(PageCache.class, DependencyResolver.SelectionStrategy.ONLY);
    String storeFileName = access.storeFileName();
    try {
      for (PagedFile pf : pageCache.listExistingMappings()) {
        if (pf.file().getName().equals(storeFileName)) {
          pageSize = pf.pageSize();
          recordsPerPage = pageSize / recordSize;
          pagedFile = pf;
          break;
        } 
      } 
    } catch (IOException iOException) {}

    
    this.prefetchSize = prefetchSize;
    this.nextPageId = (AtomicLong)new PaddedAtomicLong();
    this.cursors = new ThreadLocal<>();
    this.recordSize = recordSize;
    this.recordsPerPage = recordsPerPage;
    this.maxId = 1L + store.getHighestPossibleIdInUse();
    this.pageSize = pageSize;
    this.recordFormat = access.recordFormat(neoStores.getRecordFormats());
    this.store = store;
    this.pagedFile = pagedFile;
  }
  
  public final Cursor getCursor() {
    Cursor cursor = this.cursors.get();
    if (cursor == null) {
      PageCursor pageCursor;


      
      long next = this.nextPageId.get();

      
      try {
        if (this.pagedFile != null) {
          pageCursor = this.pagedFile.io(next, 9);
        } else {
          long recordId = next * this.recordSize;
          pageCursor = this.store.openPageCursorForReading(recordId);
        } 
      } catch (IOException e) {
        throw new UnderlyingStorageException(e);
      } 
      AbstractBaseRecord abstractBaseRecord = this.store.newRecord();
      cursor = new Cursor(pageCursor, (Record)abstractBaseRecord);
      this.cursors.set(cursor);
    } 
    return cursor;
  }
  
  final long storeSize() {
    if (this.pagedFile != null) {
      return this.pagedFile.file().length();
    }
    long recordsInUse = 1L + this.store.getHighestPossibleIdInUse();
    long idsInPages = (recordsInUse + this.recordsPerPage - 1L) / this.recordsPerPage * this.recordsPerPage;
    return idsInPages * this.recordSize;
  }

  
  RecordStore<Record> store() { return this.store; }
  
  public static interface RecordConsumer<Record extends AbstractBaseRecord> {
    void offer(Record param1Record);
  }
  
  public static interface Access<Record extends AbstractBaseRecord> {
    RecordStore<Record> store(NeoStores param1NeoStores);
    
    RecordFormat<Record> recordFormat(RecordFormats param1RecordFormats);
    
    String storeFileName();
    
    AbstractStorePageCacheScanner<Record> newScanner(GraphDatabaseAPI param1GraphDatabaseAPI, int param1Int);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\AbstractStorePageCacheScanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */