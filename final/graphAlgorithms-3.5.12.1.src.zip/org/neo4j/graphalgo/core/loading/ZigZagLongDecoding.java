package org.neo4j.graphalgo.core.loading;





















final class ZigZagLongDecoding
{
  static int zigZagUncompress(byte[] array, int limit, long[] out) { return zigZagUncompress(array, 0, limit, out); }

  
  static int zigZagUncompress(byte[] array, int offset, int length, long[] out) {
    long startValue = 0L, value = 0L;
    int into = 0, shift = 0, limit = offset + length;
    while (offset < limit) {
      long input = array[offset++];
      value += (input & 0x7FL) << shift;
      if ((input & 0x80L) == 128L) {
        startValue += value >>> 1L ^ -(value & 0x1L);
        out[into++] = startValue;
        value = 0L;
        shift = 0; continue;
      } 
      shift += 7;
    } 
    
    return into;
  }

  
  private ZigZagLongDecoding() { throw new UnsupportedOperationException("No instances"); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\ZigZagLongDecoding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */