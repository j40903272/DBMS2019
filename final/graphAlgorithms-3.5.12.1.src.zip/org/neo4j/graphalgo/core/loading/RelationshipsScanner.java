package org.neo4j.graphalgo.core.loading;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import org.neo4j.graphalgo.api.GraphSetup;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.core.utils.RawValues;
import org.neo4j.graphalgo.core.utils.StatementAction;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.internal.kernel.api.CursorFactory;
import org.neo4j.internal.kernel.api.Read;
import org.neo4j.kernel.api.KernelTransaction;
import org.neo4j.kernel.impl.store.record.RelationshipRecord;
import org.neo4j.kernel.internal.GraphDatabaseAPI;


























final class RelationshipsScanner
  extends StatementAction
  implements RecordScanner
{
  private final TerminationFlag terminationFlag;
  private final ImportProgress progress;
  private final IdMapping idMap;
  private final AbstractStorePageCacheScanner<RelationshipRecord> scanner;
  private final int scannerIndex;
  private final List<SingleTypeRelationshipImporter.Builder.WithImporter> importerBuilders;
  private long relationshipsImported;
  private long weightsImported;
  
  static InternalImporter.CreateScanner of(GraphDatabaseAPI api, GraphSetup setup, ImportProgress progress, IdMapping idMap, AbstractStorePageCacheScanner<RelationshipRecord> scanner, boolean loadWeights, Collection<SingleTypeRelationshipImporter.Builder> importerBuilders) {
    List<SingleTypeRelationshipImporter.Builder.WithImporter> builders = (List<SingleTypeRelationshipImporter.Builder.WithImporter>)importerBuilders.stream().map(relImporter -> relImporter.loadImporter(setup.loadAsUndirected, setup.loadOutgoing, setup.loadIncoming, loadWeights)).filter(Objects::nonNull).collect(Collectors.toList());
    if (builders.isEmpty()) {
      return InternalImporter.createEmptyScanner();
    }
    return new Creator(api, progress, idMap, scanner, builders, setup.terminationFlag);
  }


  
  static final class Creator
    implements InternalImporter.CreateScanner
  {
    private final GraphDatabaseAPI api;

    
    private final ImportProgress progress;

    
    private final IdMapping idMap;

    
    private final AbstractStorePageCacheScanner<RelationshipRecord> scanner;
    
    private final List<SingleTypeRelationshipImporter.Builder.WithImporter> importerBuilders;
    
    private final TerminationFlag terminationFlag;

    
    Creator(GraphDatabaseAPI api, ImportProgress progress, IdMapping idMap, AbstractStorePageCacheScanner<RelationshipRecord> scanner, List<SingleTypeRelationshipImporter.Builder.WithImporter> importerBuilders, TerminationFlag terminationFlag) {
      this.api = api;
      this.progress = progress;
      this.idMap = idMap;
      this.scanner = scanner;
      this.importerBuilders = importerBuilders;
      this.terminationFlag = terminationFlag;
    }


    
    public RecordScanner create(int index) { return new RelationshipsScanner(this.api, this.terminationFlag, this.progress, this.idMap, this.scanner, index, this.importerBuilders, null); }










    
    public Collection<Runnable> flushTasks() {
      return (Collection<Runnable>)this.importerBuilders.stream()
        .flatMap(SingleTypeRelationshipImporter.Builder.WithImporter::flushTasks)
        .collect(Collectors.toList());
    }
  }

















  
  private RelationshipsScanner(GraphDatabaseAPI api, TerminationFlag terminationFlag, ImportProgress progress, IdMapping idMap, AbstractStorePageCacheScanner<RelationshipRecord> scanner, int threadIndex, List<SingleTypeRelationshipImporter.Builder.WithImporter> importerBuilders) {
    super(api);
    this.terminationFlag = terminationFlag;
    this.progress = progress;
    this.idMap = idMap;
    this.scanner = scanner;
    this.scannerIndex = threadIndex;
    this.importerBuilders = importerBuilders;
  }


  
  public String threadName() { return "relationship-store-scan-" + this.scannerIndex; }



  
  public void accept(KernelTransaction transaction) { scanRelationships(transaction.dataRead(), transaction.cursors()); }

  
  private void scanRelationships(Read read, CursorFactory cursors) {
    try (AbstractStorePageCacheScanner<RelationshipRecord>.Cursor cursor = this.scanner.getCursor()) {

      
      List<SingleTypeRelationshipImporter> importers = (List<SingleTypeRelationshipImporter>)this.importerBuilders.stream().map(imports -> imports.withBuffer(this.idMap, cursor.bulkSize(), read, cursors)).collect(Collectors.toList());



      
      RelationshipsBatchBuffer[] buffers = (RelationshipsBatchBuffer[])importers.stream().map(SingleTypeRelationshipImporter::buffer).toArray(x$0 -> new RelationshipsBatchBuffer[x$0]);
      
      RecordsBatchBuffer<RelationshipRecord> buffer = CompositeRelationshipsBatchBuffer.of(buffers);
      
      long allImportedRels = 0L;
      long allImportedWeights = 0L;
      while (buffer.scan(cursor)) {
        this.terminationFlag.assertRunning();
        long imported = 0L;
        for (SingleTypeRelationshipImporter importer : importers) {
          imported += importer.importRels();
        }
        int importedRels = RawValues.getHead(imported);
        int importedWeights = RawValues.getTail(imported);
        this.progress.relationshipsImported(importedRels);
        allImportedRels += importedRels;
        allImportedWeights += importedWeights;
      } 
      this.relationshipsImported = allImportedRels;
      this.weightsImported = allImportedWeights;
    } 
  }


  
  public long propertiesImported() { return this.weightsImported; }



  
  public long recordsImported() { return this.relationshipsImported; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\RelationshipsScanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */