package org.neo4j.graphalgo.core.loading;

import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.kernel.impl.store.record.AbstractBaseRecord;
import org.neo4j.kernel.impl.store.record.RelationshipRecord;
























public final class RelationshipsBatchBuffer
  extends RecordsBatchBuffer<RelationshipRecord>
{
  public static final int SOURCE_ID_OFFSET = 0;
  public static final int TARGET_ID_OFFSET = 1;
  public static final int RELATIONSHIP_REFERENCE_OFFSET = 2;
  public static final int PROPERTIES_REFERENCE_OFFSET = 3;
  public static final int BATCH_ENTRY_SIZE = 4;
  private final IdMapping idMap;
  private final int type;
  private final long[] sortCopy;
  private final int[] histogram;
  
  public RelationshipsBatchBuffer(IdMapping idMap, int type, int capacity) {
    super(Math.multiplyExact(4, capacity));
    this.idMap = idMap;
    this.type = type;
    this.sortCopy = RadixSort.newCopy(this.buffer);
    this.histogram = RadixSort.newHistogram(capacity);
  }

  
  public void offer(RelationshipRecord record) {
    if (this.type == -1 || this.type == record.getType()) {
      long source = this.idMap.toMappedNodeId(record.getFirstNode());
      if (source != -1L) {
        long target = this.idMap.toMappedNodeId(record.getSecondNode());
        if (target != -1L) {
          add(source, target, record.getId(), record.getNextProp());
        }
      } 
    } 
  }
  
  public void add(long sourceId, long targetId, long relationshipReference, long propertyReference) {
    int position = this.length;
    long[] buffer = this.buffer;
    buffer[position] = sourceId;
    buffer[1 + position] = targetId;
    buffer[2 + position] = relationshipReference;
    buffer[3 + position] = propertyReference;
    this.length = 4 + position;
  }
  
  long[] sortBySource() {
    RadixSort.radixSort(this.buffer, this.sortCopy, this.histogram, this.length);
    return this.buffer;
  }
  
  long[] sortByTarget() {
    RadixSort.radixSort2(this.buffer, this.sortCopy, this.histogram, this.length);
    return this.buffer;
  }

  
  long[] spareLongs() { return this.sortCopy; }


  
  int[] spareInts() { return this.histogram; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\RelationshipsBatchBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */