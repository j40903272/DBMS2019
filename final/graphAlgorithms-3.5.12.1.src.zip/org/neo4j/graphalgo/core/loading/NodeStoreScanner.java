package org.neo4j.graphalgo.core.loading;

import org.neo4j.io.layout.DatabaseFile;
import org.neo4j.kernel.impl.store.NeoStores;
import org.neo4j.kernel.impl.store.NodeStore;
import org.neo4j.kernel.impl.store.RecordStore;
import org.neo4j.kernel.impl.store.format.RecordFormat;
import org.neo4j.kernel.impl.store.format.RecordFormats;
import org.neo4j.kernel.impl.store.record.NodeRecord;
import org.neo4j.kernel.internal.GraphDatabaseAPI;



















public final class NodeStoreScanner
  extends AbstractStorePageCacheScanner<NodeRecord>
{
  public static final AbstractStorePageCacheScanner.Access<NodeRecord> NODE_ACCESS = new AbstractStorePageCacheScanner.Access<NodeRecord>()
    {
      public RecordStore<NodeRecord> store(NeoStores neoStores) {
        return (RecordStore<NodeRecord>)neoStores.getNodeStore();
      }


      
      public RecordFormat<NodeRecord> recordFormat(RecordFormats formats) { return formats.node(); }



      
      public String storeFileName() { return DatabaseFile.NODE_STORE.getName(); }





      
      public AbstractStorePageCacheScanner<NodeRecord> newScanner(GraphDatabaseAPI api, int prefetchSize) { return new NodeStoreScanner(prefetchSize, api, null); }
    };


  
  private NodeStoreScanner(int prefetchSize, GraphDatabaseAPI api) { super(prefetchSize, api, NODE_ACCESS); }



  
  NodeStore store() { return (NodeStore)super.store(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\NodeStoreScanner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */