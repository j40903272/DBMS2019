package org.neo4j.graphalgo.core.loading;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;
import org.neo4j.graphalgo.core.huge.AdjacencyList;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.PageUtil;




























final class AdjacencyListBuilder
{
  private static final long MAX_SIZE = 562949953421312L;
  private static final long PAGE_SIZE_IN_BYTES = MemoryUsage.sizeOfByteArray(262144);
  
  private static final int PREFETCH_PAGES = 1;
  
  private static final long PREFETCH_ELEMENTS = 262144L;
  
  private final AllocationTracker tracker;
  
  private final ReentrantLock growLock;
  private final AtomicLong allocIdx;
  private final AtomicLong size;
  private final AtomicLong capacity;
  private byte[][] pages;
  
  static AdjacencyListBuilder newBuilder(AllocationTracker tracker) { return new AdjacencyListBuilder(tracker); }

  
  private AdjacencyListBuilder(AllocationTracker tracker) {
    this.tracker = tracker;
    this.growLock = new ReentrantLock(true);
    this.size = new AtomicLong();
    this.capacity = new AtomicLong();
    this.allocIdx = new AtomicLong();
    this.pages = new byte[0][];
    tracker.add(MemoryUsage.sizeOfObjectArray(0));
  }

  
  Allocator newAllocator() { return new Allocator(this); }


  
  public AdjacencyList build() { return new AdjacencyList(this.pages); }

  
  private long allocateNewPages(Allocator into) {
    long intoIndex = this.allocIdx.getAndAdd(262144L);
    grow(intoIndex + 262144L);
    into.setNewPages(this.pages, intoIndex);
    return intoIndex;
  }
  
  private long allocatePage(byte[] page, Allocator into) {
    long intoIndex = this.allocIdx.getAndAdd(262144L);
    int pageIndex = PageUtil.pageIndex(intoIndex, 18);
    grow(intoIndex + 262144L, pageIndex, page);
    this.tracker.add(MemoryUsage.sizeOfByteArray(page.length));
    into.insertPage(page);
    return intoIndex;
  }

  
  private void grow(long newSize) { grow(newSize, -1, null); }

  
  private void grow(long newSize, int skipPage, byte[] page) {
    assert newSize <= 562949953421312L;
    boolean didSetSize = tryGrowSize(newSize);
    if (didSetSize) {
      return;
    }
    this.growLock.lock();
    try {
      didSetSize = tryGrowSize(newSize);
      if (didSetSize) {
        return;
      }
      int newNumPages = PageUtil.numPagesFor(newSize, 18, 262143L);
      long newCap = PageUtil.capacityFor(newNumPages, 18);
      setPages(newNumPages, this.pages.length, skipPage, page);
      this.capacity.set(newCap);
      this.size.set(newSize);
    } finally {
      this.growLock.unlock();
    } 
  }
  
  private boolean tryGrowSize(long newSize) {
    long cap = this.capacity.get();
    if (newSize > cap) {
      return false;
    }
    setSize(newSize);
    return true;
  }
  
  private void setSize(long newSize) {
    long size;
    do {
      size = this.size.get();
    } while (size < newSize && !this.size.compareAndSet(size, newSize));
  }
  
  private void setPages(int newNumPages, int currentNumPages, int skipPage, byte[] page) {
    assert skipPage == -1L || page != null : "Trying to insert null page at skipPage index (" + skipPage + ")";
    
    int newPages = newNumPages - currentNumPages;
    if (newPages > 0) {
      AllocationTracker tracker = this.tracker;
      tracker.add(MemoryUsage.sizeOfObjectArrayElements(newPages));
      byte[][] pages = Arrays.copyOf(this.pages, newNumPages);
      for (int i = currentNumPages; i < newNumPages; i++) {
        if (i != skipPage) {
          tracker.add(PAGE_SIZE_IN_BYTES);
          pages[i] = new byte[262144];
        } else {
          pages[i] = page;
        } 
      } 
      this.pages = pages;
    } 
  }

  
  static final class Allocator
  {
    private final AdjacencyListBuilder builder;
    
    private long top;
    
    private byte[][] pages;
    private int prevOffset;
    private int toPageIndex;
    private int currentPageIndex;
    public byte[] page;
    public int offset;
    
    private Allocator(AdjacencyListBuilder builder) {
      this.builder = builder;
      this.prevOffset = -1;
    }
    
    void prepare() {
      this.top = this.builder.allocateNewPages(this);
      if (this.top == 0L) {
        this.top++;
        this.offset++;
      } 
    }

    
    long allocate(int size) { return localAllocate(size, this.top); }

    
    private long localAllocate(int size, long address) {
      int maxOffset = 262144 - size;
      if (maxOffset >= this.offset) {
        this.top += size;
        return address;
      } 
      return majorAllocate(size, maxOffset, address);
    }
    
    private long majorAllocate(int size, int maxOffset, long address) {
      if (maxOffset < 0) {
        return oversizingAllocate(size);
      }
      if (reset() && maxOffset >= this.offset) {
        this.top += size;
        return address;
      } 
      int waste = 262144 - this.offset;
      address = this.top += waste;
      if (next()) {

        
        this.top += size;
        return address;
      } 
      return prefetchAllocate(size);
    }





    
    private long oversizingAllocate(int size) {
      byte[] largePage = new byte[size];
      return this.builder.allocatePage(largePage, this);
    }
    
    private long prefetchAllocate(int size) {
      long address = this.top = this.builder.allocateNewPages(this);
      this.top += size;
      return address;
    }
    
    private boolean reset() {
      if (this.prevOffset != -1) {
        this.page = this.pages[this.currentPageIndex];
        this.offset = this.prevOffset;
        this.prevOffset = -1;
        return true;
      } 
      return false;
    }
    
    private boolean next() {
      if (++this.currentPageIndex <= this.toPageIndex) {
        this.page = this.pages[this.currentPageIndex];
        this.offset = 0;
        return true;
      } 
      this.page = null;
      return false;
    }
    
    private void setNewPages(byte[][] pages, long fromIndex) {
      assert PageUtil.indexInPage(fromIndex, 262143L) == 0;
      this.pages = pages;
      this.currentPageIndex = PageUtil.pageIndex(fromIndex, 18);
      this.toPageIndex = this.currentPageIndex + 1 - 1;
      this.page = pages[this.currentPageIndex];
      this.offset = 0;
    }
    
    private void insertPage(byte[] page) {
      if (this.prevOffset == -1) {
        this.prevOffset = this.offset;
      }
      this.page = page;
      this.offset = 0;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\AdjacencyListBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */