package org.neo4j.graphalgo.core.loading;

import java.util.Optional;
import org.neo4j.graphalgo.core.huge.AdjacencyList;
import org.neo4j.graphalgo.core.huge.AdjacencyOffsets;































public class Relationships
{
  private final long rows;
  private final long relationshipCount;
  private final AdjacencyList inAdjacency;
  private final AdjacencyList outAdjacency;
  private final AdjacencyOffsets inOffsets;
  private final AdjacencyOffsets outOffsets;
  private final Optional<Double> maybeDefaultRelProperty;
  private final AdjacencyList inRelProperties;
  private final AdjacencyList outRelProperties;
  private final AdjacencyOffsets inRelPropertyOffsets;
  private final AdjacencyOffsets outRelPropertyOffsets;
  
  public Relationships(long rows, long relationshipCount, AdjacencyList inAdjacency, AdjacencyList outAdjacency, AdjacencyOffsets inOffsets, AdjacencyOffsets outOffsets, Optional<Double> maybeDefaultRelProperty, AdjacencyList inRelProperties, AdjacencyList outRelProperties, AdjacencyOffsets inRelPropertyOffsets, AdjacencyOffsets outRelPropertyOffsets) {
    this.rows = rows;
    this.relationshipCount = relationshipCount;
    this.inAdjacency = inAdjacency;
    this.outAdjacency = outAdjacency;
    this.inOffsets = inOffsets;
    this.outOffsets = outOffsets;
    this.maybeDefaultRelProperty = maybeDefaultRelProperty;
    this.inRelProperties = inRelProperties;
    this.outRelProperties = outRelProperties;
    this.inRelPropertyOffsets = inRelPropertyOffsets;
    this.outRelPropertyOffsets = outRelPropertyOffsets;
  }

  
  public long rows() { return this.rows; }

  
  public long relationshipCount() { return this.relationshipCount; }
  
  public AdjacencyList inAdjacency() { return this.inAdjacency; }
  
  public AdjacencyList outAdjacency() { return this.outAdjacency; }
  
  public AdjacencyOffsets inOffsets() { return this.inOffsets; }
  
  public AdjacencyOffsets outOffsets() { return this.outOffsets; }
  
  public Optional<Double> maybeDefaultRelProperty() { return this.maybeDefaultRelProperty; }
  
  public AdjacencyList inRelProperties() { return this.inRelProperties; }
  
  public AdjacencyList outRelProperties() { return this.outRelProperties; }
  
  public AdjacencyOffsets inRelPropertyOffsets() { return this.inRelPropertyOffsets; }
  
  public AdjacencyOffsets outRelPropertyOffsets() { return this.outRelPropertyOffsets; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\Relationships.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */