package org.neo4j.graphalgo.core.loading;

import java.util.Arrays;
import org.apache.lucene.util.ArrayUtil;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;



























final class CompressedLongArray
{
  private static final byte[] EMPTY_BYTES = new byte[0];
  
  private final AllocationTracker tracker;
  
  private byte[] storage;
  private long[][] weights;
  private int pos;
  private long lastValue;
  private int length;
  
  CompressedLongArray(AllocationTracker tracker) { this(tracker, 0); }

  
  CompressedLongArray(AllocationTracker tracker, int numberOfProperties) {
    this.tracker = tracker;
    this.storage = EMPTY_BYTES;
    this.weights = new long[numberOfProperties][0];
  }







  
  void add(long[] values, int start, int end) {
    long currentLastValue = this.lastValue;

    
    int requiredBytes = 0;
    for (int i = start; i < end; i++) {
      long delta = values[i] - currentLastValue;
      long compressedValue = VarLongEncoding.zigZag(delta);
      currentLastValue = values[i];
      values[i] = compressedValue;
      requiredBytes += VarLongEncoding.encodedVLongSize(compressedValue);
    } 
    ensureCapacity(this.pos, requiredBytes, this.storage);
    this.pos = VarLongEncoding.encodeVLongs(values, start, end, this.storage, this.pos);
    
    this.lastValue = currentLastValue;
    this.length += end - start;
  }








  
  void add(long[] values, long[][] allWeights, int start, int end) {
    for (int i = 0; i < allWeights.length; i++) {
      long[] weights = allWeights[i];
      addWeights(weights, start, end, i);
    } 

    
    add(values, start, end);
  }
  
  private void addWeights(long[] weights, int start, int end, int weightIndex) {
    int targetCount = end - start;
    ensureCapacity(this.length, targetCount, weightIndex);
    System.arraycopy(weights, start, this.weights[weightIndex], this.length, targetCount);
  }
  
  private void ensureCapacity(int pos, int required, byte[] storage) {
    if (storage.length <= pos + required) {
      int newLength = ArrayUtil.oversize(pos + required, 1);
      this.tracker.remove(MemoryUsage.sizeOfByteArray(storage.length));
      this.tracker.add(MemoryUsage.sizeOfByteArray(newLength));
      this.storage = Arrays.copyOf(storage, newLength);
    } 
  }
  
  private void ensureCapacity(int pos, int required, int weightIndex) {
    if ((this.weights[weightIndex]).length <= pos + required) {
      int newLength = ArrayUtil.oversize(pos + required, 8);
      this.tracker.remove(MemoryUsage.sizeOfDoubleArray((this.weights[weightIndex]).length));
      this.tracker.add(MemoryUsage.sizeOfDoubleArray(newLength));
      this.weights[weightIndex] = Arrays.copyOf(this.weights[weightIndex], newLength);
    } 
  }

  
  int length() { return this.length; }

  
  int uncompress(long[] into) {
    assert into.length >= this.length;
    return ZigZagLongDecoding.zigZagUncompress(this.storage, this.pos, into);
  }

  
  byte[] storage() { return this.storage; }


  
  long[][] weights() { return this.weights; }


  
  boolean hasWeights() { return (this.weights != null && this.weights.length != 0); }

  
  void release() {
    if (this.storage.length > 0) {
      this.tracker.remove(MemoryUsage.sizeOfByteArray(this.storage.length));
      this.tracker.remove(MemoryUsage.sizeOfDoubleArray(this.weights.length));
    } 
    this.storage = null;
    this.weights = (long[][])null;
    this.pos = 0;
    this.length = 0;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\CompressedLongArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */