package org.neo4j.graphalgo.core.loading;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Stream;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.core.huge.UnionGraph;
import org.neo4j.graphalgo.core.utils.RelationshipTypes;
import org.neo4j.helpers.collection.Iterables;






















public interface GraphsByRelationshipType
{
  static GraphsByRelationshipType of(Graph graph) { return new NoRelationshipType(graph); }

  
  static GraphsByRelationshipType of(Map<String, Map<String, Graph>> graphs) {
    if (graphs.size() == 1) {
      Map<String, ? extends Graph> byProperty = (Map<String, ? extends Graph>)Iterables.single(graphs.values());
      if (byProperty.size() == 1) {
        return of((Graph)Iterables.single(byProperty.values()));
      }
    } 
    return new MultipleRelationshipTypes(graphs);
  }

  
  default Graph getGraph(String relationshipType) { return getGraph(relationshipType, Optional.empty()); }

  
  Graph getGraph(String paramString, Optional<String> paramOptional);
  
  Graph getUnion();
  
  String getGraphType();
  
  void canRelease(boolean paramBoolean);
  
  long nodeCount();
  
  long relationshipCount();
  
  Set<String> availableRelationshipTypes();
  
  public static final class NoRelationshipType
    implements GraphsByRelationshipType
  {
    private final Graph graph;
    
    private NoRelationshipType(Graph graph) { this.graph = graph; }



    
    public Graph getGraph(String relationshipType, Optional<String> maybeRelationshipProperty) { return this.graph; }



    
    public Graph getUnion() { return this.graph; }



    
    public void canRelease(boolean canRelease) { this.graph.canRelease(canRelease); }



    
    public String getGraphType() { return this.graph.getType(); }



    
    public long nodeCount() { return this.graph.nodeCount(); }



    
    public long relationshipCount() { return this.graph.relationshipCount(); }



    
    public Set<String> availableRelationshipTypes() { return Collections.emptySet(); }
  }
  
  public static final class MultipleRelationshipTypes
    implements GraphsByRelationshipType
  {
    private final Map<String, Map<String, Graph>> graphs;
    
    private MultipleRelationshipTypes(Map<String, Map<String, Graph>> graphs) {
      this.graphs = graphs;
      forEach(g -> g.canRelease(false));
    }

    
    public Graph getGraph(String relationshipType, Optional<String> maybeRelationshipProperty) {
      Set<String> types = RelationshipTypes.parse(relationshipType);
      
      if (types.isEmpty() && !maybeRelationshipProperty.isPresent()) {
        return getUnion();
      }
      
      Collection<Graph> graphParts = new ArrayList<>();
      if (types.isEmpty()) {
        String weightProperty = maybeRelationshipProperty.get();
        for (Map<String, ? extends Graph> graphsByProperty : this.graphs.values()) {
          Graph graph = getExistingByProperty(weightProperty, graphsByProperty);
          graphParts.add(graph);
        }
      
      } else if (maybeRelationshipProperty.isPresent()) {
        String weightProperty = maybeRelationshipProperty.get();
        for (String type : types) {
          Map<String, ? extends Graph> graphsByProperty = getExistingByType(type);
          Graph graph = getExistingByProperty(weightProperty, graphsByProperty);
          graphParts.add(graph);
        } 
      } else {
        for (String type : types) {
          Map<String, ? extends Graph> graphsByProperty = getExistingByType(type);
          graphParts.addAll(graphsByProperty.values());
        } 
      } 

      
      return UnionGraph.of(graphParts);
    }

    
    public Graph getUnion() {
      Collection<Graph> graphParts = new ArrayList<>();
      forEach(graphParts::add);
      return UnionGraph.of(graphParts);
    }

    
    private Map<String, ? extends Graph> getExistingByType(String singleType) { return getExisting(singleType, "type", this.graphs); }


    
    private Graph getExistingByProperty(String property, Map<String, ? extends Graph> graphs) { return getExisting(property, "property", graphs); }

    
    private <T> T getExisting(String key, String type, Map<String, ? extends T> graphs) {
      T graph = graphs.get(key);
      if (graph == null) {
        throw new IllegalArgumentException(String.format("No graph was loaded for %s %s", new Object[] { type, key }));
      }
      return graph;
    }


    
    public void canRelease(boolean canRelease) { forEach(g -> g.canRelease(canRelease)); }



    
    public String getGraphType() { return "huge"; }


    
    public long nodeCount() {
      return this.graphs
        .values().stream()
        .flatMap(g -> g.values().stream())
        .mapToLong(IdMapping::nodeCount)
        .findFirst()
        .orElse(0L);
    }


    
    public long relationshipCount() { return this.graphs
        .values().stream()
        .mapToLong(g -> g.values().stream().mapToLong(Graph::relationshipCount).max().orElse(0L))
        .sum(); }



    
    public Set<String> availableRelationshipTypes() { return this.graphs.keySet(); }

    
    private void forEach(Consumer<? super Graph> action) {
      for (Map<String, ? extends Graph> graphsByProperty : this.graphs.values()) {
        for (Graph graph : graphsByProperty.values())
          action.accept(graph); 
      } 
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\GraphsByRelationshipType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */