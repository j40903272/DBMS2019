package org.neo4j.graphalgo.core.loading;

import java.util.Optional;
import java.util.concurrent.atomic.LongAdder;
import org.neo4j.graphalgo.PropertyMapping;
import org.neo4j.graphalgo.api.GraphSetup;
import org.neo4j.graphalgo.core.DeduplicationStrategy;
import org.neo4j.graphalgo.core.huge.AdjacencyList;
import org.neo4j.graphalgo.core.huge.AdjacencyOffsets;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.kernel.internal.GraphDatabaseAPI;























class CypherRelationshipLoader
  extends CypherRecordLoader<Relationships>
{
  private static final int SINGLE_RELATIONSHIP_WEIGHT = 1;
  private static final int NO_RELATIONSHIP_WEIGHT = 0;
  private static final int DEFAULT_WEIGHT_PROPERTY_ID = -2;
  private final IdMap idMap;
  private final RelationshipsBuilder outgoingRelationshipsBuilder;
  private final RelationshipImporter importer;
  private final RelationshipImporter.Imports imports;
  private final Optional<Double> maybeDefaultRelProperty;
  private long totalRecordsSeen;
  private long totalRelationshipsImported;
  
  CypherRelationshipLoader(IdMap idMap, GraphDatabaseAPI api, GraphSetup setup) {
    super(setup.relationshipType, idMap.nodeCount(), api, setup);
    
    DeduplicationStrategy deduplicationStrategy = (setup.deduplicationStrategy == DeduplicationStrategy.DEFAULT) ? DeduplicationStrategy.NONE : setup.deduplicationStrategy;


    
    this

      
      .outgoingRelationshipsBuilder = new RelationshipsBuilder(new DeduplicationStrategy[] { deduplicationStrategy }, setup.tracker, setup.shouldLoadRelationshipProperties() ? 1 : 0);
    
    ImportSizing importSizing = ImportSizing.of(setup.concurrency, idMap.nodeCount());
    int pageSize = importSizing.pageSize();
    int numberOfPages = importSizing.numberOfPages();
    
    this.maybeDefaultRelProperty = setup.relationshipDefaultPropertyValue;
    Double defaultRelationshipProperty = this.maybeDefaultRelProperty.orElseGet(PropertyMapping.EMPTY_PROPERTY::defaultValue);
    
    AdjacencyBuilder outBuilder = AdjacencyBuilder.compressing(this.outgoingRelationshipsBuilder, numberOfPages, pageSize, setup.tracker, new LongAdder(), new int[] { -2 }, new double[] { defaultRelationshipProperty





          
          .doubleValue() });

    
    this.idMap = idMap;
    this.importer = new RelationshipImporter(setup.tracker, outBuilder, null);
    this.imports = this.importer.imports(false, true, false, this.maybeDefaultRelProperty.isPresent());
    this.totalRecordsSeen = 0L;
    this.totalRelationshipsImported = 0L;
  }

  
  BatchLoadResult loadOneBatch(long offset, int batchSize, int bufferSize) {
    RelationshipsBatchBuffer buffer = new RelationshipsBatchBuffer(this.idMap, -1, bufferSize);


    
    RelationshipRowVisitor visitor = new RelationshipRowVisitor(buffer, this.idMap, this.maybeDefaultRelProperty, this.imports);




    
    runLoadingQuery(offset, batchSize, visitor);
    visitor.flush();
    return new BatchLoadResult(offset, visitor.rows(), -1L, visitor.relationshipCount());
  }

  
  void updateCounts(BatchLoadResult result) {
    this.totalRecordsSeen += result.rows();
    this.totalRelationshipsImported += result.count();
  }

  
  Relationships result() {
    ParallelUtil.run(this.importer.flushTasks(), this.setup.executor);
    
    AdjacencyList outAdjacencyList = this.outgoingRelationshipsBuilder.adjacency.build();
    AdjacencyOffsets outAdjacencyOffsets = this.outgoingRelationshipsBuilder.globalAdjacencyOffsets;
    AdjacencyList outWeightList = this.setup.shouldLoadRelationshipProperties() ? this.outgoingRelationshipsBuilder.weights[0].build() : null;
    AdjacencyOffsets outWeightOffsets = this.setup.shouldLoadRelationshipProperties() ? this.outgoingRelationshipsBuilder.globalWeightOffsets[0] : null;
    
    return new Relationships(this.totalRecordsSeen, this.totalRelationshipsImported, null, outAdjacencyList, null, outAdjacencyOffsets, this.setup.relationshipDefaultPropertyValue, null, outWeightList, null, outWeightOffsets);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\CypherRelationshipLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */