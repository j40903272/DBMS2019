package org.neo4j.graphalgo.core.loading;

import com.carrotsearch.hppc.ObjectLongHashMap;
import com.carrotsearch.hppc.ObjectLongMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.LongAdder;
import java.util.stream.Collectors;
import org.apache.commons.lang3.tuple.Pair;
import org.neo4j.graphalgo.RelationshipTypeMapping;
import org.neo4j.graphalgo.api.GraphSetup;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.core.GraphDimensions;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.kernel.impl.store.record.RelationshipRecord;
import org.neo4j.kernel.internal.GraphDatabaseAPI;






























final class ScanningRelationshipsImporter
  extends ScanningRecordsImporter<RelationshipRecord, ObjectLongMap<RelationshipTypeMapping>>
{
  private final GraphSetup setup;
  private final ImportProgress progress;
  private final AllocationTracker tracker;
  private final IdMapping idMap;
  private final Map<RelationshipTypeMapping, Pair<RelationshipsBuilder, RelationshipsBuilder>> allBuilders;
  private final Map<RelationshipTypeMapping, LongAdder> allRelationshipCounters;
  
  ScanningRelationshipsImporter(GraphSetup setup, GraphDatabaseAPI api, GraphDimensions dimensions, ImportProgress progress, AllocationTracker tracker, IdMapping idMap, Map<RelationshipTypeMapping, Pair<RelationshipsBuilder, RelationshipsBuilder>> allBuilders, ExecutorService threadPool, int concurrency) {
    super(RelationshipStoreScanner.RELATIONSHIP_ACCESS, "Relationship", api, dimensions, threadPool, concurrency);





    
    this.setup = setup;
    this.progress = progress;
    this.tracker = tracker;
    this.idMap = idMap;
    this.allBuilders = allBuilders;
    this.allRelationshipCounters = new HashMap<>();
  }





  
  InternalImporter.CreateScanner creator(long nodeCount, ImportSizing sizing, AbstractStorePageCacheScanner<RelationshipRecord> scanner) {
    int pageSize = sizing.pageSize();
    int numberOfPages = sizing.numberOfPages();
    
    boolean importWeights = this.dimensions.relProperties().atLeastOneExists();




    
    List<SingleTypeRelationshipImporter.Builder> importerBuilders = (List<SingleTypeRelationshipImporter.Builder>)this.allBuilders.entrySet().stream().map(entry -> createImporterBuilder(pageSize, numberOfPages, entry)).collect(Collectors.toList());
    
    for (SingleTypeRelationshipImporter.Builder importerBuilder : importerBuilders) {
      this.allRelationshipCounters.put(importerBuilder.mapping(), importerBuilder.relationshipCounter());
    }
    
    return RelationshipsScanner.of(this.api, this.setup, this.progress, this.idMap, scanner, importWeights, importerBuilders);
  }











  
  private SingleTypeRelationshipImporter.Builder createImporterBuilder(int pageSize, int numberOfPages, Map.Entry<RelationshipTypeMapping, Pair<RelationshipsBuilder, RelationshipsBuilder>> entry) {
    RelationshipTypeMapping mapping = entry.getKey();
    RelationshipsBuilder outRelationshipsBuilder = (RelationshipsBuilder)((Pair)entry.getValue()).getLeft();
    RelationshipsBuilder inRelationshipsBuilder = (RelationshipsBuilder)((Pair)entry.getValue()).getRight();
    
    int[] weightProperties = this.dimensions.relProperties().allPropertyKeyIds();
    double[] defaultWeights = this.dimensions.relProperties().allDefaultWeights();
    
    LongAdder relationshipCounter = new LongAdder();
    AdjacencyBuilder outBuilder = AdjacencyBuilder.compressing(outRelationshipsBuilder, numberOfPages, pageSize, this.tracker, relationshipCounter, weightProperties, defaultWeights);






    
    AdjacencyBuilder inBuilder = AdjacencyBuilder.compressing(inRelationshipsBuilder, numberOfPages, pageSize, this.tracker, relationshipCounter, weightProperties, defaultWeights);







    
    RelationshipImporter importer = new RelationshipImporter(this.setup.tracker, outBuilder, this.setup.loadAsUndirected ? outBuilder : inBuilder);




    
    return new SingleTypeRelationshipImporter.Builder(mapping, importer, relationshipCounter);
  }

  
  ObjectLongMap<RelationshipTypeMapping> build() {
    ObjectLongHashMap objectLongHashMap = new ObjectLongHashMap(this.allRelationshipCounters.size());
    this.allRelationshipCounters.forEach((mapping, counter) -> relationshipCounters.put(mapping, counter.sum()));
    return (ObjectLongMap<RelationshipTypeMapping>)objectLongHashMap;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\loading\ScanningRelationshipsImporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */