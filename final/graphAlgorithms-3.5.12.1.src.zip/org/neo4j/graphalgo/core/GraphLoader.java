package org.neo4j.graphalgo.core;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import org.neo4j.graphalgo.PropertyMapping;
import org.neo4j.graphalgo.PropertyMappings;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.GraphFactory;
import org.neo4j.graphalgo.api.GraphSetup;
import org.neo4j.graphalgo.core.loading.GraphLoadFactory;
import org.neo4j.graphalgo.core.utils.Pools;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphdb.Direction;
import org.neo4j.graphdb.Label;
import org.neo4j.graphdb.RelationshipType;
import org.neo4j.helpers.Exceptions;
import org.neo4j.kernel.internal.GraphDatabaseAPI;
import org.neo4j.logging.Log;
import org.neo4j.logging.NullLog;
































public class GraphLoader
{
  private static final MethodHandles.Lookup LOOKUP = MethodHandles.lookup();
  private static final MethodType CTOR_METHOD = MethodType.methodType(void.class, GraphDatabaseAPI.class, new Class[] { GraphSetup.class });



  
  private String name = null;
  private String label = null;
  private String relation = null;
  private Direction direction = Direction.BOTH;
  
  private final GraphDatabaseAPI api;
  private ExecutorService executorService;
  private final Map<String, Object> params = new HashMap<>();
  private int batchSize = 10000;
  
  private int concurrency;
  private DeduplicationStrategy deduplicationStrategy = DeduplicationStrategy.DEFAULT;
  
  private Log log = (Log)NullLog.getInstance();
  private long logMillis = -1L;
  private AllocationTracker tracker = AllocationTracker.EMPTY;
  private TerminationFlag terminationFlag = TerminationFlag.RUNNING_TRUE;
  private boolean sorted = false;
  private boolean undirected = false;
  private final PropertyMappings.Builder nodePropertyMappings = new PropertyMappings.Builder();
  private final PropertyMappings.Builder relPropertyMappings = new PropertyMappings.Builder();

  
  private boolean isLoadedGraph = false;

  
  public GraphLoader(GraphDatabaseAPI api) {
    this.api = Objects.requireNonNull(api);
    this.executorService = null;
    this.concurrency = Pools.DEFAULT_CONCURRENCY;
  }





  
  public GraphLoader(GraphDatabaseAPI api, ExecutorService executorService) {
    this.api = Objects.requireNonNull(api);
    this.executorService = Objects.requireNonNull(executorService);
    this.concurrency = Pools.DEFAULT_CONCURRENCY;
  }

  
  public GraphLoader init(Log log, String label, String relationship, ProcedureConfiguration config) { return withLog(log)
      .withName(config.getGraphName(null))
      .withOptionalLabel(label)
      .withOptionalRelationshipType(relationship)
      .withConcurrency(config.getReadConcurrency())
      .withBatchSize(config.getBatchSize())
      .withDeduplicationStrategy(config.getDeduplicationStrategy())
      .withParams(config.getParams())
      .withLoadedGraph((config.getGraphImpl() == GraphLoadFactory.class)); }




  
  public GraphLoader withLog(Log log) {
    this.log = log;
    return this;
  }





  
  public GraphLoader withLogInterval(long value, TimeUnit unit) {
    this.logMillis = unit.toMillis(value);
    return this;
  }
  
  public GraphLoader withLoadedGraph(boolean isLoadedGraph) {
    this.isLoadedGraph = isLoadedGraph;
    return this;
  }
  
  public GraphLoader sorted() {
    this.sorted = true;
    return this;
  }
  
  public GraphLoader undirected() {
    this.undirected = true;
    return this;
  }





  
  public GraphLoader withAllocationTracker(AllocationTracker tracker) {
    this.tracker = (tracker == null) ? AllocationTracker.EMPTY : tracker;
    return this;
  }





  
  public GraphLoader withTerminationFlag(TerminationFlag terminationFlag) {
    this.terminationFlag = (terminationFlag == null) ? TerminationFlag.RUNNING_TRUE : terminationFlag;
    return this;
  }



  
  public GraphLoader withExecutorService(ExecutorService executorService) {
    this.executorService = Objects.requireNonNull(executorService);
    return this;
  }



  
  public GraphLoader withConcurrency(int newConcurrency) {
    if (newConcurrency <= 0)
      throw new IllegalArgumentException(String.format("Concurrency less than one is invalid: %d", new Object[] {
              
              Integer.valueOf(newConcurrency)
            })); 
    this.concurrency = Pools.allowedConcurrency(newConcurrency);
    return this;
  }





  
  public GraphLoader withDefaultConcurrency() { return withConcurrency(Pools.DEFAULT_CONCURRENCY); }

  
  public GraphLoader withName(String name) {
    this.name = name;
    return this;
  }





  
  public GraphLoader withLabel(String label) {
    this.label = Objects.requireNonNull(label);
    return this;
  }





  
  public GraphLoader withOptionalLabel(String label) {
    this.label = label;
    return this;
  }





  
  public GraphLoader withLabel(Label label) {
    this.label = ((Label)Objects.requireNonNull(label)).name();
    return this;
  }



  
  public GraphLoader withAnyLabel() {
    this.label = null;
    return this;
  }





  
  public GraphLoader withRelationshipType(String relationshipType) {
    this.relation = Objects.requireNonNull(relationshipType);
    return this;
  }






  
  public GraphLoader withOptionalRelationshipType(String relationshipType) {
    this.relation = relationshipType;
    return this;
  }





  
  public GraphLoader withRelationshipType(RelationshipType relationshipType) {
    this.relation = ((RelationshipType)Objects.requireNonNull(relationshipType)).name();
    return this;
  }



  
  public GraphLoader withAnyRelationshipType() {
    this.relation = null;
    return this;
  }



  
  public GraphLoader withDirection(Direction direction) {
    this.direction = direction;
    return this;
  }
  
  public GraphLoader withOptionalNodeProperties(PropertyMapping... nodePropertyMappings) {
    this.nodePropertyMappings.addAllOptionalMappings(nodePropertyMappings);
    return this;
  }
  
  public GraphLoader withOptionalNodeProperties(PropertyMappings nodePropertyMappings) {
    this.nodePropertyMappings.addAllOptionalMappings(nodePropertyMappings.stream());
    return this;
  }
  
  public GraphLoader withRelationshipProperties(PropertyMapping... relPropertyMappings) {
    this.relPropertyMappings.addAllMappings(relPropertyMappings);
    return this;
  }
  
  public GraphLoader withRelationshipProperties(PropertyMappings relPropertyMappings) {
    this.relPropertyMappings.addAllMappings(relPropertyMappings.stream());
    return this;
  }









  
  public GraphLoader withReducedRelationshipLoading(Direction direction) {
    if (direction == Direction.BOTH && !this.isLoadedGraph) {
      return undirected().withDirection(Direction.OUTGOING);
    }
    return withDirection(direction);
  }

  
  public GraphLoader withParams(Map<String, Object> params) {
    this.params.putAll(params);
    return this;
  }





  
  public GraphLoader withNodeStatement(String nodeStatement) {
    this.label = nodeStatement;
    return this;
  }





  
  public GraphLoader withRelationshipStatement(String relationshipStatement) {
    this.relation = relationshipStatement;
    return this;
  }





  
  public GraphLoader withBatchSize(int batchSize) {
    this.batchSize = batchSize;
    return this;
  }







  
  public GraphLoader withDeduplicationStrategy(DeduplicationStrategy deduplicationStrategy) {
    this.deduplicationStrategy = deduplicationStrategy;
    return this;
  }



  
  public final <T extends GraphFactory> T build(Class<T> factoryType) {
    MethodHandle constructor = findConstructor(factoryType);
    return factoryType.cast(invokeConstructor(constructor));
  }










  
  public Graph load(Class<? extends GraphFactory> factoryType) { return build(factoryType).build(); }







  
  public MemoryEstimation memoryEstimation(Class<? extends GraphFactory> factoryType) { return build(factoryType).memoryEstimation(); }

  
  private MethodHandle findConstructor(Class<?> factoryType) {
    try {
      return LOOKUP.findConstructor(factoryType, CTOR_METHOD);
    } catch (NoSuchMethodException|IllegalAccessException e) {
      throw new RuntimeException(e);
    } 
  }

  
  private GraphFactory invokeConstructor(MethodHandle constructor) {
    GraphSetup setup = toSetup();
    
    try {
      return constructor.invoke(this.api, setup);
    } catch (Throwable throwable) {
      throw Exceptions.launderedException(throwable
          .getMessage(), throwable);
    } 
  }

  
  public GraphSetup toSetup() {
    PropertyMappings relMappings = this.relPropertyMappings.build();
    if (this.deduplicationStrategy != DeduplicationStrategy.DEFAULT)
    {
      
      relMappings = (new PropertyMappings.Builder()).addAllMappings(relMappings.stream().map(p -> p.withDeduplicationStrategy(this.deduplicationStrategy))).build();
    }
    
    return new GraphSetup(this.label, null, this.relation, this.direction, this.params, this.executorService, this.concurrency, this.batchSize, this.deduplicationStrategy, this.log, this.logMillis, this.sorted, this.undirected, this.tracker, this.terminationFlag, this.name, this.nodePropertyMappings















        
        .build(), relMappings);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\GraphLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */