package org.neo4j.graphalgo.core.huge;

























final class VarLongDecoding
{
  static int decodeDeltaVLongs(long startValue, byte[] adjacencyPage, int offset, int limit, long[] out) {
    long value = 0L;
    int into = 0, shift = 0;
    while (into < limit) {
      long input = adjacencyPage[offset++];
      value += (input & 0x7FL) << shift;
      if ((input & 0x80L) == 128L) {
        startValue += value;
        out[into++] = startValue;
        value = 0L;
        shift = 0; continue;
      } 
      shift += 7;
    } 

    
    return offset;
  }

  
  private VarLongDecoding() { throw new UnsupportedOperationException("No instances"); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\huge\VarLongDecoding.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */