package org.neo4j.graphalgo.core.huge;

import org.neo4j.graphalgo.api.IntersectionConsumer;
import org.neo4j.graphalgo.api.RelationshipConsumer;
import org.neo4j.graphalgo.api.RelationshipIntersect;

























class HugeGraphIntersectImpl
  implements RelationshipIntersect
{
  private AdjacencyList adjacency;
  private AdjacencyOffsets offsets;
  private AdjacencyList.DecompressingCursor empty;
  private AdjacencyList.DecompressingCursor cache;
  private AdjacencyList.DecompressingCursor cacheA;
  private AdjacencyList.DecompressingCursor cacheB;
  
  HugeGraphIntersectImpl(AdjacencyList adjacency, AdjacencyOffsets offsets) {
    assert adjacency != null;
    assert offsets != null;
    this.adjacency = adjacency;
    this.offsets = offsets;
    this.cache = adjacency.rawDecompressingCursor();
    this.cacheA = adjacency.rawDecompressingCursor();
    this.cacheB = adjacency.rawDecompressingCursor();
    this.empty = adjacency.rawDecompressingCursor();
  }

  
  public void intersectAll(long nodeIdA, IntersectionConsumer consumer) {
    AdjacencyOffsets offsets = this.offsets;
    AdjacencyList adjacency = this.adjacency;
    
    AdjacencyList.DecompressingCursor mainDecompressingCursor = cursor(nodeIdA, this.cache, offsets, adjacency);
    long nodeIdB = mainDecompressingCursor.skipUntil(nodeIdA);
    if (nodeIdB <= nodeIdA) {
      return;
    }
    
    AdjacencyList.DecompressingCursor decompressingCursorA = this.cacheA, decompressingCursorB = this.cacheB;
    
    boolean hasNext = true;
    
    while (hasNext) {
      decompressingCursorB = cursor(nodeIdB, decompressingCursorB, offsets, adjacency);
      long nodeIdC = decompressingCursorB.skipUntil(nodeIdB);
      if (nodeIdC > nodeIdB) {
        AdjacencyList.DecompressingCursor follow, lead; decompressingCursorA.copyFrom(mainDecompressingCursor);
        long currentA = decompressingCursorA.advance(nodeIdC);
        
        if (currentA == nodeIdC) {
          consumer.accept(nodeIdA, nodeIdB, nodeIdC);
        }
        
        if (decompressingCursorA.remaining() <= decompressingCursorB.remaining()) {
          lead = decompressingCursorA;
          follow = decompressingCursorB;
        } else {
          lead = decompressingCursorB;
          follow = decompressingCursorA;
        } 
        
        while (lead.hasNextVLong() && follow.hasNextVLong()) {
          long s = lead.nextVLong();
          long t = follow.advance(s);
          if (t == s) {
            consumer.accept(nodeIdA, nodeIdB, s);
          }
        } 
      } 
      
      if (hasNext = mainDecompressingCursor.hasNextVLong()) {
        nodeIdB = mainDecompressingCursor.nextVLong();
      }
    } 
  }
  
  private int degree(long node, AdjacencyOffsets offsets, AdjacencyList array) {
    long offset = offsets.get(node);
    if (offset == 0L) {
      return 0;
    }
    return array.getDegree(offset);
  }




  
  private AdjacencyList.DecompressingCursor cursor(long node, AdjacencyList.DecompressingCursor reuse, AdjacencyOffsets offsets, AdjacencyList array) {
    long offset = offsets.get(node);
    if (offset == 0L) {
      return this.empty;
    }
    return array.decompressingCursor(reuse, offset);
  }




  
  private void consumeNodes(long startNode, AdjacencyList.DecompressingCursor decompressingCursor, RelationshipConsumer consumer) {
    while (decompressingCursor.hasNextVLong() && consumer.accept(startNode, decompressingCursor.nextVLong()));
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\huge\HugeGraphIntersectImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */