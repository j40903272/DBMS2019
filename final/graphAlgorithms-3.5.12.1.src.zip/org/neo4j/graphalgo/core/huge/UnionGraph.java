package org.neo4j.graphalgo.core.huge;

import java.util.Collection;
import java.util.Set;
import java.util.function.LongPredicate;
import java.util.stream.Collectors;
import org.neo4j.collection.primitive.PrimitiveLongIterable;
import org.neo4j.collection.primitive.PrimitiveLongIterator;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.api.RelationshipConsumer;
import org.neo4j.graphalgo.api.RelationshipIntersect;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.api.RelationshipWithPropertyConsumer;
import org.neo4j.graphdb.Direction;
import org.neo4j.helpers.collection.Iterables;



















public final class UnionGraph
  implements Graph
{
  private final Graph first;
  private final Collection<? extends Graph> graphs;
  
  public static Graph of(Collection<? extends Graph> graphs) {
    if (graphs.isEmpty()) {
      throw new IllegalArgumentException("no graphs");
    }
    if (graphs.size() == 1) {
      return (Graph)Iterables.single(graphs);
    }
    return new UnionGraph(graphs);
  }
  
  private UnionGraph(Collection<? extends Graph> graphs) {
    this.first = (Graph)Iterables.first(graphs);
    this.graphs = graphs;
  }


  
  public long nodeCount() { return this.first.nodeCount(); }



  
  public long relationshipCount() { return this.graphs.stream().mapToLong(Graph::relationshipCount).sum(); }



  
  public Collection<PrimitiveLongIterable> batchIterables(int batchSize) { return this.first.batchIterables(batchSize); }



  
  public void forEachNode(LongPredicate consumer) { this.first.forEachNode(consumer); }



  
  public PrimitiveLongIterator nodeIterator() { return this.first.nodeIterator(); }



  
  public NodeProperties nodeProperties(String type) { return this.first.nodeProperties(type); }



  
  public Set<String> availableNodeProperties() { return this.first.availableNodeProperties(); }



  
  public long toMappedNodeId(long nodeId) { return this.first.toMappedNodeId(nodeId); }



  
  public long toOriginalNodeId(long nodeId) { return this.first.toOriginalNodeId(nodeId); }



  
  public boolean contains(long nodeId) { return this.first.contains(nodeId); }



  
  public double relationshipProperty(long sourceNodeId, long targetNodeId, double fallbackValue) { return this.first.relationshipProperty(sourceNodeId, targetNodeId, fallbackValue); }



  
  public double relationshipProperty(long sourceNodeId, long targetNodeId) { return this.first.relationshipProperty(sourceNodeId, targetNodeId); }


  
  public void forEachRelationship(long nodeId, Direction direction, RelationshipConsumer consumer) {
    for (Graph graph : this.graphs) {
      graph.forEachRelationship(nodeId, direction, consumer);
    }
  }





  
  public void forEachRelationship(long nodeId, Direction direction, double fallbackValue, RelationshipWithPropertyConsumer consumer) {
    for (Graph graph : this.graphs) {
      graph.forEachRelationship(nodeId, direction, fallbackValue, consumer);
    }
  }


  
  public int degree(long node, Direction direction) { return Math.toIntExact(this.graphs.stream().mapToLong(g -> g.degree(node, direction)).sum()); }


  
  public void forEachIncoming(long node, RelationshipConsumer consumer) {
    for (Graph graph : this.graphs) {
      graph.forEachIncoming(node, consumer);
    }
  }

  
  public void forEachOutgoing(long node, RelationshipConsumer consumer) {
    for (Graph graph : this.graphs) {
      graph.forEachOutgoing(node, consumer);
    }
  }


  
  public Graph concurrentCopy() { return of((Collection<? extends Graph>)this.graphs.stream().map(graph -> (Graph)graph.concurrentCopy()).collect(Collectors.toList())); }



  
  public RelationshipIntersect intersection() { throw new UnsupportedOperationException("#intersection is not supported for multiple relationship types"); }






  
  public boolean exists(long sourceNodeId, long targetNodeId, Direction direction) { return this.graphs.stream().anyMatch(g -> g.exists(sourceNodeId, targetNodeId, direction)); }





  
  public long getTarget(long sourceNodeId, long index, Direction direction) {
    return this.graphs.stream()
      .mapToLong(g -> g.getTarget(sourceNodeId, index, direction))
      .filter(t -> (t != -1L))
      .findFirst()
      .orElse(-1L);
  }

  
  public void canRelease(boolean canRelease) {
    for (Graph graph : this.graphs) {
      graph.canRelease(canRelease);
    }
  }

  
  public void releaseTopology() {
    for (Graph graph : this.graphs) {
      graph.releaseProperties();
    }
  }

  
  public void releaseProperties() {
    for (Graph graph : this.graphs) {
      graph.releaseProperties();
    }
  }


  
  public Direction getLoadDirection() { return this.first.getLoadDirection(); }



  
  public boolean hasRelationshipProperty() { return this.first.hasRelationshipProperty(); }



  
  public boolean isUndirected() { return this.first.isUndirected(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\huge\UnionGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */