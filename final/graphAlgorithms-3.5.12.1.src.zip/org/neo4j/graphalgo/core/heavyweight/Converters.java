package org.neo4j.graphalgo.core.heavyweight;

import java.util.function.IntConsumer;
import java.util.function.IntPredicate;
import java.util.function.LongConsumer;
import java.util.function.LongPredicate;
import org.neo4j.graphalgo.api.IntBinaryPredicate;
import org.neo4j.graphalgo.api.RelationshipConsumer;
import org.neo4j.graphalgo.api.RelationshipWithPropertyConsumer;


























public interface Converters
{
  static LongPredicate longToIntPredicate(IntPredicate p) {
    return value -> {
        
        int downCast = Math.toIntExact(value);
        return p.test(downCast);
      };
  }
  
  static LongConsumer longToIntConsumer(IntConsumer p) {
    return value -> {
        
        int downCast = Math.toIntExact(value);
        p.accept(downCast);
      };
  }
  
  static RelationshipConsumer longToIntConsumer(IntBinaryPredicate p) {
    return (sourceNodeId, targetNodeId) -> {
        int s = Math.toIntExact(sourceNodeId);
        int t = Math.toIntExact(targetNodeId);
        return p.test(s, t);
      };
  }
  
  static RelationshipWithPropertyConsumer longToIntConsumer(IntIntDoublePredicate p) {
    return (sourceNodeId, targetNodeId, property) -> {
        int s = Math.toIntExact(sourceNodeId);
        int t = Math.toIntExact(targetNodeId);
        return p.test(s, t, property);
      };
  }
  
  @FunctionalInterface
  public static interface IntIntDoublePredicate {
    boolean test(int param1Int1, int param1Int2, double param1Double);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\heavyweight\Converters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */