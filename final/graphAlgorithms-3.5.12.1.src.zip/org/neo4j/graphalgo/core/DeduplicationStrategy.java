package org.neo4j.graphalgo.core;

import java.util.Arrays;
import java.util.stream.Collectors;



















public enum DeduplicationStrategy
{
  DEFAULT,





  
  NONE,





  
  SKIP,



  
  SUM,



  
  MIN,



  
  MAX;






  
  public static DeduplicationStrategy lookup(String name) {
    DeduplicationStrategy deduplicationStrategy = null;
    try {
      deduplicationStrategy = valueOf(name);
    } catch (IllegalArgumentException e) {


      
      String availableStrategies = Arrays.stream(values()).map(Enum::name).collect(Collectors.joining(", "));
      throw new IllegalArgumentException(String.format("Deduplication strategy `%s` is not supported. Must be one of: %s.", new Object[] { name, availableStrategies }));
    } 


    
    return deduplicationStrategy;
  }
  
  public abstract double merge(double paramDouble1, double paramDouble2);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\DeduplicationStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */