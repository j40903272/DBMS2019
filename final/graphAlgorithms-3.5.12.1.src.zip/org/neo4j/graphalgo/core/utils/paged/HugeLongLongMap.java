package org.neo4j.graphalgo.core.utils.paged;

import com.carrotsearch.hppc.BitMixer;
import com.carrotsearch.hppc.cursors.LongLongCursor;
import java.util.Iterator;
import java.util.NoSuchElementException;
import org.neo4j.graphalgo.core.utils.BitUtil;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;

























public final class HugeLongLongMap
  implements Iterable<LongLongCursor>
{
  private static final MemoryEstimation MEMORY_REQUIREMENTS = MemoryEstimations.builder(HugeLongLongMap.class)
    .field("keysCursor", HugeCursor.class)
    .field("entries", EntryIterator.class)
    .perNode("keys", HugeLongArray::memoryEstimation)
    .perNode("values", HugeLongArray::memoryEstimation)
    .build();
  
  private final AllocationTracker tracker;
  
  private HugeLongArray keys;
  
  private HugeLongArray values;
  
  private HugeCursor<long[]> keysCursor;
  private EntryIterator entries;
  private long assigned;
  private long mask;
  private long resizeAt;
  private static final long DEFAULT_EXPECTED_ELEMENTS = 4L;
  private static final double LOAD_FACTOR = 0.75D;
  private static final int MIN_HASH_ARRAY_LENGTH = 4;
  
  public static MemoryEstimation memoryEstimation() { return MEMORY_REQUIREMENTS; }





  
  public HugeLongLongMap(AllocationTracker tracker) { this(4L, tracker); }




  
  public HugeLongLongMap(long expectedElements, AllocationTracker tracker) {
    this.tracker = tracker;
    initialBuffers(expectedElements);
  }

  
  public long sizeOf() { return this.keys.sizeOf() + this.values.sizeOf(); }


  
  public void addTo(long key, long value) { addTo0(1L + key, value); }


  
  public long getOrDefault(long key, long defaultValue) { return getOrDefault0(1L + key, defaultValue); }

  
  private void addTo0(long key, long value) {
    assert this.assigned < this.mask + 1L;
    long hash = BitMixer.mixPhi(key);
    long slot = findSlot(key, hash & this.mask);
    assert slot != -1L;
    if (slot >= 0L) {
      this.values.addTo(slot, value);
      
      return;
    } 
    slot = 1L + slot ^ 0xFFFFFFFFFFFFFFFFL;
    if (this.assigned == this.resizeAt) {
      allocateThenInsertThenRehash(slot, key, value);
    } else {
      this.values.set(slot, value);
      this.keys.set(slot, key);
    } 
    
    this.assigned++;
  }
  
  private long getOrDefault0(long key, long defaultValue) {
    long hash = BitMixer.mixPhi(key);
    long slot = findSlot(key, hash & this.mask);
    if (slot >= 0L) {
      return this.values.get(slot);
    }
    
    return defaultValue;
  }


  
  private long findSlot(long key, long start) {
    HugeLongArray keys = this.keys;
    HugeCursor<long[]> cursor = this.keysCursor;
    long slot = findSlot(key, start, keys.size(), keys, cursor);
    if (slot == -1L) {
      slot = findSlot(key, 0L, start, keys, cursor);
    }
    return slot;
  }






  
  private long findSlot(long key, long start, long end, HugeLongArray keys, HugeCursor<long[]> cursor) {
    long slot = start;


    
    keys.initCursor((HugeCursor)cursor, start, end);
    while (cursor.next()) {
      long[] keysBlock = (long[])cursor.array;
      int blockPos = cursor.offset;
      int blockEnd = cursor.limit;
      while (blockPos < blockEnd) {
        long existing = keysBlock[blockPos];
        if (existing == key) {
          return slot;
        }
        if (existing == 0L) {
          return (slot ^ 0xFFFFFFFFFFFFFFFFL) - 1L;
        }
        blockPos++;
        slot++;
      } 
    } 
    return -1L;
  }

  
  public long size() { return this.assigned; }


  
  public boolean isEmpty() { return (size() == 0L); }

  
  public void release() {
    long released = 0L;
    released += this.keys.release();
    released += this.values.release();
    this.tracker.remove(released);
    
    this.keys = null;
    this.values = null;
    this.assigned = 0L;
    this.mask = 0L;
  }

  
  private void initialBuffers(long expectedElements) { allocateBuffers(minBufferSize(expectedElements), this.tracker); }



  
  public Iterator<LongLongCursor> iterator() { return this.entries.reset(); }





  
  public String toString() {
    StringBuilder buffer = new StringBuilder();
    buffer.append('[');
    
    for (LongLongCursor cursor : this) {
      buffer
        .append(cursor.key)
        .append("=>")
        .append(cursor.value)
        .append(", ");
    }
    
    if (buffer.length() > 1) {
      buffer.setLength(buffer.length() - 1);
      buffer.setCharAt(buffer.length() - 1, ']');
    } else {
      buffer.append(']');
    } 
    
    return buffer.toString();
  }




  
  private void allocateBuffers(long arraySize, AllocationTracker tracker) {
    assert BitUtil.isPowerOfTwo(arraySize);

    
    HugeLongArray prevKeys = this.keys;
    HugeLongArray prevValues = this.values;
    try {
      this.keys = HugeLongArray.newArray(arraySize, tracker);
      this.values = HugeLongArray.newArray(arraySize, tracker);
      this.keysCursor = this.keys.newCursor();
      this.entries = new EntryIterator();
    } catch (OutOfMemoryError e) {
      this.keys = prevKeys;
      this.values = prevValues;
      throw e;
    } 
    
    this.resizeAt = expandAtCount(arraySize);
    this.mask = arraySize - 1L;
  }





  
  private void rehash(HugeLongArray fromKeys, HugeLongArray fromValues) {
    assert fromKeys.size() == fromValues.size() && 
      BitUtil.isPowerOfTwo(fromValues.size());

    
    HugeLongArray newKeys = this.keys;
    HugeLongArray newValues = this.values;
    long mask = this.mask;
    
    try (EntryIterator fromEntries = new EntryIterator(fromKeys, fromValues)) {
      for (LongLongCursor cursor : fromEntries) {
        long key = cursor.key + 1L;
        long slot = BitMixer.mixPhi(key) & mask;
        slot = findSlot(key, slot);
        slot = 1L + slot ^ 0xFFFFFFFFFFFFFFFFL;
        newKeys.set(slot, key);
        newValues.set(slot, cursor.value);
      } 
    } 
  }









  
  private void allocateThenInsertThenRehash(long slot, long pendingKey, long pendingValue) {
    assert this.assigned == this.resizeAt;

    
    HugeLongArray prevKeys = this.keys;
    HugeLongArray prevValues = this.values;
    allocateBuffers(nextBufferSize(this.mask + 1L), this.tracker);
    assert this.keys.size() > prevKeys.size();


    
    prevKeys.set(slot, pendingKey);
    prevValues.set(slot, pendingValue);

    
    rehash(prevKeys, prevValues);
    
    long released = 0L;
    released += prevKeys.release();
    released += prevValues.release();
    this.tracker.remove(released);
  }



  
  private static long minBufferSize(long elements) {
    if (elements < 0L) {
      throw new IllegalArgumentException("Number of elements must be >= 0: " + elements);
    }

    
    long length = (long)Math.ceil(elements / 0.75D);
    if (length == elements) {
      length++;
    }
    length = Math.max(4L, BitUtil.nextHighestPowerOfTwo(length));
    return length;
  }
  
  private static long nextBufferSize(long arraySize) {
    assert BitUtil.isPowerOfTwo(arraySize);
    return arraySize << 1L;
  }
  
  private static long expandAtCount(long arraySize) {
    assert BitUtil.isPowerOfTwo(arraySize);
    return Math.min(arraySize, (long)Math.ceil(arraySize * 0.75D));
  }
  
  private final class EntryIterator implements AutoCloseable, Iterable<LongLongCursor>, Iterator<LongLongCursor> {
    private HugeCursor<long[]> keyCursor;
    private HugeCursor<long[]> valueCursor;
    private boolean nextFetched = false;
    private boolean hasNext = false;
    private LongLongCursor cursor;
    private int pos = 0; private int end = 0;
    private long[] ks;
    private long[] vs;
    
    EntryIterator() { this(HugeLongLongMap.this.keys, HugeLongLongMap.this.values); }

    
    EntryIterator(HugeLongArray keys, HugeLongArray values) {
      this.keyCursor = (HugeCursor)keys.initCursor((HugeCursor)keys.newCursor());
      this.valueCursor = (HugeCursor)values.initCursor((HugeCursor)values.newCursor());
      this.cursor = new LongLongCursor();
    }

    
    EntryIterator reset() { return reset(HugeLongLongMap.this.keys, HugeLongLongMap.this.values); }

    
    EntryIterator reset(HugeLongArray keys, HugeLongArray values) {
      this.keyCursor = (HugeCursor)keys.initCursor((HugeCursor)this.keyCursor);
      this.valueCursor = (HugeCursor)values.initCursor((HugeCursor)this.valueCursor);
      this.pos = 0;
      this.end = 0;
      this.hasNext = false;
      this.nextFetched = false;
      return this;
    }

    
    public boolean hasNext() {
      if (!this.nextFetched) {
        this.nextFetched = true;
        return this.hasNext = fetchNext();
      } 
      return this.hasNext;
    }

    
    public LongLongCursor next() {
      if (!hasNext()) {
        throw new NoSuchElementException();
      }
      this.nextFetched = false;
      return this.cursor;
    }

    
    private boolean fetchNext() {
      do {
        while (this.pos < this.end) {
          long key; if ((key = this.ks[this.pos]) != 0L) {
            this.cursor.index = this.pos;
            this.cursor.key = key - 1L;
            this.cursor.value = this.vs[this.pos];
            this.pos++;
            return true;
          } 
          this.pos++;
        } 
      } while (nextPage());
      return false;
    }

    
    private boolean nextPage() { return nextPage(this.keyCursor, this.valueCursor); }



    
    private boolean nextPage(HugeCursor<long[]> keys, HugeCursor<long[]> values) {
      boolean valuesHasNext = values.next();
      if (!keys.next()) {
        assert !valuesHasNext;
        return false;
      } 
      assert valuesHasNext;
      this.ks = (long[])keys.array;
      this.pos = keys.offset;
      this.end = keys.limit;
      this.vs = (long[])values.array;
      assert this.pos == values.offset;
      assert this.end == values.limit;
      
      return true;
    }


    
    public Iterator<LongLongCursor> iterator() { return this; }


    
    public void close() {
      this.keyCursor.close();
      this.keyCursor = null;
      this.valueCursor.close();
      this.valueCursor = null;
      this.cursor = null;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\HugeLongLongMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */