package org.neo4j.graphalgo.core.utils.paged;

import org.neo4j.graphalgo.core.utils.BitUtil;





















public final class PageUtil
{
  private static final int PAGE_SIZE_IN_BYTES = 32768;
  
  public static int pageSizeFor(int sizeOfElement) {
    assert BitUtil.isPowerOfTwo(sizeOfElement);
    return 32768 >> Integer.numberOfTrailingZeros(sizeOfElement);
  }
  
  public static int numPagesFor(long capacity, int pageSize) {
    int pageShift = Integer.numberOfTrailingZeros(pageSize);
    int pageMask = pageSize - 1;
    return numPagesFor(capacity, pageShift, pageMask);
  }
  
  public static int numPagesFor(long capacity, int pageShift, long pageMask) {
    long numPages = capacity + pageMask >>> pageShift;
    assert numPages <= 2147483647L : "pageSize=" + (pageMask + 1L) + " is too small for such as capacity: " + capacity;
    return (int)numPages;
  }

  
  public static long capacityFor(int numPages, int pageShift) { return numPages << pageShift; }


  
  public static int pageIndex(long index, int pageShift) { return (int)(index >>> pageShift); }


  
  public static int indexInPage(long index, int pageMask) { return (int)(index & pageMask); }


  
  public static int indexInPage(long index, long pageMask) { return (int)(index & pageMask); }


  
  private PageUtil() { throw new UnsupportedOperationException("No instances"); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\PageUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */