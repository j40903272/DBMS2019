package org.neo4j.graphalgo.core.utils.paged.dss;

import org.neo4j.graphalgo.core.utils.paged.HugeCursor;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;


























@Deprecated
public abstract class SequentialDisjointSetStruct
  implements DisjointSetStruct
{
  public void union(long p, long q) {
    long pRoot = findAndBalance(p);
    long qRoot = findAndBalance(q);
    
    long pSet = setIdOfRoot(pRoot);
    long qSet = setIdOfRoot(qRoot);
    
    if (pSet < qSet) {
      parent().set(qRoot, pRoot);
    } else if (qSet < pSet) {
      parent().set(pRoot, qRoot);
    } 
  }








  
  public abstract long find(long paramLong);








  
  public final long findAndBalance(long p) {
    long pv = parent().get(p);
    if (pv == -1L) {
      return p;
    }
    
    long value = findAndBalance(pv);
    parent().set(p, value);
    return value;
  }


  
  public final boolean sameSet(long p, long q) { return (find(p) == find(q)); }







  
  public SequentialDisjointSetStruct merge(SequentialDisjointSetStruct other) {
    if (!getClass().equals(other.getClass())) {
      throw new IllegalArgumentException(String.format("Cannot merge DisjointSetStructs of different types: %s and %s.", new Object[] {
              
              getClass().getSimpleName(), other
              .getClass().getSimpleName()
            }));
    }
    if (other.size() != size()) {
      throw new IllegalArgumentException(String.format("Cannot merge DisjointSetStructs with different sizes: %d and %d.", new Object[] {
              
              Long.valueOf(other.size()), 
              Long.valueOf(size())
            }));
    }
    HugeCursor<long[]> others = other.parent().initCursor(other.parent().newCursor());
    long nodeId = 0L;
    while (others.next()) {
      long[] parentPage = (long[])others.array;
      int offset = others.offset;
      int limit = others.limit;
      while (offset < limit) {
        
        if (parentPage[offset] != -1L) {
          union(nodeId, other.findAndBalance(nodeId));
        }
        offset++;
        nodeId++;
      } 
    } 
    
    return this;
  }
  
  abstract long setIdOfRoot(long paramLong);
  
  abstract HugeLongArray parent();
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\dss\SequentialDisjointSetStruct.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */