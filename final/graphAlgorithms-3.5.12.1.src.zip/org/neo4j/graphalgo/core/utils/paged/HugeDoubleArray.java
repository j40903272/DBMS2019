package org.neo4j.graphalgo.core.utils.paged;

import java.util.Arrays;
import java.util.function.LongFunction;
import java.util.function.LongToDoubleFunction;
import java.util.stream.DoubleStream;
import org.neo4j.graphalgo.core.utils.ArrayUtil;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
import org.neo4j.graphalgo.core.write.PropertyTranslator;































































































































public abstract class HugeDoubleArray
  extends HugeArray<double[], Double, HugeDoubleArray>
{
  public final HugeDoubleArray copyOf(long newLength, AllocationTracker tracker) {
    HugeDoubleArray copy = newArray(newLength, tracker);
    copyTo(copy, newLength);
    return copy;
  }





  
  final Double boxedGet(long index) { return Double.valueOf(get(index)); }






  
  final void boxedSet(long index, Double value) { set(index, value.doubleValue()); }






  
  final void boxedSetAll(LongFunction<Double> gen) { setAll(gen::apply); }






  
  final void boxedFill(Double value) { fill(value.doubleValue()); }






  
  public double[] toArray() { return dumpToArray((Class)double[].class); }




  
  public static HugeDoubleArray newArray(long size, AllocationTracker tracker)
  {
    if (size <= ArrayUtil.MAX_ARRAY_LENGTH) {
      return 
















































        
        SingleHugeDoubleArray.of(size, tracker);
    }




















































































































    
    return PagedHugeDoubleArray.of(size, tracker); } public static long memoryEstimation(long size) { assert size >= 0L; if (size <= ArrayUtil.MAX_ARRAY_LENGTH) return MemoryUsage.sizeOfInstance(SingleHugeDoubleArray.class) + MemoryUsage.sizeOfDoubleArray((int)size);  long sizeOfInstance = MemoryUsage.sizeOfInstance(PagedHugeDoubleArray.class); int numPages = HugeArrays.numberOfPages(size); long memoryUsed = MemoryUsage.sizeOfObjectArray(numPages); long pageBytes = MemoryUsage.sizeOfDoubleArray(16384); memoryUsed += (numPages - 1) * pageBytes; int lastPageSize = HugeArrays.exclusiveIndexOfPage(size); return sizeOfInstance + memoryUsed + MemoryUsage.sizeOfDoubleArray(lastPageSize); } public static HugeDoubleArray of(double... values) { return new SingleHugeDoubleArray(values.length, values); } static HugeDoubleArray newSingleArray(int size, AllocationTracker tracker) { return SingleHugeDoubleArray.of(size, tracker); } public abstract double get(long paramLong); public abstract void set(long paramLong, double paramDouble); public abstract void addTo(long paramLong, double paramDouble); public abstract void setAll(LongToDoubleFunction paramLongToDoubleFunction); public abstract void fill(double paramDouble); public abstract long size(); static HugeDoubleArray newPagedArray(long size, AllocationTracker tracker) { return PagedHugeDoubleArray.of(size, tracker); } public abstract long sizeOf(); public abstract long release(); public abstract HugeCursor<double[]> newCursor(); public abstract DoubleStream stream(); public abstract void copyTo(HugeDoubleArray paramHugeDoubleArray, long paramLong); public static class Translator implements PropertyTranslator.OfDouble<HugeDoubleArray> {
    public static final Translator INSTANCE = new Translator(); public double toDouble(HugeDoubleArray data, long nodeId) { return data.get(nodeId); } } private static final class SingleHugeDoubleArray extends HugeDoubleArray {
    private final int size; private double[] page; private static HugeDoubleArray of(long size, AllocationTracker tracker) { assert size <= ArrayUtil.MAX_ARRAY_LENGTH; int intSize = (int)size; double[] page = new double[intSize]; tracker.add(MemoryUsage.sizeOfDoubleArray(intSize)); return new SingleHugeDoubleArray(intSize, page); } private SingleHugeDoubleArray(int size, double[] page) { this.size = size; this.page = page; } public double get(long index) { assert index < this.size; return this.page[(int)index]; } public void set(long index, double value) { assert index < this.size; this.page[(int)index] = value; } public void addTo(long index, double value) { assert index < this.size; this.page[(int)index] = this.page[(int)index] + value; } public void setAll(LongToDoubleFunction gen) { Arrays.setAll(this.page, gen::applyAsDouble); } public void fill(double value) { Arrays.fill(this.page, value); } public void copyTo(HugeDoubleArray dest, long length) { if (length > this.size) length = this.size;  if (length > dest.size()) length = dest.size();  if (dest instanceof SingleHugeDoubleArray) { SingleHugeDoubleArray dst = (SingleHugeDoubleArray)dest; System.arraycopy(this.page, 0, dst.page, 0, (int)length); Arrays.fill(dst.page, (int)length, dst.size, 0.0D); } else if (dest instanceof HugeDoubleArray.PagedHugeDoubleArray) { HugeDoubleArray.PagedHugeDoubleArray dst = (HugeDoubleArray.PagedHugeDoubleArray)dest; int start = 0; int remaining = (int)length; for (double[] dstPage : dst.pages) { int toCopy = Math.min(remaining, dstPage.length); if (toCopy == 0) { Arrays.fill(this.page, 0.0D); } else { System.arraycopy(this.page, start, dstPage, 0, toCopy); if (toCopy < dstPage.length) Arrays.fill(dstPage, toCopy, dstPage.length, 0.0D);  start += toCopy; remaining -= toCopy; }  }  }  } public long size() { return this.size; } public long sizeOf() { return MemoryUsage.sizeOfDoubleArray(this.size); } public long release() { if (this.page != null) { this.page = null; return MemoryUsage.sizeOfDoubleArray(this.size); }  return 0L; } public HugeCursor<double[]> newCursor() { return (HugeCursor)new HugeCursor.SinglePageCursor<>(this.page); } public DoubleStream stream() { return Arrays.stream(this.page); } public double[] toArray() { return this.page; } public String toString() { return Arrays.toString(this.page); } } private static final class PagedHugeDoubleArray extends HugeDoubleArray {
    private static HugeDoubleArray of(long size, AllocationTracker tracker) { int numPages = HugeArrays.numberOfPages(size);
      double[][] pages = new double[numPages][];
      
      long memoryUsed = MemoryUsage.sizeOfObjectArray(numPages);
      long pageBytes = MemoryUsage.sizeOfDoubleArray(16384);
      for (int i = 0; i < numPages - 1; i++) {
        memoryUsed += pageBytes;
        pages[i] = new double[16384];
      } 
      int lastPageSize = HugeArrays.exclusiveIndexOfPage(size);
      pages[numPages - 1] = new double[lastPageSize];
      memoryUsed += MemoryUsage.sizeOfDoubleArray(lastPageSize);
      tracker.add(memoryUsed);
      
      return new PagedHugeDoubleArray(size, pages, memoryUsed); }

    
    private final long size;
    private double[][] pages;
    private final long memoryUsed;
    
    private PagedHugeDoubleArray(long size, double[][] pages, long memoryUsed) {
      this.size = size;
      this.pages = pages;
      this.memoryUsed = memoryUsed;
    }

    
    public double get(long index) {
      assert index < this.size;
      int pageIndex = HugeArrays.pageIndex(index);
      int indexInPage = HugeArrays.indexInPage(index);
      return this.pages[pageIndex][indexInPage];
    }

    
    public void set(long index, double value) {
      assert index < this.size;
      int pageIndex = HugeArrays.pageIndex(index);
      int indexInPage = HugeArrays.indexInPage(index);
      this.pages[pageIndex][indexInPage] = value;
    }

    
    public void addTo(long index, double value) {
      assert index < this.size;
      int pageIndex = HugeArrays.pageIndex(index);
      int indexInPage = HugeArrays.indexInPage(index);
      this.pages[pageIndex][indexInPage] = this.pages[pageIndex][indexInPage] + value;
    }

    
    public void setAll(LongToDoubleFunction gen) {
      for (int i = 0; i < this.pages.length; i++) {
        long t = i << 14L;
        Arrays.setAll(this.pages[i], j -> gen.applyAsDouble(t + j));
      } 
    }

    
    public void fill(double value) {
      for (double[] page : this.pages) {
        Arrays.fill(page, value);
      }
    }

    
    public void copyTo(HugeDoubleArray dest, long length) {
      if (length > this.size) {
        length = this.size;
      }
      if (length > dest.size()) {
        length = dest.size();
      }
      if (dest instanceof HugeDoubleArray.SingleHugeDoubleArray) {
        HugeDoubleArray.SingleHugeDoubleArray dst = (HugeDoubleArray.SingleHugeDoubleArray)dest;
        int start = 0;
        int remaining = (int)length;
        for (double[] page : this.pages) {
          int toCopy = Math.min(remaining, page.length);
          if (toCopy == 0) {
            break;
          }
          System.arraycopy(page, 0, dst.page, start, toCopy);
          start += toCopy;
          remaining -= toCopy;
        } 
        Arrays.fill(dst.page, start, dst.size, 0.0D);
      } else if (dest instanceof PagedHugeDoubleArray) {
        PagedHugeDoubleArray dst = (PagedHugeDoubleArray)dest;
        int pageLen = Math.min(this.pages.length, dst.pages.length);
        int lastPage = pageLen - 1;
        long remaining = length;
        for (int i = 0; i < lastPage; i++) {
          double[] page = this.pages[i];
          double[] dstPage = dst.pages[i];
          System.arraycopy(page, 0, dstPage, 0, page.length);
          remaining -= page.length;
        } 
        if (remaining > 0L) {
          System.arraycopy(this.pages[lastPage], 0, dst.pages[lastPage], 0, (int)remaining);
          Arrays.fill(dst.pages[lastPage], (int)remaining, (dst.pages[lastPage]).length, 0.0D);
        } 
        for (int i = pageLen; i < dst.pages.length; i++) {
          Arrays.fill(dst.pages[i], 0.0D);
        }
      } 
    }


    
    public long size() { return this.size; }



    
    public long sizeOf() { return this.memoryUsed; }


    
    public long release() {
      if (this.pages != null) {
        this.pages = (double[][])null;
        return this.memoryUsed;
      } 
      return 0L;
    }


    
    public HugeCursor<double[]> newCursor() { return (HugeCursor)new HugeCursor.PagedCursor<>(this.size, this.pages); }



    
    public DoubleStream stream() { return Arrays.stream(this.pages).flatMapToDouble(Arrays::stream); }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\HugeDoubleArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */