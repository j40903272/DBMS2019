package org.neo4j.graphalgo.core.utils.paged;

import java.util.Arrays;
import java.util.function.LongFunction;
import java.util.function.LongUnaryOperator;
import org.neo4j.graphalgo.core.utils.ArrayUtil;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
import org.neo4j.graphalgo.core.write.PropertyTranslator;















































































































































public abstract class HugeLongArray
  extends HugeArray<long[], Long, HugeLongArray>
{
  public final HugeLongArray copyOf(long newLength, AllocationTracker tracker) {
    HugeLongArray copy = newArray(newLength, tracker);
    copyTo(copy, newLength);
    return copy;
  }





  
  final Long boxedGet(long index) { return Long.valueOf(get(index)); }






  
  final void boxedSet(long index, Long value) { set(index, value.longValue()); }






  
  final void boxedSetAll(LongFunction<Long> gen) { setAll(gen::apply); }






  
  final void boxedFill(Long value) { fill(value.longValue()); }






  
  public long[] toArray() { return dumpToArray((Class)long[].class); }




  
  public static HugeLongArray newArray(long size, AllocationTracker tracker)
  {
    if (size <= ArrayUtil.MAX_ARRAY_LENGTH) {
      return 
















































        
        SingleHugeLongArray.of(size, tracker);
    }



























































































































    
    return PagedHugeLongArray.of(size, tracker); } public static long memoryEstimation(long size) { assert size >= 0L; if (size <= ArrayUtil.MAX_ARRAY_LENGTH) return MemoryUsage.sizeOfInstance(SingleHugeLongArray.class) + MemoryUsage.sizeOfLongArray((int)size);  long sizeOfInstance = MemoryUsage.sizeOfInstance(PagedHugeLongArray.class); int numPages = HugeArrays.numberOfPages(size); long memoryUsed = MemoryUsage.sizeOfObjectArray(numPages); long pageBytes = MemoryUsage.sizeOfLongArray(16384); memoryUsed += (numPages - 1) * pageBytes; int lastPageSize = HugeArrays.exclusiveIndexOfPage(size); return sizeOfInstance + memoryUsed + MemoryUsage.sizeOfLongArray(lastPageSize); } public static HugeLongArray of(long... values) { return new SingleHugeLongArray(values.length, values); } static HugeLongArray newSingleArray(int size, AllocationTracker tracker) { return SingleHugeLongArray.of(size, tracker); } public abstract long get(long paramLong); public abstract void set(long paramLong1, long paramLong2); public abstract void or(long paramLong1, long paramLong2); public abstract long and(long paramLong1, long paramLong2); public abstract void addTo(long paramLong1, long paramLong2); public abstract void setAll(LongUnaryOperator paramLongUnaryOperator); public abstract void fill(long paramLong); static HugeLongArray newPagedArray(long size, AllocationTracker tracker) { return PagedHugeLongArray.of(size, tracker); } public abstract long size(); public abstract long sizeOf(); public abstract long release(); public abstract HugeCursor<long[]> newCursor(); public abstract void copyTo(HugeLongArray paramHugeLongArray, long paramLong); public static class Translator implements PropertyTranslator.OfLong<HugeLongArray> {
    public static final Translator INSTANCE = new Translator(); public long toLong(HugeLongArray data, long nodeId) { return data.get(nodeId); } } private static final class SingleHugeLongArray extends HugeLongArray {
    private final int size; private long[] page; private static HugeLongArray of(long size, AllocationTracker tracker) { assert size <= ArrayUtil.MAX_ARRAY_LENGTH; int intSize = (int)size; long[] page = new long[intSize]; tracker.add(MemoryUsage.sizeOfLongArray(intSize)); return new SingleHugeLongArray(intSize, page); } private SingleHugeLongArray(int size, long[] page) { this.size = size; this.page = page; } public long get(long index) { assert index < this.size; return this.page[(int)index]; } public void set(long index, long value) { assert index < this.size; this.page[(int)index] = value; } public void or(long index, long value) { assert index < this.size; this.page[(int)index] = this.page[(int)index] | value; } public long and(long index, long value) { assert index < this.size; this.page[(int)index] = this.page[(int)index] & value; return this.page[(int)index] & value; } public void addTo(long index, long value) { assert index < this.size; this.page[(int)index] = this.page[(int)index] + value; } public void setAll(LongUnaryOperator gen) { Arrays.setAll(this.page, gen::applyAsLong); } public void fill(long value) { Arrays.fill(this.page, value); } public void copyTo(HugeLongArray dest, long length) { if (length > this.size) length = this.size;  if (length > dest.size()) length = dest.size();  if (dest instanceof SingleHugeLongArray) { SingleHugeLongArray dst = (SingleHugeLongArray)dest; System.arraycopy(this.page, 0, dst.page, 0, (int)length); Arrays.fill(dst.page, (int)length, dst.size, 0L); } else if (dest instanceof HugeLongArray.PagedHugeLongArray) { HugeLongArray.PagedHugeLongArray dst = (HugeLongArray.PagedHugeLongArray)dest; int start = 0; int remaining = (int)length; for (long[] dstPage : dst.pages) { int toCopy = Math.min(remaining, dstPage.length); if (toCopy == 0) { Arrays.fill(this.page, 0L); } else { System.arraycopy(this.page, start, dstPage, 0, toCopy); if (toCopy < dstPage.length) Arrays.fill(dstPage, toCopy, dstPage.length, 0L);  start += toCopy; remaining -= toCopy; }  }  }  } public long size() { return this.size; } public long sizeOf() { return MemoryUsage.sizeOfLongArray(this.size); } public long release() { if (this.page != null) { this.page = null; return MemoryUsage.sizeOfLongArray(this.size); }  return 0L; } public HugeCursor<long[]> newCursor() { return (HugeCursor)new HugeCursor.SinglePageCursor<>(this.page); } public String toString() { return Arrays.toString(this.page); } public long[] toArray() { return this.page; } } private static final class PagedHugeLongArray extends HugeLongArray {
    private static HugeLongArray of(long size, AllocationTracker tracker) { int numPages = HugeArrays.numberOfPages(size);
      long[][] pages = new long[numPages][];
      
      long memoryUsed = MemoryUsage.sizeOfObjectArray(numPages);
      long pageBytes = MemoryUsage.sizeOfLongArray(16384);
      for (int i = 0; i < numPages - 1; i++) {
        memoryUsed += pageBytes;
        pages[i] = new long[16384];
      } 
      int lastPageSize = HugeArrays.exclusiveIndexOfPage(size);
      pages[numPages - 1] = new long[lastPageSize];
      memoryUsed += MemoryUsage.sizeOfLongArray(lastPageSize);
      tracker.add(memoryUsed);
      
      return new PagedHugeLongArray(size, pages, memoryUsed); }

    
    private final long size;
    private long[][] pages;
    private final long memoryUsed;
    
    private PagedHugeLongArray(long size, long[][] pages, long memoryUsed) {
      this.size = size;
      this.pages = pages;
      this.memoryUsed = memoryUsed;
    }

    
    public long get(long index) {
      assert index < this.size;
      int pageIndex = HugeArrays.pageIndex(index);
      int indexInPage = HugeArrays.indexInPage(index);
      return this.pages[pageIndex][indexInPage];
    }

    
    public void set(long index, long value) {
      assert index < this.size;
      int pageIndex = HugeArrays.pageIndex(index);
      int indexInPage = HugeArrays.indexInPage(index);
      this.pages[pageIndex][indexInPage] = value;
    }

    
    public void or(long index, long value) {
      assert index < this.size;
      int pageIndex = HugeArrays.pageIndex(index);
      int indexInPage = HugeArrays.indexInPage(index);
      this.pages[pageIndex][indexInPage] = this.pages[pageIndex][indexInPage] | value;
    }

    
    public long and(long index, long value) {
      assert index < this.size;
      int pageIndex = HugeArrays.pageIndex(index);
      int indexInPage = HugeArrays.indexInPage(index);
      this.pages[pageIndex][indexInPage] = this.pages[pageIndex][indexInPage] & value; return this.pages[pageIndex][indexInPage] & value;
    }

    
    public void addTo(long index, long value) {
      assert index < this.size;
      int pageIndex = HugeArrays.pageIndex(index);
      int indexInPage = HugeArrays.indexInPage(index);
      this.pages[pageIndex][indexInPage] = this.pages[pageIndex][indexInPage] + value;
    }

    
    public void setAll(LongUnaryOperator gen) {
      for (int i = 0; i < this.pages.length; i++) {
        long t = i << 14L;
        Arrays.setAll(this.pages[i], j -> gen.applyAsLong(t + j));
      } 
    }

    
    public void fill(long value) {
      for (long[] page : this.pages) {
        Arrays.fill(page, value);
      }
    }

    
    public void copyTo(HugeLongArray dest, long length) {
      if (length > this.size) {
        length = this.size;
      }
      if (length > dest.size()) {
        length = dest.size();
      }
      if (dest instanceof HugeLongArray.SingleHugeLongArray) {
        HugeLongArray.SingleHugeLongArray dst = (HugeLongArray.SingleHugeLongArray)dest;
        int start = 0;
        int remaining = (int)length;
        for (long[] page : this.pages) {
          int toCopy = Math.min(remaining, page.length);
          if (toCopy == 0) {
            break;
          }
          System.arraycopy(page, 0, dst.page, start, toCopy);
          start += toCopy;
          remaining -= toCopy;
        } 
        Arrays.fill(dst.page, start, dst.size, 0L);
      } else if (dest instanceof PagedHugeLongArray) {
        PagedHugeLongArray dst = (PagedHugeLongArray)dest;
        int pageLen = Math.min(this.pages.length, dst.pages.length);
        int lastPage = pageLen - 1;
        long remaining = length;
        for (int i = 0; i < lastPage; i++) {
          long[] page = this.pages[i];
          long[] dstPage = dst.pages[i];
          System.arraycopy(page, 0, dstPage, 0, page.length);
          remaining -= page.length;
        } 
        if (remaining > 0L) {
          System.arraycopy(this.pages[lastPage], 0, dst.pages[lastPage], 0, (int)remaining);
          Arrays.fill(dst.pages[lastPage], (int)remaining, (dst.pages[lastPage]).length, 0L);
        } 
        for (int i = pageLen; i < dst.pages.length; i++) {
          Arrays.fill(dst.pages[i], 0L);
        }
      } 
    }


    
    public long size() { return this.size; }



    
    public long sizeOf() { return this.memoryUsed; }


    
    public long release() {
      if (this.pages != null) {
        this.pages = (long[][])null;
        return this.memoryUsed;
      } 
      return 0L;
    }


    
    public HugeCursor<long[]> newCursor() { return (HugeCursor)new HugeCursor.PagedCursor<>(this.size, this.pages); }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\HugeLongArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */