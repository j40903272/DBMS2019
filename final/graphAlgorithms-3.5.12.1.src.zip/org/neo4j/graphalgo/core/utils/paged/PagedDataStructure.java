package org.neo4j.graphalgo.core.utils.paged;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;






















public class PagedDataStructure<T>
{
  final int pageSize;
  final int pageShift;
  final int pageMask;
  private final long maxSupportedSize;
  volatile T[] pages;
  private final AtomicLong size = new PaddedAtomicLong();
  private final AtomicLong capacity = new PaddedAtomicLong();
  private final ReentrantLock growLock = new ReentrantLock(true);
  
  private final PageAllocator<T> allocator;
  
  PagedDataStructure(long size, PageAllocator<T> allocator) {
    this.pageSize = allocator.pageSize();
    this.pageShift = Integer.numberOfTrailingZeros(this.pageSize);
    this.pageMask = this.pageSize - 1;
    
    int maxIndexShift = 31 + this.pageShift;
    this.maxSupportedSize = 1L << maxIndexShift;
    assert size <= this.maxSupportedSize;
    this.size.set(size);
    
    this.allocator = allocator;
    this.pages = allocator.emptyPages();
    setPages(numPages(size));
  }
  
  PagedDataStructure(long size, T[] pages, PageAllocator<T> allocator) {
    this.pageSize = allocator.pageSize();
    this.pageShift = Integer.numberOfTrailingZeros(this.pageSize);
    this.pageMask = this.pageSize - 1;
    
    if (numPages(size) != pages.length) {
      throw new IllegalArgumentException(String.format("The capacity of [%d] would require [%d] pages, but [%d] were provided", new Object[] {
              
              Long.valueOf(size), 
              Integer.valueOf(numPages(size)), 
              Integer.valueOf(pages.length)
            }));
    }
    int maxIndexShift = 31 + this.pageShift;
    this.maxSupportedSize = 1L << maxIndexShift;
    
    this.allocator = allocator;
    this.pages = pages;
    this.capacity.set(capacityFor(pages.length));
    this.size.set(size);
  }





  
  public long size() { return this.size.get(); }






  
  public final long capacity() { return this.capacity.get(); }

  
  public long release() {
    this.size.set(0L);
    long freed = this.allocator.estimateMemoryUsage(this.capacity.getAndSet(0L));
    this.pages = null;
    return freed;
  }

  
  protected int numPages(long capacity) { return PageUtil.numPagesFor(capacity, this.pageShift, this.pageMask); }


  
  final long capacityFor(int numPages) { return numPages << this.pageShift; }


  
  final int pageIndex(long index) { return (int)(index >>> this.pageShift); }


  
  final int indexInPage(long index) { return (int)(index & this.pageMask); }






  
  final void grow(long newSize) { grow(newSize, -1); }





  
  final void grow(long newSize, int skipPage) {
    assert newSize <= this.maxSupportedSize;
    long cap = this.capacity.get();
    if (cap >= newSize) {
      growSize(newSize);
      return;
    } 
    this.growLock.lock();
    try {
      cap = this.capacity.get();
      if (cap >= newSize) {
        growSize(newSize);
        return;
      } 
      setPages(numPages(newSize), this.pages.length, skipPage);
      growSize(newSize);
    } finally {
      this.growLock.unlock();
    } 
  }
  
  private void growSize(long newSize) {
    long size;
    do {
      size = this.size.get();
    } while (size < newSize && !this.size.compareAndSet(size, newSize));
  }
  
  private void setPages(int numPages) {
    if (numPages > 0) {
      setPages(numPages, 0, -1);
    }
  }
  
  private void setPages(int numPages, int currentNumPages, int skipPage) {
    Object[] arrayOfObject = Arrays.copyOf((Object[])this.pages, numPages);
    for (int i = currentNumPages; i < numPages; i++) {
      if (i != skipPage) {
        arrayOfObject[i] = allocateNewPage();
      }
    } 
    this.pages = (T[])arrayOfObject;
    this.capacity.set(capacityFor(numPages));
  }

  
  T allocateNewPage() { return this.allocator.newPage(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\PagedDataStructure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */