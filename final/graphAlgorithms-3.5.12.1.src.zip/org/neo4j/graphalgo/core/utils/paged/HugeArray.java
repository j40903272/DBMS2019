package org.neo4j.graphalgo.core.utils.paged;

import java.lang.reflect.Array;
import java.util.function.LongFunction;






































































abstract class HugeArray<Array, Box, Self extends HugeArray<Array, Box, Self>>
{
  public abstract void copyTo(Self paramSelf, long paramLong);
  
  public abstract Self copyOf(long paramLong, AllocationTracker paramAllocationTracker);
  
  public abstract long size();
  
  public abstract long sizeOf();
  
  public abstract long release();
  
  public abstract HugeCursor<Array> newCursor();
  
  public final HugeCursor<Array> initCursor(HugeCursor<Array> cursor) {
    cursor.setRange();
    return cursor;
  }














  
  public final HugeCursor<Array> initCursor(HugeCursor<Array> cursor, long start, long end) {
    assert start >= 0L && start <= size() : "start expected to be in [0 : " + size() + "] but got " + start;
    assert end >= start && end <= size() : "end expected to be in [" + start + " : " + size() + "] but got " + end;
    cursor.setRange(start, end);
    return cursor;
  }





  
  abstract Box boxedGet(long paramLong);





  
  abstract void boxedSet(long paramLong, Box paramBox);





  
  abstract void boxedSetAll(LongFunction<Box> paramLongFunction);





  
  abstract void boxedFill(Box paramBox);





  
  public abstract Array toArray();




  
  public final int copyFromArrayIntoSlice(Array source, long sliceStart, long sliceEnd) {
    int sourceIndex = 0;
    try (HugeCursor<Array> cursor = initCursor(newCursor(), sliceStart, sliceEnd)) {
      int sourceLength = Array.getLength(source);
      while (cursor.next() && sourceIndex < sourceLength) {
        int copyLength = Math.min(cursor.limit - cursor.offset, sourceLength - sourceIndex);


        
        System.arraycopy(source, sourceIndex, cursor.array, cursor.offset, copyLength);
        sourceIndex += copyLength;
      } 
    } 
    return sourceIndex;
  }

  
  public String toString() {
    if (size() == 0L) {
      return "[]";
    }
    StringBuilder sb = new StringBuilder();
    sb.append('[');
    try (HugeCursor<Array> cursor = initCursor(newCursor())) {
      while (cursor.next()) {
        Array array = cursor.array;
        for (int i = cursor.offset; i < cursor.limit; i++) {
          sb.append(Array.get(array, i)).append(", ");
        }
      } 
    } 
    sb.setLength(sb.length() - 1);
    sb.setCharAt(sb.length() - 1, ']');
    return sb.toString();
  }

  
  Array dumpToArray(Class<Array> componentClass) {
    long fullSize = size();
    if ((int)fullSize != fullSize) {
      throw new IllegalStateException("array with " + fullSize + " elements does not fit into a Java array");
    }
    int size = (int)fullSize;
    Object result = Array.newInstance(componentClass.getComponentType(), size);
    int pos = 0;
    try (HugeCursor<Array> cursor = initCursor(newCursor())) {
      while (cursor.next()) {
        Array array = cursor.array;
        int length = cursor.limit - cursor.offset;
        System.arraycopy(array, cursor.offset, result, pos, length);
        pos += length;
      } 
    } 
    return (Array)result;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\paged\HugeArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */