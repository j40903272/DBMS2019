package org.neo4j.graphalgo.core.utils;

import org.neo4j.util.FeatureToggles;

























public final class ArrayUtil
{
  private static final int MAX_ARRAY_LENGTH_SHIFT = FeatureToggles.getInteger(ArrayUtil.class, "maxArrayLengthShift", 28);

  
  public static final int MAX_ARRAY_LENGTH = 1 << MAX_ARRAY_LENGTH_SHIFT;
  
  public static final int LINEAR_SEARCH_LIMIT = 64;
  
  public static boolean binarySearch(int[] arr, int length, int key) {
    int low = 0;
    int high = length - 1;
    while (high - low > 64) {
      int mid = low + high >>> 1;
      int midVal = arr[mid];
      if (midVal < key) {
        low = mid + 1; continue;
      }  if (midVal > key) {
        high = mid - 1; continue;
      } 
      return true;
    } 
    return linearSearch2(arr, low, high, key);
  }

  
  public static int binarySearchIndex(int[] arr, int length, int key) {
    int low = 0;
    int high = length - 1;
    while (high - low > 64) {
      int mid = low + high >>> 1;
      int midVal = arr[mid];
      if (midVal < key) {
        low = mid + 1; continue;
      }  if (midVal > key) {
        high = mid - 1; continue;
      } 
      return mid;
    } 
    return linearSearch2index(arr, low, high, key);
  }


  
  public static boolean linearSearch2(int[] arr, int low, int high, int key) {
    for (int i = low; i <= high; i++) {
      if (arr[i] == key) return true; 
      if (arr[i] > key) return false; 
    } 
    return false;
  }

  
  public static int linearSearch2index(int[] arr, int low, int high, int key) {
    for (int i = low; i <= high; i++) {
      if (arr[i] == key) return i; 
      if (arr[i] > key) return -i - 1; 
    } 
    return -high - 1;
  }
  
  public static boolean linearSearch(int[] arr, int length, int key) {
    int i = 0;
    for (; i < length - 4; i += 4) {
      if (arr[i] == key) return true; 
      if (arr[i + 1] == key) return true; 
      if (arr[i + 2] == key) return true; 
      if (arr[i + 3] == key) return true; 
    } 
    for (; i < length; i++) {
      if (arr[i] == key) {
        return true;
      }
    } 
    return false;
  }
  
  public static int linearSearchIndex(int[] arr, int length, int key) {
    int i = 0;
    for (; i < length - 4; i += 4) {
      if (arr[i] == key) return i; 
      if (arr[i + 1] == key) return i; 
      if (arr[i + 2] == key) return i; 
      if (arr[i + 3] == key) return i; 
    } 
    for (; i < length; i++) {
      if (arr[i] == key) {
        return i;
      }
    } 
    return -length - 1;
  }
  
  private static boolean linearSearch(int[] arr, int low, int high, int key) {
    int i = low;
    for (; i < high - 3; i += 4) {
      if (arr[i] > key) return false; 
      if (arr[i] == key) return true; 
      if (arr[i + 1] == key) return true; 
      if (arr[i + 2] == key) return true; 
      if (arr[i + 3] == key) return true; 
    } 
    for (; i <= high; i++) {
      if (arr[i] == key) {
        return true;
      }
    } 
    return false;
  }







  
  public static int binaryLookup(long id, long[] ids) {
    int length = ids.length;
    
    int low = 0;
    int high = length - 1;
    
    while (low <= high) {
      int mid = low + high >>> 1;
      long midVal = ids[mid];
      
      if (midVal < id) {
        low = mid + 1; continue;
      }  if (midVal > id) {
        high = mid - 1; continue;
      } 
      return mid;
    } 
    
    return low - 1;
  }







  
  public static int binaryLookup(int id, int[] ids) {
    int length = ids.length;
    
    int low = 0;
    int high = length - 1;
    
    while (low <= high) {
      int mid = low + high >>> 1;
      int midVal = ids[mid];
      
      if (midVal < id) {
        low = mid + 1; continue;
      }  if (midVal > id) {
        high = mid - 1; continue;
      } 
      return mid;
    } 
    
    return low - 1;
  }

  
  private ArrayUtil() { throw new UnsupportedOperationException("No instances"); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\ArrayUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */