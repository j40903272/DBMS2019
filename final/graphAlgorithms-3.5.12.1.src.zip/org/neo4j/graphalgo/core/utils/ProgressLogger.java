package org.neo4j.graphalgo.core.utils;

import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import org.neo4j.logging.Log;
import org.neo4j.logging.NullLog;
























public interface ProgressLogger
{
  public static final ProgressLogger NULL_LOGGER = new ProgressLoggerAdapter((Log)NullLog.getInstance(), "NULL");
  public static final Supplier<String> NO_MESSAGE = () -> null;

  
  static ProgressLogger wrap(Log log, String task) { return new ProgressLoggerAdapter(log, task); }

  
  static ProgressLogger wrap(Log log, String task, long time, TimeUnit unit) {
    if (log == null || log == NullLog.getInstance() || task == null) {
      return NULL_LOGGER;
    }
    ProgressLoggerAdapter logger = new ProgressLoggerAdapter(log, task);
    if (time > 0L) {
      logger.withLogIntervalMillis((int)Math.min(unit.toMillis(time), 2147483647L));
    }
    return logger;
  }





  
  default void log(String msg) { log(() -> msg); }


  
  default void logDone(Supplier<String> msg) { log(msg); }


  
  default void logProgress(double numerator, double denominator, Supplier<String> msg) { logProgress(numerator / denominator, msg); }


  
  default void logProgress(double numerator, double denominator) { logProgress(numerator, denominator, NO_MESSAGE); }


  
  default void logProgress(double percentDone) { logProgress(percentDone, NO_MESSAGE); }


  
  default void logDone() { logDone(NO_MESSAGE); }
  
  void logProgress(double paramDouble, Supplier<String> paramSupplier);
  
  void log(Supplier<String> paramSupplier);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\ProgressLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */