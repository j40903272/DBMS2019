package org.neo4j.graphalgo.core.utils;

import org.neo4j.kernel.api.KernelTransaction;























public class TerminationFlagImpl
  implements TerminationFlag
{
  private final KernelTransaction transaction;
  private long interval = 10000L;
  
  private volatile long lastCheck = 0L;
  
  private volatile boolean running = true;

  
  public TerminationFlagImpl(KernelTransaction transaction) { this.transaction = transaction; }

  
  public TerminationFlagImpl withCheckInterval(long interval) {
    this.interval = interval;
    return this;
  }

  
  public boolean running() {
    long currentTime = System.currentTimeMillis();
    if (currentTime > this.lastCheck + this.interval) {
      if (this.transaction.getReasonIfTerminated().isPresent() || !this.transaction.isOpen()) {
        this.running = false;
      }
      this.lastCheck = currentTime;
    } 
    return this.running;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\TerminationFlagImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */