package org.neo4j.graphalgo.core.utils;

import java.util.concurrent.atomic.AtomicLongArray;
import java.util.stream.IntStream;






























public class AtomicDoubleArray
{
  private final AtomicLongArray data;
  private final int capacity;
  
  public AtomicDoubleArray(int capacity) {
    this.capacity = capacity;
    this.data = new AtomicLongArray(capacity);
  }







  
  public double get(int index) { return Double.longBitsToDouble(this.data.get(index)); }








  
  public void set(int index, double value) { this.data.set(index, Double.doubleToLongBits(value)); }






  
  public void add(int index, double value) {
    long currentBits;
    long newBits;
    do {
      currentBits = this.data.get(index);
      newBits = Double.doubleToLongBits(Double.longBitsToDouble(currentBits) + value);
    } while (!this.data.compareAndSet(index, currentBits, newBits));
  }






  
  public int length() { return this.data.length(); }




  
  public void clear() {
    for (int i = this.data.length() - 1; i >= 0; i--) {
      this.data.set(i, 0L);
    }
  }

  
  public String toString() {
    StringBuilder builder = new StringBuilder();
    for (int i = 0; i < this.data.length(); i++) {
      if (i > 0) {
        builder.append(", ");
      }
      builder.append(get(i));
      if (i >= 20) {
        builder.append(", ..");
        break;
      } 
    } 
    return "[" + builder.toString() + "]";
  }

  
  public double[] toArray() { return IntStream.range(0, this.capacity)
      .mapToDouble(this::get)
      .toArray(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\AtomicDoubleArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */