package org.neo4j.graphalgo.core.utils.mem;
import com.carrotsearch.hppc.ObjectLongIdentityHashMap;
import com.carrotsearch.hppc.ObjectLongMap;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.security.AccessController;

public final class MemoryUsage {
  private static final int SHIFT_BYTE;
  private static final int SHIFT_CHAR;
  private static final int SHIFT_SHORT;
  private static final int SHIFT_INT;
  private static final int SHIFT_FLOAT;
  private static final int SHIFT_LONG;
  private static final int SHIFT_DOUBLE;
  private static final int SHIFT_OBJECT_REF;
  public static final int BYTES_OBJECT_REF;
  private static final int BYTES_OBJECT_HEADER;
  private static final int BYTES_ARRAY_HEADER;
  private static final int MASK1_OBJECT_ALIGNMENT;
  private static final int MASK2_OBJECT_ALIGNMENT;
  private static final ObjectLongMap<Class<?>> primitiveSizes;
  private static final String MANAGEMENT_FACTORY_CLASS = "java.lang.management.ManagementFactory";
  private static final String HOTSPOT_BEAN_CLASS = "com.sun.management.HotSpotDiagnosticMXBean";
  private static final String[] UNITS;
  
  public static long sizeOfByteArray(int length) { return alignObjectSize(BYTES_ARRAY_HEADER + (length << SHIFT_BYTE)); }
  
  public static long sizeOfCharArray(int length) { return alignObjectSize(BYTES_ARRAY_HEADER + (length << SHIFT_CHAR)); }
  
  public static long sizeOfShortArray(int length) { return alignObjectSize(BYTES_ARRAY_HEADER + (length << SHIFT_SHORT)); }
  
  static  {
    boolean is64Bit;
    SHIFT_BYTE = Integer.numberOfTrailingZeros(1);
    SHIFT_CHAR = Integer.numberOfTrailingZeros(2);
    SHIFT_SHORT = Integer.numberOfTrailingZeros(2);
    SHIFT_INT = Integer.numberOfTrailingZeros(4);
    SHIFT_FLOAT = Integer.numberOfTrailingZeros(4);
    SHIFT_LONG = Integer.numberOfTrailingZeros(8);
    SHIFT_DOUBLE = Integer.numberOfTrailingZeros(8);



















    
    primitiveSizes = (ObjectLongMap<Class<?>>)new ObjectLongIdentityHashMap();

    
    primitiveSizes.put(boolean.class, 1L);
    primitiveSizes.put(byte.class, 1L);
    primitiveSizes.put(char.class, 2L);
    primitiveSizes.put(short.class, 2L);
    primitiveSizes.put(int.class, 4L);
    primitiveSizes.put(float.class, 4L);
    primitiveSizes.put(double.class, 8L);
    primitiveSizes.put(long.class, 8L);








    
    String osArch = System.getProperty("os.arch");
    String x = System.getProperty("sun.arch.data.model");
    
    if (x != null) {
      is64Bit = x.contains("64");
    } else {
      is64Bit = (osArch != null && osArch.contains("64"));
    } 
    if (is64Bit) {

      
      boolean compressedOops = false;
      int objectAlignment = 8;
      try {
        Class<?> beanClazz = Class.forName("com.sun.management.HotSpotDiagnosticMXBean");




        
        Object hotSpotBean = Class.forName("java.lang.management.ManagementFactory").getMethod("getPlatformMXBean", new Class[] { Class.class }).invoke(null, new Object[] { beanClazz });
        if (hotSpotBean != null) {
          Method getVMOptionMethod = beanClazz.getMethod("getVMOption", new Class[] { String.class });

          
          try {
            Object vmOption = getVMOptionMethod.invoke(hotSpotBean, new Object[] { "UseCompressedOops" });

            
            compressedOops = Boolean.parseBoolean(vmOption
                
                .getClass()
                .getMethod("getValue", new Class[0])
                .invoke(vmOption, new Object[0])
                .toString());
          }
          catch (ReflectiveOperationException|RuntimeException reflectiveOperationException) {}
          
          try {
            Object vmOption = getVMOptionMethod.invoke(hotSpotBean, new Object[] { "ObjectAlignmentInBytes" });

            
            objectAlignment = Integer.parseInt(vmOption
                .getClass()
                .getMethod("getValue", new Class[0])
                .invoke(vmOption, new Object[0])
                .toString());
            objectAlignment = BitUtil.nextHighestPowerOfTwo(objectAlignment);
          } catch (ReflectiveOperationException|RuntimeException reflectiveOperationException) {}
        }
      
      } catch (ReflectiveOperationException|RuntimeException reflectiveOperationException) {}
      
      boolean compressedRefsEnabled = compressedOops;
      int bytesObjectAlignment = objectAlignment;
      MASK1_OBJECT_ALIGNMENT = bytesObjectAlignment - 1;
      MASK2_OBJECT_ALIGNMENT = MASK1_OBJECT_ALIGNMENT ^ 0xFFFFFFFF;
      
      BYTES_OBJECT_REF = compressedRefsEnabled ? 4 : 8;
      SHIFT_OBJECT_REF = Integer.numberOfTrailingZeros(BYTES_OBJECT_REF);
      
      BYTES_OBJECT_HEADER = 8 + BYTES_OBJECT_REF;
      
      BYTES_ARRAY_HEADER = (int)alignObjectSize((BYTES_OBJECT_HEADER + 4));
    } else {
      int bytesObjectAlignment = 8;
      MASK1_OBJECT_ALIGNMENT = bytesObjectAlignment - 1;
      MASK2_OBJECT_ALIGNMENT = MASK1_OBJECT_ALIGNMENT ^ 0xFFFFFFFF;
      BYTES_OBJECT_REF = 4;
      SHIFT_OBJECT_REF = Integer.numberOfTrailingZeros(BYTES_OBJECT_REF);
      BYTES_OBJECT_HEADER = 8;
      
      BYTES_ARRAY_HEADER = BYTES_OBJECT_HEADER + 4;
    } 





























































































    
    UNITS = new String[] { " Bytes", " KiB", " MiB", " GiB", " TiB", " PiB", " EiB", " ZiB", " YiB" };
  }
  
  public static long sizeOfIntArray(int length) { return alignObjectSize(BYTES_ARRAY_HEADER + (length << SHIFT_INT)); }
  
  public static String humanReadable(long bytes) {
    for (String unit : UNITS) {

      
      if (bytes >> 14L == 0L) {
        return bytes + unit;
      }
      bytes >>= 10L;
    } 

    
    return null;
  } public static long sizeOfFloatArray(int length) { return alignObjectSize(BYTES_ARRAY_HEADER + (length << SHIFT_FLOAT)); }
  public static long sizeOfLongArray(int length) { return alignObjectSize(BYTES_ARRAY_HEADER + (length << SHIFT_LONG)); }
  public static long sizeOfDoubleArray(int length) { return alignObjectSize(BYTES_ARRAY_HEADER + (length << SHIFT_DOUBLE)); }
  private MemoryUsage() { throw new UnsupportedOperationException("No instances"); }
  
  public static long sizeOfObjectArray(int length) { return alignObjectSize(BYTES_ARRAY_HEADER + (length << SHIFT_OBJECT_REF)); }
  
  public static long sizeOfObjectArrayElements(int length) { return alignObjectSize(length << SHIFT_OBJECT_REF); }
  
  public static long sizeOfArray(int length, long bytesPerElement) { return alignObjectSize(BYTES_ARRAY_HEADER + length * bytesPerElement); }
  
  public static long sizeOfInstance(Class<?> clazz) {
    if (clazz.isArray())
      throw new IllegalArgumentException("This method does not work with array classes."); 
    if (clazz.isPrimitive())
      return primitiveSizes.get(clazz); 
    long size = BYTES_OBJECT_HEADER;
    for (; clazz != null; clazz = clazz.getSuperclass()) {
      Field[] fields = AccessController.doPrivileged(clazz::getDeclaredFields);
      for (Field f : fields) {
        if (!Modifier.isStatic(f.getModifiers()))
          size += adjustForField(f); 
      } 
    } 
    return alignObjectSize(size);
  }
  
  private static long alignObjectSize(long size) { return size + MASK1_OBJECT_ALIGNMENT & MASK2_OBJECT_ALIGNMENT; }
  
  private static long adjustForField(Field f) {
    Class<?> type = f.getType();
    if (type.isPrimitive())
      return primitiveSizes.get(type); 
    return (1 << SHIFT_OBJECT_REF);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\mem\MemoryUsage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */