package org.neo4j.graphalgo.core.utils.mem;

import java.util.Collection;
import java.util.Collections;
import org.neo4j.graphalgo.core.GraphDimensions;































public interface MemoryEstimation
{
  String description();
  
  default Collection<MemoryEstimation> components() { return Collections.emptyList(); }


  
  default MemoryEstimation times(long factor) { return MemoryEstimations.andThen(this, memoryRange -> memoryRange.times(factor)); }
  
  MemoryTree estimate(GraphDimensions paramGraphDimensions, int paramInt);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\mem\MemoryEstimation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */