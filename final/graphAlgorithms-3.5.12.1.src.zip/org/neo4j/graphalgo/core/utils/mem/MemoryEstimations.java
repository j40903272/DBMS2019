package org.neo4j.graphalgo.core.utils.mem;

import java.util.ArrayList;
import java.util.Collection;
import java.util.function.Function;
import java.util.function.IntToLongFunction;
import java.util.function.LongFunction;
import java.util.function.LongUnaryOperator;
import java.util.function.ToLongFunction;
import java.util.function.UnaryOperator;
import org.neo4j.graphalgo.core.GraphDimensions;




































public final class MemoryEstimations
{
  public static MemoryEstimation empty() { return NULL_ESTIMATION; }







  
  public static MemoryEstimation of(Class<?> instanceType) {
    return new LeafEstimation("instance", (dimensions, concurrency) -> 
        
        MemoryRange.of(MemoryUsage.sizeOfInstance(instanceType)));
  }










  
  public static MemoryEstimation of(String description, MemoryResident resident) { return new LeafEstimation(description, resident); }









  
  private static MemoryEstimation of(String description, Collection<MemoryEstimation> components) { return new CompositeEstimation(description, components); }











  
  public static MemoryEstimation setup(String description, MemoryEstimationSetup setup) { return new SetupEstimation(description, setup); }











  
  public static MemoryEstimation setup(String description, Function<GraphDimensions, MemoryEstimation> fn) { return new SetupEstimation(description, (dimensions, concurrency) -> (MemoryEstimation)fn.apply(dimensions)); }











  
  public static MemoryEstimation andThen(MemoryEstimation delegate, MemoryRangeModifier andThen) { return andThen(delegate.description(), delegate, andThen); }











  
  public static MemoryEstimation andThen(MemoryEstimation delegate, UnaryOperator<MemoryRange> andThen) { return andThen(delegate.description(), delegate, (range, dimensions, concurrency) -> (MemoryRange)andThen.apply(range)); }













  
  public static MemoryEstimation andThen(String description, MemoryEstimation delegate, MemoryRangeModifier andThen) { return new AndThenEstimation(description, delegate, andThen); }







  
  public static Builder builder() { return new Builder(""); }







  
  public static Builder builder(String description) { return new Builder(description); }









  
  public static Builder builder(Class<?> type) { return new Builder(type.getSimpleName(), type); }









  
  public static Builder builder(String description, Class<?> type) { return new Builder(description, type); }

  
  public static final class Builder
  {
    private final String description;
    private final Collection<MemoryEstimation> components = new ArrayList<>();
    private Builder parent = null;

    
    private Builder(String description) { this.description = description; }

    
    private Builder(String description, Class<?> type) {
      this(description);
      field("this.instance", type);
    }
    
    private Builder(String description, Class<?> type, Builder parent) {
      this(description, type);
      this.parent = parent;
    }











    
    public Builder startField(String name, Class<?> type) { return new Builder(name, type, this); }







    
    public Builder endField() {
      if (this.parent == null) {
        throw new IllegalArgumentException("Cannot end field from root builder");
      }
      this.parent.components.add(build());
      return this.parent;
    }







    
    public Builder add(MemoryEstimation estimation) {
      this.components.add(estimation);
      return this;
    }








    
    public Builder add(String description, MemoryEstimation estimation) {
      this.components.add(new DelegateEstimation(estimation, description));
      return this;
    }





















    
    public Builder field(String description, Class<?> type) {
      this.components.add(new LeafEstimation(description, (dimensions, concurrency) -> 
            
            MemoryRange.of(MemoryUsage.sizeOfInstance(type))));
      return this;
    }







    
    public Builder fixed(String description, long bytes) {
      this.components.add(new LeafEstimation(description, (dimensions, concurrency) -> 
            
            MemoryRange.of(bytes)));
      return this;
    }







    
    public Builder fixed(String description, MemoryRange range) {
      this.components.add(new LeafEstimation(description, (dimensions, concurrency) -> 
            
            range));
      return this;
    }









    
    public Builder perNode(String description, MemoryEstimation estimation) {
      this.components.add(new AndThenEstimation(description, estimation, (mem, dim, concurrency) -> 

            
            mem.times(dim.nodeCount())));
      return this;
    }










    
    public Builder perNode(String description, LongUnaryOperator fn) {
      this.components.add(new LeafEstimation(description, (dimensions, concurrency) -> 
            
            MemoryRange.of(fn.applyAsLong(dimensions.nodeCount()))));
      return this;
    }










    
    public Builder rangePerNode(String description, LongFunction<MemoryRange> fn) {
      this.components.add(new LeafEstimation(description, (dimensions, concurrency) -> 
            
            (MemoryRange)fn.apply(dimensions.nodeCount())));
      return this;
    }










    
    public Builder perGraphDimension(String description, ToLongFunction<GraphDimensions> fn) {
      this.components.add(new LeafEstimation(description, (dimensions, concurrency) -> 
            
            MemoryRange.of(fn.applyAsLong(dimensions))));
      return this;
    }












    
    public Builder rangePerGraphDimension(String description, Function<GraphDimensions, MemoryRange> fn) {
      this.components.add(new LeafEstimation(description, (dimensions, concurrency) -> 
            
            (MemoryRange)fn.apply(dimensions)));
      return this;
    }









    
    public Builder perThread(String description, long bytes) {
      this.components.add(new LeafEstimation(description, (dimensions, concurrency) -> 
            
            MemoryRange.of(concurrency * bytes)));
      return this;
    }










    
    public Builder perThread(String description, IntToLongFunction fn) {
      this.components.add(new LeafEstimation(description, (dimensions, concurrency) -> 
            
            MemoryRange.of(fn.applyAsLong(concurrency))));
      return this;
    }









    
    public Builder perThread(String description, MemoryEstimation estimation) {
      this.components.add(new AndThenEstimation(description, estimation, (mem, dim, concurrency) -> 

            
            mem.times(concurrency)));
      return this;
    }

    
    public MemoryEstimation build() { return MemoryEstimations.of(this.description, this.components); }
  }

  
  private static final MemoryEstimation NULL_ESTIMATION = new MemoryEstimation()
    {
      public String description() {
        return "";
      }


      
      public MemoryTree estimate(GraphDimensions dimensions, int concurrency) { return MemoryTree.empty(); }
    };


  
  private MemoryEstimations() { throw new UnsupportedOperationException("No instances"); }
  
  @FunctionalInterface
  public static interface MemoryEstimationSetup {
    MemoryEstimation setup(GraphDimensions param1GraphDimensions, int param1Int);
  }
  
  @FunctionalInterface
  public static interface MemoryRangeModifier {
    MemoryRange modify(MemoryRange param1MemoryRange, GraphDimensions param1GraphDimensions, int param1Int);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\mem\MemoryEstimations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */