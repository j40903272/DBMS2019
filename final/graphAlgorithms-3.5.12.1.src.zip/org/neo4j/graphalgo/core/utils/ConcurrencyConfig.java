package org.neo4j.graphalgo.core.utils;





















final class ConcurrencyConfig
{
  private static final String PROCESSORS_OVERRIDE_PROPERTY = "neo4j.graphalgo.processors";
  private static final int MAX_CE_CONCURRENCY = 4;
  final int maxConcurrency;
  final int defaultConcurrency;
  
  static ConcurrencyConfig of() {
    Integer definedProcessors = null;
    try {
      definedProcessors = Integer.getInteger("neo4j.graphalgo.processors");
    } catch (SecurityException securityException) {}
    
    if (definedProcessors == null) {
      definedProcessors = Integer.valueOf(Runtime.getRuntime().availableProcessors());
    }
    boolean isOnEnterprise = (Package.getPackage("org.neo4j.kernel.impl.enterprise") != null);
    return new ConcurrencyConfig(definedProcessors.intValue(), isOnEnterprise);
  }
  
  ConcurrencyConfig(int availableProcessors, boolean isOnEnterprise) {
    if (isOnEnterprise) {
      this.maxConcurrency = Integer.MAX_VALUE;
      this.defaultConcurrency = availableProcessors;
    } else {
      this.maxConcurrency = 4;
      this.defaultConcurrency = Math.min(availableProcessors, 4);
    } 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\ConcurrencyConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */