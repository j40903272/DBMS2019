package org.neo4j.graphalgo.core.utils;

import com.carrotsearch.hppc.AbstractIterator;
import java.util.AbstractCollection;
import java.util.Collection;
import java.util.Iterator;
import java.util.function.Function;























public final class LazyMappingCollection<T, U>
  extends AbstractCollection<U>
{
  private final Collection<T> base;
  private final Function<T, U> mappingFunction;
  
  public static <T, U> Collection<U> of(Collection<T> base, Function<T, U> mappingFunction) { return new LazyMappingCollection<>(base, mappingFunction); }



  
  private LazyMappingCollection(Collection<T> base, Function<T, U> mappingFunction) {
    this.base = base;
    this.mappingFunction = mappingFunction;
  }

  
  public Iterator<U> iterator() {
    return (Iterator<U>)new AbstractIterator<U>() {
        private final Iterator<T> it = LazyMappingCollection.this.base.iterator();

        
        protected U fetch() {
          if (this.it.hasNext()) {
            return (U)LazyMappingCollection.this.mappingFunction.apply(this.it.next());
          }
          return (U)done();
        }
      };
  }


  
  public int size() { return this.base.size(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\LazyMappingCollection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */