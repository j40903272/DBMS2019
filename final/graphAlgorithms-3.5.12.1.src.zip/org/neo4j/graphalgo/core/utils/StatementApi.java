package org.neo4j.graphalgo.core.utils;

import org.neo4j.internal.kernel.api.exceptions.KernelException;
import org.neo4j.kernel.api.KernelTransaction;
import org.neo4j.kernel.internal.GraphDatabaseAPI;





























public abstract class StatementApi
{
  protected final GraphDatabaseAPI api;
  private final TransactionWrapper tx;
  
  protected StatementApi(GraphDatabaseAPI api) {
    this.api = api;
    this.tx = new TransactionWrapper(api);
  }
  
  protected final <T> T applyInTransaction(TxFunction<T> fun) {
    return this.tx.apply(ktx -> {
          try {
            return fun.apply(ktx);
          } catch (KernelException e) {
            return ExceptionUtil.throwKernelException(e);
          } 
        });
  }
  
  protected final void acceptInTransaction(TxConsumer fun) {
    this.tx.accept(ktx -> {
          try {
            fun.accept(ktx);
          } catch (KernelException e) {
            ExceptionUtil.throwKernelException(e);
          } 
        });
  }
  
  public static interface TxFunction<T> {
    T apply(KernelTransaction param1KernelTransaction) throws KernelException;
  }
  
  public static interface TxConsumer {
    void accept(KernelTransaction param1KernelTransaction) throws KernelException;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\StatementApi.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */