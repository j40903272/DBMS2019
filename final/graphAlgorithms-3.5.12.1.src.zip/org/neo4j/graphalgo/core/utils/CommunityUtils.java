package org.neo4j.graphalgo.core.utils;

import com.carrotsearch.hppc.IntIntScatterMap;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeCursor;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;
import org.neo4j.graphalgo.core.utils.paged.PagedLongDoubleMap;






























public final class CommunityUtils
{
  public static final int NO_SUCH_SEED_PROPERTY = -1;
  
  public static int normalize(int[] communities) {
    IntIntScatterMap intIntScatterMap = new IntIntScatterMap(communities.length);
    int c = 0;
    for (int i = 0; i < communities.length; i++) {
      int community = communities[i]; int mapped;
      if ((mapped = intIntScatterMap.getOrDefault(community, -1)) != -1) {
        communities[i] = mapped;
      } else {
        intIntScatterMap.put(community, c);
        communities[i] = c++;
      } 
    } 
    return c;
  }







  
  public static long normalize(HugeLongArray communities) {
    PagedLongDoubleMap map = PagedLongDoubleMap.of(communities.size(), AllocationTracker.EMPTY);
    long c = 0L;
    HugeCursor<long[]> cursor = communities.initCursor(communities.newCursor());
    while (cursor.next()) {
      long[] array = (long[])cursor.array;
      for (int i = cursor.offset; i < cursor.limit; i++) {
        long community = array[i];
        double mapped = map.getOrDefault(community, -1.0D);
        if (mapped != -1.0D) {
          array[i] = (long)mapped;
        } else {
          map.put(community, c);
          array[i] = c++;
        } 
      } 
    } 
    return c;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\CommunityUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */