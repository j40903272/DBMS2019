package org.neo4j.graphalgo.core.utils;





















public final class BitUtil
{
  public static boolean isPowerOfTwo(int value) { return (value > 0 && (value & (value ^ 0xFFFFFFFF) + 1) == value); }


  
  public static boolean isPowerOfTwo(long value) { return (value > 0L && (value & (value ^ 0xFFFFFFFFFFFFFFFFL) + 1L) == value); }




  
  public static int previousPowerOfTwo(int v) {
    v |= v >> 1;
    v |= v >> 2;
    v |= v >> 4;
    v |= v >> 8;
    v |= v >> 16;
    return v - (v >>> 1);
  }



  
  public static long previousPowerOfTwo(long v) {
    v |= v >> 1L;
    v |= v >> 2L;
    v |= v >> 4L;
    v |= v >> 8L;
    v |= v >> 16L;
    v |= v >> 32L;
    return v - (v >>> 1L);
  }
  
  public static int nearbyPowerOfTwo(int x) {
    int next = nextHighestPowerOfTwo(x);
    int prev = next >>> 1;
    return (next - x <= x - prev) ? next : prev;
  }
  
  public static long nearbyPowerOfTwo(long x) {
    long next = nextHighestPowerOfTwo(x);
    long prev = next >>> 1L;
    return (next - x <= x - prev) ? next : prev;
  }



  
  public static int nextHighestPowerOfTwo(int v) {
    v--;
    v |= v >> 1;
    v |= v >> 2;
    v |= v >> 4;
    v |= v >> 8;
    v |= v >> 16;
    v++;
    return v;
  }



  
  public static long nextHighestPowerOfTwo(long v) {
    v--;
    v |= v >> 1L;
    v |= v >> 2L;
    v |= v >> 4L;
    v |= v >> 8L;
    v |= v >> 16L;
    v |= v >> 32L;
    v++;
    return v;
  }
  
  public static long align(long value, int alignment) {
    assert isPowerOfTwo(alignment) : "alignment must be a power of 2:" + alignment;
    return value + (alignment - 1) & (alignment - 1 ^ 0xFFFFFFFF);
  }

  
  public static long ceilDiv(long dividend, long divisor) { return 1L + (-1L + dividend) / divisor; }


  
  private BitUtil() { throw new UnsupportedOperationException("No instances"); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\BitUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */