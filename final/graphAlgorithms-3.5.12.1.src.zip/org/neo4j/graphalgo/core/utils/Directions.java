package org.neo4j.graphalgo.core.utils;

import org.neo4j.graphdb.Direction;




















































public class Directions
{
  public static final Direction DEFAULT_DIRECTION = Direction.OUTGOING;

  
  public static Direction fromString(String directionString) { return fromString(directionString, DEFAULT_DIRECTION); }


  
  public static Direction fromString(String directionString, Direction defaultDirection) {
    if (null == directionString) {
      return defaultDirection;
    }
    
    switch (directionString.toLowerCase()) {
      
      case "outgoing":
      case "out":
      case "o":
      case ">":
        return Direction.OUTGOING;
      
      case "incoming":
      case "in":
      case "i":
      case "<":
        return Direction.INCOMING;
      
      case "both":
      case "b":
      case "<>":
        return Direction.BOTH;
    } 
    
    return defaultDirection;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\Directions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */