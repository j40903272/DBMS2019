package org.neo4j.graphalgo.core.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Objects;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.LockSupport;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntConsumer;
import java.util.function.Supplier;
import java.util.stream.BaseStream;
import org.neo4j.collection.primitive.PrimitiveLongIterable;
import org.neo4j.graphalgo.api.BatchNodeIterable;
import org.neo4j.graphalgo.core.loading.HugeParallelGraphImporter;
import org.neo4j.helpers.Exceptions;






























public final class ParallelUtil
{
  public static final int DEFAULT_BATCH_SIZE = 10000;
  private static final long DEFAULT_WAIT_TIME_NANOS = 1000L;
  private static final long DEFAULT_MAX_NUMBER_OF_RETRIES = 250000000000L;
  
  public static <T extends BaseStream<?, T>, R> R parallelStream(T data, Function<T, R> fn) {
    try {
      return Pools.FJ_POOL.submit(() -> fn.apply(data.parallel())).get();
    } catch (Exception e) {
      throw new RuntimeException(e);
    } 
  }



  
  public static <T extends BaseStream<?, T>> void parallelStreamConsume(T data, Consumer<T> fn) {
    try {
      Pools.FJ_POOL.submit(() -> fn.accept(data.parallel())).get();
    } catch (Exception e) {
      throw new RuntimeException(e);
    } 
  }




  
  public static int threadCount(int batchSize, int elementCount) { return Math.toIntExact(threadCount(batchSize, elementCount)); }

  
  public static long threadCount(long batchSize, long elementCount) {
    if (batchSize <= 0L) {
      throw new IllegalArgumentException("Invalid batch size: " + batchSize);
    }
    if (batchSize >= elementCount) {
      return 1L;
    }
    return BitUtil.ceilDiv(elementCount, batchSize);
  }







  
  public static int adjustedBatchSize(int nodeCount, int concurrency, int minBatchSize) {
    if (concurrency <= 0) {
      concurrency = nodeCount;
    }
    int targetBatchSize = threadCount(concurrency, nodeCount);
    return Math.max(minBatchSize, targetBatchSize);
  }








  
  public static int adjustedBatchSize(int nodeCount, int concurrency) { return adjustedBatchSize(nodeCount, concurrency, 10000); }









  
  public static long adjustedBatchSize(long nodeCount, int concurrency, long minBatchSize) {
    if (concurrency <= 0) {
      concurrency = (int)Math.min(nodeCount, 2147483647L);
    }
    long targetBatchSize = threadCount(concurrency, nodeCount);
    return Math.max(minBatchSize, targetBatchSize);
  }










  
  public static long adjustedBatchSize(long nodeCount, int concurrency, long minBatchSize, long maxBatchSize) { return Math.min(maxBatchSize, adjustedBatchSize(nodeCount, concurrency, minBatchSize)); }







  
  public static long adjustedBatchSize(long nodeCount, long batchSize) {
    if (batchSize <= 0L) {
      batchSize = 1L;
    }
    batchSize = BitUtil.nextHighestPowerOfTwo(batchSize);
    while ((nodeCount + batchSize + 1L) / batchSize > 2147483647L) {
      batchSize <<= 1L;
    }
    return batchSize;
  }

  
  public static boolean canRunInParallel(ExecutorService executor) { return (executor != null && !executor.isShutdown() && !executor.isTerminated()); }












  
  public static <T extends Runnable> void readParallel(int concurrency, int batchSize, BatchNodeIterable idMapping, ExecutorService executor, HugeParallelGraphImporter<T> importer) {
    Collection<PrimitiveLongIterable> iterators = idMapping.batchIterables(batchSize);
    
    int threads = iterators.size();
    
    if (!canRunInParallel(executor) || threads == 1) {
      long nodeOffset = 0L;
      for (PrimitiveLongIterable iterator : iterators) {
        Runnable runnable = importer.newImporter(nodeOffset, iterator);
        runnable.run();
        nodeOffset += batchSize;
      } 
    } else {
      AtomicLong nodeOffset = new AtomicLong();
      Collection<T> importers = LazyMappingCollection.of(iterators, it -> 
          
          importer.newImporter(nodeOffset.getAndAdd(batchSize), it));
      runWithConcurrency(concurrency, (Collection)importers, executor);
    } 
  }





  
  public static void readParallel(int concurrency, long size, ExecutorService executor, BiLongConsumer task) {
    long batchSize = threadCount(concurrency, size);
    if (!canRunInParallel(executor) || concurrency == 1) {
      long start; for (start = 0L; start < size; start += batchSize) {
        long end = Math.min(size, start + batchSize);
        task.apply(start, end);
      } 
    } else {
      Collection<Runnable> threads = new ArrayList<>(concurrency); long start;
      for (start = 0L; start < size; start += batchSize) {
        long end = Math.min(size, start + batchSize);
        long finalStart = start;
        threads.add(() -> task.apply(finalStart, end));
      } 
      run(threads, executor);
    } 
  }


  
  public static Collection<Runnable> tasks(int concurrency, Supplier<? extends Runnable> newTask) {
    Collection<Runnable> tasks = new ArrayList<>();
    for (int i = 0; i < concurrency; i++) {
      tasks.add(newTask.get());
    }
    return tasks;
  }










  
  public static void run(Collection<? extends Runnable> tasks, ExecutorService executor) { run(tasks, executor, null); }





  
  public static void run(Collection<? extends Runnable> tasks, ExecutorService executor, Collection<Future<?>> futures) { awaitTermination(run(tasks, true, executor, futures)); }






  
  public static Collection<Future<?>> run(Collection<? extends Runnable> tasks, boolean allowSynchronousRun, ExecutorService executor, Collection<Future<?>> futures) {
    boolean noExecutor = !canRunInParallel(executor);
    
    if (allowSynchronousRun && (tasks.size() == 1 || noExecutor)) {
      tasks.forEach(Runnable::run);
      return Collections.emptyList();
    } 
    
    if (noExecutor) {
      throw new IllegalStateException("No running executor provided and synchronous execution is not allowed");
    }
    
    if (futures == null) {
      futures = new ArrayList<>(tasks.size());
    } else {
      futures.clear();
    } 
    
    for (Runnable task : tasks) {
      futures.add(executor.submit(task));
    }
    
    return futures;
  }





  
  public static void run(Collection<? extends Runnable> tasks, Runnable selfTask, ExecutorService executor, Collection<Future<?>> futures) {
    if (tasks.isEmpty()) {
      selfTask.run();
      
      return;
    } 
    if (null == executor) {
      tasks.forEach(Runnable::run);
      selfTask.run();
      
      return;
    } 
    if (executor.isShutdown() || executor.isTerminated()) {
      throw new IllegalStateException("Executor is shut down");
    }
    
    if (futures == null) {
      futures = new ArrayList<>(tasks.size());
    } else {
      futures.clear();
    } 
    
    for (Runnable task : tasks) {
      futures.add(executor.submit(task));
    }
    
    awaitTermination(futures);
  }








































  
  public static void runWithConcurrency(int concurrency, Collection<? extends Runnable> tasks, ExecutorService executor) { runWithConcurrency(concurrency, tasks, 1000L, 250000000000L, TerminationFlag.RUNNING_TRUE, executor); }
















































  
  public static void runWithConcurrency(int concurrency, Collection<? extends Runnable> tasks, long maxRetries, ExecutorService executor) { runWithConcurrency(concurrency, tasks, 1000L, maxRetries, TerminationFlag.RUNNING_TRUE, executor); }





















































  
  public static void runWithConcurrency(int concurrency, Collection<? extends Runnable> tasks, TerminationFlag terminationFlag, ExecutorService executor) { runWithConcurrency(concurrency, tasks, 1000L, 250000000000L, terminationFlag, executor); }





















































  
  public static void runWithConcurrency(int concurrency, Collection<? extends Runnable> tasks, long waitTime, TimeUnit timeUnit, ExecutorService executor) {
    runWithConcurrency(concurrency, tasks, timeUnit

        
        .toNanos(waitTime), 2147483647L, TerminationFlag.RUNNING_TRUE, executor);
  }























































  
  public static void runWithConcurrency(int concurrency, Collection<? extends Runnable> tasks, long waitTime, TimeUnit timeUnit, TerminationFlag terminationFlag, ExecutorService executor) {
    runWithConcurrency(concurrency, tasks, timeUnit

        
        .toNanos(waitTime), 2147483647L, terminationFlag, executor);
  }



















































  
  public static void runWithConcurrency(int concurrency, Collection<? extends Runnable> tasks, long maxRetries, long waitTime, TimeUnit timeUnit, ExecutorService executor) {
    runWithConcurrency(concurrency, tasks, timeUnit

        
        .toNanos(waitTime), maxRetries, TerminationFlag.RUNNING_TRUE, executor);
  }

























































  
  public static void runWithConcurrency(int concurrency, Collection<? extends Runnable> tasks, long maxRetries, long waitTime, TimeUnit timeUnit, TerminationFlag terminationFlag, ExecutorService executor) {
    runWithConcurrency(concurrency, tasks, timeUnit

        
        .toNanos(waitTime), maxRetries, terminationFlag, executor);
  }









  
  private static void runWithConcurrency(int concurrency, Collection<? extends Runnable> tasks, long waitNanos, long maxWaitRetries, TerminationFlag terminationFlag, ExecutorService executor) {
    if (!canRunInParallel(executor) || tasks
      .size() == 1 || concurrency <= 1) {
      
      for (Runnable task : tasks) {
        terminationFlag.assertRunning();
        task.run();
      } 
      
      return;
    } 
    CompletionService completionService = new CompletionService(executor, concurrency);


    
    PushbackIterator<Runnable> ts = new PushbackIterator<>(tasks.iterator());
    
    Throwable error = null;

    
    try {
      int i = concurrency;
      
      while (i-- > 0 && terminationFlag.running() && completionService.trySubmit(ts));

      
      terminationFlag.assertRunning();

      
      int tries = 0;
      while (ts.hasNext()) {
        if (completionService.hasTasks()) {
          try {
            completionService.awaitNext();
          } catch (ExecutionException e) {
            error = Exceptions.chain(error, e.getCause());
          } catch (CancellationException cancellationException) {}
        }

        
        terminationFlag.assertRunning();
        
        if (!completionService.trySubmit(ts) && !completionService.hasTasks()) {
          if (++tries >= maxWaitRetries)
            throw new IllegalThreadStateException(String.format("Attempted to submit tasks for %d times with a %d nanosecond delay (%d milliseconds) between each attempt, but ran out of time", new Object[] {
                    
                    Integer.valueOf(tries), 
                    Long.valueOf(waitNanos), 
                    Long.valueOf(TimeUnit.NANOSECONDS.toMillis(waitNanos))
                  })); 
          LockSupport.parkNanos(waitNanos);
        } 
      } 

      
      while (completionService.hasTasks()) {
        terminationFlag.assertRunning();
        try {
          completionService.awaitNext();
        } catch (ExecutionException e) {
          error = Exceptions.chain(error, e.getCause());
        } catch (CancellationException cancellationException) {}
      }
    
    } catch (InterruptedException e) {
      error = (error == null) ? e : Exceptions.chain(e, error);
    } finally {
      finishRunWithConcurrency(completionService, error);
    } 
  }




  
  private static void finishRunWithConcurrency(CompletionService completionService, Throwable error) {
    completionService.cancelAll();
    if (error != null) {
      throw Exceptions.launderedException(error);
    }
  }
  
  public static void awaitTermination(Collection<Future<?>> futures) {
    boolean done = false;
    Throwable error = null;
    try {
      for (Future<?> future : futures) {
        try {
          future.get();
        } catch (ExecutionException ee) {
          Throwable cause = ee.getCause();
          if (error != cause) {
            error = Exceptions.chain(error, cause);
          }
        } catch (CancellationException cancellationException) {}
      } 
      
      done = true;
    } catch (InterruptedException e) {
      error = Exceptions.chain(e, error);
    } finally {
      if (!done) {
        for (Future<?> future : futures) {
          future.cancel(false);
        }
      }
    } 
    if (error != null) {
      throw Exceptions.launderedException(error);
    }
  }
  
  public static void awaitTerminations(Queue<Future<?>> futures) {
    boolean done = false;
    Throwable error = null;
    try {
      while (!futures.isEmpty()) {
        try {
          ((Future)futures.poll()).get();
        } catch (ExecutionException ee) {
          error = Exceptions.chain(error, ee.getCause());
        } catch (CancellationException cancellationException) {}
      } 
      
      done = true;
    } catch (InterruptedException e) {
      error = Exceptions.chain(e, error);
    } finally {
      if (!done) {
        for (Future<?> future : futures) {
          future.cancel(false);
        }
      }
    } 
    if (error != null) {
      throw Exceptions.launderedException(error);
    }
  }




  
  public static void iterateParallel(ExecutorService executorService, int size, int concurrency, IntConsumer consumer) {
    if (!canRunInParallel(executorService)) {
      throw new IllegalArgumentException("no executor available to run the tasks in parallel");
    }
    Collection<Future<?>> futures = new ArrayList<>();
    int batchSize = threadCount(concurrency, size); int i;
    for (i = 0; i < size; i += batchSize) {
      int start = i;
      int end = Math.min(size, start + batchSize);
      futures.add(executorService.submit(() -> {
              for (int j = start; j < end; j++) {
                consumer.accept(j);
              }
            }));
    } 
    awaitTermination(futures);
  }

  
  private static final class CompletionService
  {
    private final Executor executor;
    
    private final ThreadPoolExecutor pool;
    private final int availableConcurrency;
    private final Set<Future<Void>> running;
    private final BlockingQueue<Future<Void>> completionQueue;
    
    private class QueueingFuture
      extends FutureTask<Void>
    {
      QueueingFuture(Runnable runnable) {
        super(runnable, null);
        ParallelUtil.CompletionService.this.running.add(this);
      }

      
      protected void done() {
        ParallelUtil.CompletionService.this.running.remove(this);
        if (!isCancelled())
        {
          while (!ParallelUtil.CompletionService.this.completionQueue.offer(this));
        }
      }
    }
    
    CompletionService(ExecutorService executor, int targetConcurrency) {
      if (!ParallelUtil.canRunInParallel(executor)) {
        throw new IllegalArgumentException("executor already terminated or not usable");
      }
      
      if (executor instanceof ThreadPoolExecutor) {
        this.pool = (ThreadPoolExecutor)executor;
        this.availableConcurrency = this.pool.getCorePoolSize();
        int capacity = Math.max(targetConcurrency, this.availableConcurrency) + 1;
        this.completionQueue = new ArrayBlockingQueue<>(capacity);
      } else {
        this.pool = null;
        this.availableConcurrency = Integer.MAX_VALUE;
        this.completionQueue = new LinkedBlockingQueue<>();
      } 
      
      this.executor = executor;
      this.running = Collections.newSetFromMap(new ConcurrentHashMap<>());
    }
    
    boolean trySubmit(ParallelUtil.PushbackIterator<Runnable> tasks) {
      if (tasks.hasNext()) {
        Runnable next = tasks.next();
        if (submit(next)) {
          return true;
        }
        tasks.pushBack(next);
      } 
      return false;
    }
    
    boolean submit(Runnable task) {
      Objects.requireNonNull(task);
      if (canSubmit()) {
        this.executor.execute(new QueueingFuture(task));
        return true;
      } 
      return false;
    }

    
    boolean hasTasks() { return (!this.running.isEmpty() || !this.completionQueue.isEmpty()); }


    
    void awaitNext() throws InterruptedException, ExecutionException { ((Future)this.completionQueue.take()).get(); }

    
    void cancelAll() {
      stopFuturesAndStopScheduling(this.running);
      stopFutures(this.completionQueue);
    }

    
    private boolean canSubmit() { return (this.pool == null || this.pool.getActiveCount() < this.availableConcurrency); }

    
    private void stopFutures(Collection<Future<Void>> futures) {
      for (Future<Void> future : futures) {
        future.cancel(false);
      }
      futures.clear();
    }
    
    private void stopFuturesAndStopScheduling(Collection<Future<Void>> futures) {
      if (this.pool == null) {
        stopFutures(futures);
        return;
      } 
      for (Future<Void> future : futures) {
        if (future instanceof Runnable) {
          this.pool.remove((Runnable)future);
        }
        future.cancel(false);
      } 
      futures.clear();
      this.pool.purge();
    }
  }
  
  private static final class PushbackIterator<T>
    implements Iterator<T> {
    private final Iterator<? extends T> delegate;
    private T pushedElement;
    
    private PushbackIterator(Iterator<? extends T> delegate) { this.delegate = delegate; }



    
    public boolean hasNext() { return (this.pushedElement != null || this.delegate.hasNext()); }


    
    public T next() {
      T el;
      if ((el = this.pushedElement) != null) {
        this.pushedElement = null;
      } else {
        el = this.delegate.next();
      } 
      return el;
    }
    
    void pushBack(T element) {
      if (this.pushedElement != null) {
        throw new IllegalArgumentException("Cannot push back twice");
      }
      this.pushedElement = element;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\cor\\utils\ParallelUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */