package org.neo4j.graphalgo.core;

import java.util.Set;
import org.neo4j.graphalgo.PropertyMapping;
import org.neo4j.graphalgo.PropertyMappings;
import org.neo4j.graphalgo.RelationshipTypeMapping;
import org.neo4j.graphalgo.RelationshipTypeMappings;
import org.neo4j.graphalgo.api.GraphSetup;
import org.neo4j.graphalgo.core.utils.RelationshipTypes;
import org.neo4j.graphalgo.core.utils.StatementFunction;
import org.neo4j.internal.kernel.api.Read;
import org.neo4j.internal.kernel.api.TokenRead;
import org.neo4j.internal.kernel.api.exceptions.KernelException;
import org.neo4j.kernel.api.KernelTransaction;
import org.neo4j.kernel.impl.newapi.InternalReadOps;
import org.neo4j.kernel.internal.GraphDatabaseAPI;





















public final class GraphDimensionsReader
  extends StatementFunction<GraphDimensions>
{
  private final GraphSetup setup;
  private final boolean readTokens;
  
  public GraphDimensionsReader(GraphDatabaseAPI api, GraphSetup setup, boolean readTokens) {
    super(api);
    this.setup = setup;
    this.readTokens = readTokens;
  }

  
  public GraphDimensions apply(KernelTransaction transaction) throws RuntimeException {
    TokenRead tokenRead = transaction.tokenRead();
    Read dataRead = transaction.dataRead();
    
    int labelId = (this.readTokens && !this.setup.loadAnyLabel()) ? tokenRead.nodeLabel(this.setup.startLabel) : -1;

    
    RelationshipTypeMappings.Builder mappingsBuilder = new RelationshipTypeMappings.Builder();
    if (this.readTokens && !this.setup.loadAnyRelationshipType()) {
      Set<String> types = RelationshipTypes.parse(this.setup.relationshipType);
      for (String typeName : types) {
        int typeId = tokenRead.relationshipType(typeName);
        RelationshipTypeMapping typeMapping = RelationshipTypeMapping.of(typeName, typeId);
        mappingsBuilder.addMapping(typeMapping);
      } 
    } 
    RelationshipTypeMappings relationshipTypeMappings = mappingsBuilder.build();
    
    PropertyMappings nodeProperties = loadPropertyMapping(tokenRead, this.setup.nodePropertyMappings);
    PropertyMappings relProperties = loadPropertyMapping(tokenRead, this.setup.relationshipPropertyMappings);
    
    long nodeCount = dataRead.countsForNode(labelId);
    long allNodesCount = InternalReadOps.getHighestPossibleNodeCount(dataRead, this.api);



    
    long maxRelCount = relationshipTypeMappings.stream().filter(RelationshipTypeMapping::doesExist).mapToLong(m -> maxRelCountForLabelAndType(dataRead, labelId, m.typeId())).sum();
    
    return (new GraphDimensions.Builder())
      .setNodeCount(nodeCount)
      .setHighestNeoId(allNodesCount)
      .setMaxRelCount(maxRelCount)
      .setLabelId(labelId)
      .setNodeProperties(nodeProperties)
      .setRelationshipTypeMappings(relationshipTypeMappings)
      .setRelationshipProperties(relProperties)
      .build();
  }
  
  private PropertyMappings loadPropertyMapping(TokenRead tokenRead, PropertyMappings propertyMappings) {
    PropertyMappings.Builder builder = new PropertyMappings.Builder();
    for (PropertyMapping mapping : propertyMappings) {
      String propertyName = mapping.neoPropertyKey();
      int key = (propertyName != null) ? tokenRead.propertyKey(propertyName) : -1;
      builder.addMapping(mapping.resolveWith(key));
    } 
    return builder.build();
  }
  
  private static long maxRelCountForLabelAndType(Read dataRead, int labelId, int id) {
    return Math.max(dataRead
        .countsForRelationshipWithoutTxState(labelId, id, -1), dataRead
        .countsForRelationshipWithoutTxState(-1, id, labelId));
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\core\GraphDimensionsReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */