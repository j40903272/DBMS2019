package org.neo4j.graphalgo.api;

import java.util.Optional;
import org.neo4j.graphdb.Direction;

























public interface Graph
  extends IdMapping, Degrees, NodeIterator, BatchNodeIterable, RelationshipIterator, RelationshipProperties, RelationshipAccess, NodePropertyContainer
{
  public static final String TYPE = "huge";
  public static final long RELATIONSHIP_COUNT_NOT_SUPPORTED = -1L;
  
  default boolean isEmpty() { return (nodeCount() == 0L); }




  
  long relationshipCount();



  
  default void release() {
    releaseTopology();
    releaseProperties();
  }



  
  default void releaseTopology() {}


  
  default void releaseProperties() {}


  
  default String getType() { return "huge"; }

  
  boolean isUndirected();
  
  boolean hasRelationshipProperty();
  
  Direction getLoadDirection();
  
  default Optional<Direction> compatibleDirection(Direction procedureDirection) {
    boolean isUndirected = isUndirected();
    Direction loadDirection = getLoadDirection();
    
    switch (procedureDirection) {
      case OUTGOING:
        if (!isUndirected && (loadDirection == Direction.BOTH || loadDirection == Direction.OUTGOING)) {
          return Optional.of(Direction.OUTGOING);
        }
        break;
      case INCOMING:
        if (!isUndirected && (loadDirection == Direction.BOTH || loadDirection == Direction.INCOMING)) {
          return Optional.of(Direction.INCOMING);
        }
        break;
      case BOTH:
        if (isUndirected && loadDirection == Direction.OUTGOING) {
          return Optional.of(Direction.OUTGOING);
        }
        if (!isUndirected && loadDirection == Direction.BOTH) {
          return Optional.of(Direction.BOTH);
        }
        break;
    } 
    
    return Optional.empty();
  }
  
  void canRelease(boolean paramBoolean);
  
  RelationshipIntersect intersection();
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\api\Graph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */