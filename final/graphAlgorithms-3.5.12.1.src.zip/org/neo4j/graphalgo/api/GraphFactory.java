package org.neo4j.graphalgo.api;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import org.neo4j.graphalgo.core.GraphDimensions;
import org.neo4j.graphalgo.core.GraphDimensionsReader;
import org.neo4j.graphalgo.core.loading.ApproximatedImportProgress;
import org.neo4j.graphalgo.core.loading.ImportProgress;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.mem.Assessable;
import org.neo4j.kernel.internal.GraphDatabaseAPI;
import org.neo4j.logging.Log;

























public abstract class GraphFactory
  implements Assessable
{
  public static final String TASK_LOADING = "LOADING";
  protected final ExecutorService threadPool;
  protected final GraphDatabaseAPI api;
  protected final GraphSetup setup;
  protected final GraphDimensions dimensions;
  protected final ImportProgress progress;
  protected final Log log;
  protected final ProgressLogger progressLogger;
  
  public GraphFactory(GraphDatabaseAPI api, GraphSetup setup) { this(api, setup, true); }

  
  public GraphFactory(GraphDatabaseAPI api, GraphSetup setup, boolean readTokens) {
    this.threadPool = setup.executor;
    this.api = api;
    this.setup = setup;
    this.log = setup.log;
    this.progressLogger = progressLogger(this.log, setup.logMillis);
    this.dimensions = (GraphDimensions)(new GraphDimensionsReader(api, setup, readTokens)).call();
    this.progress = importProgress(this.progressLogger, this.dimensions, setup);
  }
  
  public Graph build() {
    validateTokens();
    return importGraph();
  }
  
  protected abstract Graph importGraph();
  
  protected void validateTokens() {
    this.dimensions.checkValidNodePredicate(this.setup);
    this.dimensions.checkValidRelationshipTypePredicate(this.setup);
    this.dimensions.checkValidNodeProperties();
    this.dimensions.checkValidRelationshipProperty();
  }

  
  public GraphDimensions dimensions() { return this.dimensions; }




  
  protected ImportProgress importProgress(ProgressLogger progressLogger, GraphDimensions dimensions, GraphSetup setup) {
    long relOperations = 0L;
    if (setup.loadIncoming || setup.loadAsUndirected) {
      relOperations += dimensions.maxRelCount();
    }
    if (setup.loadOutgoing || setup.loadAsUndirected) {
      relOperations += dimensions.maxRelCount();
    }
    return (ImportProgress)new ApproximatedImportProgress(progressLogger, setup.tracker, dimensions

        
        .nodeCount(), relOperations);
  }



  
  private static ProgressLogger progressLogger(Log log, long time) { return ProgressLogger.wrap(log, "LOADING", time, TimeUnit.MILLISECONDS); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\api\GraphFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */