package org.neo4j.graphalgo.api;

import org.neo4j.graphdb.Direction;
























public interface RelationshipPredicate
{
  boolean exists(long paramLong1, long paramLong2, Direction paramDirection);
  
  default boolean exists(long sourceNodeId, long targetNodeId) { return exists(sourceNodeId, targetNodeId, Direction.OUTGOING); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\api\RelationshipPredicate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */