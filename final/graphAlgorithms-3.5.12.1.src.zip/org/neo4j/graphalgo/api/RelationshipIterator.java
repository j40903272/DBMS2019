package org.neo4j.graphalgo.api;

import org.neo4j.graphdb.Direction;


















































public interface RelationshipIterator
  extends RelationshipPredicate
{
  void forEachRelationship(long paramLong, Direction paramDirection, RelationshipConsumer paramRelationshipConsumer);
  
  void forEachRelationship(long paramLong, Direction paramDirection, double paramDouble, RelationshipWithPropertyConsumer paramRelationshipWithPropertyConsumer);
  
  default void forEachIncoming(long nodeId, RelationshipConsumer consumer) { forEachRelationship(nodeId, Direction.INCOMING, consumer); }




  
  default void forEachOutgoing(long nodeId, RelationshipConsumer consumer) { forEachRelationship(nodeId, Direction.OUTGOING, consumer); }






  
  default RelationshipIterator concurrentCopy() { return this; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\api\RelationshipIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */