package org.neo4j.graphalgo.api;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import org.neo4j.graphalgo.PropertyMapping;
import org.neo4j.graphalgo.PropertyMappings;
import org.neo4j.graphalgo.core.DeduplicationStrategy;
import org.neo4j.graphalgo.core.utils.Pools;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphdb.Direction;
import org.neo4j.logging.Log;
import org.neo4j.logging.NullLog;
















































public class GraphSetup
{
  public final String name;
  public final String startLabel;
  public final String endLabel;
  public final String relationshipType;
  public final Direction direction;
  public final boolean loadIncoming;
  public final boolean loadOutgoing;
  public final boolean loadBoth;
  @Deprecated
  public final Optional<Double> relationshipDefaultPropertyValue;
  public final Map<String, Object> params;
  public final Log log;
  public final long logMillis;
  public final AllocationTracker tracker;
  public final TerminationFlag terminationFlag;
  public final ExecutorService executor;
  public final int concurrency;
  public final int batchSize;
  public final boolean sort;
  public final boolean loadAsUndirected;
  public final PropertyMappings nodePropertyMappings;
  public final PropertyMappings relationshipPropertyMappings;
  public final DeduplicationStrategy deduplicationStrategy;
  
  public GraphSetup() { this(null, null, null, 1.0D, null); }






  
  public GraphSetup(String label, String relation, String weightProperty, double defaultWeight, ExecutorService executor) {
    this(label, label, relation, Direction.BOTH, 



        
        Collections.emptyMap(), executor, Pools.DEFAULT_CONCURRENCY, -1, DeduplicationStrategy.NONE, 



        
        (Log)NullLog.getInstance(), -1L, false, false, AllocationTracker.EMPTY, TerminationFlag.RUNNING_TRUE, null, 





        
        PropertyMappings.of(new PropertyMapping[0]), 
        PropertyMappings.of(new PropertyMapping[] { PropertyMapping.of(weightProperty, weightProperty, defaultWeight) }));
  }































  
  public GraphSetup(String startLabel, String endLabel, String relationshipType, Direction direction, Map<String, Object> params, ExecutorService executor, int concurrency, int batchSize, DeduplicationStrategy deduplicationStrategy, Log log, long logMillis, boolean sort, boolean loadAsUndirected, AllocationTracker tracker, TerminationFlag terminationFlag, String name, PropertyMappings nodePropertyMappings, PropertyMappings relationshipPropertyMappings) {
    this.startLabel = startLabel;
    this.endLabel = endLabel;
    this.relationshipType = relationshipType;
    this.loadOutgoing = (direction == Direction.OUTGOING || direction == Direction.BOTH);
    this.loadIncoming = (direction == Direction.INCOMING || direction == Direction.BOTH);
    this.loadBoth = (this.loadOutgoing && this.loadIncoming);
    this.direction = direction;
    this.relationshipDefaultPropertyValue = relationshipPropertyMappings.defaultWeight();
    this.params = (params == null) ? Collections.emptyMap() : params;
    this.executor = executor;
    this.concurrency = concurrency;
    this.batchSize = batchSize;
    this.deduplicationStrategy = deduplicationStrategy;
    this.log = log;
    this.logMillis = logMillis;
    this.sort = sort;
    this.loadAsUndirected = loadAsUndirected;
    this.tracker = tracker;
    this.terminationFlag = terminationFlag;
    this.name = name;
    this.nodePropertyMappings = nodePropertyMappings;
    this.relationshipPropertyMappings = relationshipPropertyMappings;
  }

  
  public boolean loadConcurrent() { return (this.executor != null); }

  
  public int concurrency() {
    if (!loadConcurrent()) {
      return 1;
    }
    return this.concurrency;
  }

  
  public boolean shouldLoadRelationshipProperties() { return this.relationshipPropertyMappings.hasMappings(); }


  
  public boolean loadAnyLabel() { return (this.startLabel == null || this.startLabel.isEmpty()); }


  
  public boolean loadAnyRelationshipType() { return (this.relationshipType == null); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\api\GraphSetup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */