package org.neo4j.graphalgo.linkprediction;

import java.util.Map;
import java.util.Set;
import org.neo4j.graphalgo.core.ProcedureConfiguration;
import org.neo4j.graphdb.Direction;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.RelationshipType;
import org.neo4j.kernel.internal.GraphDatabaseAPI;
import org.neo4j.procedure.Context;
import org.neo4j.procedure.Description;
import org.neo4j.procedure.Name;
import org.neo4j.procedure.UserFunction;
























public class LinkPredictionFunc
{
  @Context
  public GraphDatabaseAPI api;
  
  @UserFunction("algo.linkprediction.adamicAdar")
  @Description("algo.linkprediction.adamicAdar(node1:Node, node2:Node, {relationshipQuery:'relationshipName', direction:'BOTH'}) given two nodes, calculate Adamic Adar similarity")
  public double adamicAdarSimilarity(@Name("node1") Node node1, @Name("node2") Node node2, @Name(value = "config", defaultValue = "{}") Map<String, Object> config) {
    if (node1 == null || node2 == null) {
      throw new RuntimeException("Nodes must not be null");
    }
    
    ProcedureConfiguration configuration = ProcedureConfiguration.create(config);
    RelationshipType relationshipType = configuration.getRelationship();
    Direction direction = configuration.getDirection(Direction.BOTH);
    
    Set<Node> neighbors = (new NeighborsFinder(this.api)).findCommonNeighbors(node1, node2, relationshipType, direction);
    return neighbors.stream().mapToDouble(nb -> 1.0D / Math.log(degree(nb, relationshipType, direction))).sum();
  }




  
  @UserFunction("algo.linkprediction.resourceAllocation")
  @Description("algo.linkprediction.resourceAllocation(node1:Node, node2:Node, {relationshipQuery:'relationshipName', direction:'BOTH'}) given two nodes, calculate Resource Allocation similarity")
  public double resourceAllocationSimilarity(@Name("node1") Node node1, @Name("node2") Node node2, @Name(value = "config", defaultValue = "{}") Map<String, Object> config) {
    if (node1 == null || node2 == null) {
      throw new RuntimeException("Nodes must not be null");
    }
    
    ProcedureConfiguration configuration = ProcedureConfiguration.create(config);
    RelationshipType relationshipType = configuration.getRelationship();
    Direction direction = configuration.getDirection(Direction.BOTH);
    
    Set<Node> neighbors = (new NeighborsFinder(this.api)).findCommonNeighbors(node1, node2, relationshipType, direction);
    return neighbors.stream().mapToDouble(nb -> 1.0D / degree(nb, relationshipType, direction)).sum();
  }


  
  @UserFunction("algo.linkprediction.commonNeighbors")
  @Description("algo.linkprediction.commonNeighbors(node1:Node, node2:Node, {relationshipQuery:'relationshipName', direction:'BOTH'}) given two nodes, returns the number of common neighbors")
  public double commonNeighbors(@Name("node1") Node node1, @Name("node2") Node node2, @Name(value = "config", defaultValue = "{}") Map<String, Object> config) {
    if (node1 == null || node2 == null) {
      throw new RuntimeException("Nodes must not be null");
    }
    
    ProcedureConfiguration configuration = ProcedureConfiguration.create(config);
    RelationshipType relationshipType = configuration.getRelationship();
    Direction direction = configuration.getDirection(Direction.BOTH);
    
    Set<Node> neighbors = (new NeighborsFinder(this.api)).findCommonNeighbors(node1, node2, relationshipType, direction);
    return neighbors.size();
  }


  
  @UserFunction("algo.linkprediction.preferentialAttachment")
  @Description("algo.linkprediction.preferentialAttachment(node1:Node, node2:Node, {relationshipQuery:'relationshipName', direction:'BOTH'}) given two nodes, calculate Preferential Attachment")
  public double preferentialAttachment(@Name("node1") Node node1, @Name("node2") Node node2, @Name(value = "config", defaultValue = "{}") Map<String, Object> config) {
    if (node1 == null || node2 == null) {
      throw new RuntimeException("Nodes must not be null");
    }
    
    ProcedureConfiguration configuration = ProcedureConfiguration.create(config);
    RelationshipType relationshipType = configuration.getRelationship();
    Direction direction = configuration.getDirection(Direction.BOTH);
    
    return (degree(node1, relationshipType, direction) * degree(node2, relationshipType, direction));
  }


  
  @UserFunction("algo.linkprediction.totalNeighbors")
  @Description("algo.linkprediction.totalNeighbors(node1:Node, node2:Node, {relationshipQuery:'relationshipName', direction:'BOTH'}) given two nodes, calculate Total Neighbors")
  public double totalNeighbors(@Name("node1") Node node1, @Name("node2") Node node2, @Name(value = "config", defaultValue = "{}") Map<String, Object> config) {
    ProcedureConfiguration configuration = ProcedureConfiguration.create(config);
    RelationshipType relationshipType = configuration.getRelationship();
    Direction direction = configuration.getDirection(Direction.BOTH);
    
    NeighborsFinder neighborsFinder = new NeighborsFinder(this.api);
    return neighborsFinder.findNeighbors(node1, node2, relationshipType, direction).size();
  }


  
  @UserFunction("algo.linkprediction.sameCommunity")
  @Description("algo.linkprediction.sameCommunity(node1:Node, node2:Node, communityProperty: String) given two nodes, indicates if they have the same community")
  public double sameCommunity(@Name("node1") Node node1, @Name("node2") Node node2, @Name(value = "communityProperty", defaultValue = "community") String communityProperty) {
    if (!node1.hasProperty(communityProperty) || !node2.hasProperty(communityProperty)) {
      return 0.0D;
    }
    return node1.getProperty(communityProperty).equals(node2.getProperty(communityProperty)) ? 1.0D : 0.0D;
  }

  
  private int degree(Node node, RelationshipType relationshipType, Direction direction) { return (relationshipType == null) ? node.getDegree(direction) : node.getDegree(relationshipType, direction); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\linkprediction\LinkPredictionFunc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */