package org.neo4j.graphalgo.beta.pregel;

import java.util.Queue;
import org.neo4j.graphdb.Direction;






















public abstract class Computation
{
  private Pregel.ComputeStep computeStep;
  
  protected abstract void compute(long paramLong, Queue<Double> paramQueue);
  
  protected void voteToHalt(long nodeId) { this.computeStep.voteToHalt(nodeId); }


  
  protected int getSuperstep() { return this.computeStep.getIteration(); }


  
  protected double getNodeValue(long nodeId) { return this.computeStep.getNodeValue(nodeId); }


  
  protected void setNodeValue(long nodeId, double value) { this.computeStep.setNodeValue(nodeId, value); }


  
  protected void sendMessages(long nodeId, double message) { sendMessages(nodeId, message, getMessageDirection()); }


  
  protected void sendMessages(long nodeId, double message, Direction direction) { this.computeStep.sendMessages(nodeId, message, direction); }


  
  protected int getDegree(long nodeId) { return getDegree(nodeId, getMessageDirection()); }


  
  protected int getDegree(long nodeId, Direction direction) { return this.computeStep.getDegree(nodeId, direction); }


  
  protected Direction getMessageDirection() { return Direction.OUTGOING; }


  
  protected double getDefaultNodeValue() { return -1.0D; }


  
  void setComputeStep(Pregel.ComputeStep computeStep) { this.computeStep = computeStep; }


  
  protected boolean supportsAsynchronousParallel() { return false; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\beta\pregel\Computation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */