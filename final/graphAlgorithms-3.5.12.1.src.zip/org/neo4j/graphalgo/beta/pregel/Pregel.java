package org.neo4j.graphalgo.beta.pregel;

import com.carrotsearch.hppc.BitSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ExecutorService;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.LongStream;
import java.util.stream.Stream;
import org.jctools.queues.MpscArrayQueue;
import org.jctools.queues.MpscLinkedQueue;
import org.neo4j.collection.primitive.PrimitiveLongCollections;
import org.neo4j.collection.primitive.PrimitiveLongIterable;
import org.neo4j.collection.primitive.PrimitiveLongIterator;
import org.neo4j.graphalgo.api.Degrees;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.LazyBatchCollection;
import org.neo4j.graphalgo.core.utils.LazyMappingCollection;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeDoubleArray;
import org.neo4j.graphalgo.core.utils.paged.HugeObjectArray;
import org.neo4j.graphdb.Direction;





















public final class Pregel
{
  private static final Double TERMINATION_SYMBOL = Double.valueOf(NaND);

  
  private final Supplier<Computation> computationFactory;

  
  private final Graph graph;

  
  private final HugeDoubleArray nodeValues;

  
  private final HugeObjectArray<? extends Queue<Double>> messageQueues;

  
  private final int batchSize;
  
  private final int concurrency;
  
  private final ExecutorService executor;
  
  private int iterations;

  
  public static Pregel withDefaultNodeValues(Graph graph, Supplier<Computation> computationFactory, int batchSize, int concurrency, ExecutorService executor, AllocationTracker tracker) {
    double defaultNodeValue = ((Computation)computationFactory.get()).getDefaultNodeValue();
    HugeDoubleArray hugeDoubleArray = HugeDoubleArray.newArray(graph.nodeCount(), tracker);
    ParallelUtil.parallelStreamConsume(
        LongStream.range(0L, graph.nodeCount()), nodeIds -> 
        nodeIds.forEach(()));

    
    return new Pregel(graph, computationFactory, hugeDoubleArray, batchSize, concurrency, executor, tracker);
  }

















  
  public static Pregel withInitialNodeValues(Graph graph, Supplier<Computation> computationFactory, NodeProperties initialNodeValues, int batchSize, int concurrency, ExecutorService executor, AllocationTracker tracker) {
    HugeDoubleArray hugeDoubleArray = HugeDoubleArray.newArray(graph.nodeCount(), tracker);
    ParallelUtil.parallelStreamConsume(
        LongStream.range(0L, graph.nodeCount()), nodeIds -> 
        nodeIds.forEach(()));

    
    return new Pregel(graph, computationFactory, hugeDoubleArray, batchSize, concurrency, executor, tracker);
  }















  
  private Pregel(Graph graph, Supplier<Computation> computationFactory, HugeDoubleArray initialNodeValues, int batchSize, int concurrency, ExecutorService executor, AllocationTracker tracker) {
    this.graph = graph;
    this.computationFactory = computationFactory;
    this.nodeValues = initialNodeValues;
    this.batchSize = batchSize;
    this.concurrency = concurrency;
    this.executor = executor;
    
    Direction loadDirection = graph.getLoadDirection();



    
    this
      
      .messageQueues = (loadDirection == Direction.BOTH) ? (HugeObjectArray)initArrayQueues(graph, computationFactory, tracker) : (HugeObjectArray)initLinkedQueues(graph, tracker);
  }
  
  public HugeDoubleArray run(int maxIterations) {
    this.iterations = 0;
    boolean canHalt = false;

    
    BitSet receiverBits = new BitSet(this.graph.nodeCount());
    
    BitSet voteBits = new BitSet(this.graph.nodeCount());

    
    Collection<PrimitiveLongIterable> nodeBatches = LazyBatchCollection.of(this.graph
        .nodeCount(), this.batchSize, (start, length) -> ());


    
    while (this.iterations < maxIterations && !canHalt) {
      int iteration = this.iterations++;
      
      List<ComputeStep> computeSteps = runComputeSteps(nodeBatches, iteration, receiverBits, voteBits);
      
      receiverBits = unionBitSets(computeSteps, ComputeStep::getSenders);
      voteBits = unionBitSets(computeSteps, ComputeStep::getVotes);

      
      if (receiverBits.nextSetBit(0) == -1) {
        canHalt = true;
      }
    } 
    return this.nodeValues;
  }

  
  public int getIterations() { return this.iterations; }

  
  private BitSet unionBitSets(Collection<ComputeStep> computeSteps, Function<ComputeStep, BitSet> fn) {
    return (BitSet)ParallelUtil.parallelStream(computeSteps.stream(), stream -> 


        
        (BitSet)stream.map(fn).reduce(()).orElseGet(BitSet::new));
  }





  
  private List<ComputeStep> runComputeSteps(Collection<PrimitiveLongIterable> nodeBatches, int iteration, BitSet messageBits, BitSet voteToHaltBits) {
    List<ComputeStep> tasks = new ArrayList<>(nodeBatches.size());
    
    if (!((Computation)this.computationFactory.get()).supportsAsynchronousParallel())
    {

      
      if (iteration > 0) {
        ParallelUtil.parallelStreamConsume(
            LongStream.range(0L, this.graph.nodeCount()), nodeIds -> 
            nodeIds.forEach(()));
      }
    }




    
    Collection<ComputeStep> computeSteps = LazyMappingCollection.of(nodeBatches, nodeBatch -> {



          
          ComputeStep task = new ComputeStep(this.computationFactory.get(), this.graph.nodeCount(), iteration, nodeBatch, (Degrees)this.graph, this.nodeValues, messageBits, voteToHaltBits, this.messageQueues, (RelationshipIterator)this.graph);







          
          tasks.add(task);
          return task;
        });
    
    ParallelUtil.runWithConcurrency(this.concurrency, computeSteps, this.executor);
    return tasks;
  }




  
  private HugeObjectArray<MpscArrayQueue<Double>> initArrayQueues(Graph graph, Supplier<Computation> computationFactory, AllocationTracker tracker) {
    Computation computation = computationFactory.get();
    Direction receiveDirection = computation.getMessageDirection().reverse();
    
    int minSize = computation.supportsAsynchronousParallel() ? 0 : 1;
    
    Class<MpscArrayQueue<Double>> queueClass = (Class)(new MpscArrayQueue(0)).getClass();
    
    HugeObjectArray<MpscArrayQueue<Double>> messageQueues = HugeObjectArray.newArray(queueClass, graph
        
        .nodeCount(), tracker);

    
    ParallelUtil.parallelStreamConsume(
        LongStream.range(0L, graph.nodeCount()), nodeIds -> 
        nodeIds.forEach(()));




    
    return messageQueues;
  }



  
  private HugeObjectArray<MpscLinkedQueue<Double>> initLinkedQueues(Graph graph, AllocationTracker tracker) {
    Class<MpscLinkedQueue<Double>> queueClass = (Class)MpscLinkedQueue.newMpscLinkedQueue().getClass();
    
    HugeObjectArray<MpscLinkedQueue<Double>> messageQueues = HugeObjectArray.newArray(queueClass, graph
        
        .nodeCount(), tracker);

    
    ParallelUtil.parallelStreamConsume(
        LongStream.range(0L, graph.nodeCount()), nodeIds -> 
        nodeIds.forEach(()));
    
    return messageQueues;
  }

  
  public static final class ComputeStep
    implements Runnable
  {
    private final int iteration;
    
    private final Computation computation;
    
    private final BitSet senderBits;
    
    private final BitSet receiverBits;
    
    private final BitSet voteBits;
    
    private final PrimitiveLongIterable nodeBatch;
    
    private final Degrees degrees;
    
    private final HugeDoubleArray nodeValues;
    
    private final HugeObjectArray<? extends Queue<Double>> messageQueues;
    private final RelationshipIterator relationshipIterator;
    
    private ComputeStep(Computation computation, long globalNodeCount, int iteration, PrimitiveLongIterable nodeBatch, Degrees degrees, HugeDoubleArray nodeValues, BitSet receiverBits, BitSet voteBits, HugeObjectArray<? extends Queue<Double>> messageQueues, RelationshipIterator relationshipIterator) {
      this.iteration = iteration;
      this.computation = computation;
      this.senderBits = new BitSet(globalNodeCount);
      this.receiverBits = receiverBits;
      this.voteBits = voteBits;
      this.nodeBatch = nodeBatch;
      this.degrees = degrees;
      this.nodeValues = nodeValues;
      this.messageQueues = messageQueues;
      this.relationshipIterator = relationshipIterator.concurrentCopy();
      
      computation.setComputeStep(this);
    }

    
    public void run() {
      PrimitiveLongIterator nodesIterator = this.nodeBatch.iterator();
      
      while (nodesIterator.hasNext()) {
        long nodeId = nodesIterator.next();
        
        if (this.receiverBits.get(nodeId) || !this.voteBits.get(nodeId)) {
          this.voteBits.clear(nodeId);
          this.computation.compute(nodeId, receiveMessages(nodeId));
        } 
      } 
    }

    
    BitSet getSenders() { return this.senderBits; }


    
    BitSet getVotes() { return this.voteBits; }


    
    public int getIteration() { return this.iteration; }


    
    int getDegree(long nodeId, Direction direction) { return this.degrees.degree(nodeId, direction); }


    
    double getNodeValue(long nodeId) { return this.nodeValues.get(nodeId); }


    
    void setNodeValue(long nodeId, double value) { this.nodeValues.set(nodeId, value); }


    
    void voteToHalt(long nodeId) { this.voteBits.set(nodeId); }

    
    void sendMessages(long nodeId, double message, Direction direction) {
      this.relationshipIterator.forEachRelationship(nodeId, direction, (sourceNodeId, targetNodeId) -> {
            ((Queue<Double>)this.messageQueues.get(targetNodeId)).add(Double.valueOf(message));
            this.senderBits.set(targetNodeId);
            return true;
          });
    }

    
    private Queue<Double> receiveMessages(long nodeId) { return this.receiverBits.get(nodeId) ? (Queue<Double>)this.messageQueues.get(nodeId) : null; }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\beta\pregel\Pregel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */