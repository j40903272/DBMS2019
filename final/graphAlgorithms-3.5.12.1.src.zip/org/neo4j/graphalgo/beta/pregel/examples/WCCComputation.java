package org.neo4j.graphalgo.beta.pregel.examples;

import java.util.Queue;
import org.neo4j.graphalgo.beta.pregel.Computation;
import org.neo4j.graphdb.Direction;
























public class WCCComputation
  extends Computation
{
  protected Direction getMessageDirection() { return Direction.BOTH; }



  
  protected boolean supportsAsynchronousParallel() { return true; }


  
  protected void compute(long nodeId, Queue<Double> messages) {
    if (getSuperstep() == 0) {
      double currentValue = getNodeValue(nodeId);
      if (currentValue == getDefaultNodeValue()) {
        sendMessages(nodeId, nodeId);
        setNodeValue(nodeId, nodeId);
      } else {
        sendMessages(nodeId, currentValue);
      } 
    } else {
      long newComponentId = (long)getNodeValue(nodeId);
      boolean hasChanged = false;
      
      if (messages != null) {
        Double message;
        while ((message = messages.poll()) != null) {
          if (message.doubleValue() < newComponentId) {
            newComponentId = message.longValue();
            hasChanged = true;
          } 
        } 
      } 
      
      if (hasChanged) {
        setNodeValue(nodeId, newComponentId);
        sendMessages(nodeId, newComponentId);
      } 
      
      voteToHalt(nodeId);
    } 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\beta\pregel\examples\WCCComputation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */