package org.neo4j.graphalgo.impl.results;

import com.carrotsearch.hppc.cursors.LongLongCursor;
import java.util.Optional;
import java.util.OptionalLong;
import java.util.Set;
import java.util.function.LongUnaryOperator;
import java.util.regex.Pattern;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.HdrHistogram.Histogram;
import org.neo4j.graphalgo.core.utils.ProgressTimer;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeLongLongMap;



















public abstract class AbstractCommunityResultBuilder<R>
  extends AbstractResultBuilder<R>
{
  private static final Pattern PERCENTILE_FIELD_REGEXP = Pattern.compile("^p\\d{1,3}$");
  private static final Pattern COMMUNITY_COUNT_REGEXP = Pattern.compile("^(community|set)Count$");
  
  private static final long EXPECTED_NUMBER_OF_COMMUNITIES_DEFAULT = 4L;
  
  private final boolean buildHistogram;
  private final boolean buildCommunityCount;
  protected long postProcessingDuration = -1L;
  
  private LongUnaryOperator communityFunction = null;
  private OptionalLong maybeExpectedCommunityCount = OptionalLong.empty();
  
  protected OptionalLong maybeCommunityCount = OptionalLong.empty();
  protected Optional<Histogram> maybeCommunityHistogram = Optional.empty();
  
  private final AllocationTracker tracker;
  
  protected AbstractCommunityResultBuilder(Set<String> returnFields, AllocationTracker tracker) {
    this.buildHistogram = returnFields.stream().anyMatch(PERCENTILE_FIELD_REGEXP.asPredicate());
    this
      
      .buildCommunityCount = (this.buildHistogram || returnFields.stream().anyMatch(COMMUNITY_COUNT_REGEXP.asPredicate()));
    this.tracker = tracker;
  }

  
  protected AbstractCommunityResultBuilder(Stream<String> returnFields, AllocationTracker tracker) { this(returnFields.collect((Collector)Collectors.toSet()), tracker); }

  
  protected abstract R buildResult();
  
  public AbstractCommunityResultBuilder<R> withExpectedNumberOfCommunities(long expectedNumberOfCommunities) {
    this.maybeExpectedCommunityCount = OptionalLong.of(expectedNumberOfCommunities);
    return this;
  }
  
  public AbstractCommunityResultBuilder<R> withCommunityFunction(LongUnaryOperator communityFunction) {
    this.communityFunction = communityFunction;
    return this;
  }

  
  public R build() {
    ProgressTimer timer = ProgressTimer.start();
    
    if (this.buildCommunityCount && this.communityFunction != null) {
      long expectedNumberOfCommunities = this.maybeExpectedCommunityCount.orElse(4L);
      HugeLongLongMap communitySizeMap = new HugeLongLongMap(expectedNumberOfCommunities, this.tracker); long nodeId;
      for (nodeId = 0L; nodeId < this.nodeCount; nodeId++) {
        long communityId = this.communityFunction.applyAsLong(nodeId);
        communitySizeMap.addTo(communityId, 1L);
      } 
      
      if (this.buildHistogram) {
        Histogram histogram = new Histogram(5);
        for (LongLongCursor cursor : communitySizeMap) {
          histogram.recordValue(cursor.value);
        }
        this.maybeCommunityHistogram = Optional.of(histogram);
      } 
      
      this.maybeCommunityCount = OptionalLong.of(communitySizeMap.size());
      communitySizeMap.release();
    } 
    
    timer.stop();
    
    this.postProcessingDuration = timer.getDuration();
    
    return buildResult();
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\results\AbstractCommunityResultBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */