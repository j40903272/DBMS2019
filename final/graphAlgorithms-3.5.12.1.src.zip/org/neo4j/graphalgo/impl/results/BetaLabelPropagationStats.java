package org.neo4j.graphalgo.impl.results;

import java.util.stream.Stream;
import org.HdrHistogram.Histogram;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;




















public class BetaLabelPropagationStats
{
  public static final BetaLabelPropagationStats EMPTY = new BetaLabelPropagationStats(0L, 0L, 0L, 0L, 0L, 0L, -1L, -1L, -1L, -1L, -1L, -1L, -1L, -1L, -1L, -1L, 0L, false, false, "<empty>", "<empty>", "<empty>");


  
  public final long loadMillis;


  
  public final long computeMillis;


  
  public final long writeMillis;


  
  public final long postProcessingMillis;

  
  public final long nodes;

  
  public final long communityCount;

  
  public final long ranIterations;

  
  public final boolean didConverge;

  
  public final long p1;

  
  public final long p5;

  
  public final long p10;

  
  public final long p25;

  
  public final long p50;

  
  public final long p75;

  
  public final long p90;

  
  public final long p95;

  
  public final long p99;

  
  public final long p100;

  
  public final String weightProperty;

  
  public final boolean write;

  
  public final String seedProperty;

  
  public final String writeProperty;


  
  public BetaLabelPropagationStats(long loadMillis, long computeMillis, long postProcessingMillis, long writeMillis, long nodes, long communityCount, long p100, long p99, long p95, long p90, long p75, long p50, long p25, long p10, long p5, long p1, long ranIterations, boolean write, boolean didConverge, String weightProperty, String seedProperty, String writeProperty) {
    this.loadMillis = loadMillis;
    this.computeMillis = computeMillis;
    this.postProcessingMillis = postProcessingMillis;
    this.writeMillis = writeMillis;
    this.nodes = nodes;
    this.communityCount = communityCount;
    this.p100 = p100;
    this.p99 = p99;
    this.p95 = p95;
    this.p90 = p90;
    this.p75 = p75;
    this.p50 = p50;
    this.p25 = p25;
    this.p10 = p10;
    this.p5 = p5;
    this.p1 = p1;
    this.ranIterations = ranIterations;
    this.write = write;
    this.didConverge = didConverge;
    this.weightProperty = weightProperty;
    this.seedProperty = seedProperty;
    this.writeProperty = writeProperty;
  }
  
  public static class WriteResultBuilder
    extends AbstractCommunityResultBuilder<BetaLabelPropagationStats> {
    private long ranIterations = 0L;
    
    private boolean didConverge = false;
    private String weightProperty;
    private String seedProperty;
    
    public WriteResultBuilder(Stream<String> returnFields, AllocationTracker tracker) { super(returnFields, tracker); }

    
    public WriteResultBuilder ranIterations(long ranIterations) {
      this.ranIterations = ranIterations;
      return this;
    }
    
    public WriteResultBuilder didConverge(boolean didConverge) {
      this.didConverge = didConverge;
      return this;
    }
    
    public WriteResultBuilder weightProperty(String weightProperty) {
      this.weightProperty = weightProperty;
      return this;
    }
    
    public WriteResultBuilder seedProperty(String seedProperty) {
      this.seedProperty = seedProperty;
      return this;
    }

    
    protected BetaLabelPropagationStats buildResult() {
      return new BetaLabelPropagationStats(this.loadMillis, this.computeMillis, this.writeMillis, this.postProcessingDuration, this.nodeCount, this.maybeCommunityCount




          
          .orElse(-1L), ((Long)this.maybeCommunityHistogram
          .map(histogram -> Long.valueOf(histogram.getValueAtPercentile(100.0D))).orElse(Long.valueOf(-1L))).longValue(), ((Long)this.maybeCommunityHistogram
          .map(histogram -> Long.valueOf(histogram.getValueAtPercentile(99.0D))).orElse(Long.valueOf(-1L))).longValue(), ((Long)this.maybeCommunityHistogram
          .map(histogram -> Long.valueOf(histogram.getValueAtPercentile(95.0D))).orElse(Long.valueOf(-1L))).longValue(), ((Long)this.maybeCommunityHistogram
          .map(histogram -> Long.valueOf(histogram.getValueAtPercentile(90.0D))).orElse(Long.valueOf(-1L))).longValue(), ((Long)this.maybeCommunityHistogram
          .map(histogram -> Long.valueOf(histogram.getValueAtPercentile(75.0D))).orElse(Long.valueOf(-1L))).longValue(), ((Long)this.maybeCommunityHistogram
          .map(histogram -> Long.valueOf(histogram.getValueAtPercentile(50.0D))).orElse(Long.valueOf(-1L))).longValue(), ((Long)this.maybeCommunityHistogram
          .map(histogram -> Long.valueOf(histogram.getValueAtPercentile(25.0D))).orElse(Long.valueOf(-1L))).longValue(), ((Long)this.maybeCommunityHistogram
          .map(histogram -> Long.valueOf(histogram.getValueAtPercentile(10.0D))).orElse(Long.valueOf(-1L))).longValue(), ((Long)this.maybeCommunityHistogram
          .map(histogram -> Long.valueOf(histogram.getValueAtPercentile(5.0D))).orElse(Long.valueOf(-1L))).longValue(), ((Long)this.maybeCommunityHistogram
          .map(histogram -> Long.valueOf(histogram.getValueAtPercentile(1.0D))).orElse(Long.valueOf(-1L))).longValue(), this.ranIterations, this.write, this.didConverge, this.weightProperty, this.seedProperty, this.writeProperty);
    }
  }


  
  public static class BetaStreamResult
  {
    public final long nodeId;

    
    public final long community;


    
    public BetaStreamResult(long nodeId, long community) {
      this.nodeId = nodeId;
      this.community = community;
    }
  }
  
  @Deprecated
  public static class StreamResult {
    public final long nodeId;
    public final long label;
    
    public StreamResult(BetaLabelPropagationStats.BetaStreamResult betaStreamResult) {
      this.nodeId = betaStreamResult.nodeId;
      this.label = betaStreamResult.community;
    }
  }

  
  @Deprecated
  public static class LabelPropagationStats
  {
    public final long loadMillis;
    
    public final long computeMillis;
    public final long writeMillis;
    public final long postProcessingMillis;
    public final long nodes;
    public final long communityCount;
    public final long iterations;
    public final boolean didConverge;
    public final long p1;
    public final long p5;
    public final long p10;
    public final long p25;
    public final long p50;
    public final long p75;
    public final long p90;
    public final long p95;
    public final long p99;
    public final long p100;
    public final String weightProperty;
    public final boolean write;
    public final String seedProperty;
    public final String writeProperty;
    
    public LabelPropagationStats(BetaLabelPropagationStats betaLabelPropagationStats) {
      this.loadMillis = betaLabelPropagationStats.loadMillis;
      this.computeMillis = betaLabelPropagationStats.computeMillis;
      this.postProcessingMillis = betaLabelPropagationStats.postProcessingMillis;
      this.writeMillis = betaLabelPropagationStats.writeMillis;
      this.nodes = betaLabelPropagationStats.nodes;
      this.communityCount = betaLabelPropagationStats.nodes;
      this.p100 = betaLabelPropagationStats.p100;
      this.p99 = betaLabelPropagationStats.p99;
      this.p95 = betaLabelPropagationStats.p95;
      this.p90 = betaLabelPropagationStats.p90;
      this.p75 = betaLabelPropagationStats.p75;
      this.p50 = betaLabelPropagationStats.p50;
      this.p25 = betaLabelPropagationStats.p25;
      this.p10 = betaLabelPropagationStats.p10;
      this.p5 = betaLabelPropagationStats.p5;
      this.p1 = betaLabelPropagationStats.p1;
      this.iterations = betaLabelPropagationStats.ranIterations;
      this.write = betaLabelPropagationStats.write;
      this.didConverge = betaLabelPropagationStats.didConverge;
      this.weightProperty = betaLabelPropagationStats.weightProperty;
      this.seedProperty = betaLabelPropagationStats.seedProperty;
      this.writeProperty = betaLabelPropagationStats.writeProperty;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\results\BetaLabelPropagationStats.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */