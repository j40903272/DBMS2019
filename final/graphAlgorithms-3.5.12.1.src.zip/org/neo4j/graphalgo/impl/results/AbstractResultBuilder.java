package org.neo4j.graphalgo.impl.results;

import java.util.function.Supplier;
import org.neo4j.graphalgo.core.utils.ProgressTimer;





















public abstract class AbstractResultBuilder<R>
{
  protected long loadMillis = -1L;
  protected long computeMillis = -1L;
  protected long writeMillis = -1L;
  
  protected long nodeCount;
  
  protected boolean write = false;
  protected String writeProperty;
  
  public void setLoadMillis(long loadMillis) { this.loadMillis = loadMillis; }


  
  public void setComputeMillis(long computeMillis) { this.computeMillis = computeMillis; }


  
  public void setWriteMillis(long writeMillis) { this.writeMillis = writeMillis; }


  
  public ProgressTimer timeLoad() { return ProgressTimer.start(this::setLoadMillis); }


  
  public ProgressTimer timeEval() { return ProgressTimer.start(this::setComputeMillis); }


  
  public ProgressTimer timeWrite() { return ProgressTimer.start(this::setWriteMillis); }

  
  public void timeLoad(Runnable runnable) {
    try (ProgressTimer ignored = timeLoad()) {
      runnable.run();
    } 
  }
  
  public void timeEval(Runnable runnable) {
    try (ProgressTimer ignored = timeEval()) {
      runnable.run();
    } 
  }
  
  public <U> U timeEval(Supplier<U> supplier) {
    try (ProgressTimer ignored = timeEval()) {
      return supplier.get();
    } 
  }
  
  public void timeWrite(Runnable runnable) {
    try (ProgressTimer ignored = timeWrite()) {
      runnable.run();
    } 
  }
  
  public AbstractResultBuilder<R> withNodeCount(long nodeCount) {
    this.nodeCount = nodeCount;
    return this;
  }
  
  public AbstractResultBuilder<R> withWrite(boolean write) {
    this.write = write;
    return this;
  }
  
  public AbstractResultBuilder<R> withWriteProperty(String writeProperty) {
    this.writeProperty = writeProperty;
    return this;
  }
  
  public abstract R build();
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\results\AbstractResultBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */