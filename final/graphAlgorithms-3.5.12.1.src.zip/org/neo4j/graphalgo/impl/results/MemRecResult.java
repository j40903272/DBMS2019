package org.neo4j.graphalgo.impl.results;

import java.util.Map;
import org.neo4j.graphalgo.core.GraphDimensions;
import org.neo4j.graphalgo.core.utils.mem.MemoryRange;
import org.neo4j.graphalgo.core.utils.mem.MemoryTree;
import org.neo4j.graphalgo.core.utils.mem.MemoryTreeWithDimensions;
import org.neo4j.graphdb.Result;



















public class MemRecResult
{
  public final String requiredMemory;
  public final String treeView;
  public final Map<String, Object> mapView;
  public final long bytesMin;
  public final long bytesMax;
  public long nodes;
  public long relationships;
  
  public MemRecResult(MemoryTreeWithDimensions memory) { this(memory.memoryTree, memory.graphDimensions); }


  
  private MemRecResult(MemoryTree memory, GraphDimensions dimensions) { this(memory.render(), memory.renderMap(), memory.memoryUsage(), dimensions); }





  
  private MemRecResult(String treeView, Map<String, Object> mapView, MemoryRange estimateMemoryUsage, GraphDimensions dimensions) {
    this(estimateMemoryUsage
        .toString(), treeView, mapView, estimateMemoryUsage.min, estimateMemoryUsage.max, dimensions



        
        .nodeCount(), dimensions
        .maxRelCount());
  }








  
  private MemRecResult(String requiredMemory, String treeView, Map<String, Object> mapView, long bytesMin, long bytesMax, long nodes, long relationships) {
    this.requiredMemory = requiredMemory;
    this.treeView = treeView;
    this.mapView = mapView;
    this.bytesMin = bytesMin;
    this.bytesMax = bytesMax;
    this.nodes = nodes;
    this.relationships = relationships;
  }
  
  public MemRecResult(Result.ResultRow row) {
    this(row
        .getString("requiredMemory"), row
        .getString("treeView"), (Map<String, Object>)row
        .get("mapView"), row
        .getNumber("bytesMin").longValue(), row
        .getNumber("bytesMax").longValue(), row
        .getNumber("nodes").longValue(), row
        .getNumber("relationships").longValue());
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\results\MemRecResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */