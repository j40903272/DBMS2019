package org.neo4j.graphalgo.impl.results;

import org.neo4j.graphalgo.impl.pagerank.PageRank;




















public class PageRankScore
{
  public final long nodeId;
  public final Double score;
  
  public PageRankScore(long nodeId, Double score) {
    this.nodeId = nodeId;
    this.score = score;
  }

  
  public static final class Stats
  {
    public final long nodes;
    
    public final long iterations;
    
    public final long loadMillis;
    
    public final long computeMillis;
    
    public final long writeMillis;
    public final double dampingFactor;
    public final boolean write;
    public final String writeProperty;
    
    Stats(long nodes, long iterations, long loadMillis, long computeMillis, long writeMillis, double dampingFactor, boolean write, String writeProperty) {
      this.nodes = nodes;
      this.iterations = iterations;
      this.loadMillis = loadMillis;
      this.computeMillis = computeMillis;
      this.writeMillis = writeMillis;
      this.dampingFactor = dampingFactor;
      this.write = write;
      this.writeProperty = writeProperty;
    }
    
    public static final class Builder
      extends AbstractResultBuilder<Stats> {
      private long iterations;
      private double dampingFactor;
      
      public Builder withConfig(PageRank.Config config) {
        this.dampingFactor = config.dampingFactor;
        this.iterations = config.iterations;
        return this;
      }
      
      public Builder withIterations(long iterations) {
        this.iterations = iterations;
        return this;
      }
      
      public Builder withDampingFactor(double dampingFactor) {
        this.dampingFactor = dampingFactor;
        return this;
      }

      
      public PageRankScore.Stats build() { return new PageRankScore.Stats(this.nodeCount, this.iterations, this.loadMillis, this.computeMillis, this.writeMillis, this.dampingFactor, this.write, this.writeProperty); }
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\results\PageRankScore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */