package org.neo4j.graphalgo.impl.results;




















public class CentralityScore
{
  public final long nodeId;
  public final Double score;
  
  public CentralityScore(long nodeId, Double score) {
    this.nodeId = nodeId;
    this.score = score;
  }

  
  public static final class Stats
  {
    public final long nodes;
    
    public final long loadMillis;
    
    public final long computeMillis;
    
    public final long writeMillis;
    public final boolean write;
    public final String writeProperty;
    
    Stats(long nodes, long loadMillis, long computeMillis, long writeMillis, boolean write, String writeProperty) {
      this.nodes = nodes;
      this.loadMillis = loadMillis;
      this.computeMillis = computeMillis;
      this.writeMillis = writeMillis;
      this.write = write;
      this.writeProperty = writeProperty;
    }
    
    public static final class Builder
      extends AbstractResultBuilder<Stats>
    {
      public CentralityScore.Stats build() { return new CentralityScore.Stats(this.nodeCount, this.loadMillis, this.computeMillis, this.writeMillis, this.write, this.writeProperty); }
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\results\CentralityScore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */