package org.neo4j.graphalgo.impl.results;

import java.util.concurrent.atomic.AtomicLong;
import org.HdrHistogram.DoubleHistogram;








































public class ApproxSimilaritySummaryResult
{
  public final long nodes;
  public final long similarityPairs;
  public final long computations;
  public final boolean write;
  public final String writeRelationshipType;
  public final String writeProperty;
  public final double min;
  public final double max;
  public final double mean;
  public final double stdDev;
  public final double p25;
  public final double p50;
  public final double p75;
  public final double p90;
  public final double p95;
  public final double p99;
  public final double p999;
  public final double p100;
  public final long iterations;
  public final double scanRate;
  
  public ApproxSimilaritySummaryResult(long nodes, long similarityPairs, long computations, boolean write, String writeRelationshipType, String writeProperty, double min, double max, double mean, double stdDev, double p25, double p50, double p75, double p90, double p95, double p99, double p999, double p100, long iterations) {
    this.nodes = nodes;
    this.similarityPairs = similarityPairs;
    this.computations = computations;
    this.write = write;
    this.writeRelationshipType = writeRelationshipType;
    this.writeProperty = writeProperty;
    this.min = min;
    this.max = max;
    this.mean = mean;
    this.stdDev = stdDev;
    this.p25 = p25;
    this.p50 = p50;
    this.p75 = p75;
    this.p90 = p90;
    this.p95 = p95;
    this.p99 = p99;
    this.p999 = p999;
    this.p100 = p100;
    this.iterations = iterations;
    this.scanRate = computeScanRate(nodes, computations);
  }
  
  private double computeScanRate(long nodes, long computations) {
    long maximumComputations = nodes * (nodes - 1L) / 2L;
    return computations * 1.0D / maximumComputations;
  }








  
  public static ApproxSimilaritySummaryResult from(long length, AtomicLong similarityPairs, long computations, String writeRelationshipType, String writeProperty, boolean write, long iterations, DoubleHistogram histogram) {
    return new ApproxSimilaritySummaryResult(length, similarityPairs
        
        .get(), computations, write, writeRelationshipType, writeProperty, histogram



        
        .getMinValue(), histogram
        .getMaxValue(), histogram
        .getMean(), histogram
        .getStdDeviation(), histogram
        .getValueAtPercentile(25.0D), histogram
        .getValueAtPercentile(50.0D), histogram
        .getValueAtPercentile(75.0D), histogram
        .getValueAtPercentile(90.0D), histogram
        .getValueAtPercentile(95.0D), histogram
        .getValueAtPercentile(99.0D), histogram
        .getValueAtPercentile(99.9D), histogram
        .getValueAtPercentile(100.0D), iterations);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\results\ApproxSimilaritySummaryResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */