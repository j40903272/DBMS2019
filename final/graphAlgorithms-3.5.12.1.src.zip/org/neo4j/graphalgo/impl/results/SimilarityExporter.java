package org.neo4j.graphalgo.impl.results;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.stream.Stream;
import org.neo4j.graphalgo.core.utils.ExceptionUtil;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.StatementApi;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.internal.kernel.api.exceptions.EntityNotFoundException;
import org.neo4j.internal.kernel.api.exceptions.InvalidTransactionTypeKernelException;
import org.neo4j.internal.kernel.api.exceptions.KernelException;
import org.neo4j.internal.kernel.api.exceptions.explicitindex.AutoIndexingKernelException;
import org.neo4j.kernel.api.KernelTransaction;
import org.neo4j.kernel.internal.GraphDatabaseAPI;
import org.neo4j.values.storable.Value;
import org.neo4j.values.storable.Values;





















public class SimilarityExporter
  extends StatementApi
{
  private final int propertyId;
  private final int relationshipTypeId;
  private final TerminationFlag terminationFlag;
  private ExecutorService executorService;
  
  public SimilarityExporter(GraphDatabaseAPI api, String relationshipType, String propertyName, TerminationFlag terminationFlag, ExecutorService executorService) {
    super(api);
    this.propertyId = getOrCreatePropertyId(propertyName);
    this.relationshipTypeId = getOrCreateRelationshipId(relationshipType);
    this.terminationFlag = terminationFlag;
    this.executorService = executorService;
  }

  
  public void export(Stream<SimilarityResult> similarityPairs, long batchSize) { writeSequential(similarityPairs, batchSize); }

  
  private void export(SimilarityResult similarityResult) {
    applyInTransaction(statement -> {
          try {
            createRelationship(similarityResult, statement);
          } catch (KernelException e) {
            ExceptionUtil.throwKernelException(e);
          } 
          return null;
        });
  }

  
  private void export(List<SimilarityResult> similarityResults) {
    applyInTransaction(statement -> {
          this.terminationFlag.assertRunning();
          long progress = 0L;
          for (SimilarityResult similarityResult : similarityResults) {
            try {
              createRelationship(similarityResult, statement);
              progress++;
              if (progress % Math.min(10000, similarityResults.size() / 2) == 0L) {
                this.terminationFlag.assertRunning();
              }
            } catch (KernelException e) {
              ExceptionUtil.throwKernelException(e);
            } 
          } 
          return null;
        });
  }




  
  private void createRelationship(SimilarityResult similarityResult, KernelTransaction statement) throws EntityNotFoundException, InvalidTransactionTypeKernelException, AutoIndexingKernelException {
    long node1 = similarityResult.item1;
    long node2 = similarityResult.item2;
    long relationshipId = statement.dataWrite().relationshipCreate(node1, this.relationshipTypeId, node2);
    
    statement.dataWrite().relationshipSetProperty(relationshipId, this.propertyId, 
        (Value)Values.doubleValue(similarityResult.similarity));
  }

  
  private int getOrCreateRelationshipId(String relationshipType) { return ((Integer)applyInTransaction(stmt -> Integer.valueOf(stmt
          .tokenWrite()
          .relationshipTypeGetOrCreateForName(relationshipType)))).intValue(); }


  
  private int getOrCreatePropertyId(String propertyName) { return ((Integer)applyInTransaction(stmt -> Integer.valueOf(stmt
          .tokenWrite()
          .propertyKeyGetOrCreateForName(propertyName)))).intValue(); }

  
  private void writeSequential(Stream<SimilarityResult> similarityPairs, long batchSize) {
    if (batchSize == 1L) {
      similarityPairs.forEach(this::export);
    } else {
      Iterator<SimilarityResult> iterator = similarityPairs.iterator();
      do {
        List<SimilarityResult> items = take(iterator, Math.toIntExact(batchSize));
        List<Runnable> tasks = Collections.singletonList(() -> export(items));
        ParallelUtil.awaitTermination(ParallelUtil.run(tasks, false, this.executorService, null));
      } while (iterator.hasNext());
    } 
  }
  
  private static List<SimilarityResult> take(Iterator<SimilarityResult> iterator, int batchSize) {
    List<SimilarityResult> result = new ArrayList<>(batchSize);
    while (iterator.hasNext() && batchSize-- > 0) {
      result.add(iterator.next());
    }
    return result;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\results\SimilarityExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */