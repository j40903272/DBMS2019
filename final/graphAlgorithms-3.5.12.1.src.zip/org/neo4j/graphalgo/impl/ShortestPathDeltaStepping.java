package org.neo4j.graphalgo.impl;

import java.util.ArrayDeque;
import java.util.Collection;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.RelationshipWithPropertyConsumer;
import org.neo4j.graphalgo.core.heavyweight.Converters;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.container.Buckets;
import org.neo4j.graphdb.Direction;















































public class ShortestPathDeltaStepping
  extends Algorithm<ShortestPathDeltaStepping>
{
  private AtomicIntegerArray distance;
  private Buckets buckets;
  private Graph graph;
  private Collection<Runnable> light;
  private Collection<Runnable> heavy;
  private Collection<Future<?>> futures;
  private final double delta;
  private final int nodeCount;
  private int iDelta;
  private ExecutorService executorService;
  private double multiplier = 100000.0D;
  private Direction direction;
  
  public ShortestPathDeltaStepping(Graph graph, double delta, Direction direction) {
    this.graph = graph;
    this.delta = delta;
    this.iDelta = (int)(this.multiplier * delta);
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.direction = direction;
    this.distance = new AtomicIntegerArray(this.nodeCount);
    this.buckets = new Buckets(this.nodeCount);
    this.heavy = new ArrayDeque<>(1024);
    this.light = new ArrayDeque<>(1024);
    this.futures = new ArrayDeque<>(128);
  }






  
  public ShortestPathDeltaStepping withExecutorService(ExecutorService executorService) {
    this.executorService = executorService;
    return this;
  }






  
  public ShortestPathDeltaStepping withMultiplier(int multiplier) {
    if (multiplier < 1) {
      throw new IllegalArgumentException("multiplier must be >= 1");
    }
    this.multiplier = multiplier;
    this.iDelta = (int)(multiplier * this.delta);
    return this;
  }








  
  public ShortestPathDeltaStepping compute(long startNode) {
    for (int i = 0; i < this.nodeCount; i++) {
      this.distance.set(i, 2147483647);
    }
    this.buckets.reset();

    
    relax(Math.toIntExact(this.graph.toMappedNodeId(startNode)), 0);

    
    while (!this.buckets.isEmpty() && running()) {
      
      this.light.clear();
      this.heavy.clear();

      
      int phase = this.buckets.nextNonEmptyBucket();

      
      this.buckets.forEachInBucket(phase, node -> {
            
            RelationshipWithPropertyConsumer relationshipConsumer = Converters.longToIntConsumer(());








            
            this.graph.forEachRelationship(node, this.direction, 0.0D, relationshipConsumer);
            return true;
          });
      ParallelUtil.run(this.light, this.executorService, this.futures);
      ParallelUtil.run(this.heavy, this.executorService, this.futures);
    } 
    return this;
  }






  
  private double get(int nodeId) {
    int distance = this.distance.get(nodeId);
    return (distance == Integer.MAX_VALUE) ? Double.POSITIVE_INFINITY : (distance / this.multiplier);
  }










  
  private void cas(int nodeId, int cost) {
    boolean stored = false;
    while (!stored) {
      int oldC = this.distance.get(nodeId);
      if (cost < oldC) {
        stored = this.distance.compareAndSet(nodeId, oldC, cost);
      }
    } 
  }










  
  private void relax(int nodeId, int cost) {
    if (cost >= this.distance.get(nodeId)) {
      return;
    }
    int bucketIndex = cost / this.iDelta;
    this.buckets.set(nodeId, bucketIndex);
    cas(nodeId, cost);
  }





  
  public double[] getShortestPaths() {
    double[] d = new double[this.nodeCount];
    for (int i = this.nodeCount - 1; i >= 0; i--) {
      d[i] = get(i);
    }
    return d;
  }





  
  public Stream<DeltaSteppingResult> resultStream() {
    return IntStream.range(0, this.nodeCount)
      .mapToObj(node -> 
        new DeltaSteppingResult(this.graph.toOriginalNodeId(node), get(node)));
  }


  
  public ShortestPathDeltaStepping me() { return this; }


  
  public void release() {
    this.distance = null;
    this.buckets = null;
    this.graph = null;
    this.light = null;
    this.heavy = null;
    this.futures = null;
  }



  
  public static class DeltaSteppingResult
  {
    public final long nodeId;


    
    public final double distance;



    
    public DeltaSteppingResult(long nodeId, double distance) {
      this.nodeId = nodeId;
      this.distance = distance;
    }


    
    public String toString() { return "DeltaSteppingResult{nodeId=" + this.nodeId + ", distance=" + this.distance + '}'; }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\ShortestPathDeltaStepping.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */