package org.neo4j.graphalgo.impl.labelprop;

import org.neo4j.collection.primitive.PrimitiveLongIterable;
import org.neo4j.collection.primitive.PrimitiveLongIterator;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;
import org.neo4j.graphdb.Direction;







































final class ComputeStep
  implements Step
{
  private final RelationshipIterator localRelationshipIterator;
  private final Direction direction;
  private final HugeLongArray existingLabels;
  private final PrimitiveLongIterable nodes;
  private final ProgressLogger progressLogger;
  private final double maxNode;
  private final ComputeStepConsumer consumer;
  boolean didChange;
  long iteration;
  
  ComputeStep(Graph graph, NodeProperties nodeWeights, ProgressLogger progressLogger, Direction direction, HugeLongArray existingLabels, PrimitiveLongIterable nodes) {
    this.didChange = true;
    this.iteration = 0L; this.existingLabels = existingLabels; this.progressLogger = progressLogger; this.maxNode = graph.nodeCount() - 1.0D;
    this.localRelationshipIterator = graph.concurrentCopy();
    this.direction = direction;
    this.nodes = nodes;
    this.consumer = new ComputeStepConsumer(nodeWeights, existingLabels); } public void run() { if (this.didChange) {
      this.iteration++;
      this.didChange = iterateAll(this.nodes.iterator());
      if (!this.didChange)
        release(); 
    }  }
  
  public Step next() { return this; }
  
  private boolean iterateAll(PrimitiveLongIterator nodeIds) {
    boolean didChange = false;
    while (nodeIds.hasNext()) {
      long nodeId = nodeIds.next();
      didChange = compute(nodeId, didChange);
      this.progressLogger.logProgress(nodeId, this.maxNode);
    } 
    return didChange;
  }
  
  private boolean compute(long nodeId, boolean didChange) {
    this.consumer.clearVotes();
    long label = this.existingLabels.get(nodeId);
    this.localRelationshipIterator.forEachRelationship(nodeId, this.direction, 1.0D, this.consumer);
    long newLabel = this.consumer.tallyVotes(label);
    if (newLabel != label) {
      this.existingLabels.set(nodeId, newLabel);
      return true;
    } 
    return didChange;
  }

  
  void release() { this.consumer.release(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\labelprop\ComputeStep.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */