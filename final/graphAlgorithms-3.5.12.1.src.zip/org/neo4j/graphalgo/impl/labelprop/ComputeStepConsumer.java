package org.neo4j.graphalgo.impl.labelprop;

import com.carrotsearch.hppc.LongDoubleScatterMap;
import com.carrotsearch.hppc.cursors.LongDoubleCursor;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.api.RelationshipWithPropertyConsumer;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;





















final class ComputeStepConsumer
  implements RelationshipWithPropertyConsumer
{
  private final NodeProperties nodeWeights;
  private final HugeLongArray existingLabels;
  private final LongDoubleScatterMap votes;
  
  ComputeStepConsumer(NodeProperties nodeWeights, HugeLongArray existingLabels) {
    this.existingLabels = existingLabels;
    this.nodeWeights = nodeWeights;
    
    this.votes = new LongDoubleScatterMap();
  }

  
  public boolean accept(long sourceNodeId, long targetNodeId, double property) {
    castVote(targetNodeId, property);
    return true;
  }
  
  private void castVote(long candidate, double weight) {
    weight = weightOf(candidate, weight);
    long label = this.existingLabels.get(candidate);
    this.votes.addTo(label, weight);
  }
  
  private double weightOf(long candidate, double relationshipWeight) {
    double nodeWeight = this.nodeWeights.nodeProperty(candidate);
    return relationshipWeight * nodeWeight;
  }

  
  void clearVotes() { this.votes.clear(); }

  
  long tallyVotes(long label) {
    double weight = Double.NEGATIVE_INFINITY;
    for (LongDoubleCursor vote : this.votes) {
      if (weight < vote.value) {
        weight = vote.value;
        label = vote.key; continue;
      }  if (weight == vote.value && 
        vote.key < label) {
        label = vote.key;
      }
    } 
    
    return label;
  }
  
  private static final long[] EMPTY_LONGS = new long[0];




  
  void release() {
    if (this.votes.keys != null) {
      this.votes.keys = EMPTY_LONGS;
      this.votes.clear();
      this.votes.keys = null;
      this.votes.values = null;
    } 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\labelprop\ComputeStepConsumer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */