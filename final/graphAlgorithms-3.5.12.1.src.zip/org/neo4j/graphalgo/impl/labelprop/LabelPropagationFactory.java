package org.neo4j.graphalgo.impl.labelprop;

import com.carrotsearch.hppc.LongDoubleScatterMap;
import com.carrotsearch.hppc.OpenHashContainers;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.AlgorithmFactory;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.ProcedureConfiguration;
import org.neo4j.graphalgo.core.utils.Pools;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.mem.MemoryRange;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;
import org.neo4j.logging.Log;

























public class LabelPropagationFactory
  extends AlgorithmFactory<LabelPropagation>
{
  public LabelPropagation build(Graph graph, ProcedureConfiguration configuration, AllocationTracker tracker, Log log) {
    int concurrency = configuration.getConcurrency();
    int batchSize = configuration.getBatchSize();
    return new LabelPropagation(graph, batchSize, concurrency, Pools.DEFAULT, tracker);
  }








  
  public MemoryEstimation memoryEstimation() { return MemoryEstimations.builder(LabelPropagation.class)
      .perNode("labels", HugeLongArray::memoryEstimation)
      .perThread("votes", MemoryEstimations.builder()
        .field("init step", InitStep.class)
        .field("compute step", ComputeStep.class)
        .field("step runner", StepRunner.class)
        .field("compute step consumer", ComputeStepConsumer.class)
        .field("votes container", LongDoubleScatterMap.class)
        .rangePerNode("votes", nodeCount -> {
            int minBufferSize = OpenHashContainers.emptyBufferSize();
            int maxBufferSize = OpenHashContainers.expectedBufferSize((int)Math.min(nodeCount, 2147483647L));
            if (maxBufferSize < minBufferSize) {
              maxBufferSize = minBufferSize;
            }
            long min = MemoryUsage.sizeOfLongArray(minBufferSize) + MemoryUsage.sizeOfDoubleArray(minBufferSize);
            long max = MemoryUsage.sizeOfLongArray(maxBufferSize) + MemoryUsage.sizeOfDoubleArray(maxBufferSize);
            return MemoryRange.of(min, max);
          }).build())
      .build(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\labelprop\LabelPropagationFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */