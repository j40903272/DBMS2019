package org.neo4j.graphalgo.impl.labelprop;

import org.neo4j.collection.primitive.PrimitiveLongIterable;
import org.neo4j.collection.primitive.PrimitiveLongIterator;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;
import org.neo4j.graphdb.Direction;



























final class InitStep
  implements Step
{
  private final NodeProperties nodeProperties;
  private final HugeLongArray existingLabels;
  private final PrimitiveLongIterable nodes;
  private final Graph graph;
  private final NodeProperties nodeWeights;
  private final ProgressLogger progressLogger;
  private final Direction direction;
  private final long maxLabelId;
  
  InitStep(Graph graph, NodeProperties nodeProperties, NodeProperties nodeWeights, PrimitiveLongIterable nodes, HugeLongArray existingLabels, ProgressLogger progressLogger, Direction direction, long maxLabelId) {
    this.nodeProperties = nodeProperties;
    this.existingLabels = existingLabels;
    this.nodes = nodes;
    this.graph = graph;
    this.nodeWeights = nodeWeights;
    this.progressLogger = progressLogger;
    this.direction = direction;
    this.maxLabelId = maxLabelId;
  }

  
  public final void run() {
    PrimitiveLongIterator iterator = this.nodes.iterator();
    while (iterator.hasNext()) {
      long nodeId = iterator.next();
      double existingLabelValue = this.nodeProperties.nodeProperty(nodeId, NaND);










      
      long existingLabel = Double.isNaN(existingLabelValue) ? (this.maxLabelId + this.graph.toOriginalNodeId(nodeId) + 1L) : (long)existingLabelValue;
      
      this.existingLabels.set(nodeId, existingLabel);
    } 
  }


  
  public Step next() { return new ComputeStep(this.graph, this.nodeWeights, this.progressLogger, this.direction, this.existingLabels, this.nodes); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\labelprop\InitStep.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */