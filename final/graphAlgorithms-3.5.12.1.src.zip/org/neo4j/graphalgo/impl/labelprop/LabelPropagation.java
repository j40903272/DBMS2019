package org.neo4j.graphalgo.impl.labelprop;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import org.neo4j.collection.primitive.PrimitiveLongCollections;
import org.neo4j.collection.primitive.PrimitiveLongIterable;
import org.neo4j.collection.primitive.PrimitiveLongIterator;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.core.loading.NullPropertyMap;
import org.neo4j.graphalgo.core.utils.LazyBatchCollection;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;
import org.neo4j.graphdb.Direction;






























public class LabelPropagation
  extends Algorithm<LabelPropagation>
{
  public static final double DEFAULT_WEIGHT = 1.0D;
  public static final String SEED_TYPE = "seed";
  public static final String WEIGHT_TYPE = "weight";
  private final long nodeCount;
  private final AllocationTracker tracker;
  private final NodeProperties nodeProperties;
  private final NodeProperties nodeWeights;
  private final int batchSize;
  private final int concurrency;
  private final ExecutorService executor;
  private Graph graph;
  private HugeLongArray labels;
  private final long maxLabelId;
  private long ranIterations;
  private boolean didConverge;
  
  public LabelPropagation(Graph graph, int batchSize, int concurrency, ExecutorService executor, AllocationTracker tracker) {
    this.graph = graph;
    this.nodeCount = graph.nodeCount();
    this.batchSize = batchSize;
    this.concurrency = concurrency;
    this.executor = executor;
    this.tracker = tracker;
    
    Object object1 = graph.nodeProperties("seed");
    if (object1 == null) {
      object1 = new NullPropertyMap(0.0D);
    }
    this.nodeProperties = (NodeProperties)object1;
    
    Object object2 = graph.nodeProperties("weight");
    if (object2 == null) {
      object2 = new NullPropertyMap(1.0D);
    }
    this.nodeWeights = (NodeProperties)object2;
    this.maxLabelId = this.nodeProperties.getMaxPropertyValue().orElse(-1L);
  }


  
  public LabelPropagation me() { return this; }



  
  public void release() { this.graph = null; }


  
  public long ranIterations() { return this.ranIterations; }


  
  public boolean didConverge() { return this.didConverge; }


  
  public HugeLongArray labels() { return this.labels; }

  
  public LabelPropagation compute(Direction direction, long maxIterations) {
    if (maxIterations <= 0L) {
      throw new IllegalArgumentException("Must iterate at least 1 time");
    }
    
    if (this.labels == null || this.labels.size() != this.nodeCount) {
      this.labels = HugeLongArray.newArray(this.nodeCount, this.tracker);
    }
    
    this.ranIterations = 0L;
    this.didConverge = false;
    
    List<StepRunner> stepRunners = stepRunners(direction);
    
    long currentIteration = 0L;
    while (currentIteration < maxIterations) {
      ParallelUtil.runWithConcurrency(this.concurrency, stepRunners, 1L, TimeUnit.MICROSECONDS, this.terminationFlag, this.executor);
      currentIteration++;
    } 
    
    long maxIteration = 0L;
    boolean converged = true;
    for (StepRunner stepRunner : stepRunners) {
      Step current = stepRunner.current;
      if (current instanceof ComputeStep) {
        ComputeStep step = (ComputeStep)current;
        if (step.iteration > maxIteration) {
          maxIteration = step.iteration;
        }
        converged = (converged && !step.didChange);
        step.release();
      } 
    } 
    
    this.ranIterations = maxIteration;
    this.didConverge = converged;
    
    return me();
  }
  
  private List<StepRunner> stepRunners(Direction direction) {
    long nodeCount = this.graph.nodeCount();
    long batchSize = ParallelUtil.adjustedBatchSize(nodeCount, this.batchSize);
    
    Collection<PrimitiveLongIterable> nodeBatches = LazyBatchCollection.of(nodeCount, batchSize, (start, length) -> ());



    
    int threads = nodeBatches.size();
    List<StepRunner> tasks = new ArrayList<>(threads);
    for (PrimitiveLongIterable iter : nodeBatches) {





      
      InitStep initStep = new InitStep(this.graph, this.nodeProperties, this.nodeWeights, iter, this.labels, getProgressLogger(), direction, this.maxLabelId);


      
      StepRunner task = new StepRunner(initStep);
      tasks.add(task);
    } 
    ParallelUtil.runWithConcurrency(this.concurrency, tasks, 1L, TimeUnit.MICROSECONDS, this.terminationFlag, this.executor);
    return tasks;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\labelprop\LabelPropagation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */