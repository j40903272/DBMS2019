package org.neo4j.graphalgo.impl.triangle;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphdb.Direction;































public abstract class TriangleCountBase<Coeff, Self extends TriangleCountBase<Coeff, Self>>
  extends Algorithm<Self>
{
  public static final Direction D = Direction.OUTGOING;
  
  private final AtomicInteger visitedNodes;
  
  private AtomicIntegerArray triangles;
  Graph graph;
  final int nodeCount;
  
  TriangleCountBase(Graph graph) {
    this.graph = graph;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.triangles = new AtomicIntegerArray(this.nodeCount);
    this.visitedNodes = new AtomicInteger();
  }




  
  public final Stream<Result> resultStream() {
    return IntStream.range(0, this.nodeCount)
      .mapToObj(i -> new Result(this.graph
          .toOriginalNodeId(i), this.triangles
          .get(i), 
          coefficient(i)));
  }











  
  public final AtomicIntegerArray getTriangles() { return this.triangles; }





















  
  public final Self me() { return (Self)this; }


  
  public void release() {
    this.graph = null;
    this.triangles = null;
  }




  
  public final Self compute() {
    this.visitedNodes.set(0);
    runCompute();
    return me();
  }








  
  final void exportTriangle(int u, int v, int w) {
    this.triangles.incrementAndGet(u);
    this.triangles.incrementAndGet(v);
    this.triangles.incrementAndGet(w);
  }




  
  final void nodeVisited() { getProgressLogger().logProgress(this.visitedNodes.incrementAndGet(), this.nodeCount); }





  
  final double calculateCoefficient(int nodeId, Direction direction) { return calculateCoefficient(this.triangles.get(nodeId), this.graph.degree(nodeId, direction)); }

  
  public abstract long getTriangleCount();
  
  abstract double coefficient(int paramInt);
  
  public abstract Coeff getClusteringCoefficients();
  
  private double calculateCoefficient(int triangles, int degree) {
    if (triangles == 0) {
      return 0.0D;
    }
    return (triangles << 1) / (degree * (degree - 1));
  }

  
  abstract double getAverageClusteringCoefficient();
  
  abstract void runCompute();
  
  public static class Result
  {
    public final long nodeId;
    
    public Result(long nodeId, long triangles, double coefficient) {
      this.nodeId = nodeId;
      this.triangles = triangles;
      this.coefficient = coefficient;
    }
    
    public final long triangles;
    
    public String toString() { return "Result{nodeId=" + this.nodeId + ", triangles=" + this.triangles + ", coefficient=" + this.coefficient + '}'; }
    
    public final double coefficient;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\triangle\TriangleCountBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */