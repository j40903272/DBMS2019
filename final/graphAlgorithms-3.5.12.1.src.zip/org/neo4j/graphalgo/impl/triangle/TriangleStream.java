package org.neo4j.graphalgo.impl.triangle;

import java.util.Collection;
import java.util.Iterator;
import java.util.Objects;
import java.util.Spliterators;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.IntersectionConsumer;
import org.neo4j.graphalgo.api.RelationshipIntersect;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.TerminationFlag;




























public class TriangleStream
  extends Algorithm<TriangleStream>
{
  private Graph graph;
  private ExecutorService executorService;
  private final AtomicInteger queue;
  private final int concurrency;
  private final int nodeCount;
  private AtomicInteger visitedNodes;
  private AtomicInteger runningThreads;
  private BlockingQueue<Result> resultQueue;
  
  public TriangleStream(Graph graph, ExecutorService executorService, int concurrency) {
    this.graph = graph;
    this.executorService = executorService;
    this.concurrency = concurrency;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.resultQueue = new ArrayBlockingQueue<>(concurrency << 10);
    this.runningThreads = new AtomicInteger();
    this.visitedNodes = new AtomicInteger();
    this.queue = new AtomicInteger();
  }


  
  public TriangleStream me() { return this; }





  
  public void release() {
    this.visitedNodes = null;
    this.runningThreads = null;
    this.resultQueue = null;
    this.graph = null;
    this.executorService = null;
  }





  
  public Stream<Result> resultStream() {
    submitTasks();
    final TerminationFlag flag = getTerminationFlag();
    Iterator<Result> it = new Iterator<Result>()
      {
        public boolean hasNext()
        {
          return (flag.running() && (TriangleStream.this.runningThreads.get() > 0 || !TriangleStream.this.resultQueue.isEmpty()));
        }

        
        public TriangleStream.Result next() {
          TriangleStream.Result result = null;
          while (hasNext() && result == null) {
            result = TriangleStream.this.resultQueue.poll();
          }
          return result;
        }
      };
    
    return 
      StreamSupport.stream(Spliterators.spliteratorUnknownSize(it, 0), false)
      .filter(Objects::nonNull);
  }
  
  private void submitTasks() {
    this.queue.set(0);
    this.runningThreads.set(0);
    
    Collection<Runnable> tasks = ParallelUtil.tasks(this.concurrency, () -> new IntersectTask(this.graph));
    ParallelUtil.run(tasks, false, this.executorService, null);
  }
  
  private abstract class BaseTask
    implements Runnable
  {
    BaseTask() { TriangleStream.this.runningThreads.incrementAndGet(); }


    
    public final void run() {
      try {
        ProgressLogger progressLogger = TriangleStream.this.getProgressLogger();
        int node;
        while ((node = TriangleStream.this.queue.getAndIncrement()) < TriangleStream.this.nodeCount && TriangleStream.this.running()) {
          evaluateNode(node);
          progressLogger.logProgress(TriangleStream.this.visitedNodes.incrementAndGet(), TriangleStream.this.nodeCount);
        } 
      } finally {
        TriangleStream.this.runningThreads.decrementAndGet();
      } 
    }


    
    abstract void evaluateNode(int param1Int);

    
    void emit(long nodeA, long nodeB, long nodeC) {
      TriangleStream.Result result = new TriangleStream.Result(TriangleStream.this.graph.toOriginalNodeId(nodeA), TriangleStream.this.graph.toOriginalNodeId(nodeB), TriangleStream.this.graph.toOriginalNodeId(nodeC));
      TriangleStream.this.resultQueue.offer(result);
    }
  }
  
  private final class IntersectTask
    extends BaseTask
    implements IntersectionConsumer {
    private RelationshipIntersect intersect;
    
    IntersectTask(Graph graph) { this.intersect = graph.intersection(); }



    
    void evaluateNode(int nodeId) { this.intersect.intersectAll(nodeId, this); }



    
    public void accept(long nodeA, long nodeB, long nodeC) { emit(nodeA, nodeB, nodeC); }
  }

  
  public static class Result
  {
    public final long nodeA;
    
    public final long nodeB;
    
    public final long nodeC;

    
    public Result(long nodeA, long nodeB, long nodeC) {
      this.nodeA = nodeA;
      this.nodeB = nodeB;
      this.nodeC = nodeC;
    }


    
    public String toString() { return "Triangle{" + this.nodeA + ", " + this.nodeB + ", " + this.nodeC + '}'; }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\triangle\TriangleStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */