package org.neo4j.graphalgo.impl.triangle;

import java.util.Collection;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.IntersectionConsumer;
import org.neo4j.graphalgo.api.RelationshipIntersect;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.PagedAtomicIntegerArray;













































public class BalancedTriads
  extends Algorithm<BalancedTriads>
{
  private Graph graph;
  private ExecutorService executorService;
  private final PagedAtomicIntegerArray balancedTriangles;
  private final PagedAtomicIntegerArray unbalancedTriangles;
  private final int concurrency;
  private final long nodeCount;
  private final LongAdder balancedTriangleCount;
  private final LongAdder unbalancedTriangleCount;
  private final AtomicLong queue;
  private final AtomicLong visitedNodes;
  private BalancedPredicate balancedPredicate;
  
  public BalancedTriads(Graph graph, ExecutorService executorService, int concurrency, AllocationTracker tracker) {
    this.balancedPredicate = ((w1, w2, w3) -> (w1 * w2 * w3 >= 0.0D));

    
    this.graph = graph;
    this.executorService = executorService;
    this.concurrency = concurrency;
    this.nodeCount = graph.nodeCount();
    this.visitedNodes = new AtomicLong();
    this.balancedTriangles = PagedAtomicIntegerArray.newArray(this.nodeCount, tracker);
    this.unbalancedTriangles = PagedAtomicIntegerArray.newArray(this.nodeCount, tracker);
    this.balancedTriangleCount = new LongAdder();
    this.unbalancedTriangleCount = new LongAdder();
    this.queue = new AtomicLong();
  }


  
  public final BalancedTriads me() { return this; }





  
  public void release() {
    this.executorService = null;
    this.graph = null;
    this.unbalancedTriangles.release();
    this.balancedTriangles.release();
    this.balancedTriangleCount.reset();
    this.unbalancedTriangleCount.reset();
  }




  
  public BalancedTriads compute() {
    this.visitedNodes.set(0L);
    this.queue.set(0L);
    this.balancedTriangleCount.reset();
    this.unbalancedTriangleCount.reset();
    
    Collection<? extends Runnable> tasks = ParallelUtil.tasks(this.concurrency, () -> new HugeTask(this.graph));
    
    ParallelUtil.run(tasks, this.executorService);
    return this;
  }





  
  public Stream<Result> stream() {
    return IntStream.range(0, Math.toIntExact(this.nodeCount))
      .mapToObj(i -> new Result(this.graph
          .toOriginalNodeId(i), this.balancedTriangles
          .get(i), this.unbalancedTriangles
          .get(i)));
  }




  
  public PagedAtomicIntegerArray getBalancedTriangles() { return this.balancedTriangles; }





  
  public PagedAtomicIntegerArray getUnbalancedTriangles() { return this.unbalancedTriangles; }






  
  public long getBalancedTriangleCount() { return this.balancedTriangleCount.longValue(); }






  
  public long getUnbalancedTriangleCount() { return this.unbalancedTriangleCount.longValue(); }
  
  public static interface BalancedPredicate
  {
    boolean isBalanced(double param1Double1, double param1Double2, double param1Double3);
  }
  
  public static class Result {
    public final long nodeId;
    public final long balanced;
    public final long unbalanced;
    
    public Result(long nodeId, long balanced, long unbalanced) {
      this.nodeId = nodeId;
      this.balanced = balanced;
      this.unbalanced = unbalanced;
    }


    
    public String toString() { return "Result{nodeId=" + this.nodeId + ", balanced=" + this.balanced + ", unbalanced=" + this.unbalanced + '}'; }
  }



  
  private class HugeTask
    implements Runnable, IntersectionConsumer
  {
    private RelationshipIntersect hg;


    
    HugeTask(Graph graph) { this.hg = graph.intersection(); }


    
    public void run() {
      long node;
      while ((node = BalancedTriads.this.queue.getAndIncrement()) < BalancedTriads.this.nodeCount && BalancedTriads.this.running()) {
        this.hg.intersectAll(node, this);
        BalancedTriads.this.getProgressLogger().logProgress(BalancedTriads.this.visitedNodes.incrementAndGet(), BalancedTriads.this.nodeCount);
      } 
    }

    
    public void accept(long a, long b, long c) {
      if (BalancedTriads.this.balancedPredicate.isBalanced(BalancedTriads.this.graph.relationshipProperty(a, b, 1.0D), BalancedTriads.this.graph.relationshipProperty(a, c, 1.0D), BalancedTriads.this.graph.relationshipProperty(b, c, 1.0D))) {
        BalancedTriads.this.balancedTriangles.add(a, 1);
        BalancedTriads.this.balancedTriangles.add(b, 1);
        BalancedTriads.this.balancedTriangles.add(c, 1);
        BalancedTriads.this.balancedTriangleCount.increment();
      } else {
        BalancedTriads.this.unbalancedTriangles.add(a, 1);
        BalancedTriads.this.unbalancedTriangles.add(b, 1);
        BalancedTriads.this.unbalancedTriangles.add(c, 1);
        BalancedTriads.this.unbalancedTriangleCount.increment();
      } 
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\triangle\BalancedTriads.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */