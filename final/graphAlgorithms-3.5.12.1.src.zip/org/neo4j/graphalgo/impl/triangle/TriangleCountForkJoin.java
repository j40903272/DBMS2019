package org.neo4j.graphalgo.impl.triangle;

import com.carrotsearch.hppc.IntStack;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveTask;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.IntersectionConsumer;
import org.neo4j.graphalgo.api.RelationshipIntersect;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.heavyweight.Converters;
import org.neo4j.graphalgo.core.utils.AtomicDoubleArray;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.graphdb.Direction;




























public class TriangleCountForkJoin
  extends TriangleCountBase<AtomicDoubleArray, TriangleCountForkJoin>
{
  private final ForkJoinPool pool;
  private final int sequentialThreshold;
  private final AtomicDoubleArray coefficients;
  private long triangleCount = -1L;
  private double averageClusteringCoefficient = 0.0D;
  
  public TriangleCountForkJoin(Graph graph, ForkJoinPool pool, int sequentialThreshold) {
    super(graph);
    this.pool = pool;
    this.sequentialThreshold = sequentialThreshold;
    this.coefficients = new AtomicDoubleArray(this.nodeCount);
  }







  
  double coefficient(int node) { return this.coefficients.get(node); }







  
  public long getTriangleCount() { return this.triangleCount; }



  
  void runCompute() {
    Object object = this.graph.getType().equals("huge") ? new HugeTask(this.graph, 0, this.nodeCount) : new TriangleTask(0, this.nodeCount);

    
    this.triangleCount = ((Long)this.pool.invoke((ForkJoinTask<Long>)object)).longValue();
    CoefficientTask coefficientTask = new CoefficientTask(Direction.OUTGOING, 0, this.nodeCount);


    
    this.averageClusteringCoefficient = ((Double)this.pool.invoke(coefficientTask)).doubleValue();
  }






  
  public double getAverageClusteringCoefficient() { return this.averageClusteringCoefficient / this.nodeCount; }







  
  public AtomicDoubleArray getClusteringCoefficients() { return this.coefficients; }



  
  private class TriangleTask
    extends RecursiveTask<Long>
  {
    private final RelationshipIterator localRelationshipIterator = TriangleCountForkJoin.this.graph.concurrentCopy();
    private final RelationshipIterator localRelationshipPredicate = TriangleCountForkJoin.this.graph.concurrentCopy();
    
    private final int start;
    private final int end;
    
    private TriangleTask(int start, int end) {
      this.start = start;
      this.end = end;
    }

    
    protected Long compute() {
      int l = this.end - this.start;
      if (l > TriangleCountForkJoin.this.sequentialThreshold && TriangleCountForkJoin.this.running()) {
        int pivot = this.start + l / 2;
        TriangleTask left = new TriangleTask(this.start, pivot);
        TriangleTask right = new TriangleTask(pivot, this.end);
        left.fork();
        return Long.valueOf(right.compute().longValue() + left.join().longValue());
      } 
      return Long.valueOf(execute(this.start, this.end));
    }

    
    private long execute(int start, int end) {
      long[] triangles = { 0L };
      IntStack nodes = new IntStack();
      TerminationFlag flag = TriangleCountForkJoin.this.getTerminationFlag();
      int[] head = { -1 };
      for (head[0] = start; head[0] < end; head[0] = head[0] + 1) {
        this.localRelationshipIterator.forEachRelationship(head[0], TriangleCountBase.D, Converters.longToIntConsumer((s, t) -> {
                if (t > s) {
                  nodes.push(t);
                }
                return flag.running();
              }));
        while (!nodes.isEmpty()) {
          int node = nodes.pop();
          this.localRelationshipIterator.forEachRelationship(node, TriangleCountBase.D, Converters.longToIntConsumer((s, t) -> {
                  if (t > s && this.localRelationshipPredicate.exists(t, head[0], TriangleCountBase.D)) {
                    TriangleCountForkJoin.this.exportTriangle(head[0], s, t);
                    triangles[0] = triangles[0] + 1L;
                  } 
                  return flag.running();
                }));
        } 
        TriangleCountForkJoin.this.nodeVisited();
      } 
      return triangles[0];
    }
  }

  
  private class CoefficientTask
    extends RecursiveTask<Double>
  {
    private final Direction direction;
    
    private final int start;
    private final int end;
    
    private CoefficientTask(Direction direction, int start, int end) {
      this.direction = direction;
      this.start = start;
      this.end = end;
    }

    
    protected Double compute() {
      int l = this.end - this.start;
      if (l > TriangleCountForkJoin.this.sequentialThreshold && TriangleCountForkJoin.this.running()) {
        int pivot = this.start + l / 2;
        CoefficientTask left = new CoefficientTask(this.direction, this.start, pivot);
        CoefficientTask right = new CoefficientTask(this.direction, pivot, this.end);
        left.fork();
        return Double.valueOf(right.compute().doubleValue() + left.join().doubleValue());
      } 
      return Double.valueOf(execute(this.start, this.end));
    }

    
    private double execute(int start, int end) {
      double averageClusteringCoefficient = 0.0D;
      for (int i = start; i < end; i++) {
        double c = TriangleCountForkJoin.this.calculateCoefficient(i, this.direction);
        averageClusteringCoefficient += c;
        TriangleCountForkJoin.this.coefficients.set(i, c);
      } 
      return averageClusteringCoefficient;
    }
  }
  
  private class HugeTask
    extends RecursiveTask<Long>
    implements IntersectionConsumer {
    private Graph graph;
    private RelationshipIntersect hg;
    private final int start;
    private final int end;
    private long count;
    
    HugeTask(Graph graph, int start, int end) {
      this.graph = graph;
      this.start = start;
      this.end = end;
      this.hg = graph.intersection();
    }

    
    protected Long compute() {
      int l = this.end - this.start;
      if (l > TriangleCountForkJoin.this.sequentialThreshold && TriangleCountForkJoin.this.running()) {
        int pivot = this.start + l / 2;
        HugeTask left = new HugeTask(this.graph, this.start, pivot);
        HugeTask right = new HugeTask(this.graph, pivot, this.end);
        left.fork();
        return Long.valueOf(right.compute().longValue() + left.join().longValue());
      } 
      return Long.valueOf(execute(this.start, this.end));
    }

    
    private long execute(int start, int end) {
      for (int node = start; node < end && TriangleCountForkJoin.this.running(); node++) {
        this.hg.intersectAll(node, this);
        TriangleCountForkJoin.this.nodeVisited();
      } 
      return this.count;
    }

    
    public void accept(long nodeA, long nodeB, long nodeC) {
      this.count++;
      TriangleCountForkJoin.this.exportTriangle((int)nodeA, (int)nodeB, (int)nodeC);
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\triangle\TriangleCountForkJoin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */