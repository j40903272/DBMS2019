package org.neo4j.graphalgo.impl.triangle;

import java.util.Collection;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.LongAdder;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.IntersectionConsumer;
import org.neo4j.graphalgo.api.RelationshipIntersect;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeDoubleArray;
import org.neo4j.graphalgo.core.utils.paged.PagedAtomicIntegerArray;
import org.neo4j.graphdb.Direction;


































public class IntersectingTriangleCount
  extends Algorithm<IntersectingTriangleCount>
{
  private Graph graph;
  private ExecutorService executorService;
  private final int concurrency;
  private final long nodeCount;
  private final AllocationTracker tracker;
  private final LongAdder triangleCount;
  private final AtomicLong queue;
  private final AtomicLong visitedNodes;
  private PagedAtomicIntegerArray triangles;
  private double averageClusteringCoefficient;
  
  public IntersectingTriangleCount(Graph graph, ExecutorService executorService, int concurrency, AllocationTracker tracker) {
    this.graph = graph;
    this.tracker = tracker;
    this.executorService = executorService;
    this.concurrency = concurrency;
    this.nodeCount = graph.nodeCount();
    this.visitedNodes = new AtomicLong();
    this.triangles = PagedAtomicIntegerArray.newArray(this.nodeCount, tracker);
    this.triangleCount = new LongAdder();
    this.queue = new AtomicLong();
  }

  
  public long getTriangleCount() { return this.triangleCount.longValue(); }


  
  public double getAverageCoefficient() { return this.averageClusteringCoefficient; }


  
  public PagedAtomicIntegerArray getTriangles() { return this.triangles; }

  
  public HugeDoubleArray getCoefficients() {
    HugeDoubleArray array = HugeDoubleArray.newArray(this.nodeCount, this.tracker);
    double[] adder = { 0.0D };
    for (int i = 0; i < this.nodeCount; i++) {
      double c = calculateCoefficient(this.triangles.get(i), this.graph.degree(i, Direction.OUTGOING));
      array.set(i, c);
      adder[0] = adder[0] + c;
    } 
    this.averageClusteringCoefficient = adder[0] / this.nodeCount;
    return array;
  }
  
  public final Stream<Result> resultStream() {
    return IntStream.range(0, Math.toIntExact(this.nodeCount))
      .mapToObj(i -> new Result(this.graph
          .toOriginalNodeId(i), this.triangles
          .get(i), 
          calculateCoefficient(this.triangles.get(i), this.graph.degree(i, Direction.OUTGOING))));
  }


  
  public final IntersectingTriangleCount me() { return this; }


  
  public void release() {
    this.executorService = null;
    this.graph = null;
    this.triangles = null;
  }
  
  public IntersectingTriangleCount compute() {
    this.visitedNodes.set(0L);
    this.queue.set(0L);
    this.triangleCount.reset();
    this.averageClusteringCoefficient = 0.0D;
    
    Collection<? extends Runnable> tasks = ParallelUtil.tasks(this.concurrency, () -> new IntersectTask(this.graph));
    
    ParallelUtil.run(tasks, this.executorService);
    return this;
  }
  
  private class IntersectTask
    implements Runnable, IntersectionConsumer
  {
    private RelationshipIntersect intersect;
    
    IntersectTask(Graph graph) { this.intersect = graph.intersection(); }


    
    public void run() {
      long node;
      while ((node = IntersectingTriangleCount.this.queue.getAndIncrement()) < IntersectingTriangleCount.this.nodeCount && IntersectingTriangleCount.this.running()) {
        this.intersect.intersectAll(node, this);
        IntersectingTriangleCount.this.getProgressLogger().logProgress(IntersectingTriangleCount.this.visitedNodes.incrementAndGet(), IntersectingTriangleCount.this.nodeCount);
      } 
    }


    
    public void accept(long nodeA, long nodeB, long nodeC) {
      if (nodeA < nodeB) {
        IntersectingTriangleCount.this.triangles.add((int)nodeA, 1);
        IntersectingTriangleCount.this.triangles.add((int)nodeB, 1);
        IntersectingTriangleCount.this.triangles.add((int)nodeC, 1);
        IntersectingTriangleCount.this.triangleCount.increment();
      } 
    }
  }
  
  private double calculateCoefficient(int triangles, int degree) {
    if (triangles == 0) {
      return 0.0D;
    }
    return (triangles << 1) / (degree * (degree - 1));
  }

  
  public static class Result
  {
    public final long nodeId;
    
    public final long triangles;
    
    public final double coefficient;
    
    public Result(long nodeId, long triangles, double coefficient) {
      this.nodeId = nodeId;
      this.triangles = triangles;
      this.coefficient = coefficient;
    }

    
    public String toString() { return "Result{nodeId=" + this.nodeId + ", triangles=" + this.triangles + ", coefficient=" + this.coefficient + '}'; }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\triangle\IntersectingTriangleCount.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */