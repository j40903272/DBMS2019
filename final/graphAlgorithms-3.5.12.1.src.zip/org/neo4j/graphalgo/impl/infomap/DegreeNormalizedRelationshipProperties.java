package org.neo4j.graphalgo.impl.infomap;

import org.neo4j.graphalgo.api.Degrees;
import org.neo4j.graphalgo.api.RelationshipProperties;
import org.neo4j.graphdb.Direction;
























public class DegreeNormalizedRelationshipProperties
  implements RelationshipProperties
{
  private final Degrees degrees;
  private final Direction direction;
  
  public DegreeNormalizedRelationshipProperties(Degrees degrees) { this(degrees, Direction.OUTGOING); }

  
  public DegreeNormalizedRelationshipProperties(Degrees degrees, Direction direction) {
    this.degrees = degrees;
    this.direction = direction;
  }


  
  public double relationshipProperty(long sourceNodeId, long targetNodeId, double fallbackValue) { return 1.0D / this.degrees.degree(sourceNodeId, this.direction); }



  
  public double relationshipProperty(long sourceNodeId, long targetNodeId) { return relationshipProperty(sourceNodeId, targetNodeId, 1.0D); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\infomap\DegreeNormalizedRelationshipProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */