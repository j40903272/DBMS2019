package org.neo4j.graphalgo.impl.infomap;

import com.carrotsearch.hppc.BitSet;
import com.carrotsearch.hppc.BitSetIterator;
import com.carrotsearch.hppc.IntContainer;
import com.carrotsearch.hppc.IntDoubleAssociativeContainer;
import com.carrotsearch.hppc.IntDoubleMap;
import com.carrotsearch.hppc.IntDoubleScatterMap;
import com.carrotsearch.hppc.cursors.IntDoubleCursor;
import java.util.Arrays;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;
import java.util.function.Consumer;
import java.util.stream.LongStream;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Degrees;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.api.RelationshipProperties;
import org.neo4j.graphalgo.core.utils.Pointer;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.impl.pagerank.PageRank;
import org.neo4j.graphalgo.impl.pagerank.PageRankAlgorithmType;
import org.neo4j.graphalgo.impl.results.CentralityResult;
import org.neo4j.graphdb.Direction;



















public class InfoMap
  extends Algorithm<InfoMap>
{
  private static final double LOG2 = Math.log(2.0D);
  
  public static int PAGE_RANK_BATCH_SIZE = 10000;
  public static boolean PAGE_RANK_CACHE_WEIGHTS = false;
  public static int MIN_MODS_PARALLEL_EXEC = 20;

  
  public static final double TAU = 0.15D;

  
  public static final double THRESHOLD = 0.005D;

  
  private static final Direction D = Direction.OUTGOING;
  
  private final int nodeCount;
  
  private final double tau;
  
  private final double threshold;
  
  private RelationshipProperties weights;
  
  private final double tau1;
  
  private final double n1;
  
  private final ForkJoinPool pool;
  
  private final int concurrency;
  
  private final ProgressLogger logger;
  private final TerminationFlag terminationFlag;
  private int iterations = 0;



  
  private IndexMap<Module> modules;



  
  private int[] communities;



  
  private double sQi;




  
  public static InfoMap weighted(Graph graph, int prIterations, RelationshipProperties weights, double threshold, double tau, ForkJoinPool pool, int concurrency, ProgressLogger logger, TerminationFlag terminationFlag) {
    PageRank.Config algoConfig = new PageRank.Config(prIterations, 1.0D - tau, PageRank.DEFAULT_TOLERANCE.doubleValue(), PAGE_RANK_CACHE_WEIGHTS);


    
    if (concurrency > 1) {









      
      CentralityResult pageRankResult = PageRankAlgorithmType.WEIGHTED.create(graph, pool, concurrency, PAGE_RANK_BATCH_SIZE, algoConfig, LongStream.empty(), AllocationTracker.create()).compute().result();
      return weighted(graph, pageRankResult::score, weights, threshold, tau, pool, concurrency, logger, terminationFlag);
    } 











    
    CentralityResult pageRankResult = PageRankAlgorithmType.WEIGHTED.create(graph, algoConfig, LongStream.empty()).compute().result();

    
    return weighted(graph, pageRankResult::score, weights, threshold, tau, pool, concurrency, logger, terminationFlag);
  }





















  
  public static InfoMap weighted(Graph graph, NodeProperties pageRanks, RelationshipProperties weights, double threshold, double tau, ForkJoinPool pool, int concurrency, ProgressLogger logger, TerminationFlag terminationFlag) {
    return new InfoMap(graph, pageRanks, new NormalizedRelationshipProperties(

          
          Math.toIntExact(graph.nodeCount()), (RelationshipIterator)graph, weights), threshold, tau, pool, concurrency, logger, terminationFlag);
  }













  
  public static InfoMap unweighted(Graph graph, int prIterations, double threshold, double tau, ForkJoinPool pool, int concurrency, ProgressLogger logger, TerminationFlag terminationFlag) {
    CentralityResult pageRankResult;
    PageRank.Config algoConfig = new PageRank.Config(prIterations, 1.0D - tau, PageRank.DEFAULT_TOLERANCE.doubleValue());


    
    if (concurrency > 1) {
      AllocationTracker tracker = AllocationTracker.create();










      
      pageRankResult = PageRankAlgorithmType.NON_WEIGHTED.create(graph, pool, concurrency, PAGE_RANK_BATCH_SIZE, algoConfig, LongStream.empty(), tracker).compute().result();
    
    }
    else {
      
      pageRankResult = PageRankAlgorithmType.NON_WEIGHTED.create(graph, algoConfig, LongStream.empty()).compute().result();
    } 
    return unweighted(graph, pageRankResult::score, threshold, tau, pool, concurrency, logger, terminationFlag);
  }












  
  public static InfoMap unweighted(Graph graph, NodeProperties pageRanks, double threshold, double tau, ForkJoinPool pool, int concurrency, ProgressLogger logger, TerminationFlag terminationFlag) { return new InfoMap(graph, pageRanks, new DegreeNormalizedRelationshipProperties((Degrees)graph), threshold, tau, pool, concurrency, logger, terminationFlag); }


























  
  private InfoMap(Graph graph, NodeProperties pageRank, RelationshipProperties normalizedWeights, double threshold, double tau, ForkJoinPool pool, int concurrency, ProgressLogger logger, TerminationFlag terminationFlag) {
    this.weights = normalizedWeights;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.tau = tau;
    this.threshold = threshold;
    this.pool = pool;
    this.concurrency = concurrency;
    this.logger = logger;
    this.terminationFlag = terminationFlag;
    this.modules = new IndexMap<>(MODULE_POS, Module.class, this.nodeCount);
    this.communities = new int[this.nodeCount];
    this.tau1 = 1.0D - tau;
    this.n1 = this.nodeCount - 1.0D;
    this.sQi = 0.0D;
    Arrays.setAll(this.communities, i -> i);
    graph.forEachNode(nodeId -> {
          
          int node = (int)nodeId;
          Module module = new Module(node, graph, pageRank);
          this.modules.put(node, module);
          this.sQi += module.q;
          return true;
        });
  }



  
  public InfoMap compute() {
    this.iterations = 0;
    long start = System.currentTimeMillis();
    long ts = start;
    while (this.terminationFlag.running() && optimize()) {
      this.iterations++;
      long iterStart = ts;
      long c = System.currentTimeMillis();
      this.logger.logProgress(this.iterations / this.nodeCount, () -> String.format("Iteration %d took %dms, overall %,dms, ETA at %,d iterations: %,dms", new Object[] {
              
              Integer.valueOf(this.iterations), 
              Long.valueOf(c - iterStart), 
              Long.valueOf(c - start), 
              Integer.valueOf(this.nodeCount), 
              Long.valueOf((long)((c - start) / this.iterations * (this.nodeCount - this.iterations)))
            }));
      ts = c;
    } 
    return this;
  }


  
  public InfoMap me() { return this; }






  
  public void release() {
    this.modules.forEach(Module::release);
    this.modules.release();
    this.modules = null;
    this.communities = null;
  }






  
  public int[] getCommunities() { return this.communities; }







  
  public int getCommunityCount() { return this.modules.size(); }







  
  public int getIterations() { return this.iterations; }










  
  private boolean optimize() {
    MergePair pair = this.pool.invoke(new Task(this.modules.array(), 0, this.modules.size(), new BitSet()));
    
    if (null == pair) {
      return false;
    }
    
    pair.modA.merge(pair.modB);
    this.modules.remove(pair.modB.index);
    return true;
  }





  
  private double delta(Module j, Module k) {
    double pi = j.p + k.p;
    double qi = this.tau * pi * (this.nodeCount - (j.n + k.n)) / this.n1 + this.tau1 * (j.w + k.w - j.wil(k));
    return plogp(qi - j.q - k.q + this.sQi) - 
      plogp(this.sQi) - 2.0D * 
      plogp(qi) + 2.0D * 
      plogp(j.q) + 2.0D * 
      plogp(k.q) + 
      plogp(pi + qi) - 
      plogp(j.p + j.q) - 
      plogp(k.p + k.q);
  }
  
  private class Task
    extends RecursiveTask<MergePair> {
    private final InfoMap.Module[] m;
    private final int from;
    private final int to;
    private final BitSet visited;
    
    private Task(InfoMap.Module[] m, int from, int to, BitSet visited) {
      this.m = m;
      this.from = from;
      this.to = to;
      this.visited = visited;
    }


    
    protected InfoMap.MergePair compute() {
      int length = this.to - this.from;
      if (InfoMap.this.concurrency > 1 && length >= InfoMap.MIN_MODS_PARALLEL_EXEC) {
        
        int half = this.from + (length + 1 >> 1);
        Task taskA = new Task(this.m, this.from, half, null);
        taskA.fork();
        Task taskB = new Task(this.m, half, this.to, this.visited);
        InfoMap.MergePair mpA = taskB.compute();
        InfoMap.MergePair mpB = taskA.join();
        return InfoMap.compare(mpA, mpB);
      } 
      
      Pointer.DoublePointer min = Pointer.wrap(-1.0D * InfoMap.this.threshold);
      
      InfoMap.Module[] best = { null, null };
      BitSet visited = this.visited;
      if (visited == null) {
        visited = new BitSet();
      }
      for (int i = this.from; i < this.to; i++) {
        InfoMap.Module module = this.m[i];
        module.forEachNeighbor(l -> {
              double v = InfoMap.this.delta(module, l);
              if (v < min.v) {
                min.v = v;
                best[0] = module;
                best[1] = l;
              } 
            }visited, InfoMap.this.modules);
      } 
      
      if (null == best[0] || best[0] == best[1]) {
        return null;
      }
      
      return new InfoMap.MergePair(best[0], best[1], min.v);
    }
  }

  
  private static class MergePair
  {
    final InfoMap.Module modA;
    final InfoMap.Module modB;
    final double deltaL;
    
    private MergePair(InfoMap.Module modA, InfoMap.Module modB, double deltaL) {
      this.modA = modA;
      this.modB = modB;
      this.deltaL = deltaL;
    }
  }



  
  private class Module
  {
    int initialPosition = -1;
    
    final int index;
    
    int n = 1;
    
    double p;
    
    double w = 0.0D;
    
    double q;
    
    private BitSet nodes;
    
    private IntDoubleMap wi;
    
    Module(int startNode, Graph graph, NodeProperties pageRank) {
      this.index = startNode;
      this.wi = (IntDoubleMap)new IntDoubleScatterMap();
      graph.forEachRelationship(startNode, D, (source, target) -> {
            
            int s = (int)source;
            int t = (int)target;
            if (s != t) {
              double v = InfoMap.this.weights.relationshipProperty(s, t, 1.0D);
              this.w += v;
              this.wi.put(t, v * pageRank.nodeProperty(s) + InfoMap.this.weights.relationshipProperty(t, s, 1.0D) * pageRank.nodeProperty(t));
            } 
            return true;
          });
      this.p = pageRank.nodeProperty(startNode);
      this.w *= this.p;
      this.q = InfoMap.this.tau * this.p + InfoMap.this.tau1 * this.w;
    }



    
    void forEachNeighbor(Consumer<Module> consumer, BitSet visited, IndexMap<Module> modules) {
      visited.clear();
      for (IntDoubleCursor cursor : this.wi) {
        int node = cursor.key;
        int c = InfoMap.this.communities[node];
        if (c == this.index) {
          return;
        }
        
        if (visited.get(c)) {
          return;
        }
        
        visited.set(c);
        consumer.accept(modules.get(c));
      } 
    }
    
    double wil(Module l) {
      double wi = 0.0D;
      for (IntDoubleCursor cursor : this.wi) {
        if (InfoMap.this.communities[cursor.key] == l.index) {
          wi += cursor.value;
        }
      } 
      return wi;
    }
    
    void merge(Module l) {
      this.n += l.n;
      this.p += l.p;
      this.w += l.w - wil(l);
      if (this.nodes == null) {
        this.nodes = new BitSet(this.index);
        this.nodes.set(this.index);
      } 
      if (l.nodes != null) {
        this.nodes.or(l.nodes);
        BitSetIterator iterator = l.nodes.iterator();
        int lNode;
        while ((lNode = iterator.nextSetBit()) != -1) {
          InfoMap.this.communities[lNode] = this.index;
        }
      } else {
        this.nodes.set(l.index);
        InfoMap.this.communities[l.index] = this.index;
      } 
      this.wi.putAll((IntDoubleAssociativeContainer)l.wi);
      this.wi.removeAll((IntContainer)this.nodes.asIntLookupContainer());
      InfoMap.this.sQi = InfoMap.this.sQi - this.q + l.q;
      this.q = InfoMap.this.tau * this.p * (InfoMap.this.nodeCount - this.n) / InfoMap.this.n1 + InfoMap.this.tau1 * this.w;
      InfoMap.this.sQi = InfoMap.this.sQi + this.q;
      l.release();
    }
    
    void release() {
      this.wi = null;
      this.nodes = null;
    }
  }
  
  private static MergePair compare(MergePair mpA, MergePair mpB) {
    if (null == mpA && null == mpB) {
      return null;
    }
    if (null == mpA) {
      return mpB;
    }
    if (null == mpB) {
      return mpA;
    }
    return (mpA.deltaL < mpB.deltaL) ? mpA : mpB;
  }

  
  private static double plogp(double v) { return (v > 0.0D) ? (v * log2(v)) : 0.0D; }


  
  private static double log2(double v) { return Math.log(v) / LOG2; }

  
  private static final IndexMap.PositionMarker<Module> MODULE_POS = new IndexMap.PositionMarker<Module>()
    {
      public int position(InfoMap.Module item) {
        return item.initialPosition;
      }


      
      public void setPosition(InfoMap.Module item, int position) { item.initialPosition = position; }
    };
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\infomap\InfoMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */