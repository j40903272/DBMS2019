package org.neo4j.graphalgo.impl.infomap;

import java.lang.reflect.Array;
import java.util.function.Consumer;



























final class IndexMap<A>
{
  public static final int NO_POS = -1;
  private PositionMarker<A> marker;
  private A[] items;
  private int length;
  
  IndexMap(PositionMarker<A> marker, Class<A> classOfA, int size) {
    this.marker = marker;
    this.items = newArray(classOfA, size);
    this.length = size;
  }


  
  private static <A> A[] newArray(Class<A> classOfA, int size) { return (A[])Array.newInstance(classOfA, size); }


  
  int size() { return this.length; }


  
  void put(int index, A item) { this.items[index] = item; }

  
  A get(int index) {
    A item = this.items[index];
    int pos;
    while ((pos = this.marker.position(item)) != -1) {
      item = this.items[pos];
    }
    return item;
  }
  
  void remove(int index) {
    int last = --this.length;
    if (index > last) {
      A item = this.items[index];
      int pos;
      while ((pos = this.marker.position(item)) != -1) {
        item = this.items[index = pos];
      }
    } 
    if (index < last) {
      A lastItem = this.items[last];
      A itemToRemove = this.items[index];
      this.marker.setPosition(itemToRemove, index);
      this.items[index] = lastItem;
      this.items[last] = itemToRemove;
    } 
  }
  
  void forEach(Consumer<? super A> block) {
    for (int i = 0; i < this.length; i++) {
      block.accept(this.items[i]);
    }
  }

  
  A[] array() { return this.items; }

  
  void release() {
    this.marker = null;
    this.items = null;
    this.length = 0;
  }
  
  public static interface PositionMarker<A> {
    int position(A param1A);
    
    void setPosition(A param1A, int param1Int);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\infomap\IndexMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */