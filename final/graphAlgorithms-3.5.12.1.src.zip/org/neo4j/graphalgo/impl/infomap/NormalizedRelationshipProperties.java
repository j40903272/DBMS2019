package org.neo4j.graphalgo.impl.infomap;

import com.carrotsearch.hppc.LongDoubleMap;
import com.carrotsearch.hppc.LongDoubleScatterMap;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.api.RelationshipProperties;
import org.neo4j.graphdb.Direction;






















public class NormalizedRelationshipProperties
  implements RelationshipProperties
{
  private RelationshipProperties weights;
  private LongDoubleMap nodeWeightSum;
  
  public NormalizedRelationshipProperties(int nodeCount, RelationshipIterator relationshipIterator, RelationshipProperties weights) {
    this.weights = weights;
    this.nodeWeightSum = (LongDoubleMap)new LongDoubleScatterMap();
    for (int n = 0; n < nodeCount; n++) {
      relationshipIterator.forEachRelationship(n, Direction.OUTGOING, 1.0D, (s, t, w) -> {
            this.nodeWeightSum.addTo(s, w);
            return true;
          });
    } 
  }


  
  public double relationshipProperty(long sourceNodeId, long targetNodeId, double fallbackValue) { return this.weights.relationshipProperty(sourceNodeId, targetNodeId, 1.0D) / this.nodeWeightSum.getOrDefault(sourceNodeId, 1.0D); }



  
  public double relationshipProperty(long sourceNodeId, long targetNodeId) { return relationshipProperty(sourceNodeId, targetNodeId, 1.0D); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\infomap\NormalizedRelationshipProperties.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */