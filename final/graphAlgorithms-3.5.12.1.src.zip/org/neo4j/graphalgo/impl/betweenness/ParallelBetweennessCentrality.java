package org.neo4j.graphalgo.impl.betweenness;

import com.carrotsearch.hppc.IntArrayDeque;
import com.carrotsearch.hppc.IntStack;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.AtomicDoubleArray;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.container.Paths;
import org.neo4j.graphdb.Direction;





































public class ParallelBetweennessCentrality
  extends Algorithm<ParallelBetweennessCentrality>
{
  private Graph graph;
  private volatile AtomicInteger nodeQueue = new AtomicInteger();
  
  private AtomicDoubleArray centrality;
  
  private final int nodeCount;
  
  private final ExecutorService executorService;
  
  private final int concurrency;
  
  private Direction direction = Direction.OUTGOING;
  
  private double divisor = 1.0D;







  
  public ParallelBetweennessCentrality(Graph graph, ExecutorService executorService, int concurrency) {
    this.graph = graph;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.executorService = executorService;
    this.concurrency = concurrency;
    this.centrality = new AtomicDoubleArray(this.nodeCount);
  }







  
  public ParallelBetweennessCentrality withDirection(Direction direction) {
    this.direction = direction;
    this.divisor = (direction == Direction.BOTH) ? 2.0D : 1.0D;
    return this;
  }





  
  public ParallelBetweennessCentrality compute() {
    this.nodeQueue.set(0);
    ArrayList<Future<?>> futures = new ArrayList<>();
    for (int i = 0; i < this.concurrency; i++) {
      futures.add(this.executorService.submit(new BCTask()));
    }
    ParallelUtil.awaitTermination(futures);
    return this;
  }






  
  public AtomicDoubleArray getCentrality() { return this.centrality; }






  
  public Stream<BetweennessCentrality.Result> resultStream() {
    return IntStream.range(0, this.nodeCount)
      .mapToObj(nodeId -> 
        new BetweennessCentrality.Result(this.graph
          .toOriginalNodeId(nodeId), this.centrality
          .get(nodeId)));
  }





  
  public ParallelBetweennessCentrality me() { return this; }





  
  public void release() {
    this.graph = null;
    this.centrality = null;
  }















  
  private class BCTask
    implements Runnable
  {
    private final RelationshipIterator localRelationshipIterator = ParallelBetweennessCentrality.this.graph.concurrentCopy();
    private final Paths paths = new Paths();
    private final IntStack stack = new IntStack();
    private final IntArrayDeque queue = new IntArrayDeque();
    private final int[] sigma = new int[ParallelBetweennessCentrality.this.nodeCount];
    private final int[] distance = new int[ParallelBetweennessCentrality.this.nodeCount];
    private final double[] delta = new double[ParallelBetweennessCentrality.this.nodeCount];

    
    public void run() {
      int startNodeId;
      do {
        reset();
        
        startNodeId = ParallelBetweennessCentrality.this.nodeQueue.getAndIncrement();
        if (startNodeId >= ParallelBetweennessCentrality.this.nodeCount || !ParallelBetweennessCentrality.this.running()) {
          return;
        }
      } while (!calculateBetweenness(startNodeId));
    }









    
    private boolean calculateBetweenness(int startNodeId) {
      ParallelBetweennessCentrality.this.getProgressLogger().logProgress(startNodeId / (ParallelBetweennessCentrality.this.nodeCount - 1));
      this.sigma[startNodeId] = 1;
      this.distance[startNodeId] = 0;
      this.queue.addLast(startNodeId);
      while (!this.queue.isEmpty()) {
        int node = this.queue.removeFirst();
        this.stack.push(node);
        this.localRelationshipIterator.forEachRelationship(node, ParallelBetweennessCentrality.this.direction, (source, targetId) -> {
              
              int target = (int)targetId;
              
              if (this.distance[target] < 0) {
                this.queue.addLast(target);
                this.distance[target] = this.distance[node] + 1;
              } 
              if (this.distance[target] == this.distance[node] + 1) {
                this.sigma[target] = this.sigma[target] + this.sigma[node];
                this.paths.append(target, node);
              } 
              return true;
            });
      } 
      
      while (!this.stack.isEmpty()) {
        int node = this.stack.pop();
        this.paths.forEach(node, v -> {
              this.delta[v] = this.delta[v] + this.sigma[v] / this.sigma[node] * (this.delta[node] + 1.0D);
              return true;
            });
        if (node != startNodeId) {
          ParallelBetweennessCentrality.this.centrality.add(node, this.delta[node] / ParallelBetweennessCentrality.this.divisor);
        }
      } 
      return false;
    }



    
    private void reset() {
      this.paths.clear();
      this.stack.clear();
      this.queue.clear();
      Arrays.fill(this.sigma, 0);
      Arrays.fill(this.delta, 0.0D);
      Arrays.fill(this.distance, -1);
    }
    
    private BCTask() {}
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\betweenness\ParallelBetweennessCentrality.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */