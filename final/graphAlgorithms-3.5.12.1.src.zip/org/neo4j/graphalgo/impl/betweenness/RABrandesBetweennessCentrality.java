package org.neo4j.graphalgo.impl.betweenness;

import com.carrotsearch.hppc.IntArrayDeque;
import com.carrotsearch.hppc.IntArrayList;
import com.carrotsearch.hppc.IntDoubleMap;
import com.carrotsearch.hppc.IntDoubleScatterMap;
import com.carrotsearch.hppc.IntIntMap;
import com.carrotsearch.hppc.IntIntScatterMap;
import com.carrotsearch.hppc.IntObjectMap;
import com.carrotsearch.hppc.IntObjectScatterMap;
import com.carrotsearch.hppc.IntStack;
import com.carrotsearch.hppc.cursors.IntCursor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.AtomicDoubleArray;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphdb.Direction;

















































public class RABrandesBetweennessCentrality
  extends Algorithm<RABrandesBetweennessCentrality>
{
  private Graph graph;
  private volatile AtomicInteger nodeQueue = new AtomicInteger();
  
  private AtomicDoubleArray centrality;
  
  private final int nodeCount;
  
  private final int expectedNodeCount;
  
  private final ExecutorService executorService;
  private final int concurrency;
  private SelectionStrategy selectionStrategy;
  private Direction direction = Direction.OUTGOING;
  
  private double divisor = 1.0D;
  
  private int maxDepth = Integer.MAX_VALUE;





  
  public RABrandesBetweennessCentrality(Graph graph, ExecutorService executorService, int concurrency, SelectionStrategy selectionStrategy) {
    this.graph = graph;
    this.executorService = executorService;
    this.concurrency = concurrency;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.centrality = new AtomicDoubleArray(this.nodeCount);
    this.selectionStrategy = selectionStrategy;
    this.expectedNodeCount = selectionStrategy.size();
  }





  
  public RABrandesBetweennessCentrality withDirection(Direction direction) {
    this.direction = direction;
    
    this.divisor = (direction == Direction.BOTH) ? 2.0D : 1.0D;
    return this;
  }





  
  public RABrandesBetweennessCentrality withMaxDepth(int maxDepth) {
    this.maxDepth = maxDepth;
    return this;
  }





  
  public RABrandesBetweennessCentrality compute() {
    this.nodeQueue.set(0);
    ArrayList<Future<?>> futures = new ArrayList<>();
    for (int i = 0; i < this.concurrency; i++) {
      futures.add(this.executorService.submit(new BCTask()));
    }
    ParallelUtil.awaitTermination(futures);
    return this;
  }






  
  public AtomicDoubleArray getCentrality() { return this.centrality; }






  
  public Stream<BetweennessCentrality.Result> resultStream() {
    return IntStream.range(0, this.nodeCount)
      .mapToObj(nodeId -> 
        new BetweennessCentrality.Result(this.graph
          .toOriginalNodeId(nodeId), this.centrality
          .get(nodeId)));
  }


  
  public RABrandesBetweennessCentrality me() { return this; }





  
  public void release() {
    this.graph = null;
    this.selectionStrategy = null;
  }





















  
  private class BCTask
    implements Runnable
  {
    private final RelationshipIterator localRelationshipIterator = RABrandesBetweennessCentrality.this.graph.concurrentCopy();
    private final IntObjectMap<IntArrayList> paths = (IntObjectMap<IntArrayList>)new IntObjectScatterMap(RABrandesBetweennessCentrality.this.expectedNodeCount);
    private final IntStack pivots = new IntStack();
    private final IntArrayDeque queue = new IntArrayDeque();
    private final IntIntMap sigma = (IntIntMap)new IntIntScatterMap(RABrandesBetweennessCentrality.this.expectedNodeCount);
    private final IntDoubleMap delta = (IntDoubleMap)new IntDoubleScatterMap(RABrandesBetweennessCentrality.this.expectedNodeCount);
    
    private final int[] distance = new int[RABrandesBetweennessCentrality.this.nodeCount];


    
    public void run() {
      double f = RABrandesBetweennessCentrality.this.nodeCount * RABrandesBetweennessCentrality.this.divisor / RABrandesBetweennessCentrality.this.selectionStrategy.size();
      
      while (true) {
        int startNodeId = RABrandesBetweennessCentrality.this.nodeQueue.getAndIncrement();
        if (startNodeId >= RABrandesBetweennessCentrality.this.nodeCount || !RABrandesBetweennessCentrality.this.running()) {
          return;
        }
        
        if (!RABrandesBetweennessCentrality.this.selectionStrategy.select(startNodeId)) {
          continue;
        }
        
        RABrandesBetweennessCentrality.this.getProgressLogger().logProgress(startNodeId / (RABrandesBetweennessCentrality.this.nodeCount - 1));
        
        Arrays.fill(this.distance, -1);
        this.sigma.clear();
        this.paths.clear();
        this.delta.clear();
        this.sigma.put(startNodeId, 1);
        this.distance[startNodeId] = 0;
        this.queue.addLast(startNodeId);
        this.queue.addLast(0);
        
        while (!this.queue.isEmpty()) {
          int node = this.queue.removeFirst();
          int nodeDepth = this.queue.removeFirst();
          if (nodeDepth - 1 > RABrandesBetweennessCentrality.this.maxDepth) {
            continue;
          }
          this.pivots.push(node);
          this.localRelationshipIterator.forEachRelationship(node, RABrandesBetweennessCentrality.this.direction, (source, targetId) -> {
                
                int target = (int)targetId;

                
                if (this.distance[target] < 0) {
                  this.queue.addLast(target);
                  this.queue.addLast(nodeDepth + 1);
                  
                  this.distance[target] = this.distance[node] + 1;
                } 
                
                if (this.distance[target] == this.distance[node] + 1) {
                  this.sigma.addTo(target, this.sigma.getOrDefault(node, 0));
                  append(target, node);
                } 
                return true;
              });
        } 
        
        while (!this.pivots.isEmpty()) {
          int node = this.pivots.pop();
          IntArrayList intCursors = (IntArrayList)this.paths.get(node);
          if (null != intCursors) {
            intCursors.forEach(c -> 
                this.delta.addTo(c.value, this.sigma
                  .getOrDefault(c.value, 0) / this.sigma
                  .getOrDefault(node, 0) * (this.delta
                  .getOrDefault(node, 0.0D) + 1.0D)));
          }
          
          if (node != startNodeId) {
            RABrandesBetweennessCentrality.this.centrality.add(node, f * this.delta.getOrDefault(node, 0.0D));
          }
        } 
      } 
    }

    
    private void append(int target, int node) {
      IntArrayList intCursors = (IntArrayList)this.paths.get(target);
      if (null == intCursors) {
        intCursors = new IntArrayList();
        this.paths.put(target, intCursors);
      } 
      intCursors.add(node);
    }
    
    private BCTask() {}
  }
  
  public static interface SelectionStrategy {
    boolean select(int param1Int);
    
    int size();
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\betweenness\RABrandesBetweennessCentrality.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */