package org.neo4j.graphalgo.impl.betweenness;

import java.security.SecureRandom;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;
import org.neo4j.graphalgo.api.Degrees;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.container.SimpleBitSet;
import org.neo4j.graphdb.Direction;
























public class RandomDegreeSelectionStrategy
  implements RABrandesBetweennessCentrality.SelectionStrategy
{
  private final Degrees degrees;
  private final Direction direction;
  private final double maxDegree;
  private final SimpleBitSet bitSet;
  private final int size;
  
  public RandomDegreeSelectionStrategy(Direction direction, Graph graph, ExecutorService pool, int concurrency) {
    this.degrees = (Degrees)graph;
    this.direction = direction;
    this.bitSet = new SimpleBitSet(Math.toIntExact(graph.nodeCount()));
    SecureRandom random = new SecureRandom();
    AtomicInteger mx = new AtomicInteger(0);
    ParallelUtil.iterateParallel(pool, Math.toIntExact(graph.nodeCount()), concurrency, node -> {
          int current, degree = this.degrees.degree(node, direction);
          
          do {
            current = mx.get();
          } while (degree > current && !mx.compareAndSet(current, degree));
        });
    this.maxDegree = mx.get();
    ParallelUtil.iterateParallel(pool, Math.toIntExact(graph.nodeCount()), concurrency, node -> {
          if (random.nextDouble() <= this.degrees.degree(node, direction) / this.maxDegree) {
            this.bitSet.put(node);
          }
        });
    this.size = this.bitSet.size();
  }


  
  public boolean select(int nodeId) { return this.bitSet.contains(nodeId); }



  
  public int size() { return this.size; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\betweenness\RandomDegreeSelectionStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */