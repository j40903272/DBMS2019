package org.neo4j.graphalgo.impl.betweenness;

import java.security.SecureRandom;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.utils.container.SimpleBitSet;

























public class RandomSelectionStrategy
  implements RABrandesBetweennessCentrality.SelectionStrategy
{
  private final SimpleBitSet bitSet;
  private final int size;
  
  public RandomSelectionStrategy(Graph graph, double probability, long seed) {
    this.bitSet = new SimpleBitSet(Math.toIntExact(graph.nodeCount()));
    SecureRandom random = new SecureRandom();
    random.setSeed(seed);
    for (int i = 0; i < graph.nodeCount(); i++) {
      if (random.nextDouble() < probability) {
        this.bitSet.put(i);
      }
    } 
    this.size = this.bitSet.size();
  }

  
  public RandomSelectionStrategy(Graph graph, double probability) { this(graph, probability, 0L); }



  
  public boolean select(int nodeId) { return this.bitSet.contains(nodeId); }



  
  public int size() { return this.size; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\betweenness\RandomSelectionStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */