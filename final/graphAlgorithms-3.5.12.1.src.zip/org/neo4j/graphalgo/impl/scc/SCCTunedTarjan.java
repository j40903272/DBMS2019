package org.neo4j.graphalgo.impl.scc;

import com.carrotsearch.hppc.IntStack;
import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.heavyweight.Converters;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.graphdb.Direction;

























public class SCCTunedTarjan
  extends Algorithm<SCCTunedTarjan>
  implements SCCAlgorithm
{
  private Graph graph;
  private IntStack edgeStack;
  private IntStack open;
  private int[] connectedComponents;
  private int nodeCount;
  private int dfs = 0;
  private int setCount = 0;
  private int minSetSize = Integer.MAX_VALUE;
  private int maxSetSize = 0;
  
  public SCCTunedTarjan(Graph graph) {
    this.graph = graph;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.connectedComponents = new int[this.nodeCount];
    this.edgeStack = new IntStack();
    this.open = new IntStack();
  }

  
  public SCCTunedTarjan compute() {
    ProgressLogger progressLogger = getProgressLogger();
    Arrays.fill(this.connectedComponents, -1);
    this.setCount = 0;
    this.dfs = 0;
    this.setCount = 0;
    this.maxSetSize = 0;
    this.minSetSize = Integer.MAX_VALUE;
    this.dfs = -(this.nodeCount + 1);
    this.graph.forEachNode(Converters.longToIntPredicate(node -> {
            if (this.connectedComponents[node] == -1) {
              lowPointDFS(node);
            }
            progressLogger.logProgress(node / (this.nodeCount - 1));
            return running();
          }));
    return this;
  }





  
  public int[] getConnectedComponents() { return this.connectedComponents; }






  
  public Stream<SCCAlgorithm.StreamResult> resultStream() { return IntStream.range(0, this.nodeCount)
      .filter(i -> (this.connectedComponents[i] != -1))
      .mapToObj(i -> new SCCAlgorithm.StreamResult(this.graph.toOriginalNodeId(i), this.connectedComponents[i])); }






  
  public long getSetCount() { return this.setCount; }






  
  public long getMinSetSize() { return this.minSetSize; }






  
  public long getMaxSetSize() { return this.maxSetSize; }

  
  private int lowPointDFS(int nodeId) {
    int dfsNum = this.dfs++;
    this.connectedComponents[nodeId] = dfsNum;
    int lowPoint = dfsNum;
    this.open.push(nodeId);
    int sz = this.edgeStack.size();
    this.graph.forEachRelationship(nodeId, Direction.OUTGOING, Converters.longToIntConsumer((sourceNodeId, targetNodeId) -> {
            this.edgeStack.push(targetNodeId);
            return true;
          }));
    
    while (this.edgeStack.size() > sz) {
      int w = this.edgeStack.pop();
      int d = this.connectedComponents[w];
      if (d == -1) {
        d = lowPointDFS(w);
      }
      if (d < lowPoint) {
        lowPoint = d;
      }
    } 
    if (dfsNum == lowPoint) {
      int element, elementCount = 0;
      
      do {
        element = this.open.pop();
        this.connectedComponents[element] = this.setCount;
        elementCount++;
      } while (element != nodeId);
      this.minSetSize = Math.min(this.minSetSize, elementCount);
      this.maxSetSize = Math.max(this.maxSetSize, elementCount);
      this.setCount++;
    } 
    return lowPoint;
  }


  
  public SCCTunedTarjan me() { return this; }





  
  public void release() {
    this.graph = null;
    this.edgeStack = null;
    this.open = null;
    this.connectedComponents = null;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\scc\SCCTunedTarjan.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */