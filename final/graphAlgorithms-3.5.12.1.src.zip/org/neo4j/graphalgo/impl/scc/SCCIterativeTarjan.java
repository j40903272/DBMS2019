package org.neo4j.graphalgo.impl.scc;

import java.util.stream.LongStream;
import java.util.stream.Stream;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;
import org.neo4j.graphalgo.core.utils.paged.PagedLongStack;
import org.neo4j.graphalgo.core.utils.paged.PagedSimpleBitSet;
import org.neo4j.graphdb.Direction;









public class SCCIterativeTarjan
  extends Algorithm<SCCIterativeTarjan>
  implements SCCAlgorithm
{
  private Graph graph;
  private final long nodeCount;
  private HugeLongArray index;
  private PagedSimpleBitSet visited;
  private HugeLongArray connectedComponents;
  private PagedLongStack stack;
  private PagedLongStack boundaries;
  private PagedLongStack todo;
  private int setCount;
  private int minSetSize;
  private int maxSetSize;
  
  private enum Action
  {
    VISIT(0L),
    VISITEDGE(1L),
    POSTVISIT(2L);
    
    public final long code;

    
    Action(long code) { this.code = code; }
  }
















  
  public SCCIterativeTarjan(Graph graph, AllocationTracker tracker) {
    this.graph = graph;
    this.nodeCount = graph.nodeCount();
    this.index = HugeLongArray.newArray(this.nodeCount, tracker);
    this.stack = new PagedLongStack(this.nodeCount, tracker);
    this.boundaries = new PagedLongStack(this.nodeCount, tracker);
    this.connectedComponents = HugeLongArray.newArray(this.nodeCount, tracker);
    this.visited = PagedSimpleBitSet.newBitSet(this.nodeCount, tracker);
    this.todo = new PagedLongStack(this.nodeCount, tracker);
  }




  
  public SCCIterativeTarjan compute() {
    this.setCount = 0;
    this.minSetSize = Integer.MAX_VALUE;
    this.maxSetSize = 0;
    this.index.fill(-1L);
    this.connectedComponents.fill(-1L);
    this.todo.clear();
    this.boundaries.clear();
    this.stack.clear();
    this.graph.forEachNode(this::compute);
    return this;
  }


  
  public SCCIterativeTarjan me() { return this; }





  
  public void release() {
    this.graph = null;
    this.index = null;
    this.visited = null;
    this.connectedComponents = null;
    this.stack = null;
    this.boundaries = null;
    this.todo = null;
  }





  
  public HugeLongArray getConnectedComponents() { return this.connectedComponents; }






  
  public Stream<SCCAlgorithm.StreamResult> resultStream() { return LongStream.range(0L, this.nodeCount)
      .filter(i -> (this.connectedComponents.get(i) != -1L))
      .mapToObj(i -> new SCCAlgorithm.StreamResult(this.graph.toOriginalNodeId(i), this.connectedComponents.get(i))); }






  
  public long getSetCount() { return this.setCount; }






  
  public long getMinSetSize() { return this.minSetSize; }






  
  public long getMaxSetSize() { return this.maxSetSize; }

  
  private boolean compute(long nodeId) {
    if (!running()) {
      return false;
    }
    if (this.index.get(nodeId) != -1L) {
      return true;
    }
    push(Action.VISIT, nodeId);
    while (!this.todo.isEmpty()) {
      long action = this.todo.pop();
      long node = this.todo.pop();
      if (action == Action.VISIT.code) {
        visit(node); continue;
      }  if (action == Action.VISITEDGE.code) {
        visitEdge(node); continue;
      } 
      postVisit(node);
    } 
    
    getProgressLogger().logProgress(nodeId / (this.nodeCount - 1L));
    return true;
  }
  
  private void visitEdge(long nodeId) {
    if (this.index.get(nodeId) == -1L) {
      push(Action.VISIT, nodeId);
    } else if (!this.visited.contains(nodeId)) {
      while (this.index.get(nodeId) < this.boundaries.peek()) {
        this.boundaries.pop();
      }
    } 
  }
  
  private void postVisit(long nodeId) {
    if (this.boundaries.peek() == this.index.get(nodeId)) {
      long element; this.boundaries.pop();
      int elementCount = 0;
      
      do {
        element = this.stack.pop();
        this.connectedComponents.set(element, nodeId);
        this.visited.put(element);
        elementCount++;
      } while (element != nodeId);
      this.minSetSize = Math.min(this.minSetSize, elementCount);
      this.maxSetSize = Math.max(this.maxSetSize, elementCount);
      this.setCount++;
    } 
  }

  
  private void visit(long nodeId) {
    long stackSize = this.stack.size();
    this.index.set(nodeId, stackSize);
    this.stack.push(nodeId);
    this.boundaries.push(stackSize);
    push(Action.POSTVISIT, nodeId);
    this.graph.forEachRelationship(nodeId, Direction.OUTGOING, (s, t) -> {
          push(Action.VISITEDGE, t);
          return true;
        });
  }






  
  private void push(Action action, long value) {
    this.todo.push(value);
    this.todo.push(action.code);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\scc\SCCIterativeTarjan.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */