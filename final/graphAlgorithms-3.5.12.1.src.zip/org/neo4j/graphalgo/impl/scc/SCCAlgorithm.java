package org.neo4j.graphalgo.impl.scc;

import java.util.stream.Stream;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;




























































public interface SCCAlgorithm
{
  SCCAlgorithm compute();
  
  long getSetCount();
  
  long getMinSetSize();
  
  long getMaxSetSize();
  
  Stream<StreamResult> resultStream();
  
  SCCAlgorithm withProgressLogger(ProgressLogger paramProgressLogger);
  
  SCCAlgorithm withTerminationFlag(TerminationFlag paramTerminationFlag);
  
  void release();
  
  <V> V getConnectedComponents();
  
  public static class StreamResult
  {
    public final long nodeId;
    public final long partition;
    
    public StreamResult(long nodeId, long partition) {
      this.nodeId = nodeId;
      this.partition = partition;
    }
  }









  
  static SCCAlgorithm iterativeTarjan(Graph graph, AllocationTracker tracker) { return new SCCIterativeTarjan(graph, tracker); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\scc\SCCAlgorithm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */