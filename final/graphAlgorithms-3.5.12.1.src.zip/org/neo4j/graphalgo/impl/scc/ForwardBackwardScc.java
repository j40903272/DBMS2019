package org.neo4j.graphalgo.impl.scc;

import com.carrotsearch.hppc.IntLookupContainer;
import com.carrotsearch.hppc.IntScatterSet;
import com.carrotsearch.hppc.IntSet;
import com.carrotsearch.hppc.cursors.IntCursor;
import java.util.concurrent.ExecutorService;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.heavyweight.Converters;
import org.neo4j.graphalgo.impl.traverse.ParallelLocalQueueBFS;
import org.neo4j.graphdb.Direction;























public class ForwardBackwardScc
  extends Algorithm<ForwardBackwardScc>
{
  private ParallelLocalQueueBFS traverse;
  private IntSet scc = (IntSet)new IntScatterSet();
  private Graph graph;
  
  public ForwardBackwardScc(Graph graph, ExecutorService executorService, int concurrency) {
    this.graph = graph;
    this.traverse = new ParallelLocalQueueBFS(graph, executorService, concurrency);
  }
  
  public ForwardBackwardScc compute(long startNode) {
    int startNodeId = Math.toIntExact(startNode);
    this.scc.clear();
    
    IntScatterSet descendant = new IntScatterSet();
    this.traverse.bfs(startNodeId, Direction.OUTGOING, node -> 
        
        running(), 
        Converters.longToIntConsumer(descendant::add))
      .awaitTermination();
    getProgressLogger().logProgress(0.5D);
    
    this.traverse.reset()
      .bfs(startNodeId, Direction.INCOMING, 
        
        Converters.longToIntPredicate(node -> (descendant.contains(node) && running())), 
        Converters.longToIntConsumer(this.scc::add))
      .awaitTermination();
    getProgressLogger().logDone();
    
    this.scc.retainAll((IntLookupContainer)descendant);
    return this;
  }

  
  public IntSet getScc() { return this.scc; }


  
  public Stream<Result> resultStream() { return StreamSupport.stream(this.scc.spliterator(), false)
      .map(node -> new Result(this.graph.toOriginalNodeId(node.value))); }



  
  public ForwardBackwardScc me() { return this; }


  
  public void release() {
    this.graph = null;
    this.traverse = null;
    this.scc = null;
  }
  
  public class Result
  {
    public final long nodeId;
    
    public Result(long nodeId) { this.nodeId = nodeId; }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\scc\ForwardBackwardScc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */