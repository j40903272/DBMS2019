package org.neo4j.graphalgo.impl.scc;

import com.carrotsearch.hppc.IntStack;
import java.util.Arrays;
import java.util.BitSet;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.heavyweight.Converters;
import org.neo4j.graphdb.Direction;
































public class SCCTarjan
  extends Algorithm<SCCTarjan>
{
  private Graph graph;
  private final int nodeCount;
  private int[] communities;
  private int[] indices;
  private int[] lowLink;
  private final BitSet onStack;
  private final IntStack stack;
  private int index;
  
  public SCCTarjan(Graph graph) {
    this.graph = graph;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.indices = new int[this.nodeCount];
    this.lowLink = new int[this.nodeCount];
    this.onStack = new BitSet(this.nodeCount);
    this.stack = new IntStack(this.nodeCount);
    this.communities = new int[this.nodeCount];
    Arrays.setAll(this.communities, i -> i);
  }




  
  public SCCTarjan compute() {
    this.graph.forEachNode(Converters.longToIntPredicate(this::test));
    return this;
  }





  
  public int[] getConnectedComponents() { return this.communities; }



  
  public SCCTarjan me() { return this; }


  
  public void release() {
    this.stack.clear();
    this.communities = null;
    this.indices = null;
    this.lowLink = null;
    this.graph = null;
  }



  
  public void reset() {
    Arrays.fill(this.indices, -1);
    Arrays.fill(this.lowLink, -1);
    this.onStack.clear();
    this.stack.clear();
    this.index = 0;
  }
  
  private void strongConnect(int node) {
    this.lowLink[node] = this.index;
    this.indices[node] = this.index++;
    this.stack.push(node);
    this.onStack.set(node);
    this.graph.concurrentCopy().forEachRelationship(node, Direction.OUTGOING, Converters.longToIntConsumer(this::accept));
    if (this.indices[node] == this.lowLink[node]) {
      relax(node);
    }
  }
  
  private void relax(int nodeId) {
    int w;
    do {
      w = this.stack.pop();
      this.onStack.clear(w);
      this.communities[w] = nodeId;
    } while (w != nodeId);
  }
  
  private boolean accept(int source, int target) {
    if (this.indices[target] == -1) {
      strongConnect(target);
      this.lowLink[source] = Math.min(this.lowLink[source], this.lowLink[target]);
    } else if (this.onStack.get(target)) {
      this.lowLink[source] = Math.min(this.lowLink[source], this.indices[target]);
    } 
    return true;
  }
  
  private boolean test(int node) {
    if (this.indices[node] == -1) {
      strongConnect(node);
    }
    this.progressLogger.logProgress(node / (this.nodeCount - 1));
    return running();
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\scc\SCCTarjan.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */