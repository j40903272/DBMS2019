package org.neo4j.graphalgo.impl.nn;

import com.carrotsearch.hppc.LongContainer;
import com.carrotsearch.hppc.LongHashSet;
import com.carrotsearch.hppc.cursors.LongCursor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Supplier;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.ProcedureConfiguration;
import org.neo4j.graphalgo.core.huge.HugeGraph;
import org.neo4j.graphalgo.core.loading.IdMap;
import org.neo4j.graphalgo.core.loading.IdMapBuilder;
import org.neo4j.graphalgo.core.loading.IdsAndProperties;
import org.neo4j.graphalgo.core.loading.NodeImporter;
import org.neo4j.graphalgo.core.loading.NodesBatchBuffer;
import org.neo4j.graphalgo.core.loading.Relationships;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.Pools;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArrayBuilder;
import org.neo4j.graphalgo.impl.results.SimilarityResult;
import org.neo4j.graphalgo.impl.similarity.AnnTopKConsumer;
import org.neo4j.graphalgo.impl.similarity.RleDecoder;
import org.neo4j.graphalgo.impl.similarity.SimilarityComputer;
import org.neo4j.graphalgo.impl.similarity.SimilarityInput;
import org.neo4j.graphdb.Direction;
import org.neo4j.logging.Log;
import org.roaringbitmap.RoaringBitmap;


















public class ApproxNearestNeighbors<T extends SimilarityInput>
  extends Algorithm<ApproxNearestNeighbors<T>>
{
  private T[] inputs;
  private final int topK;
  private final int iterations;
  private final AnnTopKConsumer[] topKConsumers;
  private final double similarityCutoff;
  private final Log log;
  private final Supplier<RleDecoder> rleDecoderFactory;
  private final Random random;
  private final AtomicInteger actualIterations;
  private volatile AtomicLong nodeQueue = new AtomicLong();
  
  private final int concurrency;
  
  private final ExecutorService executor;
  
  private final SimilarityComputer<T> similarityComputer;
  
  private final double precision;
  
  private final double p;
  
  private final boolean sampling;
  
  private final RoaringBitmap[] visitedRelationships;
  
  public ApproxNearestNeighbors(ProcedureConfiguration configuration, T[] inputs, double similarityCutoff, Supplier<RleDecoder> rleDecoderFactory, SimilarityComputer<T> similarityComputer, int topK, Log log) {
    this.inputs = inputs;
    this.topK = topK;
    this.iterations = configuration.getNumber("iterations", Integer.valueOf(10)).intValue();
    this.precision = configuration.getNumber("precision", Double.valueOf(0.001D)).doubleValue();
    this.p = configuration.getNumber("p", Double.valueOf(0.5D)).doubleValue();
    this.random = new Random(configuration.getNumber("randomSeed", Integer.valueOf(1)).longValue());
    this.sampling = configuration.getBool("sampling", true).booleanValue();
    
    this.topKConsumers = AnnTopKConsumer.initializeTopKConsumers(inputs.length, topK);
    
    this.visitedRelationships = ANNUtils.initializeRoaringBitmaps(inputs.length);
    
    this.similarityCutoff = similarityCutoff;
    this.log = log;
    this.actualIterations = new AtomicInteger();
    this.concurrency = configuration.getConcurrency();
    this.executor = Pools.DEFAULT;
    this.rleDecoderFactory = rleDecoderFactory;
    this.similarityComputer = similarityComputer;
  }
  
  public void compute() {
    double sampleSize = Math.min(this.p, 1.0D) * Math.abs(this.topK);
    Collection<Runnable> tasks = createInitTasks();
    ParallelUtil.runWithConcurrency(this.concurrency, tasks, this.executor);
    
    IdsAndProperties nodes = buildNodes(this.inputs);
    
    RoaringBitmap[] tempVisitedRelationships = ANNUtils.initializeRoaringBitmaps(this.inputs.length);
    
    for (int iteration = 1; iteration <= this.iterations; iteration++) {
      for (int i = 0; i < this.inputs.length; i++) {
        this.visitedRelationships[i] = RoaringBitmap.or(this.visitedRelationships[i], tempVisitedRelationships[i]);
      }
      tempVisitedRelationships = ANNUtils.initializeRoaringBitmaps(this.inputs.length);
      
      HugeRelationshipsBuilder.HugeRelationshipsBuilderWithBuffer relationshipBuilder = (new HugeRelationshipsBuilder(nodes)).withBuffer();
      relationshipBuilder.addRelationshipsFrom(this.topKConsumers);
      Relationships hugeRels = relationshipBuilder.build();
      
      HugeGraph hugeGraph = ANNUtils.hugeGraph(nodes, hugeRels);
      HugeRelationshipsBuilder oldRelationshipsBuilder = new HugeRelationshipsBuilder(nodes);
      HugeRelationshipsBuilder newRelationshipBuilder = new HugeRelationshipsBuilder(nodes);
      
      Collection<Runnable> setupTasks = setupTasks(sampleSize, tempVisitedRelationships, hugeGraph, oldRelationshipsBuilder, newRelationshipBuilder);
      ParallelUtil.runWithConcurrency(1, setupTasks, this.executor);
      
      HugeGraph oldHugeGraph = ANNUtils.hugeGraph(nodes, oldRelationshipsBuilder.build());
      HugeGraph newHugeGraph = ANNUtils.hugeGraph(nodes, newRelationshipBuilder.build());
      
      Collection<NeighborhoodTask> computeTasks = computeTasks(sampleSize, oldHugeGraph, newHugeGraph);
      ParallelUtil.runWithConcurrency(this.concurrency, computeTasks, this.executor);
      
      int changes = mergeConsumers(computeTasks);
      
      this.log.info("ANN: Changes in iteration %d: %d", new Object[] { Integer.valueOf(iteration), Integer.valueOf(changes) });
      this.actualIterations.set(iteration);
      
      if (shouldTerminate(changes)) {
        break;
      }
    } 
  }






  
  private Collection<Runnable> setupTasks(double sampleSize, RoaringBitmap[] tempVisitedRelationships, HugeGraph hugeGraph, HugeRelationshipsBuilder oldRelationshipsBuilder, HugeRelationshipsBuilder newRelationshipBuilder) {
    int batchSize = ParallelUtil.adjustedBatchSize(this.inputs.length, this.concurrency, 100);
    int numberOfBatches = this.inputs.length / batchSize + 1;
    Collection<Runnable> setupTasks = new ArrayList<>(numberOfBatches);
    
    long startNodeId = 0L;
    for (int batch = 0; batch < numberOfBatches; batch++) {
      long nodeCount = Math.min(batchSize, this.inputs.length - batch * batchSize);
      setupTasks.add(new SetupTask(new NewOldGraph(hugeGraph, this.visitedRelationships), tempVisitedRelationships, oldRelationshipsBuilder, newRelationshipBuilder, sampleSize, startNodeId, nodeCount));






      
      startNodeId += nodeCount;
    } 
    return setupTasks;
  }
  
  private Collection<NeighborhoodTask> computeTasks(double sampleSize, HugeGraph oldHugeGraph, HugeGraph newHugeGraph) {
    this.nodeQueue.set(0L);
    Collection<NeighborhoodTask> computeTasks = new ArrayList<>();
    for (int i = 0; i < this.concurrency; i++) {
      computeTasks.add(new ComputeTask(this.rleDecoderFactory, this.inputs.length, oldHugeGraph, newHugeGraph, sampleSize));
    }



    
    return computeTasks;
  }
  
  private IdsAndProperties buildNodes(T[] inputs) {
    HugeLongArrayBuilder idMapBuilder = HugeLongArrayBuilder.of(inputs.length, AllocationTracker.EMPTY);
    NodeImporter nodeImporter = new NodeImporter(idMapBuilder, null);
    long maxNodeId = 0L;
    
    NodesBatchBuffer buffer = new NodesBatchBuffer(null, -1, inputs.length, false);
    
    for (T input : inputs) {
      if (input.getId() > maxNodeId) {
        maxNodeId = input.getId();
      }
      buffer.add(input.getId(), -1L);
      if (buffer.isFull()) {
        nodeImporter.importNodes(buffer, null);
        buffer.reset();
      } 
    } 
    nodeImporter.importNodes(buffer, null);
    
    IdMap idMap = IdMapBuilder.build(idMapBuilder, maxNodeId, 1, AllocationTracker.EMPTY);
    return new IdsAndProperties(idMap, Collections.emptyMap());
  }
  
  private List<Runnable> createInitTasks() {
    this.nodeQueue.set(0L);
    List<Runnable> tasks = new ArrayList<>();
    for (int i = 0; i < this.concurrency; i++) {
      tasks.add(new InitTask(this.rleDecoderFactory));
    }
    return tasks;
  }
  
  private int mergeConsumers(Iterable<NeighborhoodTask> neighborhoodTasks) {
    int changes = 0;
    for (NeighborhoodTask task : neighborhoodTasks) {
      changes += task.mergeInto(this.topKConsumers);
    }
    return changes;
  }

  
  private boolean shouldTerminate(int changes) { return (changes == 0 || changes < (this.inputs.length * Math.abs(this.topK)) * this.precision); }



  
  public ApproxNearestNeighbors<T> me() { return this; }



  
  public void release() { this.inputs = null; }

  
  private class InitTask
    implements Runnable
  {
    private final RleDecoder rleDecoder;
    
    InitTask(Supplier<RleDecoder> rleDecoderFactory) { this.rleDecoder = rleDecoderFactory.get(); }


    
    public void run() {
      while (true) {
        long nodeId = ApproxNearestNeighbors.this.nodeQueue.getAndIncrement();
        if (nodeId >= ApproxNearestNeighbors.this.inputs.length || !ApproxNearestNeighbors.this.running()) {
          return;
        }
        
        int index = Math.toIntExact(nodeId);
        AnnTopKConsumer consumer = ApproxNearestNeighbors.this.topKConsumers[index];
        SimilarityInput similarityInput = ApproxNearestNeighbors.this.inputs[index];
        Set<Integer> randomNeighbors = ANNUtils.selectRandomNeighbors(Math.abs(ApproxNearestNeighbors.this.topK), ApproxNearestNeighbors.this.inputs.length, index, ApproxNearestNeighbors.this.random);
        
        for (Integer neighborIndex : randomNeighbors) {
          SimilarityInput similarityInput1 = ApproxNearestNeighbors.this.inputs[neighborIndex.intValue()];
          SimilarityResult result = ApproxNearestNeighbors.this.similarityComputer.similarity(this.rleDecoder, similarityInput, similarityInput1, ApproxNearestNeighbors.this.similarityCutoff);
          if (result != null) {
            consumer.applyAsInt(result);
          }
        } 
      } 
    }
  }

  
  static interface NeighborhoodTask
    extends Runnable
  {
    int mergeInto(AnnTopKConsumer[] param1ArrayOfAnnTopKConsumer);
  }

  
  private class SetupTask
    implements Runnable
  {
    private final NewOldGraph graph;
    
    private final HugeRelationshipsBuilder.HugeRelationshipsBuilderWithBuffer oldRelationshipBuilder;
    
    private final HugeRelationshipsBuilder.HugeRelationshipsBuilderWithBuffer newRelationshipBuilder;
    private final double sampleSize;
    private final RoaringBitmap[] visitedRelationships;
    private final long startNodeId;
    private final long nodeCount;
    
    SetupTask(NewOldGraph graph, RoaringBitmap[] visitedRelationships, HugeRelationshipsBuilder oldRelationshipBuilder, HugeRelationshipsBuilder newRelationshipBuilder, double sampleSize, long startNodeId, long nodeCount) {
      this.graph = graph;
      this.visitedRelationships = visitedRelationships;
      this.oldRelationshipBuilder = oldRelationshipBuilder.withBuffer();
      this.newRelationshipBuilder = newRelationshipBuilder.withBuffer();
      this.sampleSize = sampleSize;
      this.startNodeId = startNodeId;
      this.nodeCount = nodeCount;
    }

    
    public void run() {
      long endNodeId = this.startNodeId + this.nodeCount;
      for (long longNodeId = this.startNodeId; longNodeId < endNodeId; longNodeId++) {
        if (!ApproxNearestNeighbors.this.running()) {
          return;
        }
        int nodeId = Math.toIntExact(longNodeId);
        
        for (LongCursor neighbor : this.graph.findOldNeighbors(longNodeId)) {
          this.oldRelationshipBuilder.addRelationship(longNodeId, neighbor.value);
        }
        
        long[] potentialNewNeighbors = this.graph.findNewNeighbors(longNodeId).toArray();
        long[] newOutgoingNeighbors = ApproxNearestNeighbors.this.sampling ? ANNUtils.sampleNeighbors(potentialNewNeighbors, this.sampleSize, ApproxNearestNeighbors.this

            
            .random) : potentialNewNeighbors;
        for (long neighbor : newOutgoingNeighbors)
          this.newRelationshipBuilder.addRelationship(longNodeId, neighbor);  long[] arrayOfLong;
        int i;
        byte b;
        for (arrayOfLong = newOutgoingNeighbors, i = arrayOfLong.length, b = 0; b < i; ) { Long neighbor = Long.valueOf(arrayOfLong[b]);
          int neighborNodeId = Math.toIntExact(neighbor.longValue());
          this.visitedRelationships[nodeId].add(neighborNodeId); b++; }
      
      } 
      this.oldRelationshipBuilder.flushAll();
      this.newRelationshipBuilder.flushAll();
    }
  }

  
  private class ComputeTask
    implements NeighborhoodTask
  {
    private final RleDecoder rleDecoder;
    
    private final AnnTopKConsumer[] localTopKConsumers;
    
    private final Graph oldGraph;
    private final Graph newGraph;
    private final double sampleRate;
    
    ComputeTask(Supplier<RleDecoder> rleDecoderFactory, int length, HugeGraph oldGraph, HugeGraph newGraph, double sampleRate) {
      this.rleDecoder = rleDecoderFactory.get();
      this.localTopKConsumers = AnnTopKConsumer.initializeTopKConsumers(length, ApproxNearestNeighbors.this.topK);
      this.oldGraph = (Graph)oldGraph.concurrentCopy();
      this.newGraph = (Graph)newGraph.concurrentCopy();
      this.sampleRate = sampleRate;
    }

    
    public void run() {
      while (true) {
        long nodeId = ApproxNearestNeighbors.this.nodeQueue.getAndIncrement();
        if (nodeId >= ApproxNearestNeighbors.this.inputs.length || !ApproxNearestNeighbors.this.running()) {
          return;
        }
        
        LongHashSet oldNeighbors = getNeighbors(nodeId, this.oldGraph);
        long[] newNeighbors = getNeighbors(nodeId, this.newGraph).toArray();
        
        for (int sourceIndex = 0; sourceIndex < newNeighbors.length; sourceIndex++) {
          int sourceNodeId = Math.toIntExact(newNeighbors[sourceIndex]);
          SimilarityInput similarityInput = ApproxNearestNeighbors.this.inputs[sourceNodeId];
          for (int targetIndex = sourceIndex + 1; targetIndex < newNeighbors.length; targetIndex++) {
            int targetNodeId = Math.toIntExact(newNeighbors[targetIndex]);
            SimilarityInput similarityInput1 = ApproxNearestNeighbors.this.inputs[targetNodeId];
            SimilarityResult result = ApproxNearestNeighbors.this.similarityComputer.similarity(this.rleDecoder, similarityInput, similarityInput1, ApproxNearestNeighbors.this


                
                .similarityCutoff);
            if (result != null) {
              this.localTopKConsumers[sourceNodeId].applyAsInt(result);
              this.localTopKConsumers[targetNodeId].applyAsInt(result.reverse());
            } 
          } 
          
          for (LongCursor cursor : oldNeighbors) {
            int targetNodeId = Math.toIntExact(cursor.value);
            SimilarityInput similarityInput1 = ApproxNearestNeighbors.this.inputs[targetNodeId];
            if (sourceNodeId != targetNodeId) {
              SimilarityResult result = ApproxNearestNeighbors.this.similarityComputer.similarity(this.rleDecoder, similarityInput, similarityInput1, ApproxNearestNeighbors.this


                  
                  .similarityCutoff);
              if (result != null) {
                this.localTopKConsumers[sourceNodeId].applyAsInt(result);
                this.localTopKConsumers[targetNodeId].applyAsInt(result.reverse());
              } 
            } 
          } 
        } 
      } 
    }
    
    private LongHashSet getNeighbors(long nodeId, Graph graph) {
      long[] potentialIncomingNeighbors = ApproxNearestNeighbors.this.findNeighbors(nodeId, (RelationshipIterator)graph, Direction.INCOMING).toArray();
      
      long[] incomingNeighbors = ApproxNearestNeighbors.this.sampling ? ANNUtils.sampleNeighbors(potentialIncomingNeighbors, this.sampleRate, ApproxNearestNeighbors.this.random) : potentialIncomingNeighbors;

      
      LongHashSet outgoingNeighbors = ApproxNearestNeighbors.this.findNeighbors(nodeId, (RelationshipIterator)graph, Direction.OUTGOING);
      
      LongHashSet newNeighbors = new LongHashSet();
      newNeighbors.addAll(incomingNeighbors);
      newNeighbors.addAll((LongContainer)outgoingNeighbors);
      return newNeighbors;
    }
    
    public int mergeInto(AnnTopKConsumer[] target) {
      int changes = 0;
      for (int i = 0; i < target.length; i++) {
        changes += target[i].apply(this.localTopKConsumers[i]);
      }
      return changes;
    }
  }

  
  public AnnTopKConsumer[] result() { return this.topKConsumers; }


  
  public int iterations() { return this.actualIterations.get(); }



  
  private LongHashSet findNeighbors(long nodeId, RelationshipIterator graph, Direction direction) {
    LongHashSet neighbors = new LongHashSet();
    
    graph.forEachRelationship(nodeId, direction, (sourceNodeId, targetNodeId) -> {
          neighbors.add(targetNodeId);
          return true;
        });
    return neighbors;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\nn\ApproxNearestNeighbors.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */