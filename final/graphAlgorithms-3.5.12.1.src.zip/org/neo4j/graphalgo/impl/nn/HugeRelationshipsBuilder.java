package org.neo4j.graphalgo.impl.nn;

import java.util.Optional;
import java.util.concurrent.atomic.LongAdder;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.core.DeduplicationStrategy;
import org.neo4j.graphalgo.core.loading.AdjacencyBuilder;
import org.neo4j.graphalgo.core.loading.IdMap;
import org.neo4j.graphalgo.core.loading.IdsAndProperties;
import org.neo4j.graphalgo.core.loading.ImportSizing;
import org.neo4j.graphalgo.core.loading.RelationshipImporter;
import org.neo4j.graphalgo.core.loading.Relationships;
import org.neo4j.graphalgo.core.loading.RelationshipsBatchBuffer;
import org.neo4j.graphalgo.core.loading.RelationshipsBuilder;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.impl.results.SimilarityResult;
import org.neo4j.graphalgo.impl.similarity.AnnTopKConsumer;




















class HugeRelationshipsBuilder
{
  private final IdMap idMap;
  private final RelationshipBuilder relationshipBuilder;
  
  HugeRelationshipsBuilder(IdsAndProperties nodes) {
    this.idMap = nodes.idMap();
    this.relationshipBuilder = new RelationshipBuilder((IdMapping)nodes.idMap());
  }

  
  Relationships build() { return this.relationshipBuilder.build(); }

  
  HugeRelationshipsBuilderWithBuffer withBuffer() {
    RelationshipsBatchBuffer relBuffer = new RelationshipsBatchBuffer((IdMapping)this.idMap, -1, 10000);
    return new HugeRelationshipsBuilderWithBuffer(this.idMap, this.relationshipBuilder, relBuffer);
  }

  
  static class HugeRelationshipsBuilderWithBuffer
  {
    private final HugeRelationshipsBuilder.RelationshipBuilder builder;
    
    private final RelationshipsBatchBuffer buffer;
    private final IdMap idMap;
    
    HugeRelationshipsBuilderWithBuffer(IdMap idMap, HugeRelationshipsBuilder.RelationshipBuilder builder, RelationshipsBatchBuffer buffer) {
      this.idMap = idMap;
      this.builder = builder;
      this.buffer = buffer;
    }

    
    void addRelationship(long source, long target) { add(source, target); }

    
    void addRelationshipsFrom(AnnTopKConsumer[] topKHolder) {
      for (AnnTopKConsumer consumer : topKHolder) {
        consumer.stream().forEach(result -> {
              long source = this.idMap.toMappedNodeId(result.item1);
              long target = this.idMap.toMappedNodeId(result.item2);
              if (source != -1L && target != -1L && source != target) {
                addRelationship(source, target);
              }
            });
      } 
    }

    
    void flushAll() { this.builder.flushAll(this.buffer); }

    
    private void add(long source, long target) {
      this.buffer.add(source, target, -1L, -1L);
      
      if (this.buffer.isFull()) {
        this.builder.flushAll(this.buffer);
        this.buffer.reset();
      } 
    }

    
    Relationships build() {
      flushAll();
      return this.builder.build();
    }
  }
  
  static class RelationshipBuilder {
    private final RelationshipImporter relationshipImporter;
    private final RelationshipImporter.Imports imports;
    private final RelationshipsBuilder outRelationshipsBuilder;
    private final RelationshipsBuilder inRelationshipsBuilder;
    
    RelationshipBuilder(IdMapping idMap) {
      ImportSizing importSizing = ImportSizing.of(1, idMap.nodeCount());
      int pageSize = importSizing.pageSize();
      int numberOfPages = importSizing.numberOfPages();
      
      this.outRelationshipsBuilder = createRelationshipsBuilder();
      AdjacencyBuilder outAdjacencyBuilder = createAdjacencyBuilder(pageSize, numberOfPages, this.outRelationshipsBuilder);




      
      this.inRelationshipsBuilder = createRelationshipsBuilder();
      AdjacencyBuilder inAdjacencyBuilder = createAdjacencyBuilder(pageSize, numberOfPages, this.inRelationshipsBuilder);




      
      this.relationshipImporter = new RelationshipImporter(AllocationTracker.EMPTY, outAdjacencyBuilder, inAdjacencyBuilder);
      this.imports = this.relationshipImporter.imports(false, true, true, false);
    }
    
    Relationships build() {
      ParallelUtil.run(this.relationshipImporter.flushTasks(), null);
      return new Relationships(-1L, -1L, this.inRelationshipsBuilder

          
          .adjacency(), this.outRelationshipsBuilder
          .adjacency(), this.inRelationshipsBuilder
          .globalAdjacencyOffsets(), this.outRelationshipsBuilder
          .globalAdjacencyOffsets(), 
          Optional.empty(), this.inRelationshipsBuilder
          .weights(), this.outRelationshipsBuilder
          .weights(), this.inRelationshipsBuilder
          .globalWeightOffsets(), this.outRelationshipsBuilder
          .globalWeightOffsets());
    }




    
    static AdjacencyBuilder createAdjacencyBuilder(int pageSize, int numberOfPages, RelationshipsBuilder relationshipsBuilder) { return AdjacencyBuilder.compressing(relationshipsBuilder, numberOfPages, pageSize, AllocationTracker.EMPTY, new LongAdder(), new int[] { -2 }, new double[] { -1.0D }); }





    
    static RelationshipsBuilder createRelationshipsBuilder() { return new RelationshipsBuilder(new DeduplicationStrategy[] { DeduplicationStrategy.NONE }, AllocationTracker.EMPTY, 0); }





    
    static RelationshipImporter.PropertyReader weightReader() { return RelationshipImporter.preLoadedPropertyReader(); }


    
    void flushAll(RelationshipsBatchBuffer relBuffer) { this.imports.importRels(relBuffer, weightReader()); }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\nn\HugeRelationshipsBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */