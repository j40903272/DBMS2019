package org.neo4j.graphalgo.impl.closeness;

import java.util.concurrent.ExecutorService;
import java.util.stream.LongStream;
import java.util.stream.Stream;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.PagedAtomicDoubleArray;
import org.neo4j.graphalgo.core.write.Exporter;
import org.neo4j.graphalgo.core.write.PropertyTranslator;
import org.neo4j.graphalgo.impl.msbfs.BfsConsumer;
import org.neo4j.graphalgo.impl.msbfs.BfsSources;
import org.neo4j.graphalgo.impl.msbfs.MultiSourceBFS;
import org.neo4j.graphdb.Direction;






















public class HarmonicCentrality
  extends Algorithm<HarmonicCentrality>
{
  private Graph graph;
  private final AllocationTracker allocationTracker;
  private PagedAtomicDoubleArray inverseFarness;
  private ExecutorService executorService;
  private final int concurrency;
  private final long nodeCount;
  
  public HarmonicCentrality(Graph graph, AllocationTracker allocationTracker, int concurrency, ExecutorService executorService) {
    this.graph = graph;
    this.allocationTracker = allocationTracker;
    this.concurrency = concurrency;
    this.executorService = executorService;
    this.nodeCount = graph.nodeCount();
    this.inverseFarness = PagedAtomicDoubleArray.newArray(this.nodeCount, allocationTracker);
  }
  
  public HarmonicCentrality compute() {
    ProgressLogger progressLogger = getProgressLogger();
    BfsConsumer consumer = (nodeId, depth, sourceNodeIds) -> {
        double len = sourceNodeIds.size();
        this.inverseFarness.add(nodeId, len * 1.0D / depth);
        progressLogger.logProgress(nodeId / (this.nodeCount - 1L));
      };
    
    (new MultiSourceBFS((IdMapping)this.graph, (RelationshipIterator)this.graph, Direction.BOTH, consumer, this.allocationTracker, new long[0]))




      
      .run(this.concurrency, this.executorService);
    
    return this;
  }
  
  public Stream<Result> resultStream() {
    return LongStream.range(0L, this.nodeCount)
      .mapToObj(nodeId -> new Result(this.graph
          .toOriginalNodeId(nodeId), this.inverseFarness
          .get(nodeId) / (this.nodeCount - 1L)));
  }
  
  public void export(String propertyName, Exporter exporter) {
    exporter.write(propertyName, this.inverseFarness, (PropertyTranslator)((data, nodeId) -> 


        
        data.get((int)nodeId) / (this.nodeCount - 1L)));
  }


  
  public HarmonicCentrality me() { return this; }


  
  public void release() {
    this.graph = null;
    this.executorService = null;
    this.inverseFarness.release();
    this.inverseFarness = null;
  }

  
  public final double[] exportToArray() { return resultStream()
      .limit(2147483647L)
      .mapToDouble(r -> r.centrality)
      .toArray(); }


  
  public final class Result
  {
    public final long nodeId;

    
    public final double centrality;

    
    public Result(long nodeId, double centrality) {
      this.nodeId = nodeId;
      this.centrality = centrality;
    }


    
    public String toString() { return "Result{nodeId=" + this.nodeId + ", centrality=" + this.centrality + '}'; }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\closeness\HarmonicCentrality.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */