package org.neo4j.graphalgo.impl.closeness;

import java.util.concurrent.ExecutorService;
import java.util.stream.LongStream;
import java.util.stream.Stream;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeDoubleArray;
import org.neo4j.graphalgo.core.utils.paged.PagedAtomicIntegerArray;
import org.neo4j.graphalgo.core.write.Exporter;
import org.neo4j.graphalgo.core.write.PropertyTranslator;
import org.neo4j.graphalgo.impl.msbfs.BfsConsumer;
import org.neo4j.graphalgo.impl.msbfs.BfsSources;
import org.neo4j.graphalgo.impl.msbfs.MultiSourceBFS;
import org.neo4j.graphdb.Direction;

































public class MSClosenessCentrality
  extends Algorithm<MSClosenessCentrality>
{
  private Graph graph;
  private PagedAtomicIntegerArray farness;
  private PagedAtomicIntegerArray component;
  private final int concurrency;
  private final ExecutorService executorService;
  private final long nodeCount;
  private final AllocationTracker tracker;
  private final boolean wassermanFaust;
  
  public MSClosenessCentrality(Graph graph, AllocationTracker tracker, int concurrency, ExecutorService executorService, boolean wassermanFaust) {
    this.graph = graph;
    this.nodeCount = graph.nodeCount();
    this.concurrency = concurrency;
    this.executorService = executorService;
    this.tracker = tracker;
    this.wassermanFaust = wassermanFaust;
    this.farness = PagedAtomicIntegerArray.newArray(this.nodeCount, this.tracker);
    this.component = PagedAtomicIntegerArray.newArray(this.nodeCount, this.tracker);
  }

  
  public MSClosenessCentrality compute(Direction direction) {
    ProgressLogger progressLogger = getProgressLogger();
    
    BfsConsumer consumer = (nodeId, depth, sourceNodeIds) -> {
        int len = sourceNodeIds.size();
        this.farness.add(nodeId, len * depth);
        while (sourceNodeIds.hasNext()) {
          this.component.add(sourceNodeIds.next(), 1);
        }
        progressLogger.logProgress(nodeId / (this.nodeCount - 1L));
      };
    
    (new MultiSourceBFS((IdMapping)this.graph, (RelationshipIterator)this.graph, direction, consumer, this.tracker, new long[0]))




      
      .run(this.concurrency, this.executorService);
    
    return this;
  }
  
  public HugeDoubleArray getCentrality() {
    HugeDoubleArray cc = HugeDoubleArray.newArray(this.nodeCount, this.tracker);
    for (int i = 0; i < this.nodeCount; i++) {
      cc.set(i, centrality(this.farness.get(i), this.component
            .get(i), this.nodeCount, this.wassermanFaust));
    }

    
    return cc;
  }
  
  public void export(String propertyName, Exporter exporter) {
    exporter.write(propertyName, this.farness, (PropertyTranslator)((data, nodeId) -> 


        
        centrality(data.get(nodeId), this.component.get(nodeId), this.nodeCount, this.wassermanFaust)));
  }
  
  public Stream<Result> resultStream() {
    return LongStream.range(0L, this.nodeCount)
      .mapToObj(nodeId -> new Result(this.graph
          .toOriginalNodeId(nodeId), 
          centrality(this.farness.get(nodeId), this.component.get(nodeId), this.nodeCount, this.wassermanFaust)));
  }



  
  public MSClosenessCentrality me() { return this; }


  
  public void release() {
    this.graph = null;
    this.farness = null;
  }

  
  public MSClosenessCentrality compute() { return compute(Direction.OUTGOING); }


  
  public final double[] exportToArray() { return resultStream()
      .limit(2147483647L)
      .mapToDouble(r -> r.centrality)
      .toArray(); }

  
  static double centrality(long farness, long componentSize, long nodeCount, boolean wassermanFaust) {
    if (farness == 0L) {
      return 0.0D;
    }
    if (wassermanFaust) {
      return componentSize / farness * (componentSize - 1.0D) / (nodeCount - 1.0D);
    }
    return componentSize / farness;
  }


  
  public static final class Result
  {
    public final long nodeId;
    
    public final double centrality;

    
    public Result(long nodeId, double centrality) {
      this.nodeId = nodeId;
      this.centrality = centrality;
    }


    
    public String toString() { return "Result{nodeId=" + this.nodeId + ", centrality=" + this.centrality + '}'; }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\closeness\MSClosenessCentrality.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */