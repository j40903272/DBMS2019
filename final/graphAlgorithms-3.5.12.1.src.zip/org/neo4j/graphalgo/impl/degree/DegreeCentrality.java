package org.neo4j.graphalgo.impl.degree;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeDoubleArray;
import org.neo4j.graphalgo.impl.results.CentralityResult;
import org.neo4j.graphdb.Direction;

























public class DegreeCentrality
  extends Algorithm<DegreeCentrality>
{
  public static final double DEFAULT_WEIGHT = 0.0D;
  private final int nodeCount;
  private final boolean weighted;
  private final Direction direction;
  private Graph graph;
  private final ExecutorService executor;
  private final int concurrency;
  private final HugeDoubleArray result;
  
  public DegreeCentrality(Graph graph, ExecutorService executor, int concurrency, Direction direction, boolean weighted, AllocationTracker tracker) {
    this.graph = graph;
    this.executor = executor;
    this.concurrency = concurrency;
    this.direction = direction;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.weighted = weighted;
    this.result = HugeDoubleArray.newArray(this.nodeCount, tracker);
  }
  
  public void compute() {
    int batchSize = ParallelUtil.adjustedBatchSize(this.nodeCount, this.concurrency);
    int taskCount = ParallelUtil.threadCount(batchSize, this.nodeCount);
    List<Runnable> tasks = new ArrayList<>(taskCount);
    
    long[] starts = new long[taskCount];
    double[][] partitions = new double[taskCount][batchSize];
    
    long startNode = 0L;
    for (int i = 0; i < taskCount; i++) {
      starts[i] = startNode;
      if (this.weighted) {
        tasks.add(new WeightedDegreeTask(starts[i], partitions[i]));
      } else {
        tasks.add(new DegreeTask(starts[i], partitions[i]));
      } 
      startNode += batchSize;
    } 
    ParallelUtil.runWithConcurrency(this.concurrency, tasks, this.executor);
  }

  
  public Algorithm<?> algorithm() { return this; }



  
  public DegreeCentrality me() { return this; }



  
  public void release() { this.graph = null; }


  
  public CentralityResult result() { return new CentralityResult(this.result); }
  
  private class DegreeTask
    implements Runnable {
    private final long startNodeId;
    private final double[] partition;
    private final long endNodeId;
    
    DegreeTask(long start, double[] partition) {
      this.startNodeId = start;
      this.partition = partition;
      this.endNodeId = Math.min(start + partition.length, DegreeCentrality.this.nodeCount);
    }

    
    public void run() {
      for (long nodeId = this.startNodeId; nodeId < this.endNodeId && DegreeCentrality.this.running(); nodeId++) {
        this.partition[Math.toIntExact(nodeId - this.startNodeId)] = DegreeCentrality.this.graph.degree(nodeId, DegreeCentrality.this.direction);
      }
      DegreeCentrality.this.result.copyFromArrayIntoSlice(this.partition, this.startNodeId, this.endNodeId);
    }
  }
  
  private class WeightedDegreeTask implements Runnable {
    private final long startNodeId;
    private final double[] partition;
    private final long endNodeId;
    
    WeightedDegreeTask(long start, double[] partition) {
      this.startNodeId = start;
      this.partition = partition;
      this.endNodeId = Math.min(start + partition.length, DegreeCentrality.this.nodeCount);
    }

    
    public void run() {
      for (long nodeId = this.startNodeId; nodeId < this.endNodeId && DegreeCentrality.this.running(); nodeId++) {
        int index = Math.toIntExact(nodeId - this.startNodeId);
        DegreeCentrality.this.graph.forEachRelationship(nodeId, DegreeCentrality.this.direction, 0.0D, (sourceNodeId, targetNodeId, weight) -> {
              if (weight > 0.0D) {
                this.partition[index] = this.partition[index] + weight;
              }
              return true;
            });
      } 
      
      DegreeCentrality.this.result.copyFromArrayIntoSlice(this.partition, this.startNodeId, this.endNodeId);
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\degree\DegreeCentrality.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */