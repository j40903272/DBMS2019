package org.neo4j.graphalgo.impl;

import com.carrotsearch.hppc.IntDoubleMap;
import com.carrotsearch.hppc.IntDoubleScatterMap;
import com.carrotsearch.hppc.cursors.IntDoubleCursor;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.heavyweight.Converters;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.queue.IntPriorityQueue;
import org.neo4j.graphdb.Direction;






























public class ShortestPaths
  extends Algorithm<ShortestPaths>
{
  private Graph graph;
  private IntDoubleMap costs;
  private IntPriorityQueue queue;
  private final int nodeCount;
  private ProgressLogger progressLogger;
  
  public ShortestPaths(Graph graph) {
    this.graph = graph;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.costs = (IntDoubleMap)new IntDoubleScatterMap(this.nodeCount);
    this.queue = IntPriorityQueue.min();
    this.progressLogger = getProgressLogger();
  }






  
  public ShortestPaths compute(long startNode) {
    this.graph.forEachNode(Converters.longToIntPredicate(node -> {
            this.costs.put(node, Double.POSITIVE_INFINITY);
            return true;
          }));
    int nodeId = Math.toIntExact(this.graph.toMappedNodeId(startNode));
    this.costs.put(nodeId, 0.0D);
    this.queue.add(nodeId, 0.0D);
    run();
    return this;
  }




  
  public IntDoubleMap getShortestPaths() { return this.costs; }






  
  public Stream<Result> resultStream() { return StreamSupport.stream(this.costs.spliterator(), false)
      .map(cursor -> new Result(Long.valueOf(this.graph.toOriginalNodeId(cursor.key)), Double.valueOf(cursor.value))); }

  
  private void run() {
    while (!this.queue.isEmpty() && running()) {
      int node = this.queue.pop();
      double sourceCosts = this.costs.getOrDefault(node, Double.POSITIVE_INFINITY);
      
      this.graph.forEachRelationship(node, Direction.OUTGOING, 0.0D, 


          
          Converters.longToIntConsumer((source, target, weight) -> {
              
              double targetCosts = this.costs.getOrDefault(target, Double.POSITIVE_INFINITY);
              if (weight + sourceCosts < targetCosts) {
                this.costs.put(target, weight + sourceCosts);
                this.queue.set(target, weight + sourceCosts);
              } 
              return true;
            }));
      this.progressLogger.logProgress(node / (this.nodeCount - 1));
    } 
  }


  
  public ShortestPaths me() { return this; }


  
  public void release() {
    this.graph = null;
    this.costs = null;
    this.queue = null;
  }



  
  public static class Result
  {
    public final long nodeId;


    
    public final double distance;



    
    public Result(Long nodeId, Double distance) {
      this.nodeId = nodeId.longValue();
      this.distance = distance.doubleValue();
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\ShortestPaths.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */