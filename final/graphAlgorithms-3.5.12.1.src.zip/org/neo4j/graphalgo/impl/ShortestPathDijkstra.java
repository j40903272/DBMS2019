package org.neo4j.graphalgo.impl;

import com.carrotsearch.hppc.BitSet;
import com.carrotsearch.hppc.DoubleArrayDeque;
import com.carrotsearch.hppc.IntArrayDeque;
import com.carrotsearch.hppc.IntDoubleMap;
import com.carrotsearch.hppc.IntDoubleScatterMap;
import com.carrotsearch.hppc.IntIntMap;
import com.carrotsearch.hppc.IntIntScatterMap;
import com.carrotsearch.hppc.cursors.IntCursor;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.heavyweight.Converters;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.queue.IntPriorityQueue;
import org.neo4j.graphalgo.core.utils.queue.SharedIntPriorityQueue;
import org.neo4j.graphdb.Direction;



































public class ShortestPathDijkstra
  extends Algorithm<ShortestPathDijkstra>
{
  private static final int PATH_END = -1;
  public static final double NO_PATH_FOUND = -1.0D;
  public static final int UNUSED = 42;
  private Graph graph;
  private IntDoubleMap costs;
  private IntPriorityQueue queue;
  private IntIntMap path;
  private IntArrayDeque finalPath;
  private DoubleArrayDeque finalPathCosts;
  private BitSet visited;
  private final int nodeCount;
  private double totalCost;
  private ProgressLogger progressLogger;
  
  public ShortestPathDijkstra(Graph graph) {
    this.graph = graph;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.costs = (IntDoubleMap)new IntDoubleScatterMap();
    this.queue = (IntPriorityQueue)SharedIntPriorityQueue.min(14, this.costs, Double.MAX_VALUE);


    
    this.path = (IntIntMap)new IntIntScatterMap();
    this.visited = new BitSet();
    this.finalPath = new IntArrayDeque();
    this.finalPathCosts = new DoubleArrayDeque();
    this.progressLogger = getProgressLogger();
  }






  
  public ShortestPathDijkstra compute(long startNode, long goalNode) { return compute(startNode, goalNode, Direction.BOTH); }

  
  public ShortestPathDijkstra compute(long startNode, long goalNode, Direction direction) {
    reset();
    
    int node = Math.toIntExact(this.graph.toMappedNodeId(startNode));
    int goal = Math.toIntExact(this.graph.toMappedNodeId(goalNode));
    this.costs.put(node, 0.0D);
    this.queue.add(node, 0.0D);
    run(goal, direction);
    if (!this.path.containsKey(goal)) {
      return this;
    }
    this.totalCost = this.costs.get(goal);
    int last = goal;
    while (last != -1) {
      this.finalPath.addFirst(last);
      this.finalPathCosts.addFirst(this.costs.get(last));
      last = this.path.getOrDefault(last, -1);
    } 

    
    this.costs.release();
    this.path.release();
    return this;
  }





  
  public Stream<Result> resultStream() {
    double[] costs = this.finalPathCosts.buffer;
    return StreamSupport.stream(this.finalPath.spliterator(), false)
      .map(cursor -> new Result(Long.valueOf(this.graph.toOriginalNodeId(cursor.value)), Double.valueOf(costs[cursor.index])));
  }

  
  public IntArrayDeque getFinalPath() { return this.finalPath; }


  
  public double[] getFinalPathCosts() { return this.finalPathCosts.toArray(); }







  
  public double getTotalCost() { return this.totalCost; }







  
  public int getPathLength() { return this.finalPath.size(); }

  
  private void run(int goal, Direction direction) {
    while (!this.queue.isEmpty() && running()) {
      int node = this.queue.pop();
      if (node == goal) {
        return;
      }
      
      this.visited.set(node);
      double costs = this.costs.getOrDefault(node, Double.MAX_VALUE);
      this.graph.forEachRelationship(node, direction, 1.0D, 


          
          Converters.longToIntConsumer((source, target, weight) -> {
              updateCosts(source, target, weight + costs);
              return true;
            }));
      this.progressLogger.logProgress(node / (this.nodeCount - 1));
    } 
  }

  
  private void updateCosts(int source, int target, double newCosts) {
    if (this.costs.containsKey(target)) {
      if (newCosts < this.costs.getOrDefault(target, Double.MAX_VALUE)) {
        this.costs.put(target, newCosts);
        this.path.put(target, source);
        this.queue.update(target);
      }
    
    } else if (newCosts < this.costs.getOrDefault(target, Double.MAX_VALUE)) {
      this.costs.put(target, newCosts);
      this.path.put(target, source);
      this.queue.add(target, newCosts);
    } 
  }



  
  public ShortestPathDijkstra me() { return this; }


  
  public void release() {
    this.graph = null;
    this.costs = null;
    this.queue = null;
    this.path = null;
    this.finalPath = null;
    this.visited = null;
  }
  
  private void reset() {
    this.visited.clear();
    this.queue.clear();
    this.costs.clear();
    this.path.clear();
    this.finalPath.clear();
    this.totalCost = -1.0D;
  }



  
  public static class Result
  {
    public final Long nodeId;


    
    public final Double cost;



    
    public Result(Long nodeId, Double cost) {
      this.nodeId = nodeId;
      this.cost = cost;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\ShortestPathDijkstra.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */