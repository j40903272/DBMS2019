package org.neo4j.graphalgo.impl.multistepscc;

import com.carrotsearch.hppc.IntContainer;
import com.carrotsearch.hppc.IntScatterSet;
import com.carrotsearch.hppc.IntSet;
import com.carrotsearch.hppc.IntStack;
import com.carrotsearch.hppc.cursors.IntCursor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicIntegerArray;
import java.util.function.IntPredicate;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.ExceptionUtil;
import org.neo4j.graphalgo.core.utils.container.AtomicBitSet;
import org.neo4j.graphalgo.core.utils.container.FlipStack;
import org.neo4j.graphdb.Direction;
import org.neo4j.helpers.Exceptions;
import org.neo4j.kernel.impl.util.collection.SimpleBitSet;






































public class MultiStepColoring
{
  public static final int MIN_BATCH_SIZE = 100000;
  private final Graph graph;
  private final ExecutorService executorService;
  private final AtomicIntegerArray colors;
  private final AtomicBitSet visited;
  private final List<Future<IntContainer>> futures = new ArrayList<>();
  private final int concurrency;
  private final int nodeCount;
  
  public MultiStepColoring(Graph graph, ExecutorService executorService, int concurrency) {
    this.graph = graph;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.executorService = executorService;
    this.concurrency = concurrency;
    this.colors = new AtomicIntegerArray(this.nodeCount);
    this.visited = new AtomicBitSet(this.nodeCount);
  }






  
  public MultiStepColoring compute(IntSet nodes) {
    resetColors((IntContainer)nodes);
    msColorParallel(nodes);
    return this;
  }

  
  public AtomicIntegerArray getColors() { return this.colors; }






  
  public void forEachColor(IntPredicate consumer) {
    SimpleBitSet bitSet = new SimpleBitSet(this.nodeCount);
    for (int i = 0; i < this.nodeCount; i++) {
      int color = this.colors.get(i);
      if (!bitSet.contains(color)) {
        bitSet.put(color);
        if (!consumer.test(color)) {
          return;
        }
      } 
    } 
  }






  
  private void msColorParallel(IntSet nodeSet) {
    FlipStack flipStack = new FlipStack((IntContainer)nodeSet);
    
    flipStack.flip();
    
    while (!flipStack.isEmpty()) {
      
      this.futures.clear();
      
      int size = flipStack.popStack().size();
      int batchSize = Math.floorDiv(size, this.concurrency);
      
      if (this.concurrency <= 1 || batchSize < 100000) {
        this.futures.add(this.executorService.submit(() -> msColorTask((IntContainer)flipStack.popStack())));
      } else {
        
        Iterator<IntCursor> it = flipStack.popStack().iterator(); int i;
        for (i = 0; i < size; i += batchSize) {
          
          IntScatterSet partition = partition(it, batchSize);
          
          this.futures.add(this.executorService.submit(() -> msColorTask((IntContainer)partition)));
        } 
      } 

      
      flipStack.pushStack().clear();
      union(flipStack.pushStack(), this.futures);
      
      flipStack.flip();
    } 
  }






  
  private IntContainer msColorTask(IntContainer nodes) {
    RelationshipIterator localRelationshipIterator = this.graph.concurrentCopy();
    
    IntStack levelQueue = new IntStack(nodes.size());
    
    nodes.forEach(node -> {
          int nodeColor = this.colors.get(node);
          boolean[] change = { false };
          localRelationshipIterator.forEachRelationship(node, Direction.OUTGOING, ());









          
          if (change[0] && !this.visited.get(node)) {
            levelQueue.push(node);
            this.visited.set(node);
          } 
        });
    
    return (IntContainer)levelQueue;
  }





  
  private void msColorSequential(IntSet nodes) {
    RelationshipIterator localRelationshipIterator = this.graph.concurrentCopy();
    
    FlipStack queue = new FlipStack(nodes.size());
    queue.addAll((IntContainer)nodes);
    queue.flip();
    
    while (!queue.isEmpty()) {
      queue.forEach(node -> {
            int nodeColor = this.colors.get(node);
            boolean[] change = { false };
            localRelationshipIterator.forEachRelationship(node, Direction.OUTGOING, ());









            
            if (change[0] && !this.visited.get(node)) {
              queue.push(node);
              this.visited.set(node);
            } 
          });
      queue.popStack().clear();
      queue.flip();
    } 
  }






  
  private void simpleColor(IntSet nodes) {
    RelationshipIterator localRelationshipIterator = this.graph.concurrentCopy();
    
    boolean[] changed = { false };
    do {
      changed[0] = false;
      nodes.forEach(node -> {
            int nodeColor = this.colors.get(node);
            
            localRelationshipIterator.forEachRelationship(node, Direction.OUTGOING, ());





          
          });
    }
    while (changed[0]);
  }

  
  private void resetColors(IntContainer nodes) { nodes.forEach(node -> this.colors.set(node, node)); }








  
  private IntScatterSet partition(Iterator<IntCursor> it, int batchSize) {
    IntScatterSet partition = new IntScatterSet(batchSize);
    for (int j = 0; j < batchSize && it.hasNext(); j++) {
      partition.add(((IntCursor)it.next()).value);
    }
    return partition;
  }








  
  private boolean cas(int nodeId, int color) {
    boolean stored = false;
    while (!stored) {
      int oldC = this.colors.get(nodeId);
      if (color > oldC) {
        stored = this.colors.compareAndSet(nodeId, oldC, color);
      }
    } 

    
    return stored;
  }







  
  private void union(IntStack ret, Collection<Future<IntContainer>> futures) {
    boolean done = false;
    Throwable error = null;
    try {
      for (Future<IntContainer> future : futures) {
        try {
          ((IntContainer)future.get()).forEach(ret::add);
        } catch (ExecutionException ee) {
          error = ExceptionUtil.chain(error, ee.getCause());
        } catch (CancellationException cancellationException) {}
      } 
      
      done = true;
    } catch (InterruptedException e) {
      error = ExceptionUtil.chain(e, error);
    } finally {
      if (!done) {
        for (Future<?> future : futures) {
          future.cancel(false);
        }
      }
    } 
    if (error != null)
      throw Exceptions.launderedException(error); 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\multistepscc\MultiStepColoring.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */