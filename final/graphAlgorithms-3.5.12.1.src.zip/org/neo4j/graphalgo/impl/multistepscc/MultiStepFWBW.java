package org.neo4j.graphalgo.impl.multistepscc;

import com.carrotsearch.hppc.IntLookupContainer;
import com.carrotsearch.hppc.IntScatterSet;
import com.carrotsearch.hppc.IntSet;
import java.util.concurrent.ExecutorService;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.heavyweight.Converters;
import org.neo4j.graphalgo.impl.traverse.ParallelLocalQueueBFS;
import org.neo4j.graphdb.Direction;

































public class MultiStepFWBW
{
  private final Graph graph;
  private final ParallelLocalQueueBFS traverse;
  private int root;
  
  public MultiStepFWBW(Graph graph, ExecutorService executorService, int concurrency) {
    this.graph = graph;
    this.traverse = new ParallelLocalQueueBFS(graph, executorService, concurrency);
  }
  
  public IntSet compute(IntSet nodes) {
    this.root = pivot(nodes);
    
    IntScatterSet descendant = new IntScatterSet();
    this.traverse.bfs(this.root, Direction.OUTGOING, Converters.longToIntPredicate(nodes::contains), Converters.longToIntConsumer(descendant::add))
      .awaitTermination();
    
    IntScatterSet intScatterSet = new IntScatterSet();
    this.traverse.reset()
      .bfs(this.root, Direction.INCOMING, Converters.longToIntPredicate(descendant::contains), Converters.longToIntConsumer(intScatterSet::add))
      .awaitTermination();
    
    intScatterSet.retainAll((IntLookupContainer)descendant);
    return (IntSet)intScatterSet;
  }






  
  public int getRoot() { return this.root; }








  
  private int pivot(IntSet set) {
    int product = 0;
    int[] pivot = { 0 };
    set.forEach(node -> {
          int p = this.graph.degree(node, Direction.OUTGOING) * this.graph.degree(node, Direction.INCOMING);
          if (p > product) {
            pivot[0] = node;
          }
        });
    return pivot[0];
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\multistepscc\MultiStepFWBW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */