package org.neo4j.graphalgo.impl;

import java.util.Arrays;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.LongStream;
import java.util.stream.Stream;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.heavyweight.Converters;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.queue.IntPriorityQueue;
import org.neo4j.graphdb.Direction;
















































public class WeightedAllShortestPaths
  extends MSBFSASPAlgorithm<WeightedAllShortestPaths>
{
  private Graph graph;
  private final int nodeCount;
  private final int concurrency;
  private AtomicInteger counter;
  private ExecutorService executorService;
  private final Direction direction;
  private BlockingQueue<Result> resultQueue;
  private volatile boolean outputStreamOpen;
  
  public WeightedAllShortestPaths(Graph graph, ExecutorService executorService, int concurrency, Direction direction) {
    if (!graph.hasRelationshipProperty()) {
      throw new UnsupportedOperationException("WeightedAllShortestPaths is not supported on graphs without a weight property");
    }
    
    this.graph = graph;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.executorService = executorService;
    this.direction = direction;
    if (concurrency < 1) {
      throw new IllegalArgumentException("concurrency must be >0");
    }
    this.concurrency = concurrency;
    this.counter = new AtomicInteger();
    this.resultQueue = new LinkedBlockingQueue<>();
  }








  
  public Stream<Result> resultStream() {
    this.counter.set(0);
    this.outputStreamOpen = true;
    
    for (int i = 0; i < this.concurrency; i++) {
      this.executorService.submit(new ShortestPathTask());
    }
    
    long end = this.nodeCount * this.nodeCount;
    
    return LongStream.range(0L, end)
      .onClose(() -> this.outputStreamOpen = false)
      .mapToObj(i -> {
          try {
            return this.resultQueue.take();
          } catch (InterruptedException e) {
            throw new RuntimeException(e);
          } 
        }).filter(result -> (result.distance != Double.POSITIVE_INFINITY));
  }


  
  public WeightedAllShortestPaths me() { return this; }


  
  public void release() {
    this.graph = null;
    this.counter = null;
    this.resultQueue = null;
  }








  
  private class ShortestPathTask
    implements Runnable
  {
    private final double[] distance = new double[WeightedAllShortestPaths.this.nodeCount];
    private final IntPriorityQueue queue = IntPriorityQueue.min();


    
    public void run() {
      ProgressLogger progressLogger = WeightedAllShortestPaths.this.getProgressLogger();
      int startNode;
      while (WeightedAllShortestPaths.this.outputStreamOpen && WeightedAllShortestPaths.this.running() && (startNode = WeightedAllShortestPaths.this.counter.getAndIncrement()) < WeightedAllShortestPaths.this.nodeCount) {
        compute(startNode);
        for (int i = 0; i < WeightedAllShortestPaths.this.nodeCount; i++) {

          
          WeightedAllShortestPaths.Result result = new WeightedAllShortestPaths.Result(WeightedAllShortestPaths.this.graph.toOriginalNodeId(startNode), WeightedAllShortestPaths.this.graph.toOriginalNodeId(i), this.distance[i]);

          
          try {
            WeightedAllShortestPaths.this.resultQueue.put(result);
          } catch (InterruptedException e) {
            throw new RuntimeException(e);
          } 
        } 
        progressLogger.logProgress(startNode / (WeightedAllShortestPaths.this.nodeCount - 1));
      } 
    }
    
    public void compute(int startNode) {
      Arrays.fill(this.distance, Double.POSITIVE_INFINITY);
      this.distance[startNode] = 0.0D;
      this.queue.add(startNode, 0.0D);
      while (WeightedAllShortestPaths.this.outputStreamOpen && !this.queue.isEmpty()) {
        int node = this.queue.pop();
        double sourceDistance = this.distance[node];
        WeightedAllShortestPaths.this.graph.forEachRelationship(node, WeightedAllShortestPaths.this
            
            .direction, NaND, 
            
            Converters.longToIntConsumer((source, target, weight) -> {
                
                double targetDistance = weight + sourceDistance;
                if (targetDistance < this.distance[target]) {
                  this.distance[target] = targetDistance;
                  this.queue.set(target, targetDistance);
                } 
                return true;
              }));
      } 
    }


    
    private ShortestPathTask() {}
  }


  
  public static class Result
  {
    public final long sourceNodeId;

    
    public final long targetNodeId;

    
    public final double distance;


    
    public Result(long sourceNodeId, long targetNodeId, double distance) {
      this.sourceNodeId = sourceNodeId;
      this.targetNodeId = targetNodeId;
      this.distance = distance;
    }


    
    public String toString() { return "Result{sourceNodeId=" + this.sourceNodeId + ", targetNodeId=" + this.targetNodeId + ", distance=" + this.distance + '}'; }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\WeightedAllShortestPaths.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */