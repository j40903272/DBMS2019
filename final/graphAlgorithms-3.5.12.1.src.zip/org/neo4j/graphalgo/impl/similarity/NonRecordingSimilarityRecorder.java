package org.neo4j.graphalgo.impl.similarity;

import org.neo4j.graphalgo.impl.results.SimilarityResult;



















public class NonRecordingSimilarityRecorder<T>
  implements SimilarityRecorder<T>
{
  private final SimilarityComputer<T> computer;
  
  public NonRecordingSimilarityRecorder(SimilarityComputer<T> computer) { this.computer = computer; }


  
  public long count() { return -1L; }



  
  public SimilarityResult similarity(RleDecoder decoder, T source, T target, double cutoff) { return this.computer.similarity(decoder, source, target, cutoff); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\similarity\NonRecordingSimilarityRecorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */