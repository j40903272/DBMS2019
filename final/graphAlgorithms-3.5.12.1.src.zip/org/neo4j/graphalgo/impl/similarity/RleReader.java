package org.neo4j.graphalgo.impl.similarity;






















public class RleReader
{
  private final double[] decodedVector;
  private double[] vector;
  private double value;
  private int index = 0;
  
  private int count;
  
  public RleReader(int decodedVectorSize) { this.decodedVector = new double[decodedVectorSize]; }

  
  public void reset(double[] vector) {
    if (this.vector == null || !this.vector.equals(vector)) {
      this.vector = vector;
      reset();
      compute();
    } 
  }

  
  public double[] read() { return this.decodedVector; }

  
  private void next() {
    if (this.count > 0) {
      this.count--;
      
      return;
    } 
    this.value = this.vector[this.index++];
    
    if (this.value == Double.POSITIVE_INFINITY) {
      this.count = (int)this.vector[this.index++] - 1;
      this.value = this.vector[this.index++];
    } 
  }
  
  private void reset() {
    this.index = 0;
    this.value = -1.0D;
    this.count = -1;
  }
  
  private void compute() {
    for (int i = 0; i < this.decodedVector.length; i++) {
      next();
      this.decodedVector[i] = this.value;
    } 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\similarity\RleReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */