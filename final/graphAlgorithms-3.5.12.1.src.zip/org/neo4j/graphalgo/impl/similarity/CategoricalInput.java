package org.neo4j.graphalgo.impl.similarity;

import java.util.Arrays;
import org.neo4j.graphalgo.core.utils.Intersections;
import org.neo4j.graphalgo.impl.results.SimilarityResult;



















public class CategoricalInput
  implements Comparable<CategoricalInput>, SimilarityInput
{
  long id;
  long[] targets;
  
  public CategoricalInput(long id, long[] targets) {
    this.id = id;
    this.targets = targets;
  }

  
  public long getId() { return this.id; }



  
  public int compareTo(CategoricalInput o) { return Long.compare(this.id, o.id); }

  
  public SimilarityResult jaccard(double similarityCutoff, CategoricalInput e2, boolean bidirectional) {
    long intersection = Intersections.intersection3(this.targets, e2.targets);
    if (similarityCutoff >= 0.0D && intersection == 0L) return null; 
    int count1 = this.targets.length;
    int count2 = e2.targets.length;
    long denominator = (count1 + count2) - intersection;
    double jaccard = (denominator == 0L) ? 0.0D : (intersection / denominator);
    if (jaccard < similarityCutoff) return null; 
    return new SimilarityResult(this.id, e2.id, count1, count2, intersection, jaccard, bidirectional, false);
  }

  
  public SimilarityResult overlap(double similarityCutoff, CategoricalInput e2) { return overlap(similarityCutoff, e2, true); }

  
  public SimilarityResult overlap(double similarityCutoff, CategoricalInput e2, boolean inferReverse) {
    long intersection = Intersections.intersection3(this.targets, e2.targets);
    if (similarityCutoff >= 0.0D && intersection == 0L) return null; 
    int count1 = this.targets.length;
    int count2 = e2.targets.length;
    long denominator = Math.min(count1, count2);
    double overlap = (denominator == 0L) ? 0.0D : (intersection / denominator);
    if (overlap < similarityCutoff) return null;
    
    if (count1 <= count2) {
      return new SimilarityResult(this.id, e2.id, count1, count2, intersection, overlap, false, false);
    }
    return inferReverse ? new SimilarityResult(e2.id, this.id, count2, count1, intersection, overlap, false, true) : null;
  }



  
  public String toString() {
    return "CategoricalInput{id=" + this.id + ", targets=" + 
      
      Arrays.toString(this.targets) + '}';
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\similarity\CategoricalInput.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */