package org.neo4j.graphalgo.impl;

import com.carrotsearch.hppc.AbstractIterator;
import java.util.Iterator;
import java.util.Spliterators;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.impl.msbfs.BfsSources;
import org.neo4j.graphalgo.impl.msbfs.MultiSourceBFS;
import org.neo4j.graphdb.Direction;































public class MSBFSAllShortestPaths
  extends MSBFSASPAlgorithm<MSBFSAllShortestPaths>
{
  private Graph graph;
  private BlockingQueue<WeightedAllShortestPaths.Result> resultQueue;
  private final AllocationTracker tracker;
  private final int concurrency;
  private final ExecutorService executorService;
  private final Direction direction;
  private final long nodeCount;
  
  public MSBFSAllShortestPaths(Graph graph, AllocationTracker tracker, int concurrency, ExecutorService executorService, Direction direction) {
    this.graph = graph;
    this.nodeCount = graph.nodeCount();
    this.tracker = tracker;
    this.concurrency = concurrency;
    this.executorService = executorService;
    this.direction = direction;
    this.resultQueue = new LinkedBlockingQueue<>();
  }







  
  public Stream<WeightedAllShortestPaths.Result> resultStream() {
    this.executorService.submit(new ShortestPathTask(this.concurrency, this.executorService));
    AbstractIterator<WeightedAllShortestPaths.Result> abstractIterator = new AbstractIterator<WeightedAllShortestPaths.Result>()
      {
        protected WeightedAllShortestPaths.Result fetch() {
          try {
            WeightedAllShortestPaths.Result result = MSBFSAllShortestPaths.this.resultQueue.take();
            if (result.sourceNodeId == -1L) {
              return (WeightedAllShortestPaths.Result)done();
            }
            return result;
          } catch (InterruptedException e1) {
            throw new RuntimeException(e1);
          } 
        }
      };
    return StreamSupport.stream(Spliterators.spliteratorUnknownSize((Iterator<? extends WeightedAllShortestPaths.Result>)abstractIterator, 0), false);
  }




  
  public MSBFSAllShortestPaths me() { return this; }


  
  public void release() {
    this.graph = null;
    this.resultQueue = null;
  }


  
  private class ShortestPathTask
    implements Runnable
  {
    private final int concurrency;

    
    private final ExecutorService executorService;


    
    private ShortestPathTask(int concurrency, ExecutorService executorService) {
      this.concurrency = concurrency;
      this.executorService = executorService;
    }


    
    public void run() {
      ProgressLogger progressLogger = MSBFSAllShortestPaths.this.getProgressLogger();
      double maxNodeId = (MSBFSAllShortestPaths.this.nodeCount - 1L);
      (new MultiSourceBFS(
          (IdMapping)MSBFSAllShortestPaths.this.graph, 
          (RelationshipIterator)MSBFSAllShortestPaths.this.graph, MSBFSAllShortestPaths.this
          .direction, (target, distance, sources) -> {
            
            while (sources.hasNext()) {
              long source = sources.next();

              
              WeightedAllShortestPaths.Result result = new WeightedAllShortestPaths.Result(MSBFSAllShortestPaths.this.graph.toOriginalNodeId(source), MSBFSAllShortestPaths.this.graph.toOriginalNodeId(target), distance);
              
              try {
                MSBFSAllShortestPaths.this.resultQueue.put(result);
              } catch (InterruptedException e) {
                throw new RuntimeException(e);
              } 
            } 
            progressLogger.logProgress(target, maxNodeId);
          
          }MSBFSAllShortestPaths.this.tracker, new long[0]))
        .run(this.concurrency, this.executorService);
      
      MSBFSAllShortestPaths.this.resultQueue.add(new WeightedAllShortestPaths.Result(-1L, -1L, -1.0D));
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\MSBFSAllShortestPaths.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */