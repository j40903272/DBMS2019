package org.neo4j.graphalgo.impl.msbfs;

import java.util.AbstractCollection;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeCursor;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;
import org.neo4j.graphdb.Direction;








































































public final class MultiSourceBFS
  implements Runnable
{
  static final int OMEGA = 64;
  private final ThreadLocal<HugeLongArray> visits;
  private final ThreadLocal<HugeLongArray> nexts;
  private final ThreadLocal<HugeLongArray> seens;
  private final IdMapping nodeIds;
  private final RelationshipIterator relationships;
  private final Direction direction;
  private final BfsConsumer perNodeAction;
  private final long[] startNodes;
  private int sourceNodeCount;
  private long nodeOffset;
  private long nodeCount;
  
  public MultiSourceBFS(IdMapping nodeIds, RelationshipIterator relationships, Direction direction, BfsConsumer perNodeAction, AllocationTracker tracker, long... startNodes) {
    this.nodeIds = nodeIds;
    this.relationships = relationships;
    this.direction = direction;
    this.perNodeAction = perNodeAction;
    this.startNodes = (startNodes != null && startNodes.length > 0) ? startNodes : null;
    if (this.startNodes != null) {
      Arrays.sort(this.startNodes);
    }
    this.nodeCount = nodeIds.nodeCount();
    this.visits = new LocalHugeLongArray(this.nodeCount, tracker);
    this.nexts = new LocalHugeLongArray(this.nodeCount, tracker);
    this.seens = new LocalHugeLongArray(this.nodeCount, tracker);
  }









  
  private MultiSourceBFS(IdMapping nodeIds, RelationshipIterator relationships, Direction direction, BfsConsumer perNodeAction, long nodeCount, ThreadLocal<HugeLongArray> visits, ThreadLocal<HugeLongArray> nexts, ThreadLocal<HugeLongArray> seens, long... startNodes) {
    assert startNodes != null && startNodes.length > 0;
    this.nodeIds = nodeIds;
    this.relationships = relationships;
    this.direction = direction;
    this.perNodeAction = perNodeAction;
    this.startNodes = startNodes;
    this.nodeCount = nodeCount;
    this.visits = visits;
    this.nexts = nexts;
    this.seens = seens;
  }










  
  private MultiSourceBFS(IdMapping nodeIds, RelationshipIterator relationships, Direction direction, BfsConsumer perNodeAction, long nodeCount, long nodeOffset, int sourceNodeCount, ThreadLocal<HugeLongArray> visits, ThreadLocal<HugeLongArray> nexts, ThreadLocal<HugeLongArray> seens) {
    this.nodeIds = nodeIds;
    this.relationships = relationships;
    this.direction = direction;
    this.perNodeAction = perNodeAction;
    this.startNodes = null;
    this.nodeCount = nodeCount;
    this.nodeOffset = nodeOffset;
    this.sourceNodeCount = sourceNodeCount;
    this.visits = visits;
    this.nexts = nexts;
    this.seens = seens;
  }



  
  public void run(int concurrency, ExecutorService executor) {
    int threads = numberOfThreads();
    Collection<MultiSourceBFS> bfss = allSourceBfss(threads);
    if (!ParallelUtil.canRunInParallel(executor))
    {
      executor = null;
    }
    ParallelUtil.runWithConcurrency(concurrency, bfss, (threads << 2), 100L, TimeUnit.MICROSECONDS, executor);
  }










  
  public void run() {
    SourceNodes sourceNodes;
    assert sourceLength() <= 64L : "more than 64 sources not supported";
    
    long totalNodeCount = this.nodeCount;
    
    HugeLongArray visitSet = this.visits.get();
    HugeLongArray nextSet = this.nexts.get();
    HugeLongArray seenSet = this.seens.get();

    
    if (this.startNodes == null) {
      sourceNodes = prepareOffsetSources(visitSet, seenSet);
    } else {
      sourceNodes = prepareSpecifiedSources(visitSet, seenSet);
    } 
    
    runLocalMsbfs(totalNodeCount, sourceNodes, visitSet, nextSet, seenSet);
  }
  
  private SourceNodes prepareOffsetSources(HugeLongArray visitSet, HugeLongArray seenSet) {
    int localNodeCount = this.sourceNodeCount;
    long nodeOffset = this.nodeOffset;
    SourceNodes sourceNodes = new SourceNodes(nodeOffset, localNodeCount);
    
    for (int i = 0; i < localNodeCount; i++) {
      seenSet.set(nodeOffset + i, 1L << i);
      visitSet.or(nodeOffset + i, 1L << i);
    } 
    
    return sourceNodes;
  }
  
  private SourceNodes prepareSpecifiedSources(HugeLongArray visitSet, HugeLongArray seenSet) {
    assert isSorted(this.startNodes);
    
    long[] startNodes = this.startNodes;
    int localNodeCount = startNodes.length;
    SourceNodes sourceNodes = new SourceNodes(startNodes);
    
    for (int i = 0; i < localNodeCount; i++) {
      long nodeId = startNodes[i];
      seenSet.set(nodeId, 1L << i);
      visitSet.or(nodeId, 1L << i);
    } 
    
    return sourceNodes;
  }






  
  private void runLocalMsbfs(long totalNodeCount, SourceNodes sourceNodes, HugeLongArray visitSet, HugeLongArray nextSet, HugeLongArray seenSet) {
    HugeCursor<long[]> visitCursor = visitSet.newCursor();
    HugeCursor<long[]> nextCursor = nextSet.newCursor();
    int depth = 0;
    
    while (true) {
      visitSet.initCursor(visitCursor);
      while (visitCursor.next()) {
        long[] array = (long[])visitCursor.array;
        int offset = visitCursor.offset;
        int limit = visitCursor.limit;
        long base = visitCursor.base;
        for (int i = offset; i < limit; i++) {
          if (array[i] != 0L) {
            prepareNextVisit(array[i], base + i, nextSet);
          }
        } 
      } 

      
      depth++;
      
      boolean hasNext = false;

      
      nextSet.initCursor(nextCursor);
      while (nextCursor.next()) {
        long[] array = (long[])nextCursor.array;
        int offset = nextCursor.offset;
        int limit = nextCursor.limit;
        long base = nextCursor.base;
        for (int i = offset; i < limit; i++) {
          if (array[i] != 0L) {
            long next = visitNext(base + i, seenSet, nextSet);
            if (next != 0L) {
              sourceNodes.reset(next);
              this.perNodeAction.accept(base + i, depth, sourceNodes);
              hasNext = true;
            } 
          } 
        } 
      } 
      
      if (!hasNext) {
        return;
      }
      
      nextSet.copyTo(visitSet, totalNodeCount);
      nextSet.fill(0L);
    } 
  }
  
  private void prepareNextVisit(long nodeVisit, long nodeId, HugeLongArray nextSet) {
    this.relationships.forEachRelationship(nodeId, this.direction, (src, tgt) -> {


          
          nextSet.or(tgt, nodeVisit);
          return true;
        });
  }
  
  private long visitNext(long nodeId, HugeLongArray seenSet, HugeLongArray nextSet) {
    long seen = seenSet.get(nodeId);
    long next = nextSet.and(nodeId, seen ^ 0xFFFFFFFFFFFFFFFFL);
    seenSet.or(nodeId, next);
    return next;
  }
  
  private boolean isSorted(long[] nodes) {
    long[] copy = Arrays.copyOf(nodes, nodes.length);
    Arrays.sort(copy);
    return Arrays.equals(copy, nodes);
  }
  
  private long sourceLength() {
    if (this.startNodes != null) {
      return this.startNodes.length;
    }
    if (this.sourceNodeCount == 0) {
      return this.nodeCount;
    }
    return this.sourceNodeCount;
  }
  
  private int numberOfThreads() {
    long sourceLength = sourceLength();
    long threads = ParallelUtil.threadCount(64L, sourceLength);
    if ((int)threads != threads) {
      throw new IllegalArgumentException("Unable run MS-BFS on " + sourceLength + " sources.");
    }
    return (int)threads;
  }

  
  private Collection<MultiSourceBFS> allSourceBfss(int threads) {
    if (this.startNodes == null) {
      final long sourceLength = this.nodeCount;
      return new ParallelMultiSources(threads, sourceLength)
        {
          MultiSourceBFS next(long from, int length) {
            return new MultiSourceBFS(MultiSourceBFS.this
                .nodeIds, MultiSourceBFS.this
                .relationships.concurrentCopy(), MultiSourceBFS.this
                .direction, MultiSourceBFS.this
                .perNodeAction, sourceLength, from, length, MultiSourceBFS.this


                
                .visits, MultiSourceBFS.this
                .nexts, MultiSourceBFS.this
                .seens, null);
          }
        };
    } 
    
    final long[] startNodes = this.startNodes;
    final int sourceLength = startNodes.length;
    return new ParallelMultiSources(threads, sourceLength)
      {
        MultiSourceBFS next(long from, int length) {
          return new MultiSourceBFS(MultiSourceBFS.this
              .nodeIds, MultiSourceBFS.this
              .relationships.concurrentCopy(), MultiSourceBFS.this
              .direction, MultiSourceBFS.this
              .perNodeAction, MultiSourceBFS.this
              .nodeCount, MultiSourceBFS.this
              .visits, MultiSourceBFS.this
              .nexts, MultiSourceBFS.this
              .seens, 
              Arrays.copyOfRange(startNodes, (int)from, (int)(from + length)), null);
        }
      };
  }


  
  public String toString() {
    if (this.startNodes != null && this.startNodes.length > 0) {
      return "MSBFS{" + this.startNodes[0] + " .. " + (this.startNodes[this.startNodes.length - 1] + 1L) + " (" + this.startNodes.length + ")}";
    }


    
    return "MSBFS{" + this.nodeOffset + " .. " + (this.nodeOffset + this.sourceNodeCount) + " (" + this.sourceNodeCount + ")}";
  }

  
  private static final class SourceNodes
    implements BfsSources
  {
    private final long[] sourceNodes;
    private final int maxPos;
    private final int startPos;
    private final long offset;
    private long sourceMask;
    private int pos;
    
    private SourceNodes(long[] sourceNodes) {
      assert sourceNodes.length <= 64;
      this.sourceNodes = sourceNodes;
      this.maxPos = sourceNodes.length;
      this.offset = 0L;
      this.startPos = -1;
    }
    
    private SourceNodes(long offset, int length) {
      assert length <= 64;
      this.sourceNodes = null;
      this.maxPos = length;
      this.offset = offset;
      this.startPos = -1;
    }
    
    public void reset() {
      this.pos = this.startPos;
      fetchNext();
    }
    
    void reset(long sourceMask) {
      this.sourceMask = sourceMask;
      reset();
    }


    
    public boolean hasNext() { return (this.pos < this.maxPos); }


    
    public long next() {
      int current = this.pos;
      fetchNext();
      return (this.sourceNodes != null) ? this.sourceNodes[current] : (current + this.offset);
    }


    
    public int size() { return Long.bitCount(this.sourceMask); }


    
    private void fetchNext() {
      while (++this.pos < this.maxPos && (this.sourceMask & 1L << this.pos) == 0L);
    }
  }
  
  private static abstract class ParallelMultiSources
    extends AbstractCollection<MultiSourceBFS> implements Iterator<MultiSourceBFS> {
    private final int threads;
    private final long sourceLength;
    private long start = 0L;
    private int i = 0;
    
    private ParallelMultiSources(int threads, long sourceLength) {
      this.threads = threads;
      this.sourceLength = sourceLength;
    }


    
    public boolean hasNext() { return (this.i < this.threads); }



    
    public int size() { return this.threads; }


    
    public Iterator<MultiSourceBFS> iterator() {
      this.start = 0L;
      this.i = 0;
      return this;
    }

    
    public MultiSourceBFS next() {
      int len = (int)Math.min(64L, this.sourceLength - this.start);
      MultiSourceBFS bfs = next(this.start, len);
      this.start += len;
      this.i++;
      return bfs;
    }
    
    abstract MultiSourceBFS next(long param1Long, int param1Int);
  }
  
  private static final class LocalHugeLongArray extends ThreadLocal<HugeLongArray> {
    private final long size;
    private final AllocationTracker tracker;
    
    private LocalHugeLongArray(long size, AllocationTracker tracker) {
      this.size = size;
      this.tracker = tracker;
    }


    
    protected HugeLongArray initialValue() { return HugeLongArray.newArray(this.size, this.tracker); }


    
    public HugeLongArray get() {
      HugeLongArray values = super.get();
      values.fill(0L);
      return values;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\msbfs\MultiSourceBFS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */