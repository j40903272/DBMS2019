package org.neo4j.graphalgo.impl;

import com.carrotsearch.hppc.BitSet;
import com.carrotsearch.hppc.DoubleArrayDeque;
import com.carrotsearch.hppc.LongArrayDeque;
import com.carrotsearch.hppc.LongArrayList;
import java.util.function.ObjDoubleConsumer;
import java.util.function.ObjLongConsumer;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.heavyweight.Converters;
import org.neo4j.graphdb.Direction;
























public class Traverse
  extends Algorithm<Traverse>
{
  private final int nodeCount;
  private Graph graph;
  private LongArrayDeque nodes;
  private LongArrayDeque sources;
  private DoubleArrayDeque weights;
  private BitSet visited;
  
  public Traverse(Graph graph) {
    this.graph = graph;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.nodes = new LongArrayDeque(this.nodeCount);
    this.sources = new LongArrayDeque(this.nodeCount);
    this.weights = new DoubleArrayDeque(this.nodeCount);
    this.visited = new BitSet(this.nodeCount);
  }








  
  public long[] computeBfs(long sourceId, Direction direction, ExitPredicate exitCondition) { return traverse(this.graph.toMappedNodeId(sourceId), direction, exitCondition, (s, t, w) -> 0.0D, LongArrayDeque::addLast, DoubleArrayDeque::addLast); }









  
  public long[] computeDfs(long sourceId, Direction direction, ExitPredicate exitCondition) { return traverse(this.graph.toMappedNodeId(sourceId), direction, exitCondition, (s, t, w) -> 0.0D, LongArrayDeque::addFirst, DoubleArrayDeque::addFirst); }










  
  public long[] computeBfs(long sourceId, Direction direction, ExitPredicate exitCondition, Aggregator aggregator) { return traverse(this.graph.toMappedNodeId(sourceId), direction, exitCondition, aggregator, LongArrayDeque::addLast, DoubleArrayDeque::addLast); }










  
  public long[] computeDfs(long sourceId, Direction direction, ExitPredicate exitCondition, Aggregator aggregator) { return traverse(this.graph.toMappedNodeId(sourceId), direction, exitCondition, aggregator, LongArrayDeque::addFirst, DoubleArrayDeque::addFirst); }
















  
  private long[] traverse(long sourceNode, Direction direction, ExitPredicate exitCondition, Aggregator agg, ObjLongConsumer<LongArrayDeque> nodeFunc, ObjDoubleConsumer<DoubleArrayDeque> weightFunc) {
    LongArrayList list = new LongArrayList(this.nodeCount);
    this.nodes.clear();
    this.sources.clear();
    this.visited.clear();
    nodeFunc.accept(this.nodes, sourceNode);
    nodeFunc.accept(this.sources, sourceNode);
    weightFunc.accept(this.weights, 0.0D);
    this.visited.set(sourceNode);
    
    while (!this.nodes.isEmpty() && running()) {
      long source = this.sources.removeFirst();
      long node = this.nodes.removeFirst();
      double weight = this.weights.removeFirst();
      switch (exitCondition.test(source, node, weight)) {
        case BREAK:
          list.add(this.graph.toOriginalNodeId(node));
          break;
        case CONTINUE:
          continue;
        case FOLLOW:
          list.add(this.graph.toOriginalNodeId(node));
          break;
      } 
      this.graph.forEachRelationship(node, direction, 
          
          Converters.longToIntConsumer((s, t) -> {
              if (!this.visited.get(t)) {
                this.visited.set(t);
                nodeFunc.accept(this.sources, node);
                nodeFunc.accept(this.nodes, t);
                weightFunc.accept(this.weights, agg.apply(s, t, weight));
              } 
              return running();
            }));
    } 
    return list.toArray();
  }


  
  public Traverse me() { return this; }


  
  public void release() {
    this.nodes = null;
    this.weights = null;
    this.visited = null;
  }
  
  public static interface Aggregator {
    double apply(long param1Long1, long param1Long2, double param1Double);
  }
  
  public static interface ExitPredicate { Result test(long param1Long1, long param1Long2, double param1Double);
    
    public enum Result { FOLLOW,


      
      BREAK,



      
      CONTINUE; } } public enum Result { FOLLOW, BREAK, CONTINUE; }

}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\Traverse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */