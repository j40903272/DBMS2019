package org.neo4j.graphalgo.impl.utils;

import org.neo4j.graphalgo.impl.results.CentralityResult;
import org.neo4j.graphalgo.results.CentralityResultWithStatistics;
import org.neo4j.graphalgo.results.NormalizedCentralityResult;



















public enum NormalizationFunction
{
  NONE,




  
  MAX,





  
  L1NORM,





  
  L2NORM;
  
  public abstract CentralityResult apply(CentralityResultWithStatistics paramCentralityResultWithStatistics);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\imp\\utils\NormalizationFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */