package org.neo4j.graphalgo.impl.utils;

import java.util.stream.LongStream;
import java.util.stream.Stream;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.core.ProcedureConfiguration;
import org.neo4j.graphalgo.core.utils.Pools;
import org.neo4j.graphalgo.core.utils.ProgressTimer;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.graphalgo.core.write.Exporter;
import org.neo4j.graphalgo.impl.results.AbstractResultBuilder;
import org.neo4j.graphalgo.impl.results.CentralityResult;
import org.neo4j.graphalgo.impl.results.CentralityScore;
import org.neo4j.kernel.internal.GraphDatabaseAPI;
import org.neo4j.logging.Log;































public final class CentralityUtils
{
  public static <R> void write(GraphDatabaseAPI api, Log log, IdMapping graph, TerminationFlag terminationFlag, CentralityResult result, ProcedureConfiguration configuration, AbstractResultBuilder<R> statsBuilder, String defaultScoreProperty) {
    if (configuration.isWriteFlag(true)) {
      log.debug("Writing results");
      String propertyName = configuration.getWriteProperty(defaultScoreProperty);
      try (ProgressTimer ignored = statsBuilder.timeWrite()) {



        
        Exporter exporter = Exporter.of(api, graph).withLog(log).parallel(Pools.DEFAULT, configuration.getWriteConcurrency(), terminationFlag).build();
        result.export(propertyName, exporter);
      } 
      statsBuilder.withWrite(true).withWriteProperty(propertyName);
    } else {
      statsBuilder.withWrite(false);
    } 
  }
  
  public static Stream<CentralityScore> streamResults(Graph graph, CentralityResult scores) {
    return LongStream.range(0L, graph.nodeCount())
      .mapToObj(i -> {
          long nodeId = graph.toOriginalNodeId(i);
          return new CentralityScore(nodeId, 
              
              Double.valueOf(scores.score(i)));
        });
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\imp\\utils\CentralityUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */