package org.neo4j.graphalgo.impl.wcc;

import java.util.concurrent.ExecutorService;
import java.util.function.Supplier;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.beta.pregel.Pregel;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeDoubleArray;
import org.neo4j.graphalgo.core.utils.paged.dss.DisjointSetStruct;























public class WCCPregel
  extends WCC<WCCPregel>
{
  private final Pregel pregel;
  private final long nodeCount;
  private final long batchSize;
  
  public static MemoryEstimation memoryEstimation(boolean incremental) { return 
      MemoryEstimations.builder(WCCPregel.class)
      
      .build(); }







  
  WCCPregel(Graph graph, ExecutorService executor, int minBatchSize, int concurrency, WCC.Config algoConfig, AllocationTracker tracker) {
    super(graph, algoConfig);
    this.nodeCount = graph.nodeCount();
    this.batchSize = ParallelUtil.adjustedBatchSize(this.nodeCount, concurrency, minBatchSize, 2147483647L);



    
    long threadSize = ParallelUtil.threadCount(this.batchSize, this.nodeCount);
    if (threadSize > 2147483647L) {
      throw new IllegalArgumentException(String.format("Too many nodes (%d) to run union find with the given concurrency (%d) and batchSize (%d)", new Object[] {
              
              Long.valueOf(this.nodeCount), 
              Integer.valueOf(concurrency), 
              Long.valueOf(this.batchSize)
            }));
    }
    NodeProperties communityMap = algoConfig.communityMap;
    
    if (communityMap == null || communityMap instanceof org.neo4j.graphalgo.core.loading.NullPropertyMap) {
      this.pregel = Pregel.withDefaultNodeValues(graph, org.neo4j.graphalgo.beta.pregel.examples.WCCComputation::new, (int)this.batchSize, (int)threadSize, executor, tracker);


    
    }
    else {


      
      this.pregel = Pregel.withInitialNodeValues(graph, org.neo4j.graphalgo.beta.pregel.examples.WCCComputation::new, communityMap, (int)this.batchSize, (int)threadSize, executor, tracker);
    } 
  }










  
  public DisjointSetStruct computeUnrestricted() { return compute(NaND); }


  
  public DisjointSetStruct compute(double threshold) {
    final HugeDoubleArray communities = this.pregel.run(2147483647);
    
    return new DisjointSetStruct()
      {
        public void union(long p, long q) {
          throw new UnsupportedOperationException();
        }


        
        public long setIdOf(long nodeId) { return (long)communities.get(nodeId); }



        
        public boolean sameSet(long p, long q) { return (setIdOf(p) == setIdOf(q)); }



        
        public long size() { return communities.size(); }
      };
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\wcc\WCCPregel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */