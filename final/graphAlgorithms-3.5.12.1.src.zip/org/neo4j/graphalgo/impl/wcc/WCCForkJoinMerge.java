package org.neo4j.graphalgo.impl.wcc;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Stack;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.ExceptionUtil;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.dss.DisjointSetStruct;
import org.neo4j.graphalgo.core.utils.paged.dss.SequentialDisjointSetStruct;
import org.neo4j.graphdb.Direction;



































public class WCCForkJoinMerge
  extends WCC<WCCForkJoinMerge>
{
  private final ExecutorService executor;
  private final AllocationTracker tracker;
  private final long nodeCount;
  private final long batchSize;
  private SequentialDisjointSetStruct disjointSetStruct;
  
  public static MemoryEstimation memoryEstimation(boolean incremental) { return WCC.memoryEstimation(incremental, (Class)WCCForkJoinMerge.class, ThresholdWCCProcess.class); }













  
  public WCCForkJoinMerge(Graph graph, ExecutorService executor, int minBatchSize, int concurrency, WCC.Config algoConfig, AllocationTracker tracker) {
    super(graph, algoConfig);
    
    this.nodeCount = graph.nodeCount();
    this.executor = executor;
    this.tracker = tracker;
    this.disjointSetStruct = initDisjointSetStruct(this.nodeCount, tracker);
    this.batchSize = ParallelUtil.adjustedBatchSize(this.nodeCount, concurrency, minBatchSize);
  }




  
  public DisjointSetStruct compute(double threshold) {
    ArrayList<ThresholdWCCProcess> ufProcesses = new ArrayList<>(); long i;
    for (i = 0L; i < this.nodeCount; i += this.batchSize) {
      ufProcesses.add(new ThresholdWCCProcess(i, this.batchSize, threshold));
    }
    merge((Collection)ufProcesses);
    return (DisjointSetStruct)this.disjointSetStruct;
  }

  
  public DisjointSetStruct computeUnrestricted() {
    ArrayList<WCCProcess> ufProcesses = new ArrayList<>();
    for (long i = 0L; i < this.nodeCount; i += this.batchSize) {
      ufProcesses.add(new WCCProcess(i, this.batchSize));
    }
    merge((Collection)ufProcesses);
    return (DisjointSetStruct)this.disjointSetStruct;
  }
  
  private void merge(Collection<? extends AbstractWCCTask> ufProcesses) {
    ParallelUtil.run(ufProcesses, this.executor);
    if (!running()) {
      return;
    }
    Stack<SequentialDisjointSetStruct> disjointSetStructs = new Stack<>();
    ufProcesses.forEach(uf -> disjointSetStructs.add(uf.getDisjointSetStruct()));
    this.disjointSetStruct = ForkJoinPool.commonPool().invoke(new Merge(disjointSetStructs));
  }


  
  public void release() { this.disjointSetStruct = null; }
  
  private static abstract class AbstractWCCTask
    implements Runnable
  {
    private AbstractWCCTask() {}
    
    abstract SequentialDisjointSetStruct getDisjointSetStruct();
  }
  
  private class WCCProcess
    extends AbstractWCCTask {
    private final long offset;
    private final long end;
    private final SequentialDisjointSetStruct struct;
    private final RelationshipIterator rels;
    
    WCCProcess(long offset, long length) {
      this.offset = offset;
      this.end = offset + length;
      this.struct = WCCForkJoinMerge.this.initDisjointSetStruct(WCCForkJoinMerge.this.nodeCount, WCCForkJoinMerge.this.tracker);
      this.rels = WCCForkJoinMerge.this.graph.concurrentCopy();
    }

    
    public void run() {
      for (long node = this.offset; node < this.end && node < WCCForkJoinMerge.this.nodeCount && WCCForkJoinMerge.this.running(); node++) {
        try {
          this.rels.forEachRelationship(node, Direction.OUTGOING, (sourceNodeId, targetNodeId) -> {


                
                this.struct.union(sourceNodeId, targetNodeId);
                return true;
              });
        } catch (Exception e) {
          throw ExceptionUtil.asUnchecked(e);
        } 
      } 
      WCCForkJoinMerge.this.getProgressLogger().logProgress(((this.end - 1L) / (WCCForkJoinMerge.this.nodeCount - 1L)));
    }


    
    SequentialDisjointSetStruct getDisjointSetStruct() { return this.struct; }
  }

  
  private class ThresholdWCCProcess
    extends AbstractWCCTask
  {
    private final long offset;
    
    private final long end;
    
    private final SequentialDisjointSetStruct struct;
    private final RelationshipIterator rels;
    private final double threshold;
    
    ThresholdWCCProcess(long offset, long length, double threshold) {
      this.offset = offset;
      this.end = offset + length;
      this.threshold = threshold;
      this.struct = WCCForkJoinMerge.this.initDisjointSetStruct(WCCForkJoinMerge.this.nodeCount, WCCForkJoinMerge.this.tracker);
      this.rels = WCCForkJoinMerge.this.graph.concurrentCopy();
    }

    
    public void run() {
      for (long node = this.offset; node < this.end && node < WCCForkJoinMerge.this.nodeCount && WCCForkJoinMerge.this.running(); node++) {
        this.rels.forEachRelationship(node, Direction.OUTGOING, (sourceNodeId, targetNodeId) -> {


              
              double weight = WCCForkJoinMerge.this.graph.relationshipProperty(sourceNodeId, targetNodeId, 

                  
                  WCC.defaultWeight(this.threshold));
              if (weight > this.threshold) {
                this.struct.union(sourceNodeId, targetNodeId);
              }
              return true;
            });
      } 
    }


    
    SequentialDisjointSetStruct getDisjointSetStruct() { return this.struct; }
  }

  
  private class Merge
    extends RecursiveTask<SequentialDisjointSetStruct>
  {
    private final Stack<SequentialDisjointSetStruct> communityContainers;
    
    private Merge(Stack<SequentialDisjointSetStruct> structs) { this.communityContainers = structs; }


    
    protected SequentialDisjointSetStruct compute() {
      int size = this.communityContainers.size();
      if (size == 1) {
        return this.communityContainers.pop();
      }
      if (!WCCForkJoinMerge.this.running()) {
        return this.communityContainers.pop();
      }
      if (size == 2) {
        return ((SequentialDisjointSetStruct)this.communityContainers.pop()).merge(this.communityContainers.pop());
      }
      Stack<SequentialDisjointSetStruct> list = new Stack<>();
      list.push(this.communityContainers.pop());
      list.push(this.communityContainers.pop());
      Merge mergeA = new Merge(this.communityContainers);
      Merge mergeB = new Merge(list);
      mergeA.fork();
      SequentialDisjointSetStruct computed = mergeB.compute();
      return mergeA.join().merge(computed);
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\wcc\WCCForkJoinMerge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */