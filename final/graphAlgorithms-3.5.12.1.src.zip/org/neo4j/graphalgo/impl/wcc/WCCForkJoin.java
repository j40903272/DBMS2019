package org.neo4j.graphalgo.impl.wcc;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.dss.DisjointSetStruct;
import org.neo4j.graphalgo.core.utils.paged.dss.SequentialDisjointSetStruct;
import org.neo4j.graphdb.Direction;




































public class WCCForkJoin
  extends WCC<WCCForkJoin>
{
  private final AllocationTracker tracker;
  private final long nodeCount;
  private final long batchSize;
  
  public static MemoryEstimation memoryEstimation(boolean incremental) { return WCC.memoryEstimation(incremental, (Class)WCCForkJoin.class, ThresholdWCCTask.class); }











  
  public WCCForkJoin(Graph graph, int minBatchSize, int concurrency, WCC.Config algoConfig, AllocationTracker tracker) {
    super(graph, algoConfig);
    
    this.nodeCount = graph.nodeCount();
    this.tracker = tracker;
    this.batchSize = ParallelUtil.adjustedBatchSize(this.nodeCount, concurrency, minBatchSize);
  }






  
  public DisjointSetStruct compute(double threshold) { return ForkJoinPool.commonPool().invoke(new ThresholdWCCTask(0L, threshold)); }



  
  public DisjointSetStruct computeUnrestricted() { return ForkJoinPool.commonPool().invoke(new WCCTask(0L)); }
  
  private class WCCTask
    extends RecursiveTask<SequentialDisjointSetStruct>
  {
    private final long offset;
    private final long end;
    private final RelationshipIterator rels;
    
    WCCTask(long offset) {
      this.offset = offset;
      this.end = Math.min(offset + WCCForkJoin.this.batchSize, WCCForkJoin.this.nodeCount);
      this.rels = WCCForkJoin.this.graph.concurrentCopy();
    }

    
    protected SequentialDisjointSetStruct compute() {
      if (WCCForkJoin.this.nodeCount - this.end >= WCCForkJoin.this.batchSize && WCCForkJoin.this.running()) {
        WCCTask process = new WCCTask(this.end);
        process.fork();
        return run().merge(process.join());
      } 
      return run();
    }
    
    protected SequentialDisjointSetStruct run() {
      SequentialDisjointSetStruct disjointSetStruct = WCCForkJoin.this.initDisjointSetStruct(WCCForkJoin.this.nodeCount, WCCForkJoin.this.tracker);
      for (long node = this.offset; node < this.end && WCCForkJoin.this.running(); node++) {
        this.rels.forEachRelationship(node, Direction.OUTGOING, (sourceNodeId, targetNodeId) -> {


              
              disjointSetStruct.union(sourceNodeId, targetNodeId);
              return true;
            });
      } 
      WCCForkJoin.this.getProgressLogger().logProgress((this.end - 1L), (WCCForkJoin.this.nodeCount - 1L));
      
      return disjointSetStruct;
    }
  }
  
  private class ThresholdWCCTask
    extends RecursiveTask<SequentialDisjointSetStruct> {
    private final long offset;
    private final long end;
    private final RelationshipIterator rels;
    private final double threshold;
    
    ThresholdWCCTask(long offset, double threshold) {
      this.offset = offset;
      this.end = Math.min(offset + WCCForkJoin.this.batchSize, WCCForkJoin.this.nodeCount);
      this.rels = WCCForkJoin.this.graph.concurrentCopy();
      this.threshold = threshold;
    }

    
    protected SequentialDisjointSetStruct compute() {
      if (WCCForkJoin.this.nodeCount - this.end >= WCCForkJoin.this.batchSize && WCCForkJoin.this.running()) {
        ThresholdWCCTask process = new ThresholdWCCTask(this.offset, this.end);

        
        process.fork();
        return run().merge(process.join());
      } 
      return run();
    }
    
    protected SequentialDisjointSetStruct run() {
      SequentialDisjointSetStruct disjointSetStruct = WCCForkJoin.this.initDisjointSetStruct(WCCForkJoin.this.nodeCount, WCCForkJoin.this.tracker);
      for (long node = this.offset; node < this.end && WCCForkJoin.this.running(); node++) {
        this.rels.forEachRelationship(node, Direction.OUTGOING, (source, target) -> {


              
              double weight = WCCForkJoin.this.graph.relationshipProperty(source, target, WCC.defaultWeight(this.threshold));
              if (weight >= this.threshold) {
                disjointSetStruct.union(source, target);
              }
              return true;
            });
      } 
      return disjointSetStruct;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\wcc\WCCForkJoin.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */