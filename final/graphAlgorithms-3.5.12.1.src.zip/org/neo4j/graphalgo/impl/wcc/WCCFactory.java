package org.neo4j.graphalgo.impl.wcc;

import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.AlgorithmFactory;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.ProcedureConfiguration;
import org.neo4j.graphalgo.core.utils.Pools;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.logging.Log;





















public class WCCFactory<A extends WCC<A>>
  extends AlgorithmFactory<A>
{
  public static final String CONFIG_ALGO_TYPE = "algoType";
  public static final String CONFIG_THRESHOLD = "threshold";
  public static final String CONFIG_SEED_PROPERTY = "seedProperty";
  public static final String SEED_TYPE = "seed";
  private final WCCType algorithmType;
  private final boolean incremental;
  
  public WCCFactory(WCCType algorithmType, boolean incremental) {
    this.algorithmType = algorithmType;
    this.incremental = incremental;
  }






  
  public A build(Graph graph, ProcedureConfiguration configuration, AllocationTracker tracker, Log log) {
    int concurrency = configuration.getConcurrency();
    int minBatchSize = configuration.getBatchSize();


    
    WCC.Config algoConfig = new WCC.Config(graph.availableNodeProperties().contains("seed") ? graph.nodeProperties("seed") : null, ((Double)configuration.get("threshold", Double.valueOf(NaND))).doubleValue());

    
    WCC<?> algo = this.algorithmType.create(graph, Pools.DEFAULT, minBatchSize, concurrency, algoConfig, tracker);





    
    return (A)algo;
  }


  
  public MemoryEstimation memoryEstimation() { return this.algorithmType.memoryEstimation(this.incremental); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\wcc\WCCFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */