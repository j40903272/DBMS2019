package org.neo4j.graphalgo.impl.wcc;

import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.core.GraphDimensions;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.mem.MemoryRange;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.dss.DisjointSetStruct;
import org.neo4j.graphalgo.core.utils.paged.dss.IncrementalDisjointSetStruct;
import org.neo4j.graphalgo.core.utils.paged.dss.NonInrementalDisjointSetStruct;
import org.neo4j.graphalgo.core.utils.paged.dss.SequentialDisjointSetStruct;



















public abstract class WCC<ME extends WCC<ME>>
  extends Algorithm<ME>
{
  protected Graph graph;
  protected final Config algoConfig;
  
  public static double defaultWeight(double threshold) { return threshold + 1.0D; }





  
  static MemoryEstimation memoryEstimation(boolean incremental, Class<? extends WCC<?>> unionFindClass, Class<?> taskClass) { return MemoryEstimations.builder(unionFindClass)
      .startField("computeStep", taskClass)
      .add(MemoryEstimations.of("DisjointSetStruct", (dimensions, concurrency) -> {

            
            MemoryEstimation dssEstimation = incremental ? IncrementalDisjointSetStruct.memoryEstimation() : NonInrementalDisjointSetStruct.memoryEstimation();
            return dssEstimation
              .estimate(dimensions, concurrency)
              .memoryUsage()
              .times(concurrency);
          
          })).endField()
      .build(); }

  
  protected WCC(Graph graph, Config algoConfig) {
    this.graph = graph;
    this.algoConfig = algoConfig;
  }

  
  public double threshold() { return this.algoConfig.threshold; }


  
  SequentialDisjointSetStruct initDisjointSetStruct(long nodeCount, AllocationTracker tracker) { return (this.algoConfig.communityMap == null) ? (SequentialDisjointSetStruct)new NonInrementalDisjointSetStruct(nodeCount, tracker) : (SequentialDisjointSetStruct)new IncrementalDisjointSetStruct(nodeCount, this.algoConfig.communityMap, tracker); }




  
  public DisjointSetStruct compute() { return Double.isFinite(threshold()) ? compute(threshold()) : computeUnrestricted(); }








  
  public ME me() { return (ME)this; }



  
  public void release() { this.graph = null; }
  
  public abstract DisjointSetStruct compute(double paramDouble);
  
  public abstract DisjointSetStruct computeUnrestricted();
  
  public static class Config
  {
    public Config(NodeProperties communityMap, double threshold) {
      this.communityMap = communityMap;
      this.threshold = threshold;
    }
    
    public final NodeProperties communityMap;
    public final double threshold;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\wcc\WCC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */