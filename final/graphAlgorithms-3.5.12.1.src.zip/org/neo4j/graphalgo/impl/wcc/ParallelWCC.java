package org.neo4j.graphalgo.impl.wcc;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.ExecutorService;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.api.RelationshipConsumer;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.api.RelationshipWithPropertyConsumer;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.dss.DisjointSetStruct;
import org.neo4j.graphalgo.core.utils.paged.dss.HugeAtomicDisjointSetStruct;
import org.neo4j.graphdb.Direction;



























public class ParallelWCC
  extends WCC<ParallelWCC>
{
  private final ExecutorService executor;
  private final AllocationTracker tracker;
  private final long nodeCount;
  private final long batchSize;
  private final int threadSize;
  
  public static MemoryEstimation memoryEstimation(boolean incremental) { return 
      MemoryEstimations.builder(ParallelWCC.class)
      .add("dss", HugeAtomicDisjointSetStruct.memoryEstimation(incremental))
      .build(); }







  
  public ParallelWCC(Graph graph, ExecutorService executor, int minBatchSize, int concurrency, WCC.Config algoConfig, AllocationTracker tracker) {
    super(graph, algoConfig);
    this.executor = executor;
    this.tracker = tracker;
    this.nodeCount = graph.nodeCount();
    this.batchSize = ParallelUtil.adjustedBatchSize(this.nodeCount, concurrency, minBatchSize, 2147483647L);



    
    long threadSize = ParallelUtil.threadCount(this.batchSize, this.nodeCount);
    if (threadSize > 2147483647L)
      throw new IllegalArgumentException(String.format("Too many nodes (%d) to run union find with the given concurrency (%d) and batchSize (%d)", new Object[] {
              
              Long.valueOf(this.nodeCount), 
              Integer.valueOf(concurrency), 
              Long.valueOf(this.batchSize)
            })); 
    this.threadSize = (int)threadSize;
  }


  
  public DisjointSetStruct computeUnrestricted() { return compute(NaND); }


  
  public DisjointSetStruct compute(double threshold) {
    long nodeCount = this.graph.nodeCount();
    NodeProperties communityMap = this.algoConfig.communityMap;
    HugeAtomicDisjointSetStruct hugeAtomicDisjointSetStruct = (communityMap == null) ? new HugeAtomicDisjointSetStruct(nodeCount, this.tracker) : new HugeAtomicDisjointSetStruct(nodeCount, communityMap, this.tracker);


    
    Collection<Runnable> tasks = new ArrayList<>(this.threadSize); long i;
    for (i = 0L; i < this.nodeCount; i += this.batchSize) {
      WCCTask wccTask = Double.isNaN(threshold) ? new WCCTask((DisjointSetStruct)hugeAtomicDisjointSetStruct, i) : new WCCWithThresholdTask(threshold, (DisjointSetStruct)hugeAtomicDisjointSetStruct, i);

      
      tasks.add(wccTask);
    } 
    ParallelUtil.run(tasks, this.executor);
    return (DisjointSetStruct)hugeAtomicDisjointSetStruct;
  }

  
  private class WCCTask
    implements Runnable, RelationshipConsumer
  {
    final DisjointSetStruct struct;
    final RelationshipIterator rels;
    private final long offset;
    private final long end;
    
    WCCTask(DisjointSetStruct struct, long offset) {
      this.struct = struct;
      this.rels = ParallelWCC.this.graph.concurrentCopy();
      this.offset = offset;
      this.end = Math.min(offset + ParallelWCC.this.batchSize, ParallelWCC.this.nodeCount);
    }

    
    public void run() {
      for (long node = this.offset; node < this.end; node++) {
        compute(node);
        if (node % 10000L == 0L) {
          ParallelWCC.this.assertRunning();
        }
      } 
      ParallelWCC.this.getProgressLogger().logProgress((this.end - 1.0D) / (ParallelWCC.this.nodeCount - 1.0D));
    }

    
    void compute(long node) { this.rels.forEachRelationship(node, Direction.OUTGOING, this); }


    
    public boolean accept(long sourceNodeId, long targetNodeId) {
      this.struct.union(sourceNodeId, targetNodeId);
      return true;
    }
  }

  
  private class WCCWithThresholdTask
    extends WCCTask
    implements RelationshipWithPropertyConsumer
  {
    private final double threshold;
    
    WCCWithThresholdTask(double threshold, DisjointSetStruct struct, long offset) {
      super(struct, offset);
      this.threshold = threshold;
    }


    
    void compute(long node) { this.rels.forEachRelationship(node, Direction.OUTGOING, WCC.defaultWeight(this.threshold), this); }


    
    public boolean accept(long sourceNodeId, long targetNodeId, double property) {
      if (property > this.threshold) {
        this.struct.union(sourceNodeId, targetNodeId);
      }
      return true;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\wcc\ParallelWCC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */