package org.neo4j.graphalgo.impl.wcc;

import java.util.concurrent.ExecutorService;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;





















public enum WCCType
{
  PARALLEL,





















  
  FORK_JOIN,




















  
  FJ_MERGE,





















  
  PREGEL;

























  
  MemoryEstimation memoryEstimation() { return memoryEstimation(false); }
  
  public abstract WCC<? extends WCC<?>> create(Graph paramGraph, ExecutorService paramExecutorService, int paramInt1, int paramInt2, WCC.Config paramConfig, AllocationTracker paramAllocationTracker);
  
  abstract MemoryEstimation memoryEstimation(boolean paramBoolean);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\wcc\WCCType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */