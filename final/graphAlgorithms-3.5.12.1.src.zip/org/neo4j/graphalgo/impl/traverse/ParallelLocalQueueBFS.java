package org.neo4j.graphalgo.impl.traverse;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.LongConsumer;
import java.util.function.LongPredicate;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.container.AtomicBitSet;
import org.neo4j.graphalgo.core.utils.queue.LongPriorityQueue;
import org.neo4j.graphdb.Direction;
































public class ParallelLocalQueueBFS
  implements BFS
{
  private final Graph graph;
  private final AtomicInteger threads;
  private final AtomicBitSet visited;
  private final ExecutorService executorService;
  private final int concurrency;
  private final ConcurrentLinkedQueue<Future<?>> futures;
  private AtomicInteger threadsCreated = new AtomicInteger(0);

  
  private double concurrencyFactor = 0.5D;
  
  public ParallelLocalQueueBFS(Graph graph, ExecutorService executorService, int concurrency) {
    this.graph = graph;
    this.visited = new AtomicBitSet(Math.toIntExact(graph.nodeCount()));
    this.executorService = executorService;
    this.concurrency = concurrency;
    this.threads = new AtomicInteger(0);
    this.futures = new ConcurrentLinkedQueue<>();
  }





  
  public ParallelLocalQueueBFS reset() {
    this.visited.clear();
    this.futures.clear();
    this.threadsCreated.set(0);
    this.threads.set(0);
    return this;
  }





  
  public ParallelLocalQueueBFS awaitTermination() {
    ParallelUtil.awaitTerminations(this.futures);
    return this;
  }











  
  public ParallelLocalQueueBFS bfs(long startNodeId, Direction direction, LongPredicate predicate, LongConsumer visitor) {
    if (!predicate.test(startNodeId)) {
      return this;
    }
    RelationshipIterator localRelationshipIterator = this.graph.concurrentCopy();
    LongPriorityQueue queue = LongPriorityQueue.max();
    queue.add(startNodeId, 0.0D);
    while (!queue.isEmpty()) {
      long node = queue.pop();
      
      if (!this.visited.trySet(node)) {
        continue;
      }
      visitor.accept(node);
      
      localRelationshipIterator.forEachRelationship(node, direction, (sourceNodeId, targetNodeId) -> {
            
            if (!predicate.test(targetNodeId)) {
              return true;
            }
            
            if (this.visited.get(targetNodeId)) {
              return true;
            }
            if (!addThread(())) {
              queue.add(targetNodeId, this.graph.degree(targetNodeId, direction));
            }
            return true;
          });
    } 
    this.threads.decrementAndGet();
    return this;
  }
  
  public ParallelLocalQueueBFS withConcurrencyFactor(double concurrencyFactor) {
    this.concurrencyFactor = concurrencyFactor;
    return this;
  }





  
  private boolean addThread(Runnable runnable) {
    if (Math.random() >= this.concurrencyFactor) {
      return false;
    }
    
    int current = this.threads.get();
    if (current >= this.concurrency) {
      return false;
    }
    if (this.threads.compareAndSet(current, current + 1)) {
      this.futures.add(this.executorService.submit(runnable));
      this.threadsCreated.incrementAndGet();
      return true;
    } 
    return false;
  }

  
  public int getThreadsCreated() { return this.threadsCreated.get(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\traverse\ParallelLocalQueueBFS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */