package org.neo4j.graphalgo.impl.walking;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.neo4j.graphalgo.results.VirtualRelationship;
import org.neo4j.graphdb.Node;
import org.neo4j.graphdb.Path;
import org.neo4j.graphdb.PropertyContainer;
import org.neo4j.graphdb.Relationship;
import org.neo4j.graphdb.RelationshipType;
import org.neo4j.kernel.internal.GraphDatabaseAPI;
















public class WalkPath
  implements Path
{
  public static final Path EMPTY = new WalkPath(0);
  private static final RelationshipType NEXT = RelationshipType.withName("NEXT");
  
  private List<Node> nodes;
  private List<Relationship> relationships;
  private final int size;
  
  private WalkPath(int size) {
    this.nodes = new ArrayList<>(size);
    this.relationships = new ArrayList<>(Math.max(0, size - 1));
    this.size = size;
  }
  
  public static Path toPath(GraphDatabaseAPI api, long[] nodes) {
    if (nodes.length == 0) return EMPTY; 
    WalkPath result = new WalkPath(nodes.length);
    Node node = api.getNodeById(nodes[0]);
    result.addNode(node);
    for (int i = 1; i < nodes.length; i++) {
      Node nextNode = api.getNodeById(nodes[i]);
      result.addRelationship((Relationship)new VirtualRelationship(node, nextNode, NEXT));
      result.addNode(nextNode);
      node = nextNode;
    } 
    return result;
  }
  
  public static Path toPath(GraphDatabaseAPI api, long[] nodes, double[] costs) {
    if (nodes.length == 0) return EMPTY; 
    WalkPath result = new WalkPath(nodes.length);
    Node node = api.getNodeById(nodes[0]);
    result.addNode(node);
    for (int i = 1; i < nodes.length; i++) {
      Node nextNode = api.getNodeById(nodes[i]);
      VirtualRelationship relationship = new VirtualRelationship(node, nextNode, NEXT);
      relationship.setProperty("cost", Double.valueOf(costs[i - 1]));
      result.addRelationship((Relationship)relationship);
      result.addNode(nextNode);
      node = nextNode;
    } 
    return result;
  }

  
  public void addNode(Node node) { this.nodes.add(node); }


  
  public void addRelationship(Relationship relationship) { this.relationships.add(relationship); }



  
  public Node startNode() { return (this.size == 0) ? null : this.nodes.get(0); }



  
  public Node endNode() { return (this.size == 0) ? null : this.nodes.get(this.nodes.size() - 1); }



  
  public Relationship lastRelationship() { return (this.size == 0) ? null : this.relationships.get(this.relationships.size() - 1); }



  
  public Iterable<Relationship> relationships() { return this.relationships; }


  
  public Iterable<Relationship> reverseRelationships() {
    ArrayList<Relationship> reverse = new ArrayList<>(this.relationships);
    Collections.reverse(reverse);
    return reverse;
  }


  
  public Iterable<Node> nodes() { return this.nodes; }


  
  public Iterable<Node> reverseNodes() {
    ArrayList<Node> reverse = new ArrayList<>(this.nodes);
    Collections.reverse(reverse);
    return reverse;
  }


  
  public int length() { return this.size - 1; }



  
  public String toString() { return this.nodes.toString(); }


  
  public Iterator<PropertyContainer> iterator() {
    return new Iterator<PropertyContainer>() {
        int i = 0;

        
        public boolean hasNext() { return (this.i < 2 * WalkPath.this.size); }


        
        public PropertyContainer next() {
          PropertyContainer pc = (this.i % 2 == 0) ? WalkPath.this.nodes.get(this.i / 2) : WalkPath.this.relationships.get(this.i / 2);
          this.i++;
          return pc;
        }
      };
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\walking\WalkPath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */