package org.neo4j.graphalgo.impl;

import java.util.concurrent.ExecutorService;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.AtomicDoubleArray;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.write.Exporter;
import org.neo4j.graphalgo.core.write.PropertyTranslator;
import org.neo4j.graphalgo.impl.msbfs.BfsConsumer;
import org.neo4j.graphalgo.impl.msbfs.BfsSources;
import org.neo4j.graphalgo.impl.msbfs.MultiSourceBFS;
import org.neo4j.graphdb.Direction;























public class DangalchevClosenessCentrality
  extends Algorithm<DangalchevClosenessCentrality>
{
  private Graph graph;
  private AtomicDoubleArray farness;
  private final int concurrency;
  private final ExecutorService executorService;
  private final int nodeCount;
  
  public DangalchevClosenessCentrality(Graph graph, int concurrency, ExecutorService executorService) {
    this.graph = graph;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.concurrency = concurrency;
    this.executorService = executorService;
    this.farness = new AtomicDoubleArray(this.nodeCount);
  }

  
  public DangalchevClosenessCentrality compute() {
    ProgressLogger progressLogger = getProgressLogger();
    
    BfsConsumer consumer = (nodeId, depth, sourceNodeIds) -> {
        int len = sourceNodeIds.size();
        this.farness.add(Math.toIntExact(nodeId), len * 1.0D / Math.pow(2.0D, depth));
        progressLogger.logProgress(nodeId / (this.nodeCount - 1));
      };
    
    (new MultiSourceBFS((IdMapping)this.graph, (RelationshipIterator)this.graph, Direction.OUTGOING, consumer, AllocationTracker.EMPTY, new long[0]))
      .run(this.concurrency, this.executorService);
    
    return this;
  }
  
  public Stream<Result> resultStream() {
    return IntStream.range(0, this.nodeCount)
      .mapToObj(nodeId -> new Result(this.graph
          .toOriginalNodeId(nodeId), this.farness
          .get(nodeId)));
  }
  
  public void export(String propertyName, Exporter exporter) {
    exporter.write(propertyName, this.farness, (PropertyTranslator)((data, nodeId) -> 


        
        data.get((int)nodeId)));
  }


  
  public DangalchevClosenessCentrality me() { return this; }


  
  public void release() {
    this.graph = null;
    this.farness = null;
  }


  
  public static final class Result
  {
    public final long nodeId;

    
    public final double centrality;

    
    public Result(long nodeId, double centrality) {
      this.nodeId = nodeId;
      this.centrality = centrality;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\DangalchevClosenessCentrality.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */