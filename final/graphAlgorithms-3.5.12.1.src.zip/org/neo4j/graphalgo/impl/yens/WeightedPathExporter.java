package org.neo4j.graphalgo.impl.yens;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.api.RelationshipProperties;
import org.neo4j.graphalgo.core.utils.ExceptionUtil;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.Pointer;
import org.neo4j.graphalgo.core.utils.StatementApi;
import org.neo4j.helpers.collection.Pair;
import org.neo4j.internal.kernel.api.exceptions.KernelException;
import org.neo4j.kernel.api.KernelTransaction;
import org.neo4j.kernel.internal.GraphDatabaseAPI;
import org.neo4j.values.storable.Value;
import org.neo4j.values.storable.Values;




























public class WeightedPathExporter
  extends StatementApi
{
  private final IdMapping idMapping;
  private final RelationshipProperties relationshipProperties;
  private final String relPrefix;
  private final ExecutorService executorService;
  private final String propertyName;
  
  public WeightedPathExporter(GraphDatabaseAPI api, ExecutorService executorService, IdMapping idMapping, RelationshipProperties relationshipProperties, String relPrefix, String propertyName) {
    super(api);
    this.executorService = executorService;
    this.idMapping = idMapping;
    this.relationshipProperties = relationshipProperties;
    this.relPrefix = relPrefix;
    this.propertyName = propertyName;
  }




  
  public void export(List<WeightedPath> paths) {
    if (ParallelUtil.canRunInParallel(this.executorService)) {
      writeParallel(paths);
    } else {
      writeSequential(paths);
    } 
  }
  
  private void export(String relationshipType, String propertyName, WeightedPath path) {
    applyInTransaction(statement -> {
          int relId = statement.tokenWrite().relationshipTypeGetOrCreateForName(relationshipType);
          if (relId == -1) {
            throw new IllegalStateException("no write property id is set");
          }
          path.forEachEdge(());














          
          return null;
        });
  }


  
  private int getOrCreatePropertyId(String propertyName) { return ((Integer)applyInTransaction(stmt -> Integer.valueOf(stmt
          .tokenWrite()
          .propertyKeyGetOrCreateForName(propertyName)))).intValue(); }

  
  private void writeSequential(List<WeightedPath> paths) {
    Pointer.IntPointer counter = Pointer.wrap(0);
    paths.stream()
      .sorted(WeightedPath.comparator())
      .forEach(path -> 
        export(String.format("%s%d", new Object[] { this.relPrefix, Integer.valueOf(counter.v++) }), this.propertyName, path));
  }
  
  private void writeParallel(List<WeightedPath> paths) {
    Pointer.IntPointer counter = Pointer.wrap(0);

    
    Stream<Pair<WeightedPath, String>> pathsAndRelTypes = paths.stream().sorted(WeightedPath.comparator()).map(path -> Pair.of(path, String.format("%s%d", new Object[] { this.relPrefix, Integer.valueOf(counter.v++) })));


    
    List<Runnable> tasks = (List<Runnable>)pathsAndRelTypes.map(pair -> ()).collect(Collectors.toList());
    ParallelUtil.run(tasks, this.executorService);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\yens\WeightedPathExporter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */