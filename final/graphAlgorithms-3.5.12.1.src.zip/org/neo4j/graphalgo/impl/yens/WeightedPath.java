package org.neo4j.graphalgo.impl.yens;

import java.util.Arrays;
import java.util.Comparator;
import java.util.function.IntConsumer;
import java.util.function.IntPredicate;
import org.apache.lucene.util.ArrayUtil;
import org.neo4j.graphalgo.api.RelationshipProperties;
import org.neo4j.graphalgo.core.utils.RawValues;






























public class WeightedPath
{
  private int[] nodes;
  private int offset = 0;
  private double weight = 0.0D;

  
  public WeightedPath(int initialCapacity) { this(new int[initialCapacity], 0); }

  
  public WeightedPath(int[] data, int offset) {
    this.nodes = data;
    this.offset = offset;
  }

  
  public void append(int nodeId) {
    this.nodes = ArrayUtil.grow(this.nodes, this.offset + 1);
    this.nodes[this.offset++] = nodeId;
  }




  
  public WeightedPath dropTail() {
    this.offset--;
    return this;
  }

  
  public int node(int index) { return this.nodes[index]; }


  
  public int size() { return this.offset; }

  
  public WeightedPath withWeight(double weight) {
    this.weight = weight;
    return this;
  }
  
  public boolean containsNode(int node) {
    for (int i : this.nodes) {
      if (i == node) {
        return true;
      }
    } 
    return false;
  }
  
  public void forEach(IntPredicate consumer) {
    for (int i = 0; i < this.offset; i++) {
      if (!consumer.test(this.nodes[i])) {
        return;
      }
    } 
  }
  
  public void forEachEdge(EdgeConsumer consumer) {
    for (int i = 0; i < this.offset - 1; i++) {
      consumer.accept(this.nodes[i], this.nodes[i + 1]);
    }
  }
  
  public void forEachDo(IntConsumer consumer) {
    for (int i = 0; i < this.offset; i++) {
      consumer.accept(this.nodes[i]);
    }
  }
  
  public WeightedPath evaluateAndSetCost(RelationshipProperties weights) {
    this.weight = 0.0D;
    forEachEdge((a, b) -> 
        this.weight += weights.relationshipProperty(a, b, 1.0D));
    
    return this;
  }

  
  public double getCost() { return this.weight; }

  
  public WeightedPath pathTo(int end) {
    if (end > size()) {
      throw new ArrayIndexOutOfBoundsException();
    }
    return new WeightedPath(Arrays.copyOf(this.nodes, end + 1), end + 1);
  }

  
  public long edge(int i) { return RawValues.combineIntInt(this.nodes[i], this.nodes[i + 1]); }

  
  public WeightedPath reverse() {
    for (int i = 0; i < this.offset / 2; i++) {
      int temp = this.nodes[i];
      this.nodes[i] = this.nodes[this.offset - 1 - i];
      this.nodes[this.offset - 1 - i] = temp;
    } 
    return this;
  }
  
  public String toString() {
    StringBuilder buffer = new StringBuilder(size());
    forEachDo(n -> {
          if (buffer.length() != 0) {
            buffer.append(",");
          }
          buffer.append(n);
        });
    return buffer.toString();
  }
  
  public boolean elementWiseEquals(WeightedPath other, int length) {
    if (length == 0) {
      throw new IllegalArgumentException("length == 0");
    }
    if (size() < length || other.size() < length) {
      return false;
    }
    for (int i = 0; i < length; i++) {
      if (this.nodes[i] != other.nodes[i]) {
        return false;
      }
    } 
    return true;
  }

  
  public int[] toArray() { return Arrays.copyOf(this.nodes, this.offset); }


  
  public boolean equals(Object o) {
    if (this == o) return true; 
    if (o == null || getClass() != o.getClass()) return false;
    
    WeightedPath that = (WeightedPath)o;
    
    if (this.offset != that.offset) return false; 
    return Arrays.equals(this.nodes, that.nodes);
  }

  
  public int hashCode() {
    int result = Arrays.hashCode(this.nodes);
    result = 31 * result + this.offset;
    return result;
  }




  
  public WeightedPath concat(WeightedPath other) {
    this.nodes = ArrayUtil.grow(this.nodes, this.offset + other.size());
    System.arraycopy(other.nodes, 0, this.nodes, this.offset, other.size());
    this.offset += other.size();
    this.weight += other.weight;
    return this;
  }

  
  public static Comparator<WeightedPath> comparator() { return Comparator.comparingDouble(WeightedPath::getCost); }
  
  public static interface EdgeConsumer {
    void accept(int param1Int1, int param1Int2);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\yens\WeightedPath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */