package org.neo4j.graphalgo.impl.yens;

import com.carrotsearch.hppc.BitSet;
import com.carrotsearch.hppc.IntDoubleMap;
import com.carrotsearch.hppc.IntDoubleScatterMap;
import com.carrotsearch.hppc.IntIntMap;
import com.carrotsearch.hppc.IntIntScatterMap;
import java.util.Arrays;
import java.util.Optional;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.RelationshipConsumer;
import org.neo4j.graphalgo.core.heavyweight.Converters;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.graphalgo.core.utils.queue.IntPriorityQueue;
import org.neo4j.graphalgo.core.utils.queue.SharedIntPriorityQueue;
import org.neo4j.graphdb.Direction;


























public class Dijkstra
{
  public static final int INITIAL_CAPACITY = 64;
  private static final int PATH_END = -1;
  private final Graph graph;
  private final int nodeCount;
  private TerminationFlag terminationFlag = TerminationFlag.RUNNING_TRUE;
  
  private final IntDoubleMap costs;
  
  private final IntPriorityQueue queue;
  
  private final IntIntMap path;
  
  private final BitSet visited;
  
  private RelationshipConsumer filter = (sourceNodeId, targetNodeId) -> true;
  
  private Direction direction = Direction.BOTH;
  
  private int[] depth;
  
  public Dijkstra(Graph graph) {
    this.graph = graph;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.costs = (IntDoubleMap)new IntDoubleScatterMap(this.nodeCount);
    this.queue = (IntPriorityQueue)SharedIntPriorityQueue.min(this.nodeCount, this.costs, Double.MAX_VALUE);


    
    this.path = (IntIntMap)new IntIntScatterMap(this.nodeCount);
    this.visited = new BitSet(this.nodeCount);
    this.depth = new int[this.nodeCount];
  }






  
  public Dijkstra withTerminationFlag(TerminationFlag terminationFlag) {
    this.terminationFlag = terminationFlag;
    return this;
  }






  
  public Dijkstra withFilter(RelationshipConsumer filter) {
    this.filter = filter;
    return this;
  }






  
  public Dijkstra withDirection(Direction direction) {
    this.direction = direction;
    return this;
  }








  
  public Optional<WeightedPath> compute(int sourceNode, int targetNode) { return compute(sourceNode, targetNode, 2147483647); }









  
  public Optional<WeightedPath> compute(long sourceNodeId, long targetNodeId, int maxDepth) {
    int sourceNode = Math.toIntExact(sourceNodeId);
    int targetNode = Math.toIntExact(targetNodeId);
    if (!dijkstra(sourceNode, targetNode, this.direction, maxDepth)) {
      return Optional.empty();
    }
    int last = targetNode;
    WeightedPath resultPath = new WeightedPath(64);
    while (last != -1) {
      resultPath.append(last);
      last = this.path.getOrDefault(last, -1);
    } 
    return Optional.of(resultPath
        .withWeight(this.costs.get(targetNode))
        .reverse());
  }





  
  private boolean dijkstra(int source, int target, Direction direction, int maxDepth) {
    this.costs.clear();
    this.queue.clear();
    this.path.clear();
    this.visited.clear();
    this.costs.put(source, 0.0D);
    this.queue.add(source, 0.0D);
    Arrays.fill(this.depth, 0);
    this.depth[source] = 1;
    while (!this.queue.isEmpty() && this.terminationFlag.running()) {
      int node = this.queue.pop();
      int d = this.depth[node];
      if (d >= maxDepth) {
        continue;
      }
      if (node == target) {
        return true;
      }
      this.visited.set(node);
      double costs = this.costs.getOrDefault(node, Double.MAX_VALUE);
      this.graph.forEachRelationship(node, direction, 0.0D, 


          
          Converters.longToIntConsumer((s, t, w) -> {
              if (!this.filter.accept(s, t)) {
                return true;
              }
              UpdateResult updateCosts = updateCosts(s, t, w + costs);
              if (!this.visited.get(t)) {
                switch (updateCosts) {
                  case NO_PREVIOUS_COSTS:
                    this.queue.add(t, w);
                    break;
                  case UPDATED_COST:
                    this.queue.update(t);
                    break;
                } 

                
                this.depth[t] = this.depth[s] + 1;
              } 
              return this.terminationFlag.running();
            }));
    } 
    return false;
  }




  
  private UpdateResult updateCosts(int source, int target, double newCosts) {
    double oldCosts = this.costs.getOrDefault(target, Double.MAX_VALUE);
    if (oldCosts == Double.MAX_VALUE && 
      !this.costs.containsKey(target)) {
      this.costs.put(target, newCosts);
      this.path.put(target, source);
      return UpdateResult.NO_PREVIOUS_COSTS;
    } 
    
    if (newCosts < oldCosts) {
      this.costs.put(target, newCosts);
      this.path.put(target, source);
      return UpdateResult.UPDATED_COST;
    } 
    return UpdateResult.COST_NOT_COMPETITIVE;
  }
  
  private enum UpdateResult {
    NO_PREVIOUS_COSTS, UPDATED_COST, COST_NOT_COMPETITIVE;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\yens\Dijkstra.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */