package org.neo4j.graphalgo.impl.yens;

import com.carrotsearch.hppc.IntScatterSet;
import com.carrotsearch.hppc.LongScatterSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.PriorityQueue;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.RelationshipProperties;
import org.neo4j.graphalgo.core.heavyweight.Converters;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.RawValues;
import org.neo4j.graphdb.Direction;































public class YensKShortestPaths
  extends Algorithm<YensKShortestPaths>
{
  private Dijkstra dijkstra;
  private Graph graph;
  private List<WeightedPath> shortestPaths;
  private PriorityQueue<WeightedPath> candidates;
  
  public YensKShortestPaths(Graph graph) {
    this.graph = graph;
    this.dijkstra = new Dijkstra(graph);
    this.shortestPaths = new ArrayList<>();
    this.candidates = new PriorityQueue<>(WeightedPath.comparator());
  }





  
  public List<WeightedPath> getPaths() { return this.shortestPaths; }






  
  public YensKShortestPaths compute(long startNode, long goalNode, Direction direction, int k, int maxDepth) {
    yens(k, this.graph
        .toMappedNodeId(startNode), this.graph
        .toMappedNodeId(goalNode), direction, maxDepth);

    
    getProgressLogger().log(String.format("done.. found %d/%d paths", new Object[] { Integer.valueOf(this.shortestPaths.size()), Integer.valueOf(k) }));
    return this;
  }
  
  private void yens(int k, long start, long goal, Direction direction, int maxDepth) {
    ProgressLogger progressLogger = getProgressLogger();
    
    IntScatterSet nodeBlackList = new IntScatterSet();
    LongScatterSet edgeBlackList = new LongScatterSet();
    
    this.shortestPaths.clear();







    
    Optional<WeightedPath> shortestPathOpt = this.dijkstra.withTerminationFlag(getTerminationFlag()).withDirection(direction).withFilter(Converters.longToIntConsumer((s, t) -> (!nodeBlackList.contains(t) && !edgeBlackList.contains(RawValues.combineIntInt(s, t))))).compute(start, goal, maxDepth);
    if (!shortestPathOpt.isPresent()) {
      return;
    }
    
    WeightedPath shortestPath = shortestPathOpt.get();
    this.shortestPaths.add(shortestPath);
    progressLogger.log(String.format("found shortest path: %d nodes / %.2f weight", new Object[] {
            Integer.valueOf(shortestPath.size()), 
            Double.valueOf(shortestPath.getCost())
          }));
    for (int n = 1; n < k; n++) {
      
      WeightedPath basePath = this.shortestPaths.get(this.shortestPaths.size() - 1);
      for (int i = basePath.size() - 2; i >= 0; i--) {
        
        nodeBlackList.clear();
        edgeBlackList.clear();
        
        int spurNode = basePath.node(i);


        
        WeightedPath rootPath = basePath.pathTo(i).evaluateAndSetCost((RelationshipProperties)this.graph);
        
        for (Iterator<WeightedPath> iterator = this.shortestPaths.iterator(); iterator.hasNext(); ) {
          WeightedPath p = iterator.next();
          if (rootPath.elementWiseEquals(p, i + 1))
          {
            edgeBlackList.add(p.edge(i));
          }
        } 
        
        rootPath.forEachDo(rootPathNode -> {
              if (rootPathNode != spurNode) {
                nodeBlackList.add(rootPathNode);
              }
            });
        
        int spurPathMaxDepth = maxDepth - rootPath.size() + 1;
        Optional<WeightedPath> spurPathOpt = this.dijkstra.compute(spurNode, goal, spurPathMaxDepth);
        
        if (spurPathOpt.isPresent()) {




          
          WeightedPath concatenation = rootPath.dropTail().concat(spurPathOpt.get());
          
          if (!this.candidates.contains(concatenation)) {
            progressLogger.log(String.format("found candidate: %d nodes / %.2f weight", new Object[] {
                    Integer.valueOf(concatenation.size()), 
                    Double.valueOf(concatenation.getCost()) }));
            this.candidates.add(concatenation);
          } 
        } 
      } 
      if (this.candidates.isEmpty()) {
        return;
      }
      
      WeightedPath candidate = this.candidates.remove();
      progressLogger.log(String.format("found path: %d nodes / %.2f weight", new Object[] {
              Integer.valueOf(candidate.size()), 
              Double.valueOf(candidate.getCost()) }));
      this.shortestPaths.add(candidate);
    } 
  }


  
  public YensKShortestPaths me() { return this; }


  
  public void release() {
    this.graph = null;
    this.dijkstra = null;
    this.shortestPaths = null;
    this.candidates = null;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\yens\YensKShortestPaths.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */