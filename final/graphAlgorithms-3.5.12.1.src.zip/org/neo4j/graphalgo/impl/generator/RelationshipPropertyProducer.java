package org.neo4j.graphalgo.impl.generator;

import java.util.Objects;
import java.util.Random;





















public interface RelationshipPropertyProducer
{
  static RelationshipPropertyProducer fixed(String propertyName, double value) { return new Fixed(propertyName, value); }


  
  static RelationshipPropertyProducer random(String propertyName, double min, double max) { return new Random(propertyName, min, max); }
  
  String getPropertyName();
  
  double getPropertyValue(long paramLong1, long paramLong2);
  
  public static class Fixed
    implements RelationshipPropertyProducer {
    private final String propertyName;
    private final double value;
    
    public Fixed(String propertyName, double value) {
      this.propertyName = propertyName;
      this.value = value;
    }

    
    public String getPropertyName() { return this.propertyName; }



    
    public double getPropertyValue(long source, long target) { return this.value; }


    
    public boolean equals(Object o) {
      if (this == o) return true; 
      if (o == null || getClass() != o.getClass()) return false; 
      Fixed fixed = (Fixed)o;
      return (Double.compare(fixed.value, this.value) == 0 && 
        Objects.equals(this.propertyName, fixed.propertyName));
    }


    
    public int hashCode() { return Objects.hash(new Object[] { this.propertyName, Double.valueOf(this.value) }); }



    
    public String toString() { return "Fixed{propertyName='" + this.propertyName + '\'' + ", value=" + this.value + '}'; }
  }

  
  public static class Random
    implements RelationshipPropertyProducer
  {
    private final Random random;
    
    private final String propertyName;
    private final double min;
    private final double max;
    
    public Random(String propertyName, double min, double max) {
      this.propertyName = propertyName;
      this.min = min;
      this.max = max;
      this.random = new Random();
      
      if (max <= min) {
        throw new IllegalArgumentException("Max value must be greater than min value");
      }
    }


    
    public String getPropertyName() { return this.propertyName; }



    
    public double getPropertyValue(long source, long target) { return this.min + this.random.nextDouble() * (this.max - this.min); }


    
    public boolean equals(Object o) {
      if (this == o) return true; 
      if (o == null || getClass() != o.getClass()) return false; 
      Random random = (Random)o;
      return (Double.compare(random.min, this.min) == 0 && 
        Double.compare(random.max, this.max) == 0 && 
        Objects.equals(this.propertyName, random.propertyName));
    }


    
    public int hashCode() { return Objects.hash(new Object[] { this.propertyName, Double.valueOf(this.min), Double.valueOf(this.max) }); }



    
    public String toString() { return "Random{propertyName='" + this.propertyName + '\'' + ", min=" + this.min + ", max=" + this.max + '}'; }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\generator\RelationshipPropertyProducer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */