package org.neo4j.graphalgo.impl.generator;

import java.util.Collections;
import java.util.Optional;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.LongUnaryOperator;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.core.DeduplicationStrategy;
import org.neo4j.graphalgo.core.huge.AdjacencyList;
import org.neo4j.graphalgo.core.huge.AdjacencyOffsets;
import org.neo4j.graphalgo.core.huge.HugeGraph;
import org.neo4j.graphalgo.core.loading.AdjacencyBuilder;
import org.neo4j.graphalgo.core.loading.IdMap;
import org.neo4j.graphalgo.core.loading.ImportSizing;
import org.neo4j.graphalgo.core.loading.RelationshipImporter;
import org.neo4j.graphalgo.core.loading.Relationships;
import org.neo4j.graphalgo.core.loading.RelationshipsBatchBuffer;
import org.neo4j.graphalgo.core.loading.RelationshipsBuilder;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.RawValues;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;






























public final class RandomGraphGenerator
{
  private static final int BATCH_SIZE = 10000;
  private final AllocationTracker allocationTracker;
  private final long nodeCount;
  private final long averageDegree;
  private final RelationshipDistribution relationshipDistribution;
  private final Optional<RelationshipPropertyProducer> maybePropertyProducer;
  
  public RandomGraphGenerator(long nodeCount, long averageDegree, RelationshipDistribution relationshipDistribution, Optional<RelationshipPropertyProducer> maybePropertyProducer, AllocationTracker allocationTracker) {
    this.relationshipDistribution = relationshipDistribution;
    this.maybePropertyProducer = maybePropertyProducer;
    this.allocationTracker = allocationTracker;
    this.nodeCount = nodeCount;
    this.averageDegree = averageDegree;
  }
  
  public HugeGraph generate() {
    IdMap idMap = generateNodes();
    Relationships relationships = generateRelationships(idMap);
    
    return HugeGraph.create(this.allocationTracker, idMap, 

        
        Collections.emptyMap(), relationships
        .relationshipCount(), relationships
        .inAdjacency(), relationships
        .outAdjacency(), relationships
        .inOffsets(), relationships
        .outOffsets(), 
        Optional.empty(), this.maybePropertyProducer
        .map(ignored -> relationships.inRelProperties()), this.maybePropertyProducer
        .map(ignored -> relationships.outRelProperties()), this.maybePropertyProducer
        .map(ignored -> relationships.inRelPropertyOffsets()), this.maybePropertyProducer
        .map(ignored -> relationships.outRelPropertyOffsets()), false);
  }



  
  long getNodeCount() { return this.nodeCount; }


  
  long getAverageDegree() { return this.averageDegree; }


  
  public RelationshipDistribution getRelationshipDistribution() { return this.relationshipDistribution; }


  
  public Optional<RelationshipPropertyProducer> getMaybePropertyProducer() { return this.maybePropertyProducer; }


  
  public boolean shouldGenerateRelationshipProperty() { return this.maybePropertyProducer.isPresent(); }

  
  private IdMap generateNodes() {
    HugeLongArray graphIds = HugeLongArray.newArray(this.nodeCount, this.allocationTracker);
    graphIds.fill(0L);
    
    return new IdMap(graphIds, null, this.nodeCount);
  }







  
  private Relationships generateRelationships(IdMap idMap) {
    RelImporter relImporter = new RelImporter(idMap, this.relationshipDistribution.degreeProducer(this.nodeCount, this.averageDegree), this.relationshipDistribution.relationshipProducer(this.nodeCount, this.averageDegree), this.maybePropertyProducer);
    
    return relImporter.generate();
  }

  
  class RelImporter
  {
    static final int DUMMY_PROPERTY_ID = 42;
    private final LongUnaryOperator relationshipProducer;
    private final LongUnaryOperator degreeProducer;
    private final Optional<RelationshipPropertyProducer> maybeRelationshipPropertyProducer;
    private final RelationshipsBuilder outRelationshipsBuilder;
    private final RelationshipsBuilder inRelationshipsBuilder;
    private final RelationshipImporter relationshipImporter;
    private final RelationshipImporter.Imports imports;
    private final RelationshipsBatchBuffer relationshipBuffer;
    private long importedRelationships = 0L;


    
    private final boolean shouldGenerateProperty;


    
    RelImporter(IdMap idMap, LongUnaryOperator degreeProducer, LongUnaryOperator relationshipProducer, Optional<RelationshipPropertyProducer> maybeRelationshipPropertyProducer) {
      this.relationshipProducer = relationshipProducer;
      this.degreeProducer = degreeProducer;
      this.maybeRelationshipPropertyProducer = maybeRelationshipPropertyProducer;
      
      this.shouldGenerateProperty = maybeRelationshipPropertyProducer.isPresent();
      
      ImportSizing importSizing = ImportSizing.of(1, idMap.nodeCount());
      int pageSize = importSizing.pageSize();
      int numberOfPages = importSizing.numberOfPages();
      
      this.outRelationshipsBuilder = new RelationshipsBuilder(new DeduplicationStrategy[] { DeduplicationStrategy.NONE }, AllocationTracker.EMPTY, this.shouldGenerateProperty ? 1 : 0);



      
      this.inRelationshipsBuilder = new RelationshipsBuilder(new DeduplicationStrategy[] { DeduplicationStrategy.NONE }, AllocationTracker.EMPTY, this.shouldGenerateProperty ? 1 : 0);



      
      (new int[1])[0] = 42; int[] relationshipPropertyIds = this.shouldGenerateProperty ? new int[1] : new int[0];
      
      AdjacencyBuilder outAdjacencyBuilder = AdjacencyBuilder.compressing(this.outRelationshipsBuilder, numberOfPages, pageSize, AllocationTracker.EMPTY, new LongAdder(), relationshipPropertyIds, new double[0]);






      
      AdjacencyBuilder inAdjacencyBuilder = AdjacencyBuilder.compressing(this.inRelationshipsBuilder, numberOfPages, pageSize, AllocationTracker.EMPTY, new LongAdder(), relationshipPropertyIds, new double[0]);






      
      this.relationshipImporter = new RelationshipImporter(AllocationTracker.EMPTY, outAdjacencyBuilder, inAdjacencyBuilder);


      
      this.imports = this.relationshipImporter.imports(false, true, true, this.shouldGenerateProperty);
      
      this.relationshipBuffer = new RelationshipsBatchBuffer((IdMapping)idMap, -1, 10000);
    }
    
    public Relationships generate() {
      long targetId = -1L;
      long nodeId;
      for (nodeId = 0L; nodeId < RandomGraphGenerator.this.nodeCount; nodeId++) {
        long degree = this.degreeProducer.applyAsLong(nodeId);
        
        for (int j = 0; j < degree; j++) {
          targetId = this.relationshipProducer.applyAsLong(nodeId);
          assert targetId < RandomGraphGenerator.this.nodeCount;
          add(nodeId, targetId);
        } 
      } 
      
      flushBuffer();
      return buildRelationships();
    }
    
    private void add(long source, long target) {
      this.relationshipBuffer.add(source, target, -1L, -1L);
      if (this.relationshipBuffer.isFull()) {
        flushBuffer();
        this.relationshipBuffer.reset();
      } 
    }
    
    private void flushBuffer() {
      RelationshipImporter.PropertyReader relationshipPropertyReader = this.shouldGenerateProperty ? this::generateRelationshipProperty : null;

      
      long newImportedInOut = this.imports.importRels(this.relationshipBuffer, relationshipPropertyReader);
      this.importedRelationships += (RawValues.getHead(newImportedInOut) / 2);
      this.relationshipBuffer.reset();
    }
    
    private Relationships buildRelationships() {
      ParallelUtil.run(this.relationshipImporter.flushTasks(), null);
      return new Relationships(-1L, this.importedRelationships, this.inRelationshipsBuilder

          
          .adjacency(), this.outRelationshipsBuilder
          .adjacency(), this.inRelationshipsBuilder
          .globalAdjacencyOffsets(), this.outRelationshipsBuilder
          .globalAdjacencyOffsets(), 
          Optional.empty(), this.shouldGenerateProperty ? this.inRelationshipsBuilder
          .weights() : null, this.shouldGenerateProperty ? this.outRelationshipsBuilder
          .weights() : null, this.shouldGenerateProperty ? this.inRelationshipsBuilder
          .globalWeightOffsets() : null, this.shouldGenerateProperty ? this.outRelationshipsBuilder
          .globalWeightOffsets() : null);
    }






    
    private long[][] generateRelationshipProperty(long[] batch, int batchLength, int[] weightProperty, double[] defaultWeight) {
      RelationshipPropertyProducer relationshipPropertyProducer = this.maybeRelationshipPropertyProducer.orElseGet(() -> {
            
            throw new UnsupportedOperationException("Cannot generate relationship properties without a specified generator");
          });


      
      long[] weights = new long[batchLength / 4];
      for (int i = 0; i < batchLength; i += 4) {
        long source = batch[0 + i];
        long target = batch[1 + i];
        double weight = relationshipPropertyProducer.getPropertyValue(source, target);
        weights[i / 4] = Double.doubleToLongBits(weight);
      } 
      return new long[][] { weights };
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\generator\RandomGraphGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */