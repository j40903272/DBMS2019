package org.neo4j.graphalgo.impl.generator;

import java.util.concurrent.ThreadLocalRandom;
























final class DistributionHelper
{
  static long uniformSample(long upperBound) { return (ThreadLocalRandom.current().nextLong() & Long.MAX_VALUE) % upperBound; }

  
  static long gauseanSample(long upperBound, long mean, long stdDev) {
    double gaussian = ThreadLocalRandom.current().nextGaussian() * stdDev + (mean % upperBound);
    return Math.round(gaussian);
  }

  
  static long powerLawSample(long min, long max, double gamma) {
    double v = Math.pow(Math.pow(max, -gamma + 1.0D) - Math.pow(min, -gamma + 1.0D) * ThreadLocalRandom.current().nextDouble() + Math.pow(min, -gamma + 1.0D), 1.0D / (-gamma + 1.0D));
    return Math.round(v);
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\generator\DistributionHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */