package org.neo4j.graphalgo.impl.pagerank;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.Pools;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeDoubleArray;
import org.neo4j.graphalgo.core.utils.paged.HugeObjectArray;
import org.neo4j.graphdb.Direction;



















public class WeightedDegreeCentrality
  extends Algorithm<WeightedDegreeCentrality>
{
  private final long nodeCount;
  private Graph graph;
  private final ExecutorService executor;
  private final int concurrency;
  private volatile AtomicInteger nodeQueue = new AtomicInteger();

  
  private HugeDoubleArray degrees;

  
  private HugeObjectArray<HugeDoubleArray> weights;
  
  private AllocationTracker tracker;

  
  public WeightedDegreeCentrality(Graph graph, ExecutorService executor, int concurrency, AllocationTracker tracker) {
    if (!graph.hasRelationshipProperty()) {
      throw new UnsupportedOperationException("WeightedDegreeCentrality requires a weight property to be loaded.");
    }
    
    this.tracker = tracker;
    if (concurrency <= 0) {
      concurrency = Pools.DEFAULT_CONCURRENCY;
    }
    
    this.graph = graph;
    this.executor = executor;
    this.concurrency = concurrency;
    this.nodeCount = graph.nodeCount();
    this.degrees = HugeDoubleArray.newArray(this.nodeCount, tracker);
    this.weights = HugeObjectArray.newArray(HugeDoubleArray.class, this.nodeCount, tracker);
  }
  
  public WeightedDegreeCentrality compute(boolean cacheWeights) {
    this.nodeQueue.set(0);
    
    long batchSize = ParallelUtil.adjustedBatchSize(this.nodeCount, this.concurrency);
    long threadSize = ParallelUtil.threadCount(batchSize, this.nodeCount);
    if (threadSize > 2147483647L)
      throw new IllegalArgumentException(String.format("A concurrency of %d is too small to divide graph into at most Integer.MAX_VALUE tasks", new Object[] {
              
              Integer.valueOf(this.concurrency)
            })); 
    List<Runnable> tasks = new ArrayList<>((int)threadSize);
    
    for (int i = 0; i < threadSize; i++) {
      if (cacheWeights) {
        tasks.add(new CacheDegreeTask());
      } else {
        tasks.add(new DegreeTask());
      } 
    } 
    ParallelUtil.runWithConcurrency(this.concurrency, tasks, this.executor);
    
    return this;
  }


  
  public WeightedDegreeCentrality me() { return this; }



  
  public void release() { this.graph = null; }
  
  private class DegreeTask implements Runnable {
    private DegreeTask() {}
    
    public void run() {
      Direction loadDirection = WeightedDegreeCentrality.this.graph.getLoadDirection();
      while (true) {
        int nodeId = WeightedDegreeCentrality.this.nodeQueue.getAndIncrement();
        if (nodeId >= WeightedDegreeCentrality.this.nodeCount || !WeightedDegreeCentrality.this.running()) {
          return;
        }
        
        double[] weightedDegree = new double[1];
        WeightedDegreeCentrality.this.graph.forEachRelationship(nodeId, loadDirection, NaND, (sourceNodeId, targetNodeId, weight) -> {
              if (weight > 0.0D) {
                weightedDegree[0] = weightedDegree[0] + weight;
              }
              
              return true;
            });
        
        WeightedDegreeCentrality.this.degrees.set(nodeId, weightedDegree[0]);
      } 
    }
  }
  
  private class CacheDegreeTask implements Runnable {
    private CacheDegreeTask() {}
    
    public void run() {
      Direction loadDirection = WeightedDegreeCentrality.this.graph.getLoadDirection();
      double[] weightedDegree = new double[1];
      while (true) {
        int nodeId = WeightedDegreeCentrality.this.nodeQueue.getAndIncrement();
        if (nodeId >= WeightedDegreeCentrality.this.nodeCount || !WeightedDegreeCentrality.this.running()) {
          return;
        }
        
        HugeDoubleArray nodeWeights = HugeDoubleArray.newArray(WeightedDegreeCentrality.this.graph.degree(nodeId, loadDirection), WeightedDegreeCentrality.this.tracker);
        WeightedDegreeCentrality.this.weights.set(nodeId, nodeWeights);
        
        int[] index = { 0 };
        weightedDegree[0] = 0.0D;
        WeightedDegreeCentrality.this.graph.forEachRelationship(nodeId, loadDirection, NaND, (sourceNodeId, targetNodeId, weight) -> {
              if (weight > 0.0D) {
                weightedDegree[0] = weightedDegree[0] + weight;
              }
              
              nodeWeights.set(index[0], weight);
              index[0] = index[0] + 1;
              return true;
            });
        
        WeightedDegreeCentrality.this.degrees.set(nodeId, weightedDegree[0]);
      } 
    }
  }


  
  public HugeDoubleArray degrees() { return this.degrees; }

  
  public HugeObjectArray<HugeDoubleArray> weights() { return this.weights; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\pagerank\WeightedDegreeCentrality.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */