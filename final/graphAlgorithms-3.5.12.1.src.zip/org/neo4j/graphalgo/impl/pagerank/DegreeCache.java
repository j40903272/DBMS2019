package org.neo4j.graphalgo.impl.pagerank;

import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeDoubleArray;
import org.neo4j.graphalgo.core.utils.paged.HugeObjectArray;




















public class DegreeCache
{
  public static final DegreeCache EMPTY = new DegreeCache(
      HugeDoubleArray.newArray(0L, AllocationTracker.EMPTY), 
      HugeObjectArray.newArray(HugeDoubleArray.class, 0L, AllocationTracker.EMPTY), 0.0D);
  
  private final HugeDoubleArray aggregatedDegrees;
  
  private final HugeObjectArray<HugeDoubleArray> weights;
  private final double averageDegree;
  
  public DegreeCache(HugeDoubleArray aggregatedDegrees, HugeObjectArray<HugeDoubleArray> weights, double averageDegree) {
    this.aggregatedDegrees = aggregatedDegrees;
    this.weights = weights;
    this.averageDegree = averageDegree;
  }

  
  HugeDoubleArray aggregatedDegrees() { return this.aggregatedDegrees; }


  
  double average() { return this.averageDegree; }


  
  public DegreeCache withAverage(double newAverage) { return new DegreeCache(this.aggregatedDegrees, this.weights, newAverage); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\pagerank\DegreeCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */