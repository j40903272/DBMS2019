package org.neo4j.graphalgo.impl.pagerank;

import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.RelationshipConsumer;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.ArrayUtil;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;


























final class ArticleRankComputeStep
  extends BaseComputeStep
  implements RelationshipConsumer
{
  private double averageDegree;
  private float srcRankDelta;
  
  ArticleRankComputeStep(double dampingFactor, long[] sourceNodeIds, Graph graph, AllocationTracker tracker, int partitionSize, long startNode, DegreeCache degreeCache) {
    super(dampingFactor, sourceNodeIds, graph, tracker, partitionSize, startNode);





    
    this.averageDegree = degreeCache.average();
  }
  
  void singleIteration() {
    long startNode = this.startNode;
    long endNode = this.endNode;
    RelationshipIterator rels = this.relationshipIterator; long nodeId;
    for (nodeId = startNode; nodeId < endNode; nodeId++) {
      double delta = this.deltas[(int)(nodeId - startNode)];
      if (delta > 0.0D) {
        int degree = this.degrees.degree(nodeId, this.direction);
        if (degree > 0) {
          this.srcRankDelta = (float)(delta / (degree + this.averageDegree));
          rels.forEachRelationship(nodeId, this.direction, this);
        } 
      } 
    } 
  }
  
  public boolean accept(long sourceNodeId, long targetNodeId) {
    if (this.srcRankDelta != 0.0F) {
      int idx = ArrayUtil.binaryLookup(targetNodeId, this.starts);
      this.nextScores[idx][(int)(targetNodeId - this.starts[idx])] = this.nextScores[idx][(int)(targetNodeId - this.starts[idx])] + this.srcRankDelta;
    } 
    return true;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\pagerank\ArticleRankComputeStep.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */