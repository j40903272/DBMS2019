package org.neo4j.graphalgo.impl.pagerank;

import java.util.Collections;
import java.util.List;
import java.util.stream.LongStream;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.AlgorithmFactory;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.GraphDimensions;
import org.neo4j.graphalgo.core.ProcedureConfiguration;
import org.neo4j.graphalgo.core.utils.BitUtil;
import org.neo4j.graphalgo.core.utils.Pools;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphdb.Node;
import org.neo4j.logging.Log;




















public class PageRankFactory
  extends AlgorithmFactory<PageRank>
{
  private final PageRankAlgorithmType algorithmType;
  private final PageRank.Config algoConfig;
  
  public PageRankFactory(PageRank.Config algoConfig) { this(PageRankAlgorithmType.NON_WEIGHTED, algoConfig); }

  
  public PageRankFactory(PageRankAlgorithmType algorithmType, PageRank.Config algoConfig) {
    this.algorithmType = algorithmType;
    this.algoConfig = algoConfig;
  }





  
  public PageRank build(Graph graph, ProcedureConfiguration configuration, AllocationTracker tracker, Log log) {
    int batchSize = configuration.getBatchSize();
    int concurrency = configuration.getConcurrency();
    List<Node> sourceNodes = (List<Node>)configuration.get("sourceNodes", Collections.emptyList());
    LongStream sourceNodeIds = sourceNodes.stream().mapToLong(Node::getId);
    
    return this.algorithmType.create(graph, Pools.DEFAULT, batchSize, concurrency, this.algoConfig, sourceNodeIds, tracker);
  }










  
  public MemoryEstimation memoryEstimation() { return MemoryEstimations.builder(PageRank.class)
      .add(MemoryEstimations.setup("computeSteps", (dimensions, concurrency) -> {
            
            long nodeCount = dimensions.nodeCount();
            long nodesPerThread = BitUtil.ceilDiv(nodeCount, concurrency);
            if (nodesPerThread > 1073741807L) {
              concurrency = (int)BitUtil.ceilDiv(nodeCount, 1073741807L);
              nodesPerThread = BitUtil.ceilDiv(nodeCount, concurrency);
              while (nodesPerThread > 1073741807L) {
                concurrency++;
                nodesPerThread = BitUtil.ceilDiv(nodeCount, concurrency);
              } 
            } 
            
            return 
              MemoryEstimations.builder(PageRank.ComputeSteps.class)
              .perThread("scores[] wrapper", MemoryUsage::sizeOfObjectArray)
              .perThread("starts[]", MemoryUsage::sizeOfLongArray)
              .perThread("lengths[]", MemoryUsage::sizeOfLongArray)
              .perThread("list of computeSteps", MemoryUsage::sizeOfObjectArray)
              .perThread("ComputeStep", this.algorithmType.memoryEstimation())
              .build();
          
          })).build(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\pagerank\PageRankFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */