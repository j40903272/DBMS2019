package org.neo4j.graphalgo.impl.pagerank;

import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;

public interface PageRankVariant {
  ComputeStep createComputeStep(double paramDouble1, double paramDouble2, long[] paramArrayOflong, Graph paramGraph, AllocationTracker paramAllocationTracker, int paramInt, long paramLong1, DegreeCache paramDegreeCache, long paramLong2);
  
  DegreeComputer degreeComputer(Graph paramGraph);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\pagerank\PageRankVariant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */