package org.neo4j.graphalgo.impl.pagerank;

import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;



















public class WeightedPageRankVariant
  implements PageRankVariant
{
  private final boolean cacheWeights;
  
  WeightedPageRankVariant(boolean cacheWeights) { this.cacheWeights = cacheWeights; }













  
  public ComputeStep createComputeStep(double dampingFactor, double toleranceValue, long[] sourceNodeIds, Graph graph, AllocationTracker tracker, int partitionCount, long start, DegreeCache aggregatedDegrees, long nodeCount) { return new WeightedComputeStep(dampingFactor, sourceNodeIds, graph, tracker, partitionCount, start, aggregatedDegrees); }











  
  public DegreeComputer degreeComputer(Graph graph) { return new WeightedDegreeComputer(graph, this.cacheWeights); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\pagerank\WeightedPageRankVariant.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */