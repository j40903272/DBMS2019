package org.neo4j.graphalgo.impl.pagerank;

import com.carrotsearch.hppc.IntArrayList;
import com.carrotsearch.hppc.LongArrayList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.function.Supplier;
import java.util.stream.DoubleStream;
import java.util.stream.LongStream;
import org.neo4j.collection.primitive.PrimitiveLongIterator;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Degrees;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.api.NodeIterator;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeDoubleArray;
import org.neo4j.graphalgo.impl.results.CentralityResult;
import org.neo4j.graphdb.Direction;
import org.neo4j.logging.Log;










































































public class PageRank
  extends Algorithm<PageRank>
{
  public static final double DEFAULT_WEIGHT = 1.0D;
  public static final Double DEFAULT_TOLERANCE = Double.valueOf(1.0E-7D);
  
  private final ExecutorService executor;
  
  private final int concurrency;
  
  private final int batchSize;
  private final AllocationTracker tracker;
  private final IdMapping idMapping;
  private final NodeIterator nodeIterator;
  private final Degrees degrees;
  private final double dampingFactor;
  private final int maxIterations;
  private int ranIterations;
  private final double toleranceValue;
  private final Graph graph;
  private final LongStream sourceNodeIds;
  private final PageRankVariant pageRankVariant;
  private Log log;
  private ComputeSteps computeSteps;
  private final HugeDoubleArray result;
  
  public static final class Config
  {
    public final int iterations;
    public final double dampingFactor;
    public final double toleranceValue;
    public final boolean cacheWeights;
    
    public Config(int iterations, double dampingFactor, double toleranceValue) { this(iterations, dampingFactor, toleranceValue, false); }





    
    public Config(int iterations, double dampingFactor, double toleranceValue, boolean cacheWeights) {
      this.iterations = iterations;
      this.dampingFactor = dampingFactor;
      this.toleranceValue = toleranceValue;
      this.cacheWeights = cacheWeights;
    }
  }













  
  PageRank(ExecutorService executor, int concurrency, int batchSize, AllocationTracker tracker, Graph graph, Config algoConfig, LongStream sourceNodeIds, PageRankVariant pageRankVariant) {
    assert algoConfig.iterations >= 1;
    this.executor = executor;
    this.concurrency = concurrency;
    this.batchSize = batchSize;
    this.tracker = tracker;
    this.idMapping = (IdMapping)graph;
    this.nodeIterator = (NodeIterator)graph;
    this.degrees = (Degrees)graph;
    this.graph = graph;
    this.dampingFactor = algoConfig.dampingFactor;
    this.maxIterations = algoConfig.iterations;
    this.ranIterations = 0;
    this.toleranceValue = algoConfig.toleranceValue;
    this.sourceNodeIds = sourceNodeIds;
    this.pageRankVariant = pageRankVariant;
    this.result = HugeDoubleArray.newArray(graph.nodeCount(), tracker);
  }

  
  public int iterations() { return this.ranIterations; }


  
  public double dampingFactor() { return this.dampingFactor; }




  
  public PageRank compute() {
    initializeSteps();
    this.computeSteps.run(this.maxIterations);
    return this;
  }

  
  public CentralityResult result() { return this.computeSteps.getPageRank(); }


  
  public PageRank withProgressLogger(Log log) {
    super.withProgressLogger(log);
    this.log = log;
    return this;
  }


  
  private void initializeSteps() {
    if (this.computeSteps != null) {
      return;
    }
    List<Partition> partitions = partitionGraph(
        adjustBatchSize(this.batchSize), this.nodeIterator, this.degrees);

    
    ExecutorService executor = ParallelUtil.canRunInParallel(this.executor) ? this.executor : null;

    
    this.computeSteps = createComputeSteps(this.concurrency, this.idMapping
        
        .nodeCount(), this.dampingFactor, this.sourceNodeIds
        
        .map(this.graph::toMappedNodeId).filter(mappedId -> (mappedId != -1L)).toArray(), partitions, executor);
  }


  
  private int adjustBatchSize(int batchSize) {
    if (batchSize == 0) {
      return 1073741807;
    }


    
    return Math.toIntExact(batchSize * 8L);
  }



  
  private List<Partition> partitionGraph(int batchSize, NodeIterator nodeIterator, Degrees degrees) {
    PrimitiveLongIterator nodes = nodeIterator.nodeIterator();
    List<Partition> partitions = new ArrayList<>();
    long start = 0L;
    Direction direction = this.graph.getLoadDirection();
    while (nodes.hasNext()) {
      Partition partition = new Partition(nodes, degrees, direction, start, batchSize);




      
      partitions.add(partition);
      start += partition.nodeCount;
    } 
    return partitions;
  }






  
  private ComputeSteps createComputeSteps(int concurrency, long nodeCount, double dampingFactor, long[] sourceNodeIds, List<Partition> partitions, ExecutorService pool) {
    concurrency = findIdealConcurrency(nodeCount, partitions, concurrency, this.log);
    int expectedParallelism = Math.min(concurrency, partitions
        
        .size());
    
    List<ComputeStep> computeSteps = new ArrayList<>(expectedParallelism);
    LongArrayList starts = new LongArrayList(expectedParallelism);
    IntArrayList lengths = new IntArrayList(expectedParallelism);
    int partitionsPerThread = ParallelUtil.threadCount(concurrency + 1, partitions
        
        .size());
    Iterator<Partition> parts = partitions.iterator();
    
    DegreeComputer degreeComputer = this.pageRankVariant.degreeComputer(this.graph);
    DegreeCache degreeCache = degreeComputer.degree(pool, concurrency, this.tracker);
    
    while (parts.hasNext()) {
      Partition partition = parts.next();
      int partitionSize = partition.nodeCount;
      long start = partition.startNode;
      int i = 1;
      while (parts.hasNext() && i < partitionsPerThread && partition
        
        .fits(partitionSize)) {
        partition = parts.next();
        partitionSize += partition.nodeCount;
        i++;
      } 
      
      starts.add(start);
      lengths.add(partitionSize);
      
      computeSteps.add(this.pageRankVariant.createComputeStep(dampingFactor, this.toleranceValue, sourceNodeIds, this.graph, this.tracker, partitionSize, start, degreeCache, nodeCount));
    } 










    
    long[] startArray = starts.toArray();
    int[] lengthArray = lengths.toArray();
    for (ComputeStep computeStep : computeSteps) {
      computeStep.setStarts(startArray, lengthArray);
    }
    return new ComputeSteps(this.tracker, computeSteps, concurrency, pool);
  }




  
  private static int findIdealConcurrency(long nodeCount, List<Partition> partitions, int concurrency, Log log) {
    if (concurrency <= 0) {
      concurrency = partitions.size();
    }
    
    if (log != null && log.isDebugEnabled()) {
      log.debug("PageRank: nodes=%d, concurrency=%d, available memory=%s, estimated memory usage: %s", new Object[] {
            
            Long.valueOf(nodeCount), 
            Integer.valueOf(concurrency), 
            MemoryUsage.humanReadable(availableMemory()), 
            MemoryUsage.humanReadable(memoryUsageFor(concurrency, partitions))
          });
    }
    
    int maxConcurrency = maxConcurrencyByMemory(nodeCount, concurrency, 

        
        availableMemory(), partitions);
    
    if (concurrency > maxConcurrency) {
      if (log != null) {
        long required = memoryUsageFor(concurrency, partitions);
        long newRequired = memoryUsageFor(maxConcurrency, partitions);
        long available = availableMemory();
        log.warn("Requested concurrency of %d would require %s Heap but only %s are available, PageRank will be throttled to a concurrency of %d to use only %s Heap.", new Object[] {
              
              Integer.valueOf(concurrency), 
              MemoryUsage.humanReadable(required), 
              MemoryUsage.humanReadable(available), 
              Integer.valueOf(maxConcurrency), 
              MemoryUsage.humanReadable(newRequired)
            });
      } 
      concurrency = maxConcurrency;
    } 
    return concurrency;
  }




  
  private static int maxConcurrencyByMemory(long nodeCount, int concurrency, long availableBytes, List<Partition> partitions) {
    int newConcurrency = concurrency;
    
    long memoryUsage = memoryUsageFor(newConcurrency, partitions);
    while (memoryUsage > availableBytes) {
      long perThread = estimateMemoryUsagePerThread(nodeCount, concurrency);
      long overflow = memoryUsage - availableBytes;
      newConcurrency -= (int)Math.ceil(overflow / perThread);
      
      memoryUsage = memoryUsageFor(newConcurrency, partitions);
    } 
    return newConcurrency;
  }

  
  private static long availableMemory() {
    Runtime rt = Runtime.getRuntime();
    
    long max = rt.maxMemory();
    long total = rt.totalMemory();
    long free = rt.freeMemory();
    
    return max - total + free;
  }
  
  private static long estimateMemoryUsagePerThread(long nodeCount, int concurrency) {
    int nodesPerThread = (int)Math.ceil(nodeCount / concurrency);
    long partitions = MemoryUsage.sizeOfIntArray(nodesPerThread) * concurrency;
    return MemoryUsage.sizeOfInstance(BaseComputeStep.class) + partitions;
  }


  
  private static long memoryUsageFor(int concurrency, List<Partition> partitions) {
    long perThreadUsage = 0L;
    long sharedUsage = 0L;
    int stepSize = 0;
    int partitionsPerThread = ParallelUtil.threadCount(concurrency + 1, partitions.size());
    Iterator<Partition> parts = partitions.iterator();
    
    while (parts.hasNext()) {
      Partition partition = parts.next();
      int partitionCount = partition.nodeCount;
      int i = 1;
      while (parts.hasNext() && i < partitionsPerThread && partition
        
        .fits(partitionCount)) {
        partition = parts.next();
        partitionCount += partition.nodeCount;
        i++;
      } 
      stepSize++;
      sharedUsage += MemoryUsage.sizeOfDoubleArray(partitionCount) << 1L;
      perThreadUsage += MemoryUsage.sizeOfIntArray(partitionCount);
    } 
    
    perThreadUsage *= stepSize;
    perThreadUsage += MemoryUsage.sizeOfInstance(BaseComputeStep.class);
    perThreadUsage += MemoryUsage.sizeOfObjectArray(stepSize);
    
    sharedUsage += MemoryUsage.sizeOfInstance(ComputeSteps.class);
    sharedUsage += MemoryUsage.sizeOfLongArray(stepSize) << 1L;
    
    return sharedUsage + perThreadUsage;
  }


  
  public PageRank me() { return this; }



  
  public void release() { this.computeSteps.release(); }



  
  static final class Partition
  {
    public static final int MAX_NODE_COUNT = 1073741807;

    
    private final long startNode;

    
    private final int nodeCount;


    
    Partition(PrimitiveLongIterator nodes, Degrees degrees, Direction direction, long startNode, long batchSize) {
      assert batchSize > 0L;
      int nodeCount = 0;
      long partitionSize = 0L;
      while (nodes.hasNext() && partitionSize < batchSize && nodeCount < 1073741807) {
        long nodeId = nodes.next();
        nodeCount++;
        partitionSize += degrees.degree(nodeId, direction);
      } 
      this.startNode = startNode;
      this.nodeCount = nodeCount;
    }

    
    private boolean fits(int otherPartitionsCount) { return (1073741807 - otherPartitionsCount >= this.nodeCount); }
  }

  
  final class ComputeSteps
  {
    private List<ComputeStep> steps;
    
    private final ExecutorService pool;
    
    private float[][][] scores;
    
    private final int concurrency;
    
    private ComputeSteps(AllocationTracker tracker, List<ComputeStep> steps, int concurrency, ExecutorService pool) {
      this.concurrency = concurrency;
      assert !steps.isEmpty();
      this.steps = steps;
      this.pool = pool;
      int stepSize = steps.size();
      this.scores = new float[stepSize][stepSize][];
      if (AllocationTracker.isTracking(tracker)) {
        tracker.add((stepSize + 1) * MemoryUsage.sizeOfObjectArray(stepSize));
      }
    }
    
    CentralityResult getPageRank() {
      for (ComputeStep step : this.steps) {
        step.getPageRankResult(PageRank.this.result);
      }
      return new CentralityResult(PageRank.this.result);
    }
    
    private void run(int iterations) {
      int operations = (iterations << 1) + 1;
      int op = 0;
      boolean algorithmHasStabilized = false;
      ParallelUtil.runWithConcurrency(this.concurrency, this.steps, PageRank.this.terminationFlag, this.pool);
      PageRank.this.getProgressLogger().logProgress(++op, operations, (Supplier)PageRank.this.tracker);
      for (int i = 0; i < iterations && !algorithmHasStabilized; i++) {
        
        ParallelUtil.runWithConcurrency(this.concurrency, this.steps, PageRank.this.terminationFlag, this.pool);
        PageRank.this.getProgressLogger().logProgress(++op, operations, (Supplier)PageRank.this.tracker);

        
        synchronizeScores();
        ParallelUtil.runWithConcurrency(this.concurrency, this.steps, PageRank.this.terminationFlag, this.pool);
        algorithmHasStabilized = checkTolerance();
        PageRank.this.getProgressLogger().logProgress(++op, operations, (Supplier)PageRank.this.tracker);

        
        normalizeDeltas();
        ParallelUtil.runWithConcurrency(this.concurrency, this.steps, PageRank.this.terminationFlag, this.pool);
        PageRank.this.getProgressLogger().logProgress(++op, operations, (Supplier)PageRank.this.tracker);
        
        PageRank.this.ranIterations++;
      } 
    }

    
    private boolean checkTolerance() { return this.steps.stream().allMatch(ComputeStep::partitionIsStable); }

    
    private void normalizeDeltas() {
      double l2Norm = computeNorm();
      
      for (ComputeStep step : this.steps) {
        step.prepareNormalizeDeltas(l2Norm);
      }
    }
    
    private double computeNorm() {
      double l2Norm = 0.0D;
      for (ComputeStep step : this.steps) {
        double[] deltas = step.deltas();
        l2Norm += ((Double)ParallelUtil.parallelStream(
            Arrays.stream(deltas), stream -> 
            Double.valueOf(stream.map(()).sum()))).doubleValue();
      } 
      l2Norm = Math.sqrt(l2Norm);
      l2Norm = (l2Norm < 0.0D) ? 1.0D : l2Norm;
      return l2Norm;
    }
    
    private void synchronizeScores() {
      int stepSize = this.steps.size();
      float[][][] scores = this.scores;
      
      for (int i = 0; i < stepSize; i++) {
        synchronizeScores(this.steps.get(i), i, scores);
      }
    }
    
    private void synchronizeScores(ComputeStep step, int idx, float[][][] scores) {
      step.prepareNextIteration(scores[idx]);
      float[][] nextScores = step.nextScores();
      for (int j = 0, len = nextScores.length; j < len; j++) {
        scores[j][idx] = nextScores[j];
      }
    }
    
    private void release() {
      if (AllocationTracker.isTracking(PageRank.this.tracker)) {
        PageRank.this.tracker.remove((this.scores.length + 1) * MemoryUsage.sizeOfObjectArray(this.scores.length));
      }
      this.steps.clear();
      this.steps = null;
      this.scores = (float[][][])null;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\pagerank\PageRank.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */