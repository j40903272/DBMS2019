package org.neo4j.graphalgo.impl.pagerank;

import java.util.concurrent.ExecutorService;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;

public interface DegreeComputer {
  DegreeCache degree(ExecutorService paramExecutorService, int paramInt, AllocationTracker paramAllocationTracker);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\pagerank\DegreeComputer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */