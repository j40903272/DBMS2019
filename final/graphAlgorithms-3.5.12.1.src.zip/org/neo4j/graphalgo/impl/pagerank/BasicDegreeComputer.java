package org.neo4j.graphalgo.impl.pagerank;

import java.util.concurrent.ExecutorService;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;




















public class BasicDegreeComputer
  implements DegreeComputer
{
  private final Graph graph;
  
  BasicDegreeComputer(Graph graph) { this.graph = graph; }





  
  public DegreeCache degree(ExecutorService executor, int concurrency, AllocationTracker tracker) {
    AverageDegreeCentrality degreeCentrality = new AverageDegreeCentrality(this.graph, executor, concurrency);
    degreeCentrality.compute();
    return DegreeCache.EMPTY.withAverage(degreeCentrality.average());
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\pagerank\BasicDegreeComputer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */