package org.neo4j.graphalgo.impl.pagerank;

import org.neo4j.graphalgo.core.utils.paged.HugeDoubleArray;

public interface ComputeStep extends Runnable {
  void prepareNextIteration(float[][] paramArrayOffloat);
  
  float[][] nextScores();
  
  void setStarts(long[] paramArrayOflong, int[] paramArrayOfint);
  
  double[] deltas();
  
  void prepareNormalizeDeltas(double paramDouble);
  
  boolean partitionIsStable();
  
  void getPageRankResult(HugeDoubleArray paramHugeDoubleArray);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\pagerank\ComputeStep.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */