package org.neo4j.graphalgo.impl.pagerank;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicLong;
import org.HdrHistogram.AtomicHistogram;
import org.HdrHistogram.Histogram;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.Pools;



















public class AverageDegreeCentrality
  extends Algorithm<AverageDegreeCentrality>
{
  private final long nodeCount;
  private Graph graph;
  private final ExecutorService executor;
  private final int concurrency;
  private volatile AtomicLong nodeQueue = new AtomicLong();

  
  private final Histogram histogram;


  
  public AverageDegreeCentrality(Graph graph, ExecutorService executor, int concurrency) {
    if (concurrency <= 0) {
      concurrency = Pools.DEFAULT_CONCURRENCY;
    }
    
    this.graph = graph;
    this.executor = executor;
    this.concurrency = concurrency;
    this.nodeCount = graph.nodeCount();
    this.histogram = (Histogram)new AtomicHistogram(this.nodeCount, 3);
  }
  
  public AverageDegreeCentrality compute() {
    this.nodeQueue.set(0L);
    
    List<Runnable> tasks = new ArrayList<>();
    for (int i = 0; i < this.concurrency; i++) {
      tasks.add(new DegreeTask());
    }
    ParallelUtil.runWithConcurrency(this.concurrency, tasks, this.executor);
    
    return this;
  }


  
  public AverageDegreeCentrality me() { return this; }



  
  public void release() { this.graph = null; }
  
  private class DegreeTask implements Runnable {
    private DegreeTask() {}
    
    public void run() {
      while (true) {
        long nodeId = AverageDegreeCentrality.this.nodeQueue.getAndIncrement();
        if (nodeId >= AverageDegreeCentrality.this.nodeCount || !AverageDegreeCentrality.this.running()) {
          return;
        }
        
        int degree = AverageDegreeCentrality.this.graph.degree(nodeId, AverageDegreeCentrality.this.graph.getLoadDirection());
        AverageDegreeCentrality.this.histogram.recordValue(degree);
      } 
    }
  }

  
  public double average() { return this.histogram.getMean(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\pagerank\AverageDegreeCentrality.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */