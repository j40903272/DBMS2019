package org.neo4j.graphalgo.impl.pagerank;

import java.util.concurrent.ExecutorService;
import java.util.stream.LongStream;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.GraphDimensions;
import org.neo4j.graphalgo.core.utils.BitUtil;
import org.neo4j.graphalgo.core.utils.mem.Assessable;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;































public interface PageRankAlgorithm
  extends Assessable
{
  default PageRank create(Graph graph, PageRank.Config algoConfig, LongStream sourceNodeIds) { return create(graph, algoConfig, sourceNodeIds, AllocationTracker.EMPTY); }












  
  default PageRank create(Graph graph, PageRank.Config algoConfig, LongStream sourceNodeIds, AllocationTracker tracker) { return create(graph, null, 10000, -1, algoConfig, sourceNodeIds, tracker); }









  
  default PageRank create(Graph graph, ExecutorService executor, int batchSize, int concurrency, PageRank.Config algoConfig, LongStream sourceNodeIds) { return create(graph, executor, batchSize, concurrency, algoConfig, sourceNodeIds, AllocationTracker.EMPTY); }










  
  default PageRank create(Graph graph, ExecutorService executor, int batchSize, int concurrency, PageRank.Config algoConfig, LongStream sourceNodeIds, AllocationTracker tracker) { return new PageRank(executor, concurrency, batchSize, tracker, graph, algoConfig, sourceNodeIds, 






        
        variant(algoConfig)); }

  
  PageRankVariant variant(PageRank.Config paramConfig);

  
  Class<? extends BaseComputeStep> computeStepClass();
  
  default MemoryEstimation memoryEstimation() {
    return MemoryEstimations.setup("ComputeStep", (dimensions, concurrency) -> {
          long nodeCount = dimensions.nodeCount();
          long nodesPerThread = BitUtil.ceilDiv(nodeCount, concurrency);
          return BaseComputeStep.estimateMemory((int)nodesPerThread, computeStepClass());
        });
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\pagerank\PageRankAlgorithm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */