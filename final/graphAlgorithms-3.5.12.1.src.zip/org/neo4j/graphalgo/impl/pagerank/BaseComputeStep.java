package org.neo4j.graphalgo.impl.pagerank;

import java.util.Arrays;
import java.util.stream.LongStream;
import org.neo4j.graphalgo.api.Degrees;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeDoubleArray;
import org.neo4j.graphdb.Direction;




































public abstract class BaseComputeStep
  implements ComputeStep
{
  private static final int S_INIT = 0;
  private static final int S_CALC = 1;
  private static final int S_SYNC = 2;
  private static final int S_NORM = 3;
  private int state;
  long[] starts;
  private int[] lengths;
  protected double tolerance;
  private long[] sourceNodeIds;
  final RelationshipIterator relationshipIterator;
  final Degrees degrees;
  private final AllocationTracker tracker;
  private final double alpha;
  final double dampingFactor;
  final Direction direction;
  double[] pageRank;
  double[] deltas;
  float[][] nextScores;
  float[][] prevScores;
  final long startNode;
  final long endNode;
  private final int partitionSize;
  double l2Norm;
  private boolean shouldBreak;
  
  BaseComputeStep(double dampingFactor, long[] sourceNodeIds, Graph graph, AllocationTracker tracker, int partitionSize, long startNode) {
    this(dampingFactor, PageRank.DEFAULT_TOLERANCE
        
        .doubleValue(), sourceNodeIds, graph, tracker, partitionSize, startNode);
  }














  
  BaseComputeStep(double dampingFactor, double tolerance, long[] sourceNodeIds, Graph graph, AllocationTracker tracker, int partitionSize, long startNode) {
    this.dampingFactor = dampingFactor;
    this.alpha = 1.0D - dampingFactor;
    this.tolerance = tolerance;
    this.sourceNodeIds = sourceNodeIds;
    this.relationshipIterator = graph.concurrentCopy();
    this.degrees = (Degrees)graph;
    this.direction = graph.getLoadDirection();
    this.tracker = tracker;
    this.partitionSize = partitionSize;
    this.startNode = startNode;
    this.endNode = startNode + partitionSize;
    this.state = 0;
  }



  
  static MemoryEstimation estimateMemory(int partitionSize, Class<?> computeStep) { return MemoryEstimations.builder(computeStep)
      .perThread("nextScores[] wrapper", MemoryUsage::sizeOfObjectArray)
      .perThread("inner nextScores[][]", MemoryUsage.sizeOfFloatArray(partitionSize))
      .fixed("pageRank[]", MemoryUsage.sizeOfDoubleArray(partitionSize))
      .fixed("deltas[]", MemoryUsage.sizeOfDoubleArray(partitionSize))
      .build(); }

  
  public void setStarts(long[] starts, int[] lengths) {
    this.starts = starts;
    this.lengths = lengths;
  }

  
  public void run() {
    if (this.state == 1) {
      singleIteration();
      this.state = 2;
    } else if (this.state == 2) {
      this.shouldBreak = combineScores();
      this.state = 3;
    } else if (this.state == 3) {
      normalizeDeltas();
      this.state = 1;
    } else if (this.state == 0) {
      initialize();
      this.state = 1;
    } 
  }
  
  void normalizeDeltas() {}
  
  private void initialize() {
    this.nextScores = new float[this.starts.length][];
    Arrays.setAll(this.nextScores, i -> {
          int size = this.lengths[i];
          this.tracker.add(MemoryUsage.sizeOfFloatArray(size));
          return new float[size];
        });
    
    this.tracker.add(MemoryUsage.sizeOfDoubleArray(this.partitionSize) << 1L);
    
    double[] partitionRank = new double[this.partitionSize];
    double initialValue = initialValue();
    if (this.sourceNodeIds.length == 0) {
      Arrays.fill(partitionRank, initialValue);
    } else {
      Arrays.fill(partitionRank, 0.0D);


      
      long[] partitionSourceNodeIds = LongStream.of(this.sourceNodeIds).filter(sourceNodeId -> (sourceNodeId >= this.startNode && sourceNodeId < this.endNode)).toArray();
      
      for (long sourceNodeId : partitionSourceNodeIds) {
        partitionRank[Math.toIntExact(sourceNodeId - this.startNode)] = initialValue;
      }
    } 
    
    this.pageRank = partitionRank;
    this.deltas = Arrays.copyOf(partitionRank, this.partitionSize);
  }

  
  double initialValue() { return this.alpha; }





  
  public void prepareNormalizeDeltas(double l2Norm) { this.l2Norm = l2Norm; }


  
  public void prepareNextIteration(float[][] prevScores) { this.prevScores = prevScores; }

  
  boolean combineScores() {
    assert this.prevScores != null;
    assert this.prevScores.length >= 1;
    
    int scoreDim = this.prevScores.length;
    float[][] prevScores = this.prevScores;
    
    boolean shouldBreak = true;
    
    int length = (prevScores[0]).length;
    for (int i = 0; i < length; i++) {
      double sum = 0.0D;
      for (int j = 0; j < scoreDim; j++) {
        float[] scores = prevScores[j];
        sum += scores[i];
        scores[i] = 0.0F;
      } 
      double delta = this.dampingFactor * sum;
      if (delta > this.tolerance) {
        shouldBreak = false;
      }
      this.pageRank[i] = this.pageRank[i] + delta;
      this.deltas[i] = delta;
    } 
    
    return shouldBreak;
  }

  
  public float[][] nextScores() { return this.nextScores; }



  
  public void getPageRankResult(HugeDoubleArray result) { result.copyFromArrayIntoSlice(this.pageRank, this.startNode, this.endNode); }

  
  public double[] deltas() { return this.deltas; }


  
  public boolean partitionIsStable() { return this.shouldBreak; }
  
  abstract void singleIteration();
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\pagerank\BaseComputeStep.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */