package org.neo4j.graphalgo.impl.pagerank;

import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.api.RelationshipWithPropertyConsumer;
import org.neo4j.graphalgo.core.utils.ArrayUtil;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeDoubleArray;




























public class WeightedComputeStep
  extends BaseComputeStep
  implements RelationshipWithPropertyConsumer
{
  private final HugeDoubleArray aggregatedDegrees;
  private double sumOfWeights;
  private double delta;
  
  WeightedComputeStep(double dampingFactor, long[] sourceNodeIds, Graph graph, AllocationTracker tracker, int partitionSize, long startNode, DegreeCache degreeCache) {
    super(dampingFactor, sourceNodeIds, graph, tracker, partitionSize, startNode);





    
    this.aggregatedDegrees = degreeCache.aggregatedDegrees();
  }
  
  void singleIteration() {
    long startNode = this.startNode;
    long endNode = this.endNode;
    RelationshipIterator rels = this.relationshipIterator; long nodeId;
    for (nodeId = startNode; nodeId < endNode; nodeId++) {
      this.delta = this.deltas[(int)(nodeId - startNode)];
      if (this.delta > 0.0D) {
        int degree = this.degrees.degree(nodeId, this.direction);
        if (degree > 0) {
          this.sumOfWeights = this.aggregatedDegrees.get(nodeId);
          rels.forEachRelationship(nodeId, this.direction, 1.0D, this);
        } 
      } 
    } 
  }

  
  public boolean accept(long sourceNodeId, long targetNodeId, double property) {
    if (property > 0.0D) {
      double proportion = property / this.sumOfWeights;
      float srcRankDelta = (float)(this.delta * proportion);
      if (srcRankDelta != 0.0F) {
        int idx = ArrayUtil.binaryLookup(targetNodeId, this.starts);
        this.nextScores[idx][(int)(targetNodeId - this.starts[idx])] = this.nextScores[idx][(int)(targetNodeId - this.starts[idx])] + srcRankDelta;
      } 
    } 
    
    return true;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\pagerank\WeightedComputeStep.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */