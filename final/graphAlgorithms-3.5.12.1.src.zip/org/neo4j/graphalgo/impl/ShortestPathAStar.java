package org.neo4j.graphalgo.impl;

import com.carrotsearch.hppc.IntArrayDeque;
import com.carrotsearch.hppc.IntDoubleMap;
import com.carrotsearch.hppc.IntDoubleScatterMap;
import com.carrotsearch.hppc.IntIntMap;
import com.carrotsearch.hppc.IntIntScatterMap;
import com.carrotsearch.hppc.cursors.IntCursor;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.core.heavyweight.Converters;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.container.SimpleBitSet;
import org.neo4j.graphalgo.core.utils.queue.IntPriorityQueue;
import org.neo4j.graphalgo.core.utils.queue.SharedIntPriorityQueue;
import org.neo4j.graphdb.Direction;
import org.neo4j.graphdb.Node;
import org.neo4j.kernel.internal.GraphDatabaseAPI;






















public class ShortestPathAStar
  extends Algorithm<ShortestPathAStar>
{
  private final GraphDatabaseAPI dbService;
  private static final int PATH_END = -1;
  private Graph graph;
  private final int nodeCount;
  private IntDoubleMap gCosts;
  private IntDoubleMap fCosts;
  private double totalCost;
  private IntPriorityQueue openNodes;
  private IntIntMap path;
  private IntArrayDeque shortestPath;
  private SimpleBitSet closedNodes;
  private final ProgressLogger progressLogger;
  public static final double NO_PATH_FOUND = -1.0D;
  
  public ShortestPathAStar(Graph graph, GraphDatabaseAPI dbService) {
    this.graph = graph;
    this.dbService = dbService;
    this.nodeCount = Math.toIntExact(graph.nodeCount());
    this.gCosts = (IntDoubleMap)new IntDoubleScatterMap(this.nodeCount);
    this.fCosts = (IntDoubleMap)new IntDoubleScatterMap(this.nodeCount);
    this.openNodes = (IntPriorityQueue)SharedIntPriorityQueue.min(this.nodeCount, this.fCosts, Double.MAX_VALUE);


    
    this.path = (IntIntMap)new IntIntScatterMap(this.nodeCount);
    this.closedNodes = new SimpleBitSet(this.nodeCount);
    this.shortestPath = new IntArrayDeque();
    this.progressLogger = getProgressLogger();
  }





  
  public ShortestPathAStar compute(long startNode, long goalNode, String propertyKeyLat, String propertyKeyLon, Direction direction) {
    reset();
    int startNodeInternal = Math.toIntExact(this.graph.toMappedNodeId(startNode));
    double startNodeLat = getNodeCoordinate(startNodeInternal, propertyKeyLat);
    double startNodeLon = getNodeCoordinate(startNodeInternal, propertyKeyLon);
    int goalNodeInternal = Math.toIntExact(this.graph.toMappedNodeId(goalNode));
    double goalNodeLat = getNodeCoordinate(goalNodeInternal, propertyKeyLat);
    double goalNodeLon = getNodeCoordinate(goalNodeInternal, propertyKeyLon);
    double initialHeuristic = computeHeuristic(startNodeLat, startNodeLon, goalNodeLat, goalNodeLon);
    this.gCosts.put(startNodeInternal, 0.0D);
    this.fCosts.put(startNodeInternal, initialHeuristic);
    this.openNodes.add(startNodeInternal, 0.0D);
    run(goalNodeInternal, propertyKeyLat, propertyKeyLon, direction);
    if (this.path.containsKey(goalNodeInternal)) {
      this.totalCost = this.gCosts.get(goalNodeInternal);
      int node = goalNodeInternal;
      while (node != -1) {
        this.shortestPath.addFirst(node);
        node = this.path.getOrDefault(node, -1);
      } 
    } 
    return this;
  }




  
  private void run(int goalNodeId, String propertyKeyLat, String propertyKeyLon, Direction direction) {
    double goalLat = getNodeCoordinate(goalNodeId, propertyKeyLat);
    double goalLon = getNodeCoordinate(goalNodeId, propertyKeyLon);
    while (!this.openNodes.isEmpty() && running()) {
      int currentNodeId = this.openNodes.pop();
      if (currentNodeId == goalNodeId) {
        return;
      }
      this.closedNodes.put(currentNodeId);
      double currentNodeCost = this.gCosts.getOrDefault(currentNodeId, Double.MAX_VALUE);
      this.graph.forEachRelationship(currentNodeId, direction, 0.0D, 


          
          Converters.longToIntConsumer((source, target, weight) -> {
              double neighbourLat = getNodeCoordinate(target, propertyKeyLat);
              double neighbourLon = getNodeCoordinate(target, propertyKeyLon);
              double heuristic = computeHeuristic(neighbourLat, neighbourLon, goalLat, goalLon);
              boolean weightChanged = updateCosts(source, target, weight + currentNodeCost, heuristic);
              if (!this.closedNodes.contains(target)) {
                if (weightChanged) {
                  this.openNodes.update(target);
                } else {
                  this.openNodes.add(target, 0.0D);
                } 
              }
              return true;
            }));
      this.progressLogger.logProgress(currentNodeId / (this.nodeCount - 1));
    } 
  }
  
  private double computeHeuristic(double lat1, double lon1, double lat2, double lon2) {
    int earthRadius = 6371;
    double kmToNM = 0.539957D;
    double latDistance = Math.toRadians(lat2 - lat1);
    double lonDistance = Math.toRadians(lon2 - lon1);

    
    double a = Math.sin(latDistance / 2.0D) * Math.sin(latDistance / 2.0D) + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.sin(lonDistance / 2.0D) * Math.sin(lonDistance / 2.0D);
    double c = 2.0D * Math.atan2(Math.sqrt(a), Math.sqrt(1.0D - a));
    double distance = 6371.0D * c * 0.539957D;
    return distance;
  }
  
  private double getNodeCoordinate(int nodeId, String coordinateType) {
    long neo4jId = this.graph.toOriginalNodeId(nodeId);
    Node node = this.dbService.getNodeById(neo4jId);
    return ((Double)node.getProperty(coordinateType)).doubleValue();
  }
  
  private boolean updateCosts(int source, int target, double newCost, double heuristic) {
    double oldCost = this.gCosts.getOrDefault(target, Double.MAX_VALUE);
    if (newCost < oldCost) {
      this.gCosts.put(target, newCost);
      this.fCosts.put(target, newCost + heuristic);
      this.path.put(target, source);
      return (oldCost < Double.MAX_VALUE);
    } 
    return false;
  }
  
  private void reset() {
    this.closedNodes.clear();
    this.openNodes.clear();
    this.gCosts.clear();
    this.fCosts.clear();
    this.path.clear();
    this.shortestPath.clear();
    this.totalCost = -1.0D;
  }

  
  public Stream<Result> resultStream() { return StreamSupport.stream(this.shortestPath.spliterator(), false)
      .map(cursor -> new Result(Long.valueOf(this.graph.toOriginalNodeId(cursor.value)), Double.valueOf(this.gCosts.get(cursor.value)))); }


  
  public IntArrayDeque getFinalPath() { return this.shortestPath; }


  
  public double getTotalCost() { return this.totalCost; }


  
  public int getPathLength() { return this.shortestPath.size(); }



  
  public ShortestPathAStar me() { return this; }


  
  public void release() {
    this.graph = null;
    this.gCosts = null;
    this.fCosts = null;
    this.openNodes = null;
    this.path = null;
    this.shortestPath = null;
    this.closedNodes = null;
  }


  
  public static class Result
  {
    public final Long nodeId;

    
    public final Double cost;


    
    public Result(Long nodeId, Double cost) {
      this.nodeId = nodeId;
      this.cost = cost;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\ShortestPathAStar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */