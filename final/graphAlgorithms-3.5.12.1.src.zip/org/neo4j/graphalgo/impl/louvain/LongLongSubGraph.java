package org.neo4j.graphalgo.impl.louvain;

import com.carrotsearch.hppc.LongFloatHashMap;
import com.carrotsearch.hppc.cursors.LongFloatCursor;
import java.util.function.Supplier;
import org.neo4j.graphalgo.api.RelationshipWithPropertyConsumer;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeObjectArray;


















final class LongLongSubGraph
  extends SubGraph
{
  private HugeObjectArray<LongFloatHashMap> graph;
  private final long nodeCount;
  private final AllocationTracker tracker;
  
  LongLongSubGraph(long nodeCount, boolean hasRelationshipProperty, AllocationTracker tracker) {
    super(hasRelationshipProperty);
    this.nodeCount = nodeCount;
    this.tracker = tracker;
    this.graph = HugeObjectArray.newArray(LongFloatHashMap.class, nodeCount, tracker);
  }
  
  void add(long source, long target, float weight) {
    assert source < this.graph.size() && target < this.graph.size();
    ((LongFloatHashMap)this.graph.putIfAbsent(source, LongFloatHashMap::new)).addTo(target, weight);
    ((LongFloatHashMap)this.graph.putIfAbsent(target, LongFloatHashMap::new)).addTo(source, weight);
  }


  
  public long nodeCount() { return this.nodeCount; }


  
  void forEach(long nodeId, RelationshipWithPropertyConsumer consumer) {
    LongFloatHashMap targets = (LongFloatHashMap)this.graph.get(nodeId);
    if (targets != null) {
      for (LongFloatCursor cursor : targets) {
        if (!consumer.accept(nodeId, cursor.key, cursor.value)) {
          return;
        }
      } 
    }
  }

  
  int degree(long nodeId) {
    assert nodeId < this.graph.size();
    LongFloatHashMap targets = (LongFloatHashMap)this.graph.get(nodeId);
    return (null == targets) ? 0 : targets.size();
  }

  
  public void release() {
    this.tracker.remove(this.graph.release());
    this.graph = null;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\louvain\LongLongSubGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */