package org.neo4j.graphalgo.impl.louvain;

import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.AlgorithmFactory;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.core.ProcedureConfiguration;
import org.neo4j.graphalgo.core.utils.Pools;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.mem.MemoryRange;
import org.neo4j.graphalgo.core.utils.mem.MemoryUsage;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeDoubleArray;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;
import org.neo4j.logging.Log;





















public class LouvainFactory
  extends AlgorithmFactory<Louvain>
{
  private Louvain.Config config;
  
  public LouvainFactory(Louvain.Config config) { this.config = config; }









  
  public Louvain build(Graph graph, ProcedureConfiguration configuration, AllocationTracker tracker, Log log) {
    NodeProperties communityMap = (NodeProperties)this.config.maybeSeedPropertyKey.map(graph::nodeProperties).orElse(null);
    
    return new Louvain(graph, this.config, communityMap, Pools.DEFAULT, configuration


        
        .getConcurrency(), tracker);
  }


  
  public MemoryEstimation memoryEstimation() {
    int maxLevel = this.config.maxLevel;
    return MemoryEstimations.builder(Louvain.class)
      .field("Config", Louvain.Config.class)
      .perNode("communities", HugeLongArray::memoryEstimation)
      .perNode("nodeWeights", HugeDoubleArray::memoryEstimation)
      .rangePerNode("dendrogram", nodeCount -> {
          long communityArraySize = HugeLongArray.memoryEstimation(nodeCount);
          
          MemoryRange innerCommunities = MemoryRange.of(communityArraySize, communityArraySize * maxLevel);


          
          MemoryRange communityArrayLength = MemoryRange.of(MemoryUsage.sizeOfObjectArray(1), MemoryUsage.sizeOfObjectArray(maxLevel));
          
          return innerCommunities.add(communityArrayLength);
        
        }).fixed("modularities", MemoryRange.of(MemoryUsage.sizeOfDoubleArray(1), MemoryUsage.sizeOfDoubleArray(maxLevel)))
      .add("modularityOptimization", ModularityOptimization.memoryEstimation())
      .build();
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\louvain\LouvainFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */