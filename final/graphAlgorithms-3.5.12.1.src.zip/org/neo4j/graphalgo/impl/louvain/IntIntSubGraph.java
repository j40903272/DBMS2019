package org.neo4j.graphalgo.impl.louvain;

import com.carrotsearch.hppc.IntFloatHashMap;
import com.carrotsearch.hppc.cursors.IntFloatCursor;
import org.neo4j.graphalgo.api.RelationshipWithPropertyConsumer;



















final class IntIntSubGraph
  extends SubGraph
{
  private IntFloatHashMap[] graph;
  private final int communityCount;
  
  IntIntSubGraph(int communityCount, boolean hasRelationshipProperty) {
    super(hasRelationshipProperty);
    this.graph = new IntFloatHashMap[communityCount];
    this.communityCount = communityCount;
  }
  
  void add(int source, int target, float weight) {
    assert source < this.graph.length && target < this.graph.length;
    putIfAbsent(source).addTo(target, weight);
    putIfAbsent(target).addTo(source, weight);
  }


  
  public long nodeCount() { return this.communityCount; }


  
  void forEach(long nodeId, RelationshipWithPropertyConsumer consumer) {
    assert nodeId < this.graph.length;
    IntFloatHashMap targets = this.graph[(int)nodeId];
    if (targets != null) {
      for (IntFloatCursor cursor : targets) {
        if (!consumer.accept(nodeId, cursor.key, cursor.value)) {
          return;
        }
      } 
    }
  }

  
  int degree(long nodeId) {
    assert nodeId < this.graph.length;
    IntFloatHashMap targets = this.graph[(int)nodeId];
    return (null == targets) ? 0 : targets.size();
  }


  
  public void release() { this.graph = null; }

  
  private IntFloatHashMap putIfAbsent(int communityId) {
    IntFloatHashMap targets = this.graph[communityId];
    if (null == targets) {
      targets = new IntFloatHashMap();
      this.graph[communityId] = targets;
    } 
    return targets;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\louvain\IntIntSubGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */