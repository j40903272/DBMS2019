package org.neo4j.graphalgo.impl.louvain;

import java.util.Collection;
import java.util.Set;
import java.util.function.LongPredicate;
import org.neo4j.collection.primitive.PrimitiveLongIterable;
import org.neo4j.collection.primitive.PrimitiveLongIterator;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.api.RelationshipConsumer;
import org.neo4j.graphalgo.api.RelationshipIntersect;
import org.neo4j.graphalgo.api.RelationshipWithPropertyConsumer;
import org.neo4j.graphalgo.core.utils.LazyBatchCollection;
import org.neo4j.graphdb.Direction;





















abstract class SubGraph
  implements Graph
{
  private final boolean hasRelationshipProperty;
  
  protected SubGraph(boolean hasRelationshipProperty) { this.hasRelationshipProperty = hasRelationshipProperty; }

  
  abstract int degree(long paramLong);

  
  public final int degree(long nodeId, Direction direction) { return degree(nodeId); }




  
  abstract void forEach(long paramLong, RelationshipWithPropertyConsumer paramRelationshipWithPropertyConsumer);



  
  public final void forEachRelationship(long nodeId, Direction direction, double fallbackValue, RelationshipWithPropertyConsumer consumer) { forEach(nodeId, consumer); }


  
  public final Collection<PrimitiveLongIterable> batchIterables(int batchSize) {
    return LazyBatchCollection.of(
        nodeCount(), batchSize, org.neo4j.graphalgo.core.loading.IdMap.IdIterable::new);
  }




  
  public long relationshipCount() { return -1L; }



  
  public boolean hasRelationshipProperty() { return this.hasRelationshipProperty; }



  
  public final void forEachRelationship(long nodeId, Direction direction, RelationshipConsumer consumer) { throw new UnsupportedOperationException("forEachRelationship is not supported."); }



  
  public Direction getLoadDirection() { throw new UnsupportedOperationException("getLoadDirection is not supported."); }



  
  public boolean isUndirected() { throw new UnsupportedOperationException("isUndirected is not supported."); }



  
  public final double relationshipProperty(long sourceNodeId, long targetNodeId, double fallbackValue) { throw new UnsupportedOperationException("relationshipProperty is not supported."); }



  
  public double relationshipProperty(long sourceNodeId, long targetNodeId) { throw new UnsupportedOperationException("relationshipProperty is not implemented."); }



  
  public final boolean contains(long nodeId) { throw new UnsupportedOperationException("contains is not supported."); }



  
  public final RelationshipIntersect intersection() { throw new UnsupportedOperationException("intersection is not supported."); }



  
  public final long toMappedNodeId(long nodeId) { throw new UnsupportedOperationException("toMappedNodeId is not supported."); }



  
  public final long toOriginalNodeId(long nodeId) { throw new UnsupportedOperationException("toOriginalNodeId is not supported."); }



  
  public final void forEachNode(LongPredicate consumer) { throw new UnsupportedOperationException("forEachNode is not supported."); }



  
  public final PrimitiveLongIterator nodeIterator() { throw new UnsupportedOperationException("nodeIterator is not supported."); }



  
  public final NodeProperties nodeProperties(String type) { throw new UnsupportedOperationException("nodeProperties is not supported."); }



  
  public final long getTarget(long nodeId, long index, Direction direction) { throw new UnsupportedOperationException("getTarget is not supported."); }



  
  public final boolean exists(long sourceNodeId, long targetNodeId, Direction direction) { throw new UnsupportedOperationException("exists is not supported."); }



  
  public final Set<String> availableNodeProperties() { throw new UnsupportedOperationException("availableNodeProperties is not supported."); }



  
  public final String getType() { throw new UnsupportedOperationException("getType is not supported."); }



  
  public final void canRelease(boolean canRelease) { throw new UnsupportedOperationException("canRelease is not supported."); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\louvain\SubGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */