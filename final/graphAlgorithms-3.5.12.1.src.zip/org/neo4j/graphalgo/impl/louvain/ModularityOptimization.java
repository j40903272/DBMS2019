package org.neo4j.graphalgo.impl.louvain;

import com.carrotsearch.hppc.LongDoubleHashMap;
import com.carrotsearch.hppc.LongDoubleMap;
import com.carrotsearch.hppc.cursors.LongDoubleCursor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.LongPredicate;
import org.apache.commons.lang3.mutable.MutableDouble;
import org.neo4j.collection.primitive.PrimitiveLongCollections;
import org.neo4j.collection.primitive.PrimitiveLongIterator;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.NodeIterator;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.utils.ParallelUtil;
import org.neo4j.graphalgo.core.utils.Pointer;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimation;
import org.neo4j.graphalgo.core.utils.mem.MemoryEstimations;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeDoubleArray;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;
import org.neo4j.graphdb.Direction;

































public final class ModularityOptimization
  extends Algorithm<ModularityOptimization>
{
  private static final MemoryEstimation MEMORY_ESTIMATION_TASK = MemoryEstimations.builder(Task.class)
    .perNode("sTot", HugeDoubleArray::memoryEstimation)
    .perNode("sIn", HugeDoubleArray::memoryEstimation)
    .perNode("localCommunities", HugeLongArray::memoryEstimation)
    .build();

  
  private static final MemoryEstimation MEMORY_ESTIMATION = MemoryEstimations.builder(ModularityOptimization.class)
    .perNode("communities", HugeLongArray::memoryEstimation)
    .perNode("ki", HugeDoubleArray::memoryEstimation)
    .perThread("tasks", MEMORY_ESTIMATION_TASK)
    .build();

  
  private static final double MINIMUM_MODULARITY = -1.0D;

  
  private static final Direction DIRECTION = Direction.OUTGOING; private static final int NONE = -1;
  private final long nodeCount;
  private final int concurrency;
  private final AllocationTracker tracker;
  private final NodeProperties nodeProperties;
  private Graph graph;
  private ExecutorService pool;
  private final NodeIterator nodeIterator;
  private double sumOfAllWeights;
  private double sumOfAllWeightsSquared;
  private HugeLongArray communities;
  private HugeDoubleArray summedAdjacencyWeights;
  private int iterations;
  private double q = -1.0D;
  private final AtomicInteger counter = new AtomicInteger(0);

  
  public static MemoryEstimation memoryEstimation() { return MEMORY_ESTIMATION; }






  
  ModularityOptimization(Graph graph, NodeProperties nodeProperties, ExecutorService pool, int concurrency, AllocationTracker tracker) {
    this.graph = graph;
    this.nodeProperties = nodeProperties;
    this.nodeCount = graph.nodeCount();
    this.pool = pool;
    this.concurrency = concurrency;
    this.tracker = tracker;
    this.nodeIterator = createNodeIterator(concurrency);
    
    this.summedAdjacencyWeights = HugeDoubleArray.newArray(this.nodeCount, tracker);
    this.communities = HugeLongArray.newArray(this.nodeCount, tracker);
  }










  
  private NodeIterator createNodeIterator(int concurrency) {
    if (concurrency > 1) {
      return new RandomNodeIterator(this.nodeCount);
    }
    
    return new NodeIterator()
      {
        public void forEachNode(LongPredicate consumer) {
          for (long i = 0L; i < ModularityOptimization.this.nodeCount; i++) {
            if (!consumer.test(i)) {
              return;
            }
          } 
        }


        
        public PrimitiveLongIterator nodeIterator() { return PrimitiveLongCollections.range(0L, ModularityOptimization.this.nodeCount); }
      };
  }







  
  private static Task best(Iterable<Task> tasks) {
    Task best = null;
    double q = -1.0D;
    for (Task task : tasks) {
      if (!task.improvement) {
        continue;
      }
      double modularity = task.getModularity();
      if (modularity > q) {
        q = modularity;
        best = task;
      } 
    } 
    return best;
  }
  
  private void init() {
    this.sumOfAllWeights = 0.0D;
    for (int node = 0; node < this.nodeCount; node++) {
      
      this.graph.forEachRelationship(node, DIRECTION, 1.0D, (s, t, w) -> {
            this.sumOfAllWeights += w;
            this.summedAdjacencyWeights.addTo(s, w / 2.0D);
            this.summedAdjacencyWeights.addTo(t, w / 2.0D);
            return true;
          });
    } 
    this.sumOfAllWeightsSquared = Math.pow(this.sumOfAllWeights, 2.0D);
    this.communities.setAll(i -> i);
  }






  
  public ModularityOptimization compute(int maxIterations) {
    TerminationFlag terminationFlag = getTerminationFlag();
    
    init();
    
    Collection<Task> tasks = new ArrayList<>();
    for (int i = 0; i < this.concurrency; i++) {
      tasks.add(new Task());
    }
    
    for (this.iterations = 0; this.iterations < maxIterations; this.iterations++) {
      
      this.counter.set(0);
      
      ParallelUtil.runWithConcurrency(this.concurrency, tasks, terminationFlag, this.pool);
      
      Task candidate = best(tasks);
      if (null == candidate || candidate.q <= this.q) {
        break;
      }

      
      this.q = candidate.q;
      
      sync(candidate, tasks);
    } 
    return this;
  }




  
  private void sync(Task parent, Iterable<Task> tasks) {
    for (Task task : tasks) {
      task.improvement = false;
      if (task == parent) {
        continue;
      }
      task.sync(parent);
    } 
    parent.localCommunities.copyTo(this.communities, this.nodeCount);
  }






  
  HugeLongArray getCommunityIds() { return this.communities; }







  
  public int getIterations() { return this.iterations; }


  
  double getModularity() { return this.q; }






  
  public ModularityOptimization me() { return this; }





  
  public void release() {
    this.tracker.remove(this.summedAdjacencyWeights.release());
    this.summedAdjacencyWeights = null;
    this.tracker.remove(this.communities.release());
    this.communities = null;
    this.graph = null;
    this.pool = null;
  }

  
  private final class Task
    implements Runnable
  {
    final HugeDoubleArray communityTotalWeights;
    final HugeDoubleArray communityInternalWeights;
    final HugeLongArray localCommunities;
    final RelationshipIterator rels;
    private final TerminationFlag terminationFlag;
    double q = -1.0D;

    
    boolean improvement = false;


    
    Task() {
      this.terminationFlag = ModularityOptimization.this.getTerminationFlag();
      this.communityTotalWeights = HugeDoubleArray.newArray(ModularityOptimization.this.nodeCount, ModularityOptimization.this.tracker);
      this.communityInternalWeights = HugeDoubleArray.newArray(ModularityOptimization.this.nodeCount, ModularityOptimization.this.tracker);
      this.localCommunities = HugeLongArray.newArray(ModularityOptimization.this.nodeCount, ModularityOptimization.this.tracker);
      this.rels = ModularityOptimization.this.graph.concurrentCopy();
      ModularityOptimization.this.summedAdjacencyWeights.copyTo(this.communityTotalWeights, ModularityOptimization.this.nodeCount);
      ModularityOptimization.this.communities.copyTo(this.localCommunities, ModularityOptimization.this.nodeCount);
    }

    
    public MemoryEstimation memoryEstimation() { return MEMORY_ESTIMATION_TASK; }





    
    void sync(Task parent) {
      parent.localCommunities.copyTo(this.localCommunities, ModularityOptimization.this.nodeCount);
      parent.communityTotalWeights.copyTo(this.communityTotalWeights, ModularityOptimization.this.nodeCount);
      parent.communityInternalWeights.copyTo(this.communityInternalWeights, ModularityOptimization.this.nodeCount);
      this.q = parent.q;
    }

    
    public void run() {
      ProgressLogger progressLogger = ModularityOptimization.this.getProgressLogger();
      long denominator = ModularityOptimization.this.nodeCount * ModularityOptimization.this.concurrency;
      this.improvement = false;
      ModularityOptimization.this.nodeIterator.forEachNode(node -> {
            boolean move = move(node, this.localCommunities);
            this.improvement |= move;
            long count;
            if ((count = ModularityOptimization.this.counter.incrementAndGet()) % 10000L == 0L) {
              progressLogger.logProgress(count, denominator, ());


              
              this.terminationFlag.assertRunning();
            } 
            return true;
          });
      this.q = calcModularity();
    }




    
    double getModularity() { return this.q; }









    
    private boolean move(long node, HugeLongArray localCommunities) {
      long currentCommunity = localCommunities.get(node);
      
      double summedAdjacencyWeight = ModularityOptimization.this.summedAdjacencyWeights.get(node);

      
      this.communityTotalWeights.addTo(currentCommunity, -summedAdjacencyWeight);
      
      int degree = ModularityOptimization.this.graph.degree(node, DIRECTION);
      LongDoubleHashMap longDoubleHashMap = new LongDoubleHashMap(degree);
      MutableDouble selfRelationshipWeight = new MutableDouble(0.0D);
      this.rels.forEachRelationship(node, DIRECTION, 1.0D, (s, t, weight) -> {
            long targetCommunity = localCommunities.get(t);
            if (s != t) {
              communityWeights.addTo(targetCommunity, weight);
            } else {
              selfRelationshipWeight.add(weight);
            } 
            return true;
          });
      
      double initialWeight = longDoubleHashMap.get(currentCommunity) + selfRelationshipWeight.doubleValue();

      
      this.communityInternalWeights.addTo(currentCommunity, -2.0D * (initialWeight + ModularityOptimization.this.nodeProperties.nodeProperty(node)));
      
      localCommunities.set(node, -1L);
      double bestGain = 0.0D;
      double bestWeight = initialWeight;
      long bestCommunity = currentCommunity;
      
      if (!longDoubleHashMap.isEmpty()) {
        for (LongDoubleCursor cursor : longDoubleHashMap) {
          long community = cursor.key;
          double summedWeight = cursor.value;
          double gain = summedWeight / ModularityOptimization.this.sumOfAllWeights - this.communityTotalWeights.get(community) * summedAdjacencyWeight / ModularityOptimization.this.sumOfAllWeightsSquared;
          if (gain > bestGain) {
            bestGain = gain;
            bestCommunity = community;
            bestWeight = summedWeight; continue;
          }  if (gain == bestGain && 
            community < bestCommunity) {
            bestCommunity = community;
            bestWeight = summedWeight;
          } 
        } 
      }


      
      this.communityTotalWeights.addTo(bestCommunity, summedAdjacencyWeight);

      
      this.communityInternalWeights.addTo(bestCommunity, 2.0D * (bestWeight + ModularityOptimization.this.nodeProperties.nodeProperty(node)));
      localCommunities.set(node, bestCommunity);
      return (bestCommunity != currentCommunity);
    }
    
    private double calcModularity() {
      Pointer.DoublePointer pointer = Pointer.wrap(0.0D);
      for (long node = 0L; node < ModularityOptimization.this.nodeCount; node++) {
        this.rels.forEachRelationship(node, Direction.OUTGOING, 1.0D, (s, t, w) -> {
              if (this.localCommunities.get(s) == this.localCommunities.get(t)) {
                pointer.v += w - ModularityOptimization.this.summedAdjacencyWeights.get(s) * ModularityOptimization.this.summedAdjacencyWeights.get(t) / ModularityOptimization.this.sumOfAllWeights;
              }
              return true;
            });
      } 
      return pointer.v / ModularityOptimization.this.sumOfAllWeights;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\louvain\ModularityOptimization.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */