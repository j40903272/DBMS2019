package org.neo4j.graphalgo.impl.louvain;

import com.carrotsearch.hppc.BitSet;
import com.carrotsearch.hppc.DoubleArrayList;
import com.carrotsearch.hppc.ObjectArrayList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.stream.LongStream;
import java.util.stream.Stream;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.Graph;
import org.neo4j.graphalgo.api.NodeProperties;
import org.neo4j.graphalgo.core.utils.CommunityUtils;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.TerminationFlag;
import org.neo4j.graphalgo.core.utils.paged.AllocationTracker;
import org.neo4j.graphalgo.core.utils.paged.HugeCursor;
import org.neo4j.graphalgo.core.utils.paged.HugeDoubleArray;
import org.neo4j.graphalgo.core.utils.paged.HugeLongArray;
import org.neo4j.graphalgo.core.write.Exporter;
import org.neo4j.graphalgo.core.write.PropertyTranslator;
import org.neo4j.graphdb.Direction;
import org.neo4j.values.storable.Value;
import org.neo4j.values.storable.Values;


































public final class Louvain
  extends Algorithm<Louvain>
{
  public static final double DEFAULT_WEIGHT = 1.0D;
  public static final boolean DEFAULT_INTERMEDIATE_COMMUNITIES_FLAG = false;
  private static final PropertyTranslator<HugeLongArray[]> HUGE_COMMUNITIES_TRANSLATOR = (propertyId, allCommunities, nodeId) -> {
      long[] data = new long[allCommunities.length];
      for (int i = 0; i < data.length; i++) {
        data[i] = allCommunities[i].get(nodeId);
      }
      return (Value)Values.longArray(data);
    };
  
  private final long rootNodeCount;
  
  private int level;
  
  private final ExecutorService pool;
  
  private final int concurrency;
  
  private final AllocationTracker tracker;
  
  private ProgressLogger progressLogger;
  
  private TerminationFlag terminationFlag;
  private HugeLongArray communities;
  private double[] modularities;
  private HugeLongArray[] dendrogram;
  private final HugeDoubleArray nodeWeights;
  private final NodeProperties seedingValues;
  private final Graph rootGraph;
  private long communityCount;
  private final Config config;
  private static final int MAX_MAP_ENTRIES = 1610612736;
  
  public Louvain(Graph graph, Config config, ExecutorService pool, int concurrency, AllocationTracker tracker) { this(graph, config, null, pool, concurrency, tracker); }








  
  public Louvain(Graph graph, Config config, NodeProperties seedingValues, ExecutorService pool, int concurrency, AllocationTracker tracker) {
    this.rootGraph = graph;
    this.pool = pool;
    this.concurrency = concurrency;
    this.tracker = tracker;
    this.rootNodeCount = graph.nodeCount();
    this.communities = HugeLongArray.newArray(this.rootNodeCount, tracker);
    this.nodeWeights = HugeDoubleArray.newArray(this.rootNodeCount, tracker);
    this.seedingValues = seedingValues;
    this.config = config;
    this.communityCount = this.rootNodeCount;
  }

  
  public Louvain compute() { return compute(this.config); }


  
  public Louvain compute(int maxLevel, int maxIterations) { return compute(new Config(maxLevel, maxIterations, Optional.empty())); }


  
  public Louvain compute(Config config) {
    long nodeCount;
    Graph workingGraph;
    if (this.seedingValues != null) {
      BitSet comCount = new BitSet();

      
      long maxSeedingCommunityId = this.seedingValues.getMaxPropertyValue().orElse(-1L);
      this.communities.setAll(nodeId -> {
            double existingCommunityValue = this.seedingValues.nodeProperty(nodeId, NaND);
            
            long community = Double.isNaN(existingCommunityValue) ? (maxSeedingCommunityId + this.rootGraph.toOriginalNodeId(nodeId) + 1L) : (long)existingCommunityValue;

            
            comCount.set(community);
            return community;
          });
      
      nodeCount = comCount.cardinality();
      CommunityUtils.normalize(this.communities);
      workingGraph = rebuildGraph(this.rootGraph, this.communities, nodeCount);
    } else {
      this.communities.setAll(this.rootGraph::toOriginalNodeId);
      
      nodeCount = this.communities.size();
      CommunityUtils.normalize(this.communities);
      workingGraph = rebuildGraph(this.rootGraph, this.communities, nodeCount);
    } 
    
    return computeOf(workingGraph, nodeCount, config);
  }






  
  private Louvain computeOf(Graph rootGraph, long rootNodeCount, Config config) {
    ObjectArrayList<HugeLongArray> dendrogram = new ObjectArrayList(0);
    DoubleArrayList modularities = new DoubleArrayList(0);
    long communityCount = this.communityCount;
    long nodeCount = rootNodeCount;
    Graph louvainGraph = rootGraph;
    
    for (int level = 0; level < config.maxLevel; level++) {
      assertRunning();










      
      ModularityOptimization modularityOptimization = ((ModularityOptimization)((ModularityOptimization)(new ModularityOptimization(louvainGraph, this.nodeWeights::get, this.pool, this.concurrency, this.tracker)).withProgressLogger(this.progressLogger)).withTerminationFlag(this.terminationFlag)).compute(config.maxIterations);
      
      HugeLongArray communityIds = modularityOptimization.getCommunityIds();
      communityCount = CommunityUtils.normalize(communityIds);
      if (communityCount >= nodeCount) {
        
        modularityOptimization.release();
        break;
      } 
      nodeCount = communityCount;
      rebuildCommunityStructure(communityIds);
      if (config.includeIntermediateCommunities)
      {
        
        dendrogram.add(this.communities.copyOf(rootNodeCount, this.tracker));
      }
      modularities.add(modularityOptimization.getModularity());
      louvainGraph = rebuildGraph(louvainGraph, communityIds, communityCount);
      
      modularityOptimization.release();
    } 
    this.dendrogram = (HugeLongArray[])dendrogram.toArray(HugeLongArray.class);
    this.modularities = modularities.toArray();
    this.level = modularities.elementsCount;
    this.communityCount = communityCount;
    return this;
  }










  
  private Graph rebuildGraph(Graph louvainGraph, HugeLongArray communityIds, long communityCount) {
    if (communityCount < 1610612736L) {
      return rebuildSmallerGraph(louvainGraph, communityIds, (int)communityCount);
    }
    
    HugeDoubleArray nodeWeights = this.nodeWeights;



    
    LongLongSubGraph subGraph = new LongLongSubGraph(communityCount, louvainGraph.hasRelationshipProperty(), this.tracker);



    
    HugeCursor<long[]> cursor = communityIds.initCursor(communityIds.newCursor());
    while (cursor.next()) {
      long[] communities = (long[])cursor.array;
      int start = cursor.offset;
      int end = cursor.limit;
      long base = cursor.base;
      
      while (start < end) {
        
        long sourceCommunity = communities[start];

        
        louvainGraph.forEachRelationship(base + start, Direction.OUTGOING, 1.0D, (s, t, w) -> {
              
              long targetCommunity = communityIds.get(t);
              if (sourceCommunity == targetCommunity) {
                nodeWeights.addTo(sourceCommunity, w);
              }

              
              subGraph.add(sourceCommunity, targetCommunity, (float)(w / 2.0D));
              return true;
            });
        
        start++;
      } 
    } 
    
    if (louvainGraph instanceof SubGraph) {
      louvainGraph.release();
    }

    
    return subGraph;
  }




  
  private Graph rebuildSmallerGraph(Graph louvainGraph, HugeLongArray communityIds, int communityCount) {
    HugeDoubleArray nodeWeights = this.nodeWeights;

    
    IntIntSubGraph subGraph = new IntIntSubGraph(communityCount, louvainGraph.hasRelationshipProperty());

    
    HugeCursor<long[]> cursor = communityIds.initCursor(communityIds.newCursor());
    while (cursor.next()) {
      long[] communities = (long[])cursor.array;
      int start = cursor.offset;
      int end = cursor.limit;
      long base = cursor.base;
      
      while (start < end) {
        
        int sourceCommunity = (int)communities[start];

        
        louvainGraph.forEachRelationship(base + start, Direction.OUTGOING, 1.0D, (s, t, value) -> {
              
              int targetCommunity = (int)communityIds.get(t);
              if (sourceCommunity == targetCommunity) {
                nodeWeights.addTo(sourceCommunity, value);
              }

              
              subGraph.add(sourceCommunity, targetCommunity, (float)(value / 2.0D));
              return true;
            });
        
        start++;
      } 
    } 
    
    if (louvainGraph instanceof SubGraph) {
      louvainGraph.release();
    }

    
    return subGraph;
  }
  
  private void rebuildCommunityStructure(HugeLongArray communityIds) {
    try (HugeCursor<long[]> cursor = this.communities.initCursor(this.communities.newCursor())) {
      while (cursor.next()) {
        long[] arrayRef = (long[])cursor.array;
        int limit = Math.min(cursor.limit, arrayRef.length);
        for (int i = cursor.offset; i < limit; i++) {
          arrayRef[i] = communityIds.get(arrayRef[i]);
        }
      } 
    } 
  }






  
  public HugeLongArray getCommunityIds() { return this.communities; }


  
  public HugeLongArray[] getDendrogram() { return this.dendrogram; }


  
  public double[] getModularities() { return Arrays.copyOfRange(this.modularities, 0, this.level); }

  
  public Config getConfig() { return this.config; }






  
  public int getLevel() { return this.level; }







  
  public long communityCount() { return this.communityCount; }


  
  public long communityIdOf(long node) { return this.communities.get(node); }







  
  public Stream<Result> resultStream() { return LongStream.range(0L, this.rootNodeCount)
      .mapToObj(i -> new Result(i, this.communities.get(i))); }

  
  public Stream<StreamingResult> dendrogramStream() {
    return LongStream.range(0L, this.rootNodeCount)
      .mapToObj(i -> {
          List<Long> communitiesList = null;
          if (this.config.includeIntermediateCommunities) {
            communitiesList = new ArrayList<>(this.dendrogram.length);
            for (HugeLongArray community : this.dendrogram) {
              communitiesList.add(Long.valueOf(community.get(i)));
            }
          } 
          
          return new StreamingResult(this.rootGraph.toOriginalNodeId(i), communitiesList, this.communities.get(i));
        });
  }




  
  public void export(Exporter exporter, String propertyName, String intermediateCommunitiesPropertyName) {
    if (this.config.includeIntermediateCommunities) {
      exporter.write(propertyName, this.communities, (PropertyTranslator)HugeLongArray.Translator.INSTANCE, intermediateCommunitiesPropertyName, this.dendrogram, HUGE_COMMUNITIES_TRANSLATOR);


    
    }
    else {


      
      exporter.write(propertyName, this.communities, (PropertyTranslator)HugeLongArray.Translator.INSTANCE);
    } 
  }





  
  public void release() {
    this.tracker.remove(this.communities.release());
    this.communities = null;
  }

  
  public Louvain withProgressLogger(ProgressLogger progressLogger) {
    this.progressLogger = progressLogger;
    return this;
  }

  
  public Louvain withTerminationFlag(TerminationFlag terminationFlag) {
    this.terminationFlag = terminationFlag;
    return this;
  }
  
  public double getFinalModularity() {
    double[] modularities = getModularities();
    return (modularities.length > 0) ? modularities[modularities.length - 1] : 0.0D;
  }


  
  public Louvain me() { return this; }


  
  public static final class Result
  {
    public final long nodeId;
    
    public final long community;

    
    public Result(long id, long community) {
      this.nodeId = id;
      this.community = community;
    }
  }
  
  public static final class StreamingResult {
    public final long nodeId;
    public final List<Long> communities;
    public final long community;
    
    StreamingResult(long nodeId, List<Long> communities, long community) {
      this.nodeId = nodeId;
      this.communities = communities;
      this.community = community;
    }
  }

  
  public static class Config
  {
    public final Optional<String> maybeSeedPropertyKey;
    public final int maxLevel;
    public final int maxIterations;
    public final boolean includeIntermediateCommunities;
    
    public Config(int maxLevel) { this(maxLevel, maxLevel, Optional.empty()); }






    
    public Config(int maxLevel, int maxIterations, Optional<String> maybeSeedPropertyKey) { this(maxIterations, maxLevel, maybeSeedPropertyKey, false); }






    
    public Config(int maxIterations, int maxLevel, Optional<String> maybeSeedPropertyKey, boolean includeIntermediateCommunities) {
      this.maybeSeedPropertyKey = maybeSeedPropertyKey;
      this.maxLevel = maxLevel;
      this.maxIterations = maxIterations;
      this.includeIntermediateCommunities = includeIntermediateCommunities;
    }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\louvain\Louvain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */