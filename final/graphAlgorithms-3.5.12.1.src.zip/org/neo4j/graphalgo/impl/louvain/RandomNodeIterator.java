package org.neo4j.graphalgo.impl.louvain;

import java.util.Random;
import java.util.function.LongPredicate;
import org.neo4j.collection.primitive.PrimitiveLongIterator;
import org.neo4j.graphalgo.api.NodeIterator;
import org.neo4j.graphalgo.core.utils.RandomLongIterator;
























public class RandomNodeIterator
  implements NodeIterator
{
  private final long nodeCount;
  
  public RandomNodeIterator(long nodeCount) { this.nodeCount = nodeCount; }


  
  public void forEachNode(LongPredicate consumer) {
    PrimitiveLongIterator nodeIterator = nodeIterator(); do {  }
    while (nodeIterator.hasNext() && 
      consumer.test(nodeIterator.next()));
  }





  
  public PrimitiveLongIterator nodeIterator() { return (PrimitiveLongIterator)new RandomLongIterator(this.nodeCount, new Random(System.currentTimeMillis())); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\louvain\RandomNodeIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */