package org.neo4j.graphalgo.impl.spanningTrees;

import com.carrotsearch.hppc.IntDoubleMap;
import com.carrotsearch.hppc.IntDoubleScatterMap;
import java.util.Arrays;
import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.core.heavyweight.Converters;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.container.SimpleBitSet;
import org.neo4j.graphalgo.core.utils.queue.SharedIntPriorityQueue;
import org.neo4j.graphalgo.results.AbstractResultBuilder;
import org.neo4j.graphdb.Direction;




































public class Prim
  extends Algorithm<Prim>
{
  private final RelationshipIterator relationshipIterator;
  private final int nodeCount;
  private SpanningTree spanningTree;
  
  public Prim(IdMapping idMapping, RelationshipIterator relationshipIterator) {
    this.relationshipIterator = relationshipIterator;
    this.nodeCount = Math.toIntExact(idMapping.nodeCount());
  }
  
  public Prim computeMaximumSpanningTree(int startNode) {
    this.spanningTree = prim(startNode, true);
    return this;
  }
  
  public Prim computeMinimumSpanningTree(int startNode) {
    this.spanningTree = prim(startNode, false);
    return this;
  }






  
  private SpanningTree prim(int startNode, boolean max) {
    int[] parent = new int[this.nodeCount];
    IntDoubleScatterMap intDoubleScatterMap = new IntDoubleScatterMap(this.nodeCount);
    SharedIntPriorityQueue queue = SharedIntPriorityQueue.min(this.nodeCount, (IntDoubleMap)intDoubleScatterMap, Double.MAX_VALUE);


    
    ProgressLogger logger = getProgressLogger();
    SimpleBitSet visited = new SimpleBitSet(this.nodeCount);
    Arrays.fill(parent, -1);
    intDoubleScatterMap.put(startNode, 0.0D);
    queue.add(startNode, -1.0D);
    int effectiveNodeCount = 0;
    while (!queue.isEmpty() && running()) {
      int node = queue.pop();
      if (visited.contains(node)) {
        continue;
      }
      effectiveNodeCount++;
      visited.put(node);
      this.relationshipIterator.forEachRelationship(node, Direction.OUTGOING, 0.0D, Converters.longToIntConsumer((s, t, w) -> {
              if (visited.contains(t)) {
                return true;
              }
              
              double weight = max ? -w : w;
              if (weight < cost.getOrDefault(t, Double.MAX_VALUE)) {
                if (cost.containsKey(t)) {
                  cost.put(t, weight);
                  queue.update(t);
                } else {
                  cost.put(t, weight);
                  queue.add(t, -1.0D);
                } 
                parent[t] = s;
              } 
              return true;
            }));
      logger.logProgress(effectiveNodeCount, (this.nodeCount - 1));
    } 
    return new SpanningTree(startNode, this.nodeCount, effectiveNodeCount, parent);
  }

  
  public SpanningTree getSpanningTree() { return this.spanningTree; }



  
  public Prim me() { return this; }



  
  public void release() { this.spanningTree = null; }

  
  public static class Result
  {
    public final long loadMillis;
    
    public final long computeMillis;
    
    public final long writeMillis;
    
    public final long effectiveNodeCount;
    
    public Result(long loadMillis, long computeMillis, long writeMillis, int effectiveNodeCount) {
      this.loadMillis = loadMillis;
      this.computeMillis = computeMillis;
      this.writeMillis = writeMillis;
      this.effectiveNodeCount = effectiveNodeCount;
    }
  }
  
  public static class Builder
    extends AbstractResultBuilder<Result> {
    protected int effectiveNodeCount;
    
    public Builder withEffectiveNodeCount(int effectiveNodeCount) {
      this.effectiveNodeCount = effectiveNodeCount;
      return this;
    }

    
    public Prim.Result build() { return new Prim.Result(this.loadDuration, this.evalDuration, this.writeDuration, this.effectiveNodeCount); }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\spanningTrees\Prim.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */