package org.neo4j.graphalgo.impl.spanningTrees;

import org.neo4j.graphalgo.api.RelationshipConsumer;
import org.neo4j.graphalgo.core.write.PropertyTranslator;























public class SpanningTree
{
  public final int head;
  public final int nodeCount;
  public final int effectiveNodeCount;
  public final int[] parent;
  
  public SpanningTree(int head, int nodeCount, int effectiveNodeCount, int[] parent) {
    this.head = head;
    this.nodeCount = nodeCount;
    this.effectiveNodeCount = effectiveNodeCount;
    this.parent = parent;
  }
  
  public void forEach(RelationshipConsumer consumer) {
    for (int i = 0; i < this.nodeCount; i++) {
      int parent = this.parent[i];
      if (parent != -1)
      {
        
        if (!consumer.accept(parent, i))
          return; 
      }
    } 
  }
  
  public int head(int node) {
    int p = node;
    while (-1 != this.parent[p]) {
      p = this.parent[p];
    }
    return p;
  }
  
  public static final PropertyTranslator<SpanningTree> TRANSLATOR = (PropertyTranslator<SpanningTree>)new SpanningTreeTranslator();
  
  public static class SpanningTreeTranslator
    implements PropertyTranslator.OfInt<SpanningTree>
  {
    public int toInt(SpanningTree data, long nodeId) { return data.head((int)nodeId); }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\spanningTrees\SpanningTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */