package org.neo4j.graphalgo.impl.spanningTrees;

import org.neo4j.graphalgo.Algorithm;
import org.neo4j.graphalgo.api.IdMapping;
import org.neo4j.graphalgo.api.RelationshipIterator;
import org.neo4j.graphalgo.api.RelationshipProperties;
import org.neo4j.graphalgo.core.utils.ProgressLogger;
import org.neo4j.graphalgo.core.utils.queue.IntPriorityQueue;































public class KSpanningTree
  extends Algorithm<KSpanningTree>
{
  private IdMapping idMapping;
  private RelationshipIterator relationshipIterator;
  private RelationshipProperties weights;
  private final int nodeCount;
  private SpanningTree kSpanningTree;
  
  public KSpanningTree(IdMapping idMapping, RelationshipIterator relationshipIterator, RelationshipProperties weights) {
    this.idMapping = idMapping;
    this.relationshipIterator = relationshipIterator;
    this.weights = weights;
    this.nodeCount = Math.toIntExact(idMapping.nodeCount());
  }







  
  public KSpanningTree compute(long startNodeId, long k, boolean max) {
    IntPriorityQueue priorityQueue;
    int startNode = Math.toIntExact(startNodeId);
    
    ProgressLogger logger = getProgressLogger();

    
    Prim prim = (Prim)((Prim)(new Prim(this.idMapping, this.relationshipIterator)).withProgressLogger(getProgressLogger())).withTerminationFlag(getTerminationFlag());

    
    if (max) {
      prim.computeMaximumSpanningTree(startNode);
      priorityQueue = IntPriorityQueue.min();
    } else {
      prim.computeMinimumSpanningTree(startNode);
      priorityQueue = IntPriorityQueue.max();
    } 
    int[] parent = (prim.getSpanningTree()).parent;
    for (int i = 0; i < parent.length && running(); i++) {
      int p = parent[i];
      if (p != -1) {

        
        priorityQueue.add(i, this.weights.relationshipProperty(p, i, 0.0D));
        logger.logProgress(i, this.nodeCount, () -> "reorganization");
      } 
    } 
    for (int i = 0; i < k - 1L && running(); i++) {
      int cutNode = priorityQueue.pop();
      parent[cutNode] = -1;
    } 
    this.kSpanningTree = prim.getSpanningTree();
    return this;
  }

  
  public SpanningTree getSpanningTree() { return this.kSpanningTree; }



  
  public KSpanningTree me() { return this; }


  
  public void release() {
    this.idMapping = null;
    this.relationshipIterator = null;
    this.weights = null;
    this.kSpanningTree = null;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\org\neo4j\graphalgo\impl\spanningTrees\KSpanningTree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */