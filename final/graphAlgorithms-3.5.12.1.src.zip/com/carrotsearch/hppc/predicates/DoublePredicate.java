package com.carrotsearch.hppc.predicates;

public interface DoublePredicate {
  boolean apply(double paramDouble);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\predicates\DoublePredicate.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */