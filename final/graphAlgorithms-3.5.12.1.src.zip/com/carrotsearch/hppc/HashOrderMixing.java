package com.carrotsearch.hppc;

import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.concurrent.Callable;
import java.util.logging.Level;
import java.util.logging.Logger;




public final class HashOrderMixing
{
  public static final String PROPERTY_BIT_MIXER = "hppc.bitmixer";
  private static Strategy strategy;
  
  public enum Strategy
    implements Callable<HashOrderMixingStrategy>
  {
    RANDOM,




    
    DETERMINISTIC,




    
    NONE;
  }










  
  private static final HashOrderMixingStrategy DETERMINISTIC = new HashOrderMixingStrategy()
    {
      public int newKeyMixer(int newContainerBufferSize) {
        return BitMixer.mix32(newContainerBufferSize);
      }


      
      public HashOrderMixingStrategy clone() { return this; }
    };






  
  public static HashOrderMixingStrategy randomized() { return RandomizedHashOrderMixer.INSTANCE; }










  
  public static HashOrderMixingStrategy constant(final long seed) {
    return new HashOrderMixingStrategy()
      {
        public int newKeyMixer(int newContainerBufferSize) {
          return (int)BitMixer.mix64(newContainerBufferSize ^ seed);
        }


        
        public HashOrderMixingStrategy clone() { return this; }
      };
  }












  
  @Deprecated
  public static HashOrderMixingStrategy deterministic() { return DETERMINISTIC; }









  
  @Deprecated
  public static HashOrderMixingStrategy none() {
    return new HashOrderMixingStrategy()
      {
        public int newKeyMixer(int newContainerBufferSize) {
          return 0;
        }


        
        public HashOrderMixingStrategy clone() { return this; }
      };
  }




  
  public static HashOrderMixingStrategy defaultStrategy() {
    if (strategy == null) {
      try {
        String propValue = AccessController.doPrivileged(new PrivilegedAction<String>()
            {
              public String run() {
                return System.getProperty("hppc.bitmixer");
              }
            });
        
        if (propValue != null) {
          for (Strategy s : Strategy.values()) {
            if (s.name().equalsIgnoreCase(propValue)) {
              strategy = s;
              break;
            } 
          } 
        }
      } catch (SecurityException e) {
        
        Logger.getLogger(Containers.class.getName()).log(Level.INFO, "Failed to read 'tests.seed' property for initial random seed.", e);
      } 

      
      if (strategy == null) {
        strategy = Strategy.RANDOM;
      }
    } 
    
    try {
      return strategy.call();
    } catch (Exception e) {
      throw new RuntimeException(e);
    } 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\HashOrderMixing.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */