package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.IntFloatCursor;
import com.carrotsearch.hppc.predicates.IntFloatPredicate;
import com.carrotsearch.hppc.predicates.IntPredicate;
import java.util.Iterator;

public interface IntFloatAssociativeContainer extends Iterable<IntFloatCursor> {
  Iterator<IntFloatCursor> iterator();
  
  boolean containsKey(int paramInt);
  
  int size();
  
  boolean isEmpty();
  
  int removeAll(IntContainer paramIntContainer);
  
  int removeAll(IntPredicate paramIntPredicate);
  
  int removeAll(IntFloatPredicate paramIntFloatPredicate);
  
  <T extends com.carrotsearch.hppc.procedures.IntFloatProcedure> T forEach(T paramT);
  
  <T extends IntFloatPredicate> T forEach(T paramT);
  
  IntCollection keys();
  
  FloatContainer values();
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\IntFloatAssociativeContainer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */