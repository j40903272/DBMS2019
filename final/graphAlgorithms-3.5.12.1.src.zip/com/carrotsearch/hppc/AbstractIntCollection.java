package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.IntCursor;
import com.carrotsearch.hppc.predicates.IntPredicate;
import java.util.Arrays;















abstract class AbstractIntCollection
  implements IntCollection
{
  public int removeAll(final IntLookupContainer c) {
    return removeAll(new IntPredicate()
        {
          public boolean apply(int k) { return c.contains(k); }
        });
  }






  
  public int retainAll(final IntLookupContainer c) {
    return removeAll(new IntPredicate()
        {
          public boolean apply(int k) { return !c.contains(k); }
        });
  }






  
  public int retainAll(final IntPredicate predicate) {
    return removeAll(new IntPredicate()
        {
          public boolean apply(int value) { return !predicate.apply(value); }
        });
  }







  
  public int[] toArray() {
    int[] array = new int[size()];
    int i = 0;
    for (IntCursor c : this) {
      array[i++] = c.value;
    }
    return array;
  }







  
  public String toString() { return Arrays.toString(toArray()); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\AbstractIntCollection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */