package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.IntIntCursor;

public interface IntIntMap extends IntIntAssociativeContainer {
  int get(int paramInt);
  
  int getOrDefault(int paramInt1, int paramInt2);
  
  int put(int paramInt1, int paramInt2);
  
  int putAll(IntIntAssociativeContainer paramIntIntAssociativeContainer);
  
  int putAll(Iterable<? extends IntIntCursor> paramIterable);
  
  int putOrAdd(int paramInt1, int paramInt2, int paramInt3);
  
  int addTo(int paramInt1, int paramInt2);
  
  int remove(int paramInt);
  
  boolean equals(Object paramObject);
  
  int hashCode();
  
  int indexOf(int paramInt);
  
  boolean indexExists(int paramInt);
  
  int indexGet(int paramInt);
  
  int indexReplace(int paramInt1, int paramInt2);
  
  void indexInsert(int paramInt1, int paramInt2, int paramInt3);
  
  void clear();
  
  void release();
  
  String visualizeKeyDistribution(int paramInt);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\IntIntMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */