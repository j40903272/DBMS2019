package com.carrotsearch.hppc;




































public final class BoundedProportionalArraySizingStrategy
  implements ArraySizingStrategy
{
  public static final int MAX_ARRAY_LENGTH = 2147483615;
  public static final int DEFAULT_MIN_GROW_COUNT = 10;
  public static final int DEFAULT_MAX_GROW_COUNT = 2147483615;
  public static final float DEFAULT_GROW_RATIO = 1.5F;
  public final int minGrowCount;
  public final int maxGrowCount;
  public final float growRatio;
  
  public BoundedProportionalArraySizingStrategy() { this(10, 2147483615, 1.5F); }








  
  public BoundedProportionalArraySizingStrategy(int minGrow, int maxGrow, float ratio) {
    assert minGrow >= 1 : "Min grow must be >= 1.";
    assert maxGrow >= minGrow : "Max grow must be >= min grow.";
    assert ratio >= 1.0F : "Growth ratio must be >= 1 (was " + ratio + ").";
    
    this.minGrowCount = minGrow;
    this.maxGrowCount = maxGrow;
    this.growRatio = ratio - 1.0F;
  }









  
  public int grow(int currentBufferLength, int elementsCount, int expectedAdditions) {
    long growBy = (long)((float)currentBufferLength * this.growRatio);
    growBy = Math.max(growBy, this.minGrowCount);
    growBy = Math.min(growBy, this.maxGrowCount);
    long growTo = Math.min(2147483615L, growBy + currentBufferLength);
    long newSize = Math.max(elementsCount + expectedAdditions, growTo);
    
    if (newSize > 2147483615L) {
      throw new BufferAllocationException("Java array size exceeded (current length: %d, elements: %d, expected additions: %d)", new Object[] { Integer.valueOf(currentBufferLength), Integer.valueOf(elementsCount), Integer.valueOf(expectedAdditions) });
    }


    
    return (int)newSize;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\BoundedProportionalArraySizingStrategy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */