package com.carrotsearch.hppc;

import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.logging.Level;
import java.util.logging.Logger;


















public final class Containers
{
  public static final int DEFAULT_EXPECTED_ELEMENTS = 4;
  private static String testsSeedProperty;
  private static final String NOT_AVAILABLE = new String();











  
  @SuppressForbidden
  public static long randomSeed64() {
    long initialSeed;
    if (testsSeedProperty == null) {
      try {
        testsSeedProperty = AccessController.doPrivileged(new PrivilegedAction<String>()
            {
              public String run() {
                return System.getProperty("tests.seed", NOT_AVAILABLE);
              }
            });
      } catch (SecurityException e) {
        
        testsSeedProperty = NOT_AVAILABLE;
        Logger.getLogger(Containers.class.getName()).log(Level.INFO, "Failed to read 'tests.seed' property for initial random seed.", e);
      } 
    }


    
    if (testsSeedProperty != NOT_AVAILABLE) {
      initialSeed = testsSeedProperty.hashCode();
    
    }
    else {
      
      initialSeed = System.nanoTime() ^ System.identityHashCode(new Object());
    } 
    
    return BitMixer.mix64(initialSeed);
  }




  
  static void test$reset() { testsSeedProperty = null; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\Containers.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */