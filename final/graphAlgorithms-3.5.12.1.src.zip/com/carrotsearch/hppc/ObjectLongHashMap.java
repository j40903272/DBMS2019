package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.LongCursor;
import com.carrotsearch.hppc.cursors.ObjectCursor;
import com.carrotsearch.hppc.cursors.ObjectLongCursor;
import com.carrotsearch.hppc.predicates.LongPredicate;
import com.carrotsearch.hppc.predicates.ObjectLongPredicate;
import com.carrotsearch.hppc.predicates.ObjectPredicate;
import com.carrotsearch.hppc.procedures.ObjectLongProcedure;
import com.carrotsearch.hppc.procedures.ObjectProcedure;
import java.util.Arrays;
import java.util.Iterator;






































































public class ObjectLongHashMap<KType>
  implements ObjectLongMap<KType>, Preallocable, Cloneable
{
  public Object[] keys;
  public long[] values;
  protected int keyMixer;
  protected int assigned;
  protected int mask;
  protected int resizeAt;
  protected boolean hasEmptyKey;
  protected double loadFactor;
  protected HashOrderMixingStrategy orderMixer;
  
  public ObjectLongHashMap() { this(4); }









  
  public ObjectLongHashMap(int expectedElements) { this(expectedElements, 0.75D); }












  
  public ObjectLongHashMap(int expectedElements, double loadFactor) { this(expectedElements, loadFactor, HashOrderMixing.defaultStrategy()); }














  
  public ObjectLongHashMap(int expectedElements, double loadFactor, HashOrderMixingStrategy orderMixer) {
    this.orderMixer = orderMixer;
    this.loadFactor = verifyLoadFactor(loadFactor);
    ensureCapacity(expectedElements);
  }



  
  public ObjectLongHashMap(ObjectLongAssociativeContainer<? extends KType> container) {
    this(container.size());
    putAll(container);
  }




  
  public long put(KType key, long value) {
    assert this.assigned < this.mask + 1;
    
    int mask = this.mask;
    if (key == null) {
      this.hasEmptyKey = true;
      long previousValue = this.values[mask + 1];
      this.values[mask + 1] = value;
      return previousValue;
    } 
    KType[] keys = (KType[])this.keys;
    int slot = hashKey(key) & mask;
    
    KType existing;
    while ((existing = keys[slot]) != null) {
      if (equals(existing, key)) {
        long previousValue = this.values[slot];
        this.values[slot] = value;
        return previousValue;
      } 
      slot = slot + 1 & mask;
    } 
    
    if (this.assigned == this.resizeAt) {
      allocateThenInsertThenRehash(slot, key, value);
    } else {
      keys[slot] = key;
      this.values[slot] = value;
    } 
    
    this.assigned++;
    return 0L;
  }





  
  public int putAll(ObjectLongAssociativeContainer<? extends KType> container) {
    int count = size();
    for (ObjectLongCursor<? extends KType> c : container) {
      put((KType)c.key, c.value);
    }
    return size() - count;
  }




  
  public int putAll(Iterable<? extends ObjectLongCursor<? extends KType>> iterable) {
    int count = size();
    for (ObjectLongCursor<? extends KType> c : iterable) {
      put((KType)c.key, c.value);
    }
    return size() - count;
  }












  
  public boolean putIfAbsent(KType key, long value) {
    int keyIndex = indexOf(key);
    if (!indexExists(keyIndex)) {
      indexInsert(keyIndex, key, value);
      return true;
    } 
    return false;
  }
















  
  public long putOrAdd(KType key, long putValue, long incrementValue) {
    assert this.assigned < this.mask + 1;
    
    int keyIndex = indexOf(key);
    if (indexExists(keyIndex)) {
      putValue = this.values[keyIndex] + incrementValue;
      indexReplace(keyIndex, putValue);
    } else {
      indexInsert(keyIndex, key, putValue);
    } 
    return putValue;
  }













  
  public long addTo(KType key, long incrementValue) { return putOrAdd(key, incrementValue, incrementValue); }






  
  public long remove(KType key) {
    int mask = this.mask;
    if (key == null) {
      this.hasEmptyKey = false;
      long previousValue = this.values[mask + 1];
      this.values[mask + 1] = 0L;
      return previousValue;
    } 
    KType[] keys = (KType[])this.keys;
    int slot = hashKey(key) & mask;
    
    KType existing;
    while ((existing = keys[slot]) != null) {
      if (equals(existing, key)) {
        long previousValue = this.values[slot];
        shiftConflictingKeys(slot);
        return previousValue;
      } 
      slot = slot + 1 & mask;
    } 
    
    return 0L;
  }





  
  public int removeAll(ObjectContainer<? super KType> other) {
    int before = size();




    
    if (other.size() >= size() && other instanceof ObjectLookupContainer) {
      
      if (this.hasEmptyKey && 
        other.contains(null)) {
        this.hasEmptyKey = false;
        this.values[this.mask + 1] = 0L;
      } 

      
      KType[] keys = (KType[])this.keys;
      for (int slot = 0, max = this.mask; slot <= max; ) {
        KType existing;
        if ((existing = keys[slot]) != null && other.contains(existing)) {
          
          shiftConflictingKeys(slot); continue;
        } 
        slot++;
      } 
    } else {
      
      for (ObjectCursor<?> c : other) {
        remove((KType)c.value);
      }
    } 
    
    return before - size();
  }




  
  public int removeAll(ObjectLongPredicate<? super KType> predicate) {
    int before = size();
    
    int mask = this.mask;
    
    if (this.hasEmptyKey && 
      predicate.apply(null, this.values[mask + 1])) {
      this.hasEmptyKey = false;
      this.values[mask + 1] = 0L;
    } 

    
    KType[] keys = (KType[])this.keys;
    long[] values = this.values;
    for (int slot = 0; slot <= mask; ) {
      KType existing;
      if ((existing = keys[slot]) != null && predicate.apply(existing, values[slot])) {

        
        shiftConflictingKeys(slot); continue;
      } 
      slot++;
    } 

    
    return before - size();
  }




  
  public int removeAll(ObjectPredicate<? super KType> predicate) {
    int before = size();
    
    if (this.hasEmptyKey && 
      predicate.apply(null)) {
      this.hasEmptyKey = false;
      this.values[this.mask + 1] = 0L;
    } 

    
    KType[] keys = (KType[])this.keys;
    for (int slot = 0, max = this.mask; slot <= max; ) {
      KType existing;
      if ((existing = keys[slot]) != null && predicate.apply(existing)) {

        
        shiftConflictingKeys(slot); continue;
      } 
      slot++;
    } 

    
    return before - size();
  }




  
  public long get(KType key) {
    if (key == null) {
      return this.hasEmptyKey ? this.values[this.mask + 1] : 0L;
    }
    KType[] keys = (KType[])this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    KType existing;
    while ((existing = keys[slot]) != null) {
      if (equals(existing, key)) {
        return this.values[slot];
      }
      slot = slot + 1 & mask;
    } 
    
    return 0L;
  }





  
  public long getOrDefault(KType key, long defaultValue) {
    if (key == null) {
      return this.hasEmptyKey ? this.values[this.mask + 1] : defaultValue;
    }
    KType[] keys = (KType[])this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    KType existing;
    while ((existing = keys[slot]) != null) {
      if (equals(existing, key)) {
        return this.values[slot];
      }
      slot = slot + 1 & mask;
    } 
    
    return defaultValue;
  }





  
  public boolean containsKey(KType key) {
    if (key == null) {
      return this.hasEmptyKey;
    }
    KType[] keys = (KType[])this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    KType existing;
    while ((existing = keys[slot]) != null) {
      if (equals(existing, key)) {
        return true;
      }
      slot = slot + 1 & mask;
    } 
    
    return false;
  }





  
  public int indexOf(KType key) {
    int mask = this.mask;
    if (key == null) {
      return this.hasEmptyKey ? (mask + 1) : (mask + 1 ^ 0xFFFFFFFF);
    }
    KType[] keys = (KType[])this.keys;
    int slot = hashKey(key) & mask;
    
    KType existing;
    while ((existing = keys[slot]) != null) {
      if (equals(existing, key)) {
        return slot;
      }
      slot = slot + 1 & mask;
    } 
    
    return slot ^ 0xFFFFFFFF;
  }





  
  public boolean indexExists(int index) {
    assert index == this.mask + 1 && this.hasEmptyKey;


    
    return (index >= 0);
  }




  
  public long indexGet(int index) {
    assert index >= 0 : "The index must point at an existing key.";
    assert index <= this.mask || (index == this.mask + 1 && this.hasEmptyKey);

    
    return this.values[index];
  }




  
  public long indexReplace(int index, long newValue) {
    assert index >= 0 : "The index must point at an existing key.";
    assert index <= this.mask || (index == this.mask + 1 && this.hasEmptyKey);

    
    long previousValue = this.values[index];
    this.values[index] = newValue;
    return previousValue;
  }




  
  public void indexInsert(int index, KType key, long value) {
    assert index < 0 : "The index must not point at an existing key.";
    
    index ^= 0xFFFFFFFF;
    if (key == null) {
      assert index == this.mask + 1;
      this.values[index] = value;
      this.hasEmptyKey = true;
    } else {
      assert this.keys[index] == null;
      
      if (this.assigned == this.resizeAt) {
        allocateThenInsertThenRehash(index, key, value);
      } else {
        this.keys[index] = key;
        this.values[index] = value;
      } 
      
      this.assigned++;
    } 
  }




  
  public void clear() {
    this.assigned = 0;
    this.hasEmptyKey = false;
    
    Arrays.fill(this.keys, null);
  }






  
  public void release() {
    this.assigned = 0;
    this.hasEmptyKey = false;
    
    this.keys = null;
    this.values = null;
    ensureCapacity(4);
  }





  
  public int size() { return this.assigned + (this.hasEmptyKey ? 1 : 0); }





  
  public boolean isEmpty() { return (size() == 0); }





  
  public int hashCode() {
    int h = this.hasEmptyKey ? -559038737 : 0;
    for (ObjectLongCursor<KType> c : this) {
      h += BitMixer.mix(c.key) + BitMixer.mix(c.value);
    }
    
    return h;
  }





  
  public boolean equals(Object obj) { return (obj != null && getClass() == obj.getClass() && equalElements((ObjectLongHashMap)getClass().cast(obj))); }








  
  protected boolean equalElements(ObjectLongHashMap<?> other) {
    if (other.size() != size()) {
      return false;
    }
    
    for (ObjectLongCursor<?> c : other) {
      KType key = (KType)c.key;
      if (!containsKey(key) || get(key) != c.value)
      {
        return false;
      }
    } 
    
    return true;
  }







  
  public void ensureCapacity(int expectedElements) {
    if (expectedElements > this.resizeAt || this.keys == null) {
      KType[] prevKeys = (KType[])this.keys;
      long[] prevValues = this.values;
      allocateBuffers(HashContainers.minBufferSize(expectedElements, this.loadFactor));
      if (prevKeys != null && !isEmpty()) {
        rehash(prevKeys, prevValues);
      }
    } 
  }

  
  private final class EntryIterator
    extends AbstractIterator<ObjectLongCursor<KType>>
  {
    private final ObjectLongCursor<KType> cursor;
    private final int max = ObjectLongHashMap.this.mask + 1;
    private int slot = -1;

    
    public EntryIterator() { this.cursor = new ObjectLongCursor(); }


    
    protected ObjectLongCursor<KType> fetch() {
      if (this.slot < this.max) {
        
        this.slot++; for (; this.slot < this.max; this.slot++) {
          KType existing; if ((existing = (KType)ObjectLongHashMap.this.keys[this.slot]) != null) {
            this.cursor.index = this.slot;
            this.cursor.key = existing;
            this.cursor.value = ObjectLongHashMap.this.values[this.slot];
            return this.cursor;
          } 
        } 
      } 
      
      if (this.slot == this.max && ObjectLongHashMap.this.hasEmptyKey) {
        this.cursor.index = this.slot;
        this.cursor.key = null;
        this.cursor.value = ObjectLongHashMap.this.values[this.max];
        this.slot++;
        return this.cursor;
      } 
      
      return done();
    }
  }





  
  public Iterator<ObjectLongCursor<KType>> iterator() { return new EntryIterator(); }





  
  public <T extends ObjectLongProcedure<? super KType>> T forEach(T procedure) {
    KType[] keys = (KType[])this.keys;
    long[] values = this.values;
    
    if (this.hasEmptyKey) {
      procedure.apply(null, values[this.mask + 1]);
    }
    
    for (int slot = 0, max = this.mask; slot <= max; slot++) {
      if (keys[slot] != null) {
        procedure.apply(keys[slot], values[slot]);
      }
    } 
    
    return procedure;
  }




  
  public <T extends ObjectLongPredicate<? super KType>> T forEach(T predicate) {
    KType[] keys = (KType[])this.keys;
    long[] values = this.values;
    
    if (this.hasEmptyKey && 
      !predicate.apply(null, values[this.mask + 1])) {
      return predicate;
    }

    
    for (int slot = 0, max = this.mask; slot <= max && (
      keys[slot] == null || 
      predicate.apply(keys[slot], values[slot])); slot++);




    
    return predicate;
  }





  
  public KeysContainer keys() { return new KeysContainer(); }


  
  public final class KeysContainer
    extends AbstractObjectCollection<KType>
    implements ObjectLookupContainer<KType>
  {
    private final ObjectLongHashMap<KType> owner = ObjectLongHashMap.this;


    
    public boolean contains(KType e) { return this.owner.containsKey(e); }


    
    public <T extends ObjectProcedure<? super KType>> T forEach(final T procedure) {
      this.owner.forEach(new ObjectLongProcedure<KType>()
          {
            public void apply(KType key, long value) {
              procedure.apply(key);
            }
          });
      
      return procedure;
    }

    
    public <T extends ObjectPredicate<? super KType>> T forEach(final T predicate) {
      this.owner.forEach(new ObjectLongPredicate<KType>()
          {
            public boolean apply(KType key, long value) {
              return predicate.apply(key);
            }
          });
      
      return predicate;
    }


    
    public boolean isEmpty() { return this.owner.isEmpty(); }



    
    public Iterator<ObjectCursor<KType>> iterator() { return new ObjectLongHashMap.KeysIterator(); }



    
    public int size() { return this.owner.size(); }



    
    public void clear() { this.owner.clear(); }



    
    public void release() { this.owner.release(); }



    
    public int removeAll(ObjectPredicate<? super KType> predicate) { return this.owner.removeAll(predicate); }


    
    public int removeAll(KType e) {
      boolean hasKey = this.owner.containsKey(e);
      if (hasKey) {
        this.owner.remove(e);
        return 1;
      } 
      return 0;
    }
  }

  
  private final class KeysIterator
    extends AbstractIterator<ObjectCursor<KType>>
  {
    private final ObjectCursor<KType> cursor;
    
    private final int max = ObjectLongHashMap.this.mask + 1;
    private int slot = -1;

    
    public KeysIterator() { this.cursor = new ObjectCursor(); }


    
    protected ObjectCursor<KType> fetch() {
      if (this.slot < this.max) {
        
        this.slot++; for (; this.slot < this.max; this.slot++) {
          KType existing; if ((existing = (KType)ObjectLongHashMap.this.keys[this.slot]) != null) {
            this.cursor.index = this.slot;
            this.cursor.value = existing;
            return this.cursor;
          } 
        } 
      } 
      
      if (this.slot == this.max && ObjectLongHashMap.this.hasEmptyKey) {
        this.cursor.index = this.slot;
        this.cursor.value = null;
        this.slot++;
        return this.cursor;
      } 
      
      return done();
    }
  }




  
  public LongCollection values() {
    return new ValuesContainer();
  }

  
  private final class ValuesContainer
    extends AbstractLongCollection
  {
    private final ObjectLongHashMap<KType> owner = ObjectLongHashMap.this;


    
    public int size() { return this.owner.size(); }



    
    public boolean isEmpty() { return this.owner.isEmpty(); }


    
    public boolean contains(long value) {
      for (ObjectLongCursor<KType> c : this.owner) {
        if (c.value == value) {
          return true;
        }
      } 
      return false;
    }

    
    public <T extends com.carrotsearch.hppc.procedures.LongProcedure> T forEach(T procedure) {
      for (ObjectLongCursor<KType> c : this.owner) {
        procedure.apply(c.value);
      }
      return procedure;
    }

    
    public <T extends LongPredicate> T forEach(T predicate) {
      for (ObjectLongCursor<KType> c : this.owner) {
        if (!predicate.apply(c.value)) {
          break;
        }
      } 
      return predicate;
    }


    
    public Iterator<LongCursor> iterator() { return new ObjectLongHashMap.ValuesIterator(); }


    
    public int removeAll(final long e) {
      return this.owner.removeAll(new ObjectLongPredicate<KType>()
          {
            public boolean apply(KType key, long value) {
              return (value == e);
            }
          });
    }

    
    public int removeAll(final LongPredicate predicate) {
      return this.owner.removeAll(new ObjectLongPredicate<KType>()
          {
            public boolean apply(KType key, long value) {
              return predicate.apply(value);
            }
          });
    }


    
    public void clear() { this.owner.clear(); }



    
    public void release() { this.owner.release(); }
    
    private ValuesContainer() {}
  }
  
  private final class ValuesIterator
    extends AbstractIterator<LongCursor>
  {
    private final LongCursor cursor;
    private final int max = ObjectLongHashMap.this.mask + 1;
    private int slot = -1;

    
    public ValuesIterator() { this.cursor = new LongCursor(); }


    
    protected LongCursor fetch() {
      if (this.slot < this.max) {
        this.slot++; for (; this.slot < this.max; this.slot++) {
          if (ObjectLongHashMap.this.keys[this.slot] != null) {
            this.cursor.index = this.slot;
            this.cursor.value = ObjectLongHashMap.this.values[this.slot];
            return this.cursor;
          } 
        } 
      } 
      
      if (this.slot == this.max && ObjectLongHashMap.this.hasEmptyKey) {
        this.cursor.index = this.slot;
        this.cursor.value = ObjectLongHashMap.this.values[this.max];
        this.slot++;
        return this.cursor;
      } 
      
      return done();
    }
  }





  
  public ObjectLongHashMap<KType> clone() {
    try {
      ObjectLongHashMap<KType> cloned = (ObjectLongHashMap<KType>)super.clone();
      cloned.keys = (Object[])this.keys.clone();
      cloned.values = (long[])this.values.clone();
      cloned.hasEmptyKey = cloned.hasEmptyKey;
      cloned.orderMixer = this.orderMixer.clone();
      return cloned;
    } catch (CloneNotSupportedException e) {
      throw new RuntimeException(e);
    } 
  }




  
  public String toString() {
    StringBuilder buffer = new StringBuilder();
    buffer.append("[");
    
    boolean first = true;
    for (ObjectLongCursor<KType> cursor : this) {
      if (!first) {
        buffer.append(", ");
      }
      buffer.append(cursor.key);
      buffer.append("=>");
      buffer.append(cursor.value);
      first = false;
    } 
    buffer.append("]");
    return buffer.toString();
  }


  
  public String visualizeKeyDistribution(int characters) { return ObjectBufferVisualizer.visualizeKeyDistribution(this.keys, this.mask, characters); }




  
  public static <KType> ObjectLongHashMap<KType> from(KType[] keys, long[] values) {
    if (keys.length != values.length) {
      throw new IllegalArgumentException("Arrays of keys and values must have an identical length.");
    }
    
    ObjectLongHashMap<KType> map = new ObjectLongHashMap<>(keys.length);
    for (int i = 0; i < keys.length; i++) {
      map.put(keys[i], values[i]);
    }
    
    return map;
  }












  
  protected int hashKey(KType key) {
    assert key != null;
    return BitMixer.mix(key, this.keyMixer);
  }




  
  protected double verifyLoadFactor(double loadFactor) {
    HashContainers.checkLoadFactor(loadFactor, 0.009999999776482582D, 0.9900000095367432D);
    return loadFactor;
  }



  
  protected void rehash(KType[] fromKeys, long[] fromValues) {
    assert fromKeys.length == fromValues.length && HashContainers.checkPowerOfTwo(fromKeys.length - 1);


    
    KType[] keys = (KType[])this.keys;
    long[] values = this.values;
    int mask = this.mask;


    
    int from = fromKeys.length - 1;
    keys[keys.length - 1] = fromKeys[from];
    values[values.length - 1] = fromValues[from];
    while (--from >= 0) {
      KType existing; if ((existing = fromKeys[from]) != null) {
        int slot = hashKey(existing) & mask;
        while (keys[slot] != null) {
          slot = slot + 1 & mask;
        }
        keys[slot] = existing;
        values[slot] = fromValues[from];
      } 
    } 
  }




  
  protected void allocateBuffers(int arraySize) {
    assert Integer.bitCount(arraySize) == 1;

    
    int newKeyMixer = this.orderMixer.newKeyMixer(arraySize);

    
    KType[] prevKeys = (KType[])this.keys;
    long[] prevValues = this.values;
    try {
      int emptyElementSlot = 1;
      this.keys = new Object[arraySize + emptyElementSlot];
      this.values = new long[arraySize + emptyElementSlot];
    } catch (OutOfMemoryError e) {
      this.keys = (Object[])prevKeys;
      this.values = prevValues;
      throw new BufferAllocationException("Not enough memory to allocate buffers for rehashing: %,d -> %,d", e, new Object[] { Integer.valueOf(this.mask + 1), Integer.valueOf(arraySize) });
    } 




    
    this.resizeAt = HashContainers.expandAtCount(arraySize, this.loadFactor);
    this.keyMixer = newKeyMixer;
    this.mask = arraySize - 1;
  }









  
  protected void allocateThenInsertThenRehash(int slot, KType pendingKey, long pendingValue) {
    assert this.assigned == this.resizeAt && this.keys[slot] == null && pendingKey != null;



    
    KType[] prevKeys = (KType[])this.keys;
    long[] prevValues = this.values;
    allocateBuffers(HashContainers.nextBufferSize(this.mask + 1, size(), this.loadFactor));
    assert this.keys.length > prevKeys.length;


    
    prevKeys[slot] = pendingKey;
    prevValues[slot] = pendingValue;

    
    rehash(prevKeys, prevValues);
  }




  
  protected void shiftConflictingKeys(int gapSlot) {
    KType[] keys = (KType[])this.keys;
    long[] values = this.values;
    int mask = this.mask;

    
    int distance = 0;
    while (true) {
      int slot = gapSlot + ++distance & mask;
      KType existing = keys[slot];
      if (existing == null) {
        break;
      }
      
      int idealSlot = hashKey(existing);
      int shift = slot - idealSlot & mask;
      if (shift >= distance) {



        
        keys[gapSlot] = existing;
        values[gapSlot] = values[slot];
        gapSlot = slot;
        distance = 0;
      } 
    } 

    
    keys[gapSlot] = null;
    values[gapSlot] = 0L;
    this.assigned--;
  }


  
  protected boolean equals(Object v1, Object v2) { return (v1 == v2 || (v1 != null && v1.equals(v2))); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\ObjectLongHashMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */