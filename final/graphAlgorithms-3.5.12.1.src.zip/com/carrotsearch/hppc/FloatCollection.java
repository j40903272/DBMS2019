package com.carrotsearch.hppc;

import com.carrotsearch.hppc.predicates.FloatPredicate;

public interface FloatCollection extends FloatContainer {
  int removeAll(float paramFloat);
  
  int removeAll(FloatLookupContainer paramFloatLookupContainer);
  
  int removeAll(FloatPredicate paramFloatPredicate);
  
  int retainAll(FloatLookupContainer paramFloatLookupContainer);
  
  int retainAll(FloatPredicate paramFloatPredicate);
  
  void clear();
  
  void release();
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\FloatCollection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */