package com.carrotsearch.hppc;

import java.util.RandomAccess;

public interface IntIndexedContainer extends IntCollection, RandomAccess {
  int removeFirst(int paramInt);
  
  int removeLast(int paramInt);
  
  int indexOf(int paramInt);
  
  int lastIndexOf(int paramInt);
  
  void add(int paramInt);
  
  void insert(int paramInt1, int paramInt2);
  
  int set(int paramInt1, int paramInt2);
  
  int get(int paramInt);
  
  int remove(int paramInt);
  
  void removeRange(int paramInt1, int paramInt2);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\IntIndexedContainer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */