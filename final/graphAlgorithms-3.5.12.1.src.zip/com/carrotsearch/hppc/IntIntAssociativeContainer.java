package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.IntIntCursor;
import com.carrotsearch.hppc.predicates.IntIntPredicate;
import com.carrotsearch.hppc.predicates.IntPredicate;
import java.util.Iterator;

public interface IntIntAssociativeContainer extends Iterable<IntIntCursor> {
  Iterator<IntIntCursor> iterator();
  
  boolean containsKey(int paramInt);
  
  int size();
  
  boolean isEmpty();
  
  int removeAll(IntContainer paramIntContainer);
  
  int removeAll(IntPredicate paramIntPredicate);
  
  int removeAll(IntIntPredicate paramIntIntPredicate);
  
  <T extends com.carrotsearch.hppc.procedures.IntIntProcedure> T forEach(T paramT);
  
  <T extends IntIntPredicate> T forEach(T paramT);
  
  IntCollection keys();
  
  IntContainer values();
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\IntIntAssociativeContainer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */