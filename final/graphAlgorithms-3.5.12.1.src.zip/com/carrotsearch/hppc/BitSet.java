package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.IntCursor;
import com.carrotsearch.hppc.cursors.LongCursor;
import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;





























































public class BitSet
  implements Cloneable
{
  private static final long DEFAULT_NUM_BITS = 64L;
  public long[] bits;
  public int wlen;
  
  public BitSet() { this(64L); }







  
  public BitSet(long numBits) {
    this.bits = new long[bits2words(numBits)];
    this.wlen = this.bits.length;
  }















  
  public BitSet(long[] bits, int numWords) {
    this.bits = bits;
    this.wlen = numWords;
  }







  
  public static BitSet newInstance() { return new BitSet(); }







  
  public BitSetIterator iterator() { return new BitSetIterator(this.bits, this.wlen); }






  
  public long capacity() { return (this.bits.length << 6); }









  
  public long size() { return capacity(); }







  
  public long length() {
    trimTrailingZeros();
    if (this.wlen == 0) return 0L; 
    return (this.wlen - 1L << 6L) + (64 - Long.numberOfLeadingZeros(this.bits[this.wlen - 1]));
  }






  
  public boolean isEmpty() { return (cardinality() == 0L); }






  
  public boolean get(int index) {
    int i = index >> 6;

    
    if (i >= this.bits.length) return false;
    
    int bit = index & 0x3F;
    long bitmask = 1L << bit;
    return ((this.bits[i] & bitmask) != 0L);
  }





  
  public boolean get(long index) {
    int i = (int)(index >> 6L);
    if (i >= this.bits.length) return false; 
    int bit = (int)index & 0x3F;
    long bitmask = 1L << bit;
    return ((this.bits[i] & bitmask) != 0L);
  }






  
  public void set(long index) {
    int wordNum = expandingWordNum(index);
    int bit = (int)index & 0x3F;
    long bitmask = 1L << bit;
    this.bits[wordNum] = this.bits[wordNum] | bitmask;
  }







  
  public void set(long startIndex, long endIndex) {
    if (endIndex <= startIndex)
      return; 
    int startWord = (int)(startIndex >> 6L);


    
    int endWord = expandingWordNum(endIndex - 1L);
    
    long startmask = -1L << (int)startIndex;
    long endmask = -1L >>> (int)-endIndex;

    
    if (startWord == endWord) {
      
      this.bits[startWord] = this.bits[startWord] | startmask & endmask;
      
      return;
    } 
    this.bits[startWord] = this.bits[startWord] | startmask;
    Arrays.fill(this.bits, startWord + 1, endWord, -1L);
    this.bits[endWord] = this.bits[endWord] | endmask;
  }

  
  protected int expandingWordNum(long index) {
    int wordNum = (int)(index >> 6L);
    if (wordNum >= this.wlen) {
      
      ensureCapacity(index + 1L);
      this.wlen = wordNum + 1;
    } 
    return wordNum;
  }


  
  public void clear() {
    Arrays.fill(this.bits, 0L);
    this.wlen = 0;
  }







  
  public void clear(long index) {
    int wordNum = (int)(index >> 6L);
    if (wordNum >= this.wlen)
      return;  int bit = (int)index & 0x3F;
    long bitmask = 1L << bit;
    this.bits[wordNum] = this.bits[wordNum] & (bitmask ^ 0xFFFFFFFFFFFFFFFFL);
  }







  
  public void clear(int startIndex, int endIndex) {
    if (endIndex <= startIndex)
      return; 
    int startWord = startIndex >> 6;
    if (startWord >= this.wlen) {
      return;
    }
    
    int endWord = endIndex - 1 >> 6;
    
    long startmask = -1L << startIndex;
    long endmask = -1L >>> -endIndex;


    
    startmask ^= 0xFFFFFFFFFFFFFFFFL;
    endmask ^= 0xFFFFFFFFFFFFFFFFL;
    
    if (startWord == endWord) {
      
      this.bits[startWord] = this.bits[startWord] & (startmask | endmask);
      
      return;
    } 
    this.bits[startWord] = this.bits[startWord] & startmask;
    
    int middle = Math.min(this.wlen, endWord);
    Arrays.fill(this.bits, startWord + 1, middle, 0L);
    if (endWord < this.wlen)
    {
      this.bits[endWord] = this.bits[endWord] & endmask;
    }
  }







  
  public void clear(long startIndex, long endIndex) {
    if (endIndex <= startIndex)
      return; 
    int startWord = (int)(startIndex >> 6L);
    if (startWord >= this.wlen) {
      return;
    }
    
    int endWord = (int)(endIndex - 1L >> 6L);
    
    long startmask = -1L << (int)startIndex;
    long endmask = -1L >>> (int)-endIndex;


    
    startmask ^= 0xFFFFFFFFFFFFFFFFL;
    endmask ^= 0xFFFFFFFFFFFFFFFFL;
    
    if (startWord == endWord) {
      
      this.bits[startWord] = this.bits[startWord] & (startmask | endmask);
      
      return;
    } 
    this.bits[startWord] = this.bits[startWord] & startmask;
    
    int middle = Math.min(this.wlen, endWord);
    Arrays.fill(this.bits, startWord + 1, middle, 0L);
    if (endWord < this.wlen)
    {
      this.bits[endWord] = this.bits[endWord] & endmask;
    }
  }








  
  public boolean getAndSet(int index) {
    int wordNum = index >> 6;
    int bit = index & 0x3F;
    long bitmask = 1L << bit;
    boolean val = ((this.bits[wordNum] & bitmask) != 0L);
    this.bits[wordNum] = this.bits[wordNum] | bitmask;
    return val;
  }








  
  public boolean getAndSet(long index) {
    int wordNum = (int)(index >> 6L);
    int bit = (int)index & 0x3F;
    long bitmask = 1L << bit;
    boolean val = ((this.bits[wordNum] & bitmask) != 0L);
    this.bits[wordNum] = this.bits[wordNum] | bitmask;
    return val;
  }






  
  public void flip(long index) {
    int wordNum = expandingWordNum(index);
    int bit = (int)index & 0x3F;
    long bitmask = 1L << bit;
    this.bits[wordNum] = this.bits[wordNum] ^ bitmask;
  }








  
  public boolean flipAndGet(int index) {
    int wordNum = index >> 6;
    int bit = index & 0x3F;
    long bitmask = 1L << bit;
    this.bits[wordNum] = this.bits[wordNum] ^ bitmask;
    return ((this.bits[wordNum] & bitmask) != 0L);
  }








  
  public boolean flipAndGet(long index) {
    int wordNum = (int)(index >> 6L);
    int bit = (int)index & 0x3F;
    long bitmask = 1L << bit;
    this.bits[wordNum] = this.bits[wordNum] ^ bitmask;
    return ((this.bits[wordNum] & bitmask) != 0L);
  }







  
  public void flip(long startIndex, long endIndex) {
    if (endIndex <= startIndex)
      return;  int startWord = (int)(startIndex >> 6L);


    
    int endWord = expandingWordNum(endIndex - 1L);
    
    long startmask = -1L << (int)startIndex;
    long endmask = -1L >>> (int)-endIndex;

    
    if (startWord == endWord) {
      
      this.bits[startWord] = this.bits[startWord] ^ startmask & endmask;
      
      return;
    } 
    this.bits[startWord] = this.bits[startWord] ^ startmask;
    
    for (int i = startWord + 1; i < endWord; i++)
    {
      this.bits[i] = this.bits[i] ^ 0xFFFFFFFFFFFFFFFFL;
    }
    
    this.bits[endWord] = this.bits[endWord] ^ endmask;
  }



  
  public long cardinality() { return BitUtil.pop_array(this.bits, 0, this.wlen); }










  
  public static long intersectionCount(BitSet a, BitSet b) { return BitUtil.pop_intersect(a.bits, b.bits, 0, Math.min(a.wlen, b.wlen)); }








  
  public static long unionCount(BitSet a, BitSet b) {
    long tot = BitUtil.pop_union(a.bits, b.bits, 0, Math.min(a.wlen, b.wlen));
    if (a.wlen < b.wlen) {
      
      tot += BitUtil.pop_array(b.bits, a.wlen, b.wlen - a.wlen);
    }
    else if (a.wlen > b.wlen) {
      
      tot += BitUtil.pop_array(a.bits, b.wlen, a.wlen - b.wlen);
    } 
    return tot;
  }







  
  public static long andNotCount(BitSet a, BitSet b) {
    long tot = BitUtil.pop_andnot(a.bits, b.bits, 0, Math.min(a.wlen, b.wlen));
    if (a.wlen > b.wlen)
    {
      tot += BitUtil.pop_array(a.bits, b.wlen, a.wlen - b.wlen);
    }
    return tot;
  }







  
  public static long xorCount(BitSet a, BitSet b) {
    long tot = BitUtil.pop_xor(a.bits, b.bits, 0, Math.min(a.wlen, b.wlen));
    if (a.wlen < b.wlen) {
      
      tot += BitUtil.pop_array(b.bits, a.wlen, b.wlen - a.wlen);
    }
    else if (a.wlen > b.wlen) {
      
      tot += BitUtil.pop_array(a.bits, b.wlen, a.wlen - b.wlen);
    } 
    return tot;
  }







  
  public int nextSetBit(int index) {
    int i = index >> 6;
    if (i >= this.wlen) return -1; 
    int subIndex = index & 0x3F;
    long word = this.bits[i] >> subIndex;
    
    if (word != 0L)
    {
      return (i << 6) + subIndex + Long.numberOfTrailingZeros(word);
    }
    
    while (++i < this.wlen) {
      
      word = this.bits[i];
      if (word != 0L) return (i << 6) + Long.numberOfTrailingZeros(word);
    
    } 
    return -1;
  }






  
  public long nextSetBit(long index) {
    int i = (int)(index >>> 6L);
    if (i >= this.wlen) return -1L; 
    int subIndex = (int)index & 0x3F;
    long word = this.bits[i] >>> subIndex;
    
    if (word != 0L)
    {
      return (i << 6L) + (subIndex + Long.numberOfTrailingZeros(word));
    }
    
    while (++i < this.wlen) {
      
      word = this.bits[i];
      if (word != 0L) return (i << 6L) + Long.numberOfTrailingZeros(word);
    
    } 
    return -1L;
  }



  
  public Object clone() {
    try {
      BitSet obs = (BitSet)super.clone();
      obs.bits = (long[])obs.bits.clone();
      
      return obs;
    }
    catch (CloneNotSupportedException e) {
      
      throw new RuntimeException(e);
    } 
  }





  
  public void intersect(BitSet other) {
    int newLen = Math.min(this.wlen, other.wlen);
    long[] thisArr = this.bits;
    long[] otherArr = other.bits;
    
    int pos = newLen;
    while (--pos >= 0)
    {
      thisArr[pos] = thisArr[pos] & otherArr[pos];
    }
    if (this.wlen > newLen)
    {
      
      Arrays.fill(this.bits, newLen, this.wlen, 0L);
    }
    this.wlen = newLen;
  }





  
  public void union(BitSet other) {
    int newLen = Math.max(this.wlen, other.wlen);
    ensureCapacityWords(newLen);
    
    long[] thisArr = this.bits;
    long[] otherArr = other.bits;
    int pos = Math.min(this.wlen, other.wlen);
    while (--pos >= 0)
    {
      thisArr[pos] = thisArr[pos] | otherArr[pos];
    }
    if (this.wlen < newLen)
    {
      System.arraycopy(otherArr, this.wlen, thisArr, this.wlen, newLen - this.wlen);
    }
    this.wlen = newLen;
  }





  
  public void remove(BitSet other) {
    int idx = Math.min(this.wlen, other.wlen);
    long[] thisArr = this.bits;
    long[] otherArr = other.bits;
    while (--idx >= 0)
    {
      thisArr[idx] = thisArr[idx] & (otherArr[idx] ^ 0xFFFFFFFFFFFFFFFFL);
    }
  }





  
  public void xor(BitSet other) {
    int newLen = Math.max(this.wlen, other.wlen);
    ensureCapacityWords(newLen);
    
    long[] thisArr = this.bits;
    long[] otherArr = other.bits;
    int pos = Math.min(this.wlen, other.wlen);
    while (--pos >= 0)
    {
      thisArr[pos] = thisArr[pos] ^ otherArr[pos];
    }
    if (this.wlen < newLen)
    {
      System.arraycopy(otherArr, this.wlen, thisArr, this.wlen, newLen - this.wlen);
    }
    this.wlen = newLen;
  }





  
  public void and(BitSet other) { intersect(other); }




  
  public void or(BitSet other) { union(other); }




  
  public void andNot(BitSet other) { remove(other); }






  
  public boolean intersects(BitSet other) {
    int pos = Math.min(this.wlen, other.wlen);
    long[] thisArr = this.bits;
    long[] otherArr = other.bits;
    while (--pos >= 0) {
      
      if ((thisArr[pos] & otherArr[pos]) != 0L) return true; 
    } 
    return false;
  }







  
  public void ensureCapacityWords(int numWords) {
    if (this.bits.length < numWords)
    {
      this.bits = grow(this.bits, numWords);
    }
  }

  
  public static long[] grow(long[] array, int minSize) {
    if (array.length < minSize) {
      
      long[] newArray = new long[getNextSize(minSize)];
      System.arraycopy(array, 0, newArray, 0, array.length);
      return newArray;
    } 
    return array;
  }









  
  public static int getNextSize(int targetSize) { return (targetSize >> 3) + ((targetSize < 9) ? 3 : 6) + targetSize; }









  
  public void ensureCapacity(long numBits) { ensureCapacityWords(bits2words(numBits)); }






  
  public void trimTrailingZeros() {
    int idx = this.wlen - 1;
    while (idx >= 0 && this.bits[idx] == 0L)
      idx--; 
    this.wlen = idx + 1;
  }





  
  public static int bits2words(long numBits) { return (int)((numBits - 1L >>> 6L) + 1L); }



  
  public boolean equals(Object o) {
    BitSet a;
    if (this == o) return true; 
    if (!(o instanceof BitSet)) return false;

    
    BitSet b = (BitSet)o;

    
    if (b.wlen > this.wlen) {
      
      a = b;
      b = this;
    }
    else {
      
      a = this;
    } 

    
    for (int i = a.wlen - 1; i >= b.wlen; i--) {
      
      if (a.bits[i] != 0L) return false;
    
    } 
    for (int i = b.wlen - 1; i >= 0; i--) {
      
      if (a.bits[i] != b.bits[i]) return false;
    
    } 
    return true;
  }




  
  public int hashCode() {
    long h = 0L;
    for (int i = this.bits.length; --i >= 0; ) {
      
      h ^= this.bits[i];
      h = h << 1L | h >>> 63L;
    } 


    
    return (int)(h >> 32L ^ h) + -1737092556;
  }


  
  public String toString() {
    long bit = nextSetBit(0);
    if (bit < 0L)
    {
      return "{}";
    }
    
    StringBuilder builder = new StringBuilder();
    builder.append("{");
    
    builder.append(Long.toString(bit));
    while ((bit = nextSetBit(bit + 1L)) >= 0L) {
      
      builder.append(", ");
      builder.append(Long.toString(bit));
    } 
    builder.append("}");
    
    return builder.toString();
  }











  
  public IntLookupContainer asIntLookupContainer() {
    return new IntLookupContainer()
      {
        
        public int size()
        {
          return getCurrentCardinality();
        }



        
        public boolean isEmpty() { return BitSet.this.isEmpty(); }



        
        public Iterator<IntCursor> iterator() {
          return new Iterator<IntCursor>() {
              private long nextBitSet = BitSet.this.nextSetBit(0);
              private final IntCursor cursor = new IntCursor();



              
              public boolean hasNext() { return (this.nextBitSet >= 0L); }



              
              public IntCursor next() {
                long value = this.nextBitSet;
                if (value < 0L) throw new NoSuchElementException(); 
                if (value > 2147483647L) {
                  throw new RuntimeException("BitSet range larger than maximum positive integer.");
                }
                this.nextBitSet = BitSet.this.nextSetBit(value + 1L);
                this.cursor.index = this.cursor.value = (int)value;
                return this.cursor;
              }



              
              public void remove() { throw new UnsupportedOperationException(); }
            };
        }



        
        public int[] toArray() {
          int[] data = new int[getCurrentCardinality()];
          BitSetIterator i = BitSet.this.iterator(); int bit;
          for (int j = 0; bit >= 0; bit = i.nextSetBit())
          {
            data[j++] = bit;
          }
          return data;
        }


        
        public <T extends com.carrotsearch.hppc.predicates.IntPredicate> T forEach(T predicate) {
          BitSetIterator i = BitSet.this.iterator();
          for (int bit = i.nextSetBit(); bit >= 0; bit = i.nextSetBit()) {
            
            if (!predicate.apply(bit)) {
              break;
            }
          } 
          return predicate;
        }


        
        public <T extends com.carrotsearch.hppc.procedures.IntProcedure> T forEach(T procedure) {
          BitSetIterator i = BitSet.this.iterator();
          for (int bit = i.nextSetBit(); bit >= 0; bit = i.nextSetBit())
          {
            procedure.apply(bit);
          }
          
          return procedure;
        }



        
        public boolean contains(int index) { return (index < 0 || BitSet.this.get(index)); }






        
        private int getCurrentCardinality() {
          long cardinality = BitSet.this.cardinality();
          if (cardinality > 2147483647L) {
            throw new RuntimeException("Bitset is larger than maximum positive integer: " + cardinality);
          }
          return (int)cardinality;
        }
      };
  }








  
  public LongLookupContainer asLongLookupContainer() {
    return new LongLookupContainer()
      {
        
        public int size()
        {
          return getCurrentCardinality();
        }



        
        public boolean isEmpty() { return BitSet.this.isEmpty(); }



        
        public Iterator<LongCursor> iterator() {
          return new Iterator<LongCursor>() {
              private long nextBitSet = BitSet.this.nextSetBit(0);
              private final LongCursor cursor = new LongCursor();



              
              public boolean hasNext() { return (this.nextBitSet >= 0L); }



              
              public LongCursor next() {
                long value = this.nextBitSet;
                if (value < 0L) throw new NoSuchElementException();
                
                this.nextBitSet = BitSet.this.nextSetBit(value + 1L);
                this.cursor.index = (int)value;
                this.cursor.value = value;
                return this.cursor;
              }



              
              public void remove() { throw new UnsupportedOperationException(); }
            };
        }



        
        public long[] toArray() {
          long[] data = new long[getCurrentCardinality()];
          BitSet bset = BitSet.this;
          int j = 0; long bit;
          for (bit = bset.nextSetBit(0L); bit >= 0L; bit = bset.nextSetBit(bit + 1L))
          {
            data[j++] = bit;
          }
          return data;
        }


        
        public <T extends com.carrotsearch.hppc.predicates.LongPredicate> T forEach(T predicate) {
          BitSet bset = BitSet.this;
          for (long bit = bset.nextSetBit(0L); bit >= 0L; bit = bset.nextSetBit(bit + 1L)) {
            
            if (!predicate.apply(bit)) {
              break;
            }
          } 
          return predicate;
        }


        
        public <T extends com.carrotsearch.hppc.procedures.LongProcedure> T forEach(T procedure) {
          BitSet bset = BitSet.this;
          for (long bit = bset.nextSetBit(0L); bit >= 0L; bit = bset.nextSetBit(bit + 1L))
          {
            procedure.apply(bit);
          }
          
          return procedure;
        }



        
        public boolean contains(long index) { return (index < 0L || BitSet.this.get(index)); }






        
        private int getCurrentCardinality() {
          long cardinality = BitSet.this.cardinality();
          if (cardinality > 2147483647L) {
            throw new RuntimeException("Bitset is larger than maximum positive integer: " + cardinality);
          }
          return (int)cardinality;
        }
      };
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\BitSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */