package com.carrotsearch.hppc;

import java.util.Iterator;
import java.util.NoSuchElementException;





public abstract class AbstractIterator<E>
  implements Iterator<E>
{
  private static final int NOT_CACHED = 0;
  private static final int CACHED = 1;
  private static final int AT_END = 2;
  private int state = 0;



  
  private E nextElement;




  
  public boolean hasNext() {
    if (this.state == 0) {
      this.state = 1;
      this.nextElement = fetch();
    } 
    return (this.state == 1);
  }




  
  public E next() {
    if (!hasNext()) {
      throw new NoSuchElementException();
    }
    
    this.state = 0;
    return this.nextElement;
  }





  
  public void remove() { throw new UnsupportedOperationException(); }






  
  protected abstract E fetch();






  
  protected final E done() {
    this.state = 2;
    return null;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\AbstractIterator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */