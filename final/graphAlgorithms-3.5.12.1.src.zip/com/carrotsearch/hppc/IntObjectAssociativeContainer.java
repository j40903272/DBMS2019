package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.IntObjectCursor;
import com.carrotsearch.hppc.predicates.IntObjectPredicate;
import com.carrotsearch.hppc.predicates.IntPredicate;
import java.util.Iterator;

public interface IntObjectAssociativeContainer<VType> extends Iterable<IntObjectCursor<VType>> {
  Iterator<IntObjectCursor<VType>> iterator();
  
  boolean containsKey(int paramInt);
  
  int size();
  
  boolean isEmpty();
  
  int removeAll(IntContainer paramIntContainer);
  
  int removeAll(IntPredicate paramIntPredicate);
  
  int removeAll(IntObjectPredicate<? super VType> paramIntObjectPredicate);
  
  <T extends com.carrotsearch.hppc.procedures.IntObjectProcedure<? super VType>> T forEach(T paramT);
  
  <T extends IntObjectPredicate<? super VType>> T forEach(T paramT);
  
  IntCollection keys();
  
  ObjectContainer<VType> values();
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\IntObjectAssociativeContainer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */