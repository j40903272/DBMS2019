package com.carrotsearch.hppc;


















public class IntIntScatterMap
  extends IntIntHashMap
{
  public IntIntScatterMap() { this(4); }





  
  public IntIntScatterMap(int expectedElements) { this(expectedElements, 0.75D); }






  
  public IntIntScatterMap(int expectedElements, double loadFactor) { super(expectedElements, loadFactor, HashOrderMixing.none()); }



  
  protected int hashKey(int key) { return BitMixer.mixPhi(key); }




  
  public static IntIntScatterMap from(int[] keys, int[] values) {
    if (keys.length != values.length) {
      throw new IllegalArgumentException("Arrays of keys and values must have an identical length.");
    }
    
    IntIntScatterMap map = new IntIntScatterMap(keys.length);
    for (int i = 0; i < keys.length; i++) {
      map.put(keys[i], values[i]);
    }
    
    return map;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\IntIntScatterMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */