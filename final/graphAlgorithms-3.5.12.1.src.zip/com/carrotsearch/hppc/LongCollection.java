package com.carrotsearch.hppc;

import com.carrotsearch.hppc.predicates.LongPredicate;

public interface LongCollection extends LongContainer {
  int removeAll(long paramLong);
  
  int removeAll(LongLookupContainer paramLongLookupContainer);
  
  int removeAll(LongPredicate paramLongPredicate);
  
  int retainAll(LongLookupContainer paramLongLookupContainer);
  
  int retainAll(LongPredicate paramLongPredicate);
  
  void clear();
  
  void release();
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\LongCollection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */