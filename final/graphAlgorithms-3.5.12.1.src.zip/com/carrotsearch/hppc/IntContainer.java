package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.IntCursor;
import java.util.Iterator;

public interface IntContainer extends Iterable<IntCursor> {
  Iterator<IntCursor> iterator();
  
  boolean contains(int paramInt);
  
  int size();
  
  boolean isEmpty();
  
  int[] toArray();
  
  <T extends com.carrotsearch.hppc.procedures.IntProcedure> T forEach(T paramT);
  
  <T extends com.carrotsearch.hppc.predicates.IntPredicate> T forEach(T paramT);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\IntContainer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */