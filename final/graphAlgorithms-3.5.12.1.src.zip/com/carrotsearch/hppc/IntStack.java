package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.IntCursor;






















public class IntStack
  extends IntArrayList
{
  public IntStack() {}
  
  public IntStack(int expectedElements) { super(expectedElements); }











  
  public IntStack(int expectedElements, ArraySizingStrategy resizer) { super(expectedElements, resizer); }





  
  public IntStack(IntContainer container) { super(container); }




  
  public void push(int e1) {
    ensureBufferSpace(1);
    this.buffer[this.elementsCount++] = e1;
  }



  
  public void push(int e1, int e2) {
    ensureBufferSpace(2);
    this.buffer[this.elementsCount++] = e1;
    this.buffer[this.elementsCount++] = e2;
  }



  
  public void push(int e1, int e2, int e3) {
    ensureBufferSpace(3);
    this.buffer[this.elementsCount++] = e1;
    this.buffer[this.elementsCount++] = e2;
    this.buffer[this.elementsCount++] = e3;
  }



  
  public void push(int e1, int e2, int e3, int e4) {
    ensureBufferSpace(4);
    this.buffer[this.elementsCount++] = e1;
    this.buffer[this.elementsCount++] = e2;
    this.buffer[this.elementsCount++] = e3;
    this.buffer[this.elementsCount++] = e4;
  }



  
  public void push(int[] elements, int start, int len) {
    assert start >= 0 && len >= 0;
    
    ensureBufferSpace(len);
    System.arraycopy(elements, start, this.buffer, this.elementsCount, len);
    this.elementsCount += len;
  }









  
  public final void push(int... elements) { push(elements, 0, elements.length); }





  
  public int pushAll(IntContainer container) { return addAll(container); }





  
  public int pushAll(Iterable<? extends IntCursor> iterable) { return addAll(iterable); }




  
  public void discard(int count) {
    assert this.elementsCount >= count;
    
    this.elementsCount -= count;
  }




  
  public void discard() {
    assert this.elementsCount > 0;
    
    this.elementsCount--;
  }




  
  public int pop() {
    assert this.elementsCount > 0;
    
    int v = this.buffer[--this.elementsCount];
    
    return v;
  }



  
  public int peek() {
    assert this.elementsCount > 0;
    return this.buffer[this.elementsCount - 1];
  }




  
  public static IntStack from(int... elements) {
    IntStack stack = new IntStack(elements.length);
    stack.push(elements);
    return stack;
  }





  
  public IntStack clone() { return (IntStack)super.clone(); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\IntStack.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */