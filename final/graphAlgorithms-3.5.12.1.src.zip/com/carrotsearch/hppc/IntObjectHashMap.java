package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.IntCursor;
import com.carrotsearch.hppc.cursors.IntObjectCursor;
import com.carrotsearch.hppc.cursors.ObjectCursor;
import com.carrotsearch.hppc.predicates.IntObjectPredicate;
import com.carrotsearch.hppc.predicates.IntPredicate;
import com.carrotsearch.hppc.predicates.ObjectPredicate;
import com.carrotsearch.hppc.procedures.IntObjectProcedure;
import com.carrotsearch.hppc.procedures.IntProcedure;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Objects;





































































public class IntObjectHashMap<VType>
  implements IntObjectMap<VType>, Preallocable, Cloneable
{
  public int[] keys;
  public Object[] values;
  protected int keyMixer;
  protected int assigned;
  protected int mask;
  protected int resizeAt;
  protected boolean hasEmptyKey;
  protected double loadFactor;
  protected HashOrderMixingStrategy orderMixer;
  
  public IntObjectHashMap() { this(4); }









  
  public IntObjectHashMap(int expectedElements) { this(expectedElements, 0.75D); }












  
  public IntObjectHashMap(int expectedElements, double loadFactor) { this(expectedElements, loadFactor, HashOrderMixing.defaultStrategy()); }














  
  public IntObjectHashMap(int expectedElements, double loadFactor, HashOrderMixingStrategy orderMixer) {
    this.orderMixer = orderMixer;
    this.loadFactor = verifyLoadFactor(loadFactor);
    ensureCapacity(expectedElements);
  }



  
  public IntObjectHashMap(IntObjectAssociativeContainer<? extends VType> container) {
    this(container.size());
    putAll(container);
  }




  
  public VType put(int key, VType value) {
    assert this.assigned < this.mask + 1;
    
    int mask = this.mask;
    if (key == 0) {
      this.hasEmptyKey = true;
      VType previousValue = (VType)this.values[mask + 1];
      this.values[mask + 1] = value;
      return previousValue;
    } 
    int[] keys = this.keys;
    int slot = hashKey(key) & mask;
    
    int existing;
    while ((existing = keys[slot]) != 0) {
      if (existing == key) {
        VType previousValue = (VType)this.values[slot];
        this.values[slot] = value;
        return previousValue;
      } 
      slot = slot + 1 & mask;
    } 
    
    if (this.assigned == this.resizeAt) {
      allocateThenInsertThenRehash(slot, key, value);
    } else {
      keys[slot] = key;
      this.values[slot] = value;
    } 
    
    this.assigned++;
    return null;
  }





  
  public int putAll(IntObjectAssociativeContainer<? extends VType> container) {
    int count = size();
    for (IntObjectCursor<? extends VType> c : container) {
      put(c.key, (VType)c.value);
    }
    return size() - count;
  }




  
  public int putAll(Iterable<? extends IntObjectCursor<? extends VType>> iterable) {
    int count = size();
    for (IntObjectCursor<? extends VType> c : iterable) {
      put(c.key, (VType)c.value);
    }
    return size() - count;
  }












  
  public boolean putIfAbsent(int key, VType value) {
    int keyIndex = indexOf(key);
    if (!indexExists(keyIndex)) {
      indexInsert(keyIndex, key, value);
      return true;
    } 
    return false;
  }









  
  public VType remove(int key) {
    int mask = this.mask;
    if (key == 0) {
      this.hasEmptyKey = false;
      VType previousValue = (VType)this.values[mask + 1];
      this.values[mask + 1] = null;
      return previousValue;
    } 
    int[] keys = this.keys;
    int slot = hashKey(key) & mask;
    
    int existing;
    while ((existing = keys[slot]) != 0) {
      if (existing == key) {
        VType previousValue = (VType)this.values[slot];
        shiftConflictingKeys(slot);
        return previousValue;
      } 
      slot = slot + 1 & mask;
    } 
    
    return null;
  }





  
  public int removeAll(IntContainer other) {
    int before = size();




    
    if (other.size() >= size() && other instanceof IntLookupContainer) {
      
      if (this.hasEmptyKey && 
        other.contains(0)) {
        this.hasEmptyKey = false;
        this.values[this.mask + 1] = null;
      } 

      
      int[] keys = this.keys;
      for (int slot = 0, max = this.mask; slot <= max; ) {
        int existing;
        if ((existing = keys[slot]) != 0 && other.contains(existing)) {
          
          shiftConflictingKeys(slot); continue;
        } 
        slot++;
      } 
    } else {
      
      for (IntCursor c : other) {
        remove(c.value);
      }
    } 
    
    return before - size();
  }




  
  public int removeAll(IntObjectPredicate<? super VType> predicate) {
    int before = size();
    
    int mask = this.mask;
    
    if (this.hasEmptyKey && 
      predicate.apply(0, this.values[mask + 1])) {
      this.hasEmptyKey = false;
      this.values[mask + 1] = null;
    } 

    
    int[] keys = this.keys;
    VType[] values = (VType[])this.values;
    for (int slot = 0; slot <= mask; ) {
      int existing;
      if ((existing = keys[slot]) != 0 && predicate.apply(existing, values[slot])) {

        
        shiftConflictingKeys(slot); continue;
      } 
      slot++;
    } 

    
    return before - size();
  }




  
  public int removeAll(IntPredicate predicate) {
    int before = size();
    
    if (this.hasEmptyKey && 
      predicate.apply(0)) {
      this.hasEmptyKey = false;
      this.values[this.mask + 1] = null;
    } 

    
    int[] keys = this.keys;
    for (int slot = 0, max = this.mask; slot <= max; ) {
      int existing;
      if ((existing = keys[slot]) != 0 && predicate.apply(existing)) {

        
        shiftConflictingKeys(slot); continue;
      } 
      slot++;
    } 

    
    return before - size();
  }




  
  public VType get(int key) {
    if (key == 0) {
      return this.hasEmptyKey ? (VType)this.values[this.mask + 1] : null;
    }
    int[] keys = this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    int existing;
    while ((existing = keys[slot]) != 0) {
      if (existing == key) {
        return (VType)this.values[slot];
      }
      slot = slot + 1 & mask;
    } 
    
    return null;
  }





  
  public VType getOrDefault(int key, VType defaultValue) {
    if (key == 0) {
      return this.hasEmptyKey ? (VType)this.values[this.mask + 1] : defaultValue;
    }
    int[] keys = this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    int existing;
    while ((existing = keys[slot]) != 0) {
      if (existing == key) {
        return (VType)this.values[slot];
      }
      slot = slot + 1 & mask;
    } 
    
    return defaultValue;
  }





  
  public boolean containsKey(int key) {
    if (key == 0) {
      return this.hasEmptyKey;
    }
    int[] keys = this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    int existing;
    while ((existing = keys[slot]) != 0) {
      if (existing == key) {
        return true;
      }
      slot = slot + 1 & mask;
    } 
    
    return false;
  }





  
  public int indexOf(int key) {
    int mask = this.mask;
    if (key == 0) {
      return this.hasEmptyKey ? (mask + 1) : (mask + 1 ^ 0xFFFFFFFF);
    }
    int[] keys = this.keys;
    int slot = hashKey(key) & mask;
    
    int existing;
    while ((existing = keys[slot]) != 0) {
      if (existing == key) {
        return slot;
      }
      slot = slot + 1 & mask;
    } 
    
    return slot ^ 0xFFFFFFFF;
  }





  
  public boolean indexExists(int index) {
    assert index == this.mask + 1 && this.hasEmptyKey;


    
    return (index >= 0);
  }




  
  public VType indexGet(int index) {
    assert index >= 0 : "The index must point at an existing key.";
    assert index <= this.mask || (index == this.mask + 1 && this.hasEmptyKey);

    
    return (VType)this.values[index];
  }




  
  public VType indexReplace(int index, VType newValue) {
    assert index >= 0 : "The index must point at an existing key.";
    assert index <= this.mask || (index == this.mask + 1 && this.hasEmptyKey);

    
    VType previousValue = (VType)this.values[index];
    this.values[index] = newValue;
    return previousValue;
  }




  
  public void indexInsert(int index, int key, VType value) {
    assert index < 0 : "The index must not point at an existing key.";
    
    index ^= 0xFFFFFFFF;
    if (key == 0) {
      assert index == this.mask + 1;
      this.values[index] = value;
      this.hasEmptyKey = true;
    } else {
      assert this.keys[index] == 0;
      
      if (this.assigned == this.resizeAt) {
        allocateThenInsertThenRehash(index, key, value);
      } else {
        this.keys[index] = key;
        this.values[index] = value;
      } 
      
      this.assigned++;
    } 
  }




  
  public void clear() {
    this.assigned = 0;
    this.hasEmptyKey = false;
    
    Arrays.fill(this.keys, 0);

    
    Arrays.fill(this.values, null);
  }





  
  public void release() {
    this.assigned = 0;
    this.hasEmptyKey = false;
    
    this.keys = null;
    this.values = null;
    ensureCapacity(4);
  }





  
  public int size() { return this.assigned + (this.hasEmptyKey ? 1 : 0); }





  
  public boolean isEmpty() { return (size() == 0); }





  
  public int hashCode() {
    int h = this.hasEmptyKey ? -559038737 : 0;
    for (IntObjectCursor<VType> c : this) {
      h += BitMixer.mix(c.key) + BitMixer.mix(c.value);
    }
    
    return h;
  }





  
  public boolean equals(Object obj) { return (obj != null && getClass() == obj.getClass() && equalElements((IntObjectHashMap)getClass().cast(obj))); }







  
  protected boolean equalElements(IntObjectHashMap<?> other) {
    if (other.size() != size()) {
      return false;
    }
    
    for (IntObjectCursor<?> c : other) {
      int key = c.key;
      if (!containsKey(key) || !Objects.equals(get(key), c.value))
      {
        return false;
      }
    } 
    
    return true;
  }







  
  public void ensureCapacity(int expectedElements) {
    if (expectedElements > this.resizeAt || this.keys == null) {
      int[] prevKeys = this.keys;
      VType[] prevValues = (VType[])this.values;
      allocateBuffers(HashContainers.minBufferSize(expectedElements, this.loadFactor));
      if (prevKeys != null && !isEmpty()) {
        rehash(prevKeys, prevValues);
      }
    } 
  }

  
  private final class EntryIterator
    extends AbstractIterator<IntObjectCursor<VType>>
  {
    private final IntObjectCursor<VType> cursor;
    private final int max = IntObjectHashMap.this.mask + 1;
    private int slot = -1;

    
    public EntryIterator() { this.cursor = new IntObjectCursor(); }


    
    protected IntObjectCursor<VType> fetch() {
      if (this.slot < this.max) {
        
        this.slot++; for (; this.slot < this.max; this.slot++) {
          int existing; if ((existing = IntObjectHashMap.this.keys[this.slot]) != 0) {
            this.cursor.index = this.slot;
            this.cursor.key = existing;
            this.cursor.value = IntObjectHashMap.this.values[this.slot];
            return this.cursor;
          } 
        } 
      } 
      
      if (this.slot == this.max && IntObjectHashMap.this.hasEmptyKey) {
        this.cursor.index = this.slot;
        this.cursor.key = 0;
        this.cursor.value = IntObjectHashMap.this.values[this.max];
        this.slot++;
        return this.cursor;
      } 
      
      return done();
    }
  }





  
  public Iterator<IntObjectCursor<VType>> iterator() { return new EntryIterator(); }





  
  public <T extends IntObjectProcedure<? super VType>> T forEach(T procedure) {
    int[] keys = this.keys;
    VType[] values = (VType[])this.values;
    
    if (this.hasEmptyKey) {
      procedure.apply(0, values[this.mask + 1]);
    }
    
    for (int slot = 0, max = this.mask; slot <= max; slot++) {
      if (keys[slot] != 0) {
        procedure.apply(keys[slot], values[slot]);
      }
    } 
    
    return procedure;
  }




  
  public <T extends IntObjectPredicate<? super VType>> T forEach(T predicate) {
    int[] keys = this.keys;
    VType[] values = (VType[])this.values;
    
    if (this.hasEmptyKey && 
      !predicate.apply(0, values[this.mask + 1])) {
      return predicate;
    }

    
    for (int slot = 0, max = this.mask; slot <= max && (
      keys[slot] == 0 || 
      predicate.apply(keys[slot], values[slot])); slot++);




    
    return predicate;
  }





  
  public KeysContainer keys() { return new KeysContainer(); }


  
  public final class KeysContainer
    extends AbstractIntCollection
    implements IntLookupContainer
  {
    private final IntObjectHashMap<VType> owner = IntObjectHashMap.this;


    
    public boolean contains(int e) { return this.owner.containsKey(e); }


    
    public <T extends IntProcedure> T forEach(final T procedure) {
      this.owner.forEach(new IntObjectProcedure<VType>()
          {
            public void apply(int key, VType value) {
              procedure.apply(key);
            }
          });
      
      return procedure;
    }

    
    public <T extends IntPredicate> T forEach(final T predicate) {
      this.owner.forEach(new IntObjectPredicate<VType>()
          {
            public boolean apply(int key, VType value) {
              return predicate.apply(key);
            }
          });
      
      return predicate;
    }


    
    public boolean isEmpty() { return this.owner.isEmpty(); }



    
    public Iterator<IntCursor> iterator() { return new IntObjectHashMap.KeysIterator(); }



    
    public int size() { return this.owner.size(); }



    
    public void clear() { this.owner.clear(); }



    
    public void release() { this.owner.release(); }



    
    public int removeAll(IntPredicate predicate) { return this.owner.removeAll(predicate); }


    
    public int removeAll(int e) {
      boolean hasKey = this.owner.containsKey(e);
      if (hasKey) {
        this.owner.remove(e);
        return 1;
      } 
      return 0;
    }
  }

  
  private final class KeysIterator
    extends AbstractIterator<IntCursor>
  {
    private final IntCursor cursor;
    
    private final int max = IntObjectHashMap.this.mask + 1;
    private int slot = -1;

    
    public KeysIterator() { this.cursor = new IntCursor(); }


    
    protected IntCursor fetch() {
      if (this.slot < this.max) {
        
        this.slot++; for (; this.slot < this.max; this.slot++) {
          int existing; if ((existing = IntObjectHashMap.this.keys[this.slot]) != 0) {
            this.cursor.index = this.slot;
            this.cursor.value = existing;
            return this.cursor;
          } 
        } 
      } 
      
      if (this.slot == this.max && IntObjectHashMap.this.hasEmptyKey) {
        this.cursor.index = this.slot;
        this.cursor.value = 0;
        this.slot++;
        return this.cursor;
      } 
      
      return done();
    }
  }




  
  public ObjectCollection<VType> values() {
    return new ValuesContainer();
  }

  
  private final class ValuesContainer
    extends AbstractObjectCollection<VType>
  {
    private final IntObjectHashMap<VType> owner = IntObjectHashMap.this;


    
    public int size() { return this.owner.size(); }



    
    public boolean isEmpty() { return this.owner.isEmpty(); }


    
    public boolean contains(VType value) {
      for (IntObjectCursor<VType> c : this.owner) {
        if (Objects.equals(c.value, value)) {
          return true;
        }
      } 
      return false;
    }

    
    public <T extends com.carrotsearch.hppc.procedures.ObjectProcedure<? super VType>> T forEach(T procedure) {
      for (IntObjectCursor<VType> c : this.owner) {
        procedure.apply(c.value);
      }
      return procedure;
    }

    
    public <T extends ObjectPredicate<? super VType>> T forEach(T predicate) {
      for (IntObjectCursor<VType> c : this.owner) {
        if (!predicate.apply(c.value)) {
          break;
        }
      } 
      return predicate;
    }


    
    public Iterator<ObjectCursor<VType>> iterator() { return new IntObjectHashMap.ValuesIterator(); }


    
    public int removeAll(final VType e) {
      return this.owner.removeAll(new IntObjectPredicate<VType>()
          {
            public boolean apply(int key, VType value) {
              return Objects.equals(value, e);
            }
          });
    }

    
    public int removeAll(final ObjectPredicate<? super VType> predicate) {
      return this.owner.removeAll(new IntObjectPredicate<VType>()
          {
            public boolean apply(int key, VType value) {
              return predicate.apply(value);
            }
          });
    }


    
    public void clear() { this.owner.clear(); }



    
    public void release() { this.owner.release(); }
    
    private ValuesContainer() {}
  }
  
  private final class ValuesIterator
    extends AbstractIterator<ObjectCursor<VType>>
  {
    private final ObjectCursor<VType> cursor;
    private final int max = IntObjectHashMap.this.mask + 1;
    private int slot = -1;

    
    public ValuesIterator() { this.cursor = new ObjectCursor(); }


    
    protected ObjectCursor<VType> fetch() {
      if (this.slot < this.max) {
        this.slot++; for (; this.slot < this.max; this.slot++) {
          if (IntObjectHashMap.this.keys[this.slot] != 0) {
            this.cursor.index = this.slot;
            this.cursor.value = IntObjectHashMap.this.values[this.slot];
            return this.cursor;
          } 
        } 
      } 
      
      if (this.slot == this.max && IntObjectHashMap.this.hasEmptyKey) {
        this.cursor.index = this.slot;
        this.cursor.value = IntObjectHashMap.this.values[this.max];
        this.slot++;
        return this.cursor;
      } 
      
      return done();
    }
  }





  
  public IntObjectHashMap<VType> clone() {
    try {
      IntObjectHashMap<VType> cloned = (IntObjectHashMap<VType>)super.clone();
      cloned.keys = (int[])this.keys.clone();
      cloned.values = (Object[])this.values.clone();
      cloned.hasEmptyKey = cloned.hasEmptyKey;
      cloned.orderMixer = this.orderMixer.clone();
      return cloned;
    } catch (CloneNotSupportedException e) {
      throw new RuntimeException(e);
    } 
  }




  
  public String toString() {
    StringBuilder buffer = new StringBuilder();
    buffer.append("[");
    
    boolean first = true;
    for (IntObjectCursor<VType> cursor : this) {
      if (!first) {
        buffer.append(", ");
      }
      buffer.append(cursor.key);
      buffer.append("=>");
      buffer.append(cursor.value);
      first = false;
    } 
    buffer.append("]");
    return buffer.toString();
  }


  
  public String visualizeKeyDistribution(int characters) { return IntBufferVisualizer.visualizeKeyDistribution(this.keys, this.mask, characters); }




  
  public static <VType> IntObjectHashMap<VType> from(int[] keys, VType[] values) {
    if (keys.length != values.length) {
      throw new IllegalArgumentException("Arrays of keys and values must have an identical length.");
    }
    
    IntObjectHashMap<VType> map = new IntObjectHashMap<>(keys.length);
    for (int i = 0; i < keys.length; i++) {
      map.put(keys[i], values[i]);
    }
    
    return map;
  }












  
  protected int hashKey(int key) {
    assert key != 0;
    return BitMixer.mix(key, this.keyMixer);
  }




  
  protected double verifyLoadFactor(double loadFactor) {
    HashContainers.checkLoadFactor(loadFactor, 0.009999999776482582D, 0.9900000095367432D);
    return loadFactor;
  }



  
  protected void rehash(int[] fromKeys, VType[] fromValues) {
    assert fromKeys.length == fromValues.length && HashContainers.checkPowerOfTwo(fromKeys.length - 1);


    
    int[] keys = this.keys;
    VType[] values = (VType[])this.values;
    int mask = this.mask;


    
    int from = fromKeys.length - 1;
    keys[keys.length - 1] = fromKeys[from];
    values[values.length - 1] = fromValues[from];
    while (--from >= 0) {
      int existing; if ((existing = fromKeys[from]) != 0) {
        int slot = hashKey(existing) & mask;
        while (keys[slot] != 0) {
          slot = slot + 1 & mask;
        }
        keys[slot] = existing;
        values[slot] = fromValues[from];
      } 
    } 
  }




  
  protected void allocateBuffers(int arraySize) {
    assert Integer.bitCount(arraySize) == 1;

    
    int newKeyMixer = this.orderMixer.newKeyMixer(arraySize);

    
    int[] prevKeys = this.keys;
    VType[] prevValues = (VType[])this.values;
    try {
      int emptyElementSlot = 1;
      this.keys = new int[arraySize + emptyElementSlot];
      this.values = new Object[arraySize + emptyElementSlot];
    } catch (OutOfMemoryError e) {
      this.keys = prevKeys;
      this.values = (Object[])prevValues;
      throw new BufferAllocationException("Not enough memory to allocate buffers for rehashing: %,d -> %,d", e, new Object[] { Integer.valueOf(this.mask + 1), Integer.valueOf(arraySize) });
    } 




    
    this.resizeAt = HashContainers.expandAtCount(arraySize, this.loadFactor);
    this.keyMixer = newKeyMixer;
    this.mask = arraySize - 1;
  }









  
  protected void allocateThenInsertThenRehash(int slot, int pendingKey, VType pendingValue) {
    assert this.assigned == this.resizeAt && this.keys[slot] == 0 && pendingKey != 0;



    
    int[] prevKeys = this.keys;
    VType[] prevValues = (VType[])this.values;
    allocateBuffers(HashContainers.nextBufferSize(this.mask + 1, size(), this.loadFactor));
    assert this.keys.length > prevKeys.length;


    
    prevKeys[slot] = pendingKey;
    prevValues[slot] = pendingValue;

    
    rehash(prevKeys, prevValues);
  }




  
  protected void shiftConflictingKeys(int gapSlot) {
    int[] keys = this.keys;
    VType[] values = (VType[])this.values;
    int mask = this.mask;

    
    int distance = 0;
    while (true) {
      int slot = gapSlot + ++distance & mask;
      int existing = keys[slot];
      if (existing == 0) {
        break;
      }
      
      int idealSlot = hashKey(existing);
      int shift = slot - idealSlot & mask;
      if (shift >= distance) {



        
        keys[gapSlot] = existing;
        values[gapSlot] = values[slot];
        gapSlot = slot;
        distance = 0;
      } 
    } 

    
    keys[gapSlot] = 0;
    values[gapSlot] = null;
    this.assigned--;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\IntObjectHashMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */