package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.LongFloatCursor;

public interface LongFloatMap extends LongFloatAssociativeContainer {
  float get(long paramLong);
  
  float getOrDefault(long paramLong, float paramFloat);
  
  float put(long paramLong, float paramFloat);
  
  int putAll(LongFloatAssociativeContainer paramLongFloatAssociativeContainer);
  
  int putAll(Iterable<? extends LongFloatCursor> paramIterable);
  
  float putOrAdd(long paramLong, float paramFloat1, float paramFloat2);
  
  float addTo(long paramLong, float paramFloat);
  
  float remove(long paramLong);
  
  boolean equals(Object paramObject);
  
  int hashCode();
  
  int indexOf(long paramLong);
  
  boolean indexExists(int paramInt);
  
  float indexGet(int paramInt);
  
  float indexReplace(int paramInt, float paramFloat);
  
  void indexInsert(int paramInt, long paramLong, float paramFloat);
  
  void clear();
  
  void release();
  
  String visualizeKeyDistribution(int paramInt);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\LongFloatMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */