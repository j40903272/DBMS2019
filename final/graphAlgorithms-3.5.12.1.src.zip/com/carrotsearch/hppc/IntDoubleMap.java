package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.IntDoubleCursor;

public interface IntDoubleMap extends IntDoubleAssociativeContainer {
  double get(int paramInt);
  
  double getOrDefault(int paramInt, double paramDouble);
  
  double put(int paramInt, double paramDouble);
  
  int putAll(IntDoubleAssociativeContainer paramIntDoubleAssociativeContainer);
  
  int putAll(Iterable<? extends IntDoubleCursor> paramIterable);
  
  double putOrAdd(int paramInt, double paramDouble1, double paramDouble2);
  
  double addTo(int paramInt, double paramDouble);
  
  double remove(int paramInt);
  
  boolean equals(Object paramObject);
  
  int hashCode();
  
  int indexOf(int paramInt);
  
  boolean indexExists(int paramInt);
  
  double indexGet(int paramInt);
  
  double indexReplace(int paramInt, double paramDouble);
  
  void indexInsert(int paramInt1, int paramInt2, double paramDouble);
  
  void clear();
  
  void release();
  
  String visualizeKeyDistribution(int paramInt);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\IntDoubleMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */