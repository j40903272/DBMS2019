package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.LongCursor;
import com.carrotsearch.hppc.predicates.LongPredicate;
import java.util.Arrays;
import java.util.Iterator;








































































public class LongHashSet
  extends AbstractLongCollection
  implements LongLookupContainer, LongSet, Preallocable, Cloneable
{
  public long[] keys;
  protected int assigned;
  protected int mask;
  protected int keyMixer;
  protected int resizeAt;
  protected boolean hasEmptyKey;
  protected double loadFactor;
  protected HashOrderMixingStrategy orderMixer;
  
  public LongHashSet() { this(4, 0.75D); }







  
  public LongHashSet(int expectedElements) { this(expectedElements, 0.75D); }







  
  public LongHashSet(int expectedElements, double loadFactor) { this(expectedElements, loadFactor, HashOrderMixing.defaultStrategy()); }














  
  public LongHashSet(int expectedElements, double loadFactor, HashOrderMixingStrategy orderMixer) {
    this.orderMixer = orderMixer;
    this.loadFactor = verifyLoadFactor(loadFactor);
    ensureCapacity(expectedElements);
  }



  
  public LongHashSet(LongContainer container) {
    this(container.size());
    addAll(container);
  }




  
  public boolean add(long key) {
    if (key == 0L) {
      assert this.keys[this.mask + 1] == 0L;
      boolean added = !this.hasEmptyKey;
      this.hasEmptyKey = true;
      return added;
    } 
    long[] keys = this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        return false;
      }
      slot = slot + 1 & mask;
    } 
    
    if (this.assigned == this.resizeAt) {
      allocateThenInsertThenRehash(slot, key);
    } else {
      keys[slot] = key;
    } 
    
    this.assigned++;
    return true;
  }








  
  public final int addAll(long... elements) {
    ensureCapacity(elements.length);
    int count = 0;
    for (long e : elements) {
      if (add(e)) {
        count++;
      }
    } 
    return count;
  }






  
  public int addAll(LongContainer container) {
    ensureCapacity(container.size());
    return addAll(container);
  }






  
  public int addAll(Iterable<? extends LongCursor> iterable) {
    int count = 0;
    for (LongCursor cursor : iterable) {
      if (add(cursor.value)) {
        count++;
      }
    } 
    return count;
  }





  
  public long[] toArray() {
    long[] cloned = new long[size()];
    int j = 0;
    if (this.hasEmptyKey) {
      cloned[j++] = 0L;
    }
    
    long[] keys = this.keys;
    for (int slot = 0, max = this.mask; slot <= max; slot++) {
      long existing;
      if ((existing = keys[slot]) != 0L) {
        cloned[j++] = existing;
      }
    } 
    
    return cloned;
  }



  
  public boolean remove(long key) {
    if (key == 0L) {
      boolean hadEmptyKey = this.hasEmptyKey;
      this.hasEmptyKey = false;
      return hadEmptyKey;
    } 
    long[] keys = this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        shiftConflictingKeys(slot);
        return true;
      } 
      slot = slot + 1 & mask;
    } 
    return false;
  }






  
  public int removeAll(long key) { return remove(key) ? 1 : 0; }





  
  public int removeAll(LongPredicate predicate) {
    int before = size();
    
    if (this.hasEmptyKey && 
      predicate.apply(0L)) {
      this.hasEmptyKey = false;
    }

    
    long[] keys = this.keys;
    for (int slot = 0, max = this.mask; slot <= max; ) {
      long existing;
      if ((existing = keys[slot]) != 0L && 
        predicate.apply(existing)) {
        shiftConflictingKeys(slot);
        
        continue;
      } 
      slot++;
    } 
    
    return before - size();
  }




  
  public boolean contains(long key) {
    if (key == 0L) {
      return this.hasEmptyKey;
    }
    long[] keys = this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        return true;
      }
      slot = slot + 1 & mask;
    } 
    return false;
  }





  
  public void clear() {
    this.assigned = 0;
    this.hasEmptyKey = false;
    Arrays.fill(this.keys, 0L);
  }




  
  public void release() {
    this.assigned = 0;
    this.hasEmptyKey = false;
    this.keys = null;
    ensureCapacity(4);
  }





  
  public boolean isEmpty() { return (size() == 0); }








  
  public void ensureCapacity(int expectedElements) {
    if (expectedElements > this.resizeAt || this.keys == null) {
      long[] prevKeys = this.keys;
      allocateBuffers(HashContainers.minBufferSize(expectedElements, this.loadFactor));
      if (prevKeys != null && !isEmpty()) {
        rehash(prevKeys);
      }
    } 
  }





  
  public int size() { return this.assigned + (this.hasEmptyKey ? 1 : 0); }





  
  public int hashCode() {
    int h = this.hasEmptyKey ? -559038737 : 0;
    long[] keys = this.keys;
    for (int slot = this.mask; slot >= 0; slot--) {
      long existing;
      if ((existing = keys[slot]) != 0L) {
        h += BitMixer.mix(existing);
      }
    } 
    return h;
  }





  
  public boolean equals(Object obj) { return (obj != null && getClass() == obj.getClass() && sameKeys((LongSet)getClass().cast(obj))); }






  
  private boolean sameKeys(LongSet other) {
    if (other.size() != size()) {
      return false;
    }
    
    for (LongCursor c : other) {
      if (!contains(c.value)) {
        return false;
      }
    } 
    
    return true;
  }





  
  public LongHashSet clone() {
    try {
      LongHashSet cloned = (LongHashSet)super.clone();
      cloned.keys = (long[])this.keys.clone();
      cloned.hasEmptyKey = cloned.hasEmptyKey;
      cloned.orderMixer = this.orderMixer.clone();
      return cloned;
    } catch (CloneNotSupportedException e) {
      throw new RuntimeException(e);
    } 
  }





  
  public Iterator<LongCursor> iterator() { return new EntryIterator(); }

  
  protected final class EntryIterator
    extends AbstractIterator<LongCursor>
  {
    private final LongCursor cursor;
    
    private final int max = LongHashSet.this.mask + 1;
    private int slot = -1;

    
    public EntryIterator() { this.cursor = new LongCursor(); }


    
    protected LongCursor fetch() {
      if (this.slot < this.max) {
        
        this.slot++; for (; this.slot < this.max; this.slot++) {
          long existing; if ((existing = LongHashSet.this.keys[this.slot]) != 0L) {
            this.cursor.index = this.slot;
            this.cursor.value = existing;
            return this.cursor;
          } 
        } 
      } 
      
      if (this.slot == this.max && LongHashSet.this.hasEmptyKey) {
        this.cursor.index = this.slot;
        this.cursor.value = 0L;
        this.slot++;
        return this.cursor;
      } 
      
      return done();
    }
  }




  
  public <T extends com.carrotsearch.hppc.procedures.LongProcedure> T forEach(T procedure) {
    if (this.hasEmptyKey) {
      procedure.apply(0L);
    }
    
    long[] keys = this.keys;
    for (int slot = 0, max = this.mask; slot <= max; slot++) {
      long existing;
      if ((existing = keys[slot]) != 0L) {
        procedure.apply(existing);
      }
    } 
    
    return procedure;
  }




  
  public <T extends LongPredicate> T forEach(T predicate) {
    if (this.hasEmptyKey && 
      !predicate.apply(0L)) {
      return predicate;
    }

    
    long[] keys = this.keys;
    for (int slot = 0, max = this.mask; slot <= max; slot++) {
      long existing;
      if ((existing = keys[slot]) != 0L && 
        !predicate.apply(existing)) {
        break;
      }
    } 

    
    return predicate;
  }






  
  public static LongHashSet from(long... elements) {
    LongHashSet set = new LongHashSet(elements.length);
    set.addAll(elements);
    return set;
  }












  
  protected int hashKey(long key) {
    assert key != 0L;
    return BitMixer.mix(key, this.keyMixer);
  }




















  
  public int indexOf(long key) {
    int mask = this.mask;
    if (key == 0L) {
      return this.hasEmptyKey ? (mask + 1) : (mask + 1 ^ 0xFFFFFFFF);
    }
    long[] keys = this.keys;
    int slot = hashKey(key) & mask;
    
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        return slot;
      }
      slot = slot + 1 & mask;
    } 
    
    return slot ^ 0xFFFFFFFF;
  }









  
  public boolean indexExists(int index) {
    assert index == this.mask + 1 && this.hasEmptyKey;


    
    return (index >= 0);
  }











  
  public long indexGet(int index) {
    assert index >= 0 : "The index must point at an existing key.";
    assert index <= this.mask || (index == this.mask + 1 && this.hasEmptyKey);

    
    return this.keys[index];
  }













  
  public long indexReplace(int index, long equivalentKey) {
    assert index >= 0 : "The index must point at an existing key.";
    assert index <= this.mask || (index == this.mask + 1 && this.hasEmptyKey);
    
    assert equivalentKey == this.keys[index];
    
    long previousValue = this.keys[index];
    this.keys[index] = equivalentKey;
    return previousValue;
  }











  
  public void indexInsert(int index, long key) {
    assert index < 0 : "The index must not point at an existing key.";
    
    index ^= 0xFFFFFFFF;
    if (key == 0L) {
      assert index == this.mask + 1;
      assert this.keys[index] == 0L;
      this.hasEmptyKey = true;
    } else {
      assert this.keys[index] == 0L;
      
      if (this.assigned == this.resizeAt) {
        allocateThenInsertThenRehash(index, key);
      } else {
        this.keys[index] = key;
      } 
      
      this.assigned++;
    } 
  }


  
  public String visualizeKeyDistribution(int characters) { return LongBufferVisualizer.visualizeKeyDistribution(this.keys, this.mask, characters); }





  
  protected double verifyLoadFactor(double loadFactor) {
    HashContainers.checkLoadFactor(loadFactor, 0.009999999776482582D, 0.9900000095367432D);
    return loadFactor;
  }



  
  protected void rehash(long[] fromKeys) {
    assert HashContainers.checkPowerOfTwo(fromKeys.length - 1);

    
    long[] keys = this.keys;
    int mask = this.mask;
    
    for (int i = fromKeys.length - 1; --i >= 0;) {
      if ((existing = fromKeys[i]) != 0L) {
        int slot = hashKey(existing) & mask;
        while (keys[slot] != 0L) {
          slot = slot + 1 & mask;
        }
        keys[slot] = existing;
      } 
    } 
  }




  
  protected void allocateBuffers(int arraySize) {
    assert Integer.bitCount(arraySize) == 1;

    
    int newKeyMixer = this.orderMixer.newKeyMixer(arraySize);

    
    long[] prevKeys = this.keys;
    try {
      int emptyElementSlot = 1;
      this.keys = new long[arraySize + emptyElementSlot];
    } catch (OutOfMemoryError e) {
      this.keys = prevKeys;
      throw new BufferAllocationException("Not enough memory to allocate buffers for rehashing: %,d -> %,d", e, new Object[] { Integer.valueOf((this.keys == null) ? 0 : size()), Integer.valueOf(arraySize) });
    } 




    
    this.resizeAt = HashContainers.expandAtCount(arraySize, this.loadFactor);
    this.keyMixer = newKeyMixer;
    this.mask = arraySize - 1;
  }









  
  protected void allocateThenInsertThenRehash(int slot, long pendingKey) {
    assert this.assigned == this.resizeAt && this.keys[slot] == 0L && pendingKey != 0L;



    
    long[] prevKeys = this.keys;
    allocateBuffers(HashContainers.nextBufferSize(this.mask + 1, size(), this.loadFactor));
    assert this.keys.length > prevKeys.length;


    
    prevKeys[slot] = pendingKey;

    
    rehash(prevKeys);
  }



  
  protected void shiftConflictingKeys(int gapSlot) {
    long[] keys = this.keys;
    int mask = this.mask;

    
    int distance = 0;
    while (true) {
      int slot = gapSlot + ++distance & mask;
      long existing = keys[slot];
      if (existing == 0L) {
        break;
      }
      
      int idealSlot = hashKey(existing);
      int shift = slot - idealSlot & mask;
      if (shift >= distance) {



        
        keys[gapSlot] = existing;
        gapSlot = slot;
        distance = 0;
      } 
    } 

    
    keys[gapSlot] = 0L;
    this.assigned--;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\LongHashSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */