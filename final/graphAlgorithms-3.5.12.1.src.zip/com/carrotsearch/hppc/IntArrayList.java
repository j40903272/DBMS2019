package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.IntCursor;
import com.carrotsearch.hppc.predicates.IntPredicate;
import java.util.Arrays;
import java.util.Iterator;



















public class IntArrayList
  extends AbstractIntCollection
  implements IntIndexedContainer, Preallocable, Cloneable
{
  public static final int[] EMPTY_ARRAY = new int[0];






  
  public int[] buffer = EMPTY_ARRAY;




  
  public int elementsCount;




  
  protected final ArraySizingStrategy resizer;





  
  public IntArrayList() { this(4); }









  
  public IntArrayList(int expectedElements) { this(expectedElements, new BoundedProportionalArraySizingStrategy()); }












  
  public IntArrayList(int expectedElements, ArraySizingStrategy resizer) {
    assert resizer != null;
    this.resizer = resizer;
    ensureCapacity(expectedElements);
  }




  
  public IntArrayList(IntContainer container) {
    this(container.size());
    addAll(container);
  }




  
  public void add(int e1) {
    ensureBufferSpace(1);
    this.buffer[this.elementsCount++] = e1;
  }





  
  public void add(int e1, int e2) {
    ensureBufferSpace(2);
    this.buffer[this.elementsCount++] = e1;
    this.buffer[this.elementsCount++] = e2;
  }



  
  public void add(int[] elements, int start, int length) {
    assert length >= 0 : "Length must be >= 0";
    
    ensureBufferSpace(length);
    System.arraycopy(elements, start, this.buffer, this.elementsCount, length);
    this.elementsCount += length;
  }









  
  public final void add(int... elements) { add(elements, 0, elements.length); }




  
  public int addAll(IntContainer container) {
    int size = container.size();
    ensureBufferSpace(size);
    
    for (IntCursor cursor : container) {
      add(cursor.value);
    }
    
    return size;
  }



  
  public int addAll(Iterable<? extends IntCursor> iterable) {
    int size = 0;
    for (IntCursor cursor : iterable) {
      add(cursor.value);
      size++;
    } 
    return size;
  }




  
  public void insert(int index, int e1) {
    assert index >= 0 && index <= size() : "Index " + index + " out of bounds [" + false + ", " + size() + "].";
    
    ensureBufferSpace(1);
    System.arraycopy(this.buffer, index, this.buffer, index + 1, this.elementsCount - index);
    this.buffer[index] = e1;
    this.elementsCount++;
  }




  
  public int get(int index) {
    assert index >= 0 && index < size() : "Index " + index + " out of bounds [" + false + ", " + size() + ").";
    
    return this.buffer[index];
  }




  
  public int set(int index, int e1) {
    assert index >= 0 && index < size() : "Index " + index + " out of bounds [" + false + ", " + size() + ").";
    
    int v = this.buffer[index];
    this.buffer[index] = e1;
    return v;
  }




  
  public int remove(int index) {
    assert index >= 0 && index < size() : "Index " + index + " out of bounds [" + false + ", " + size() + ").";
    
    int v = this.buffer[index];
    if (index + 1 < this.elementsCount) {
      System.arraycopy(this.buffer, index + 1, this.buffer, index, this.elementsCount - index - 1);
    }
    this.elementsCount--;
    this.buffer[this.elementsCount] = 0;
    return v;
  }





  
  public void removeRange(int fromIndex, int toIndex) {
    assert fromIndex >= 0 && fromIndex <= size() : "Index " + fromIndex + " out of bounds [" + false + ", " + size() + ").";
    
    assert toIndex >= 0 && toIndex <= size() : "Index " + toIndex + " out of bounds [" + false + ", " + size() + "].";
    
    assert fromIndex <= toIndex : "fromIndex must be <= toIndex: " + fromIndex + ", " + toIndex;
    
    System.arraycopy(this.buffer, toIndex, this.buffer, fromIndex, this.elementsCount - toIndex);
    int count = toIndex - fromIndex;
    this.elementsCount -= count;
    Arrays.fill(this.buffer, this.elementsCount, this.elementsCount + count, 0);
  }




  
  public int removeFirst(int e1) {
    int index = indexOf(e1);
    if (index >= 0)
      remove(index); 
    return index;
  }




  
  public int removeLast(int e1) {
    int index = lastIndexOf(e1);
    if (index >= 0)
      remove(index); 
    return index;
  }




  
  public int removeAll(int e1) {
    int to = 0;
    for (int from = 0; from < this.elementsCount; from++) {
      if (this.buffer[from] == e1) {
        this.buffer[from] = 0;
      }
      else {
        
        if (to != from) {
          this.buffer[to] = this.buffer[from];
          this.buffer[from] = 0;
        } 
        to++;
      } 
    } 
    int deleted = this.elementsCount - to;
    this.elementsCount = to;
    return deleted;
  }





  
  public boolean contains(int e1) { return (indexOf(e1) >= 0); }





  
  public int indexOf(int e1) {
    for (int i = 0; i < this.elementsCount; i++) {
      if (this.buffer[i] == e1) {
        return i;
      }
    } 
    
    return -1;
  }




  
  public int lastIndexOf(int e1) {
    for (int i = this.elementsCount - 1; i >= 0; i--) {
      if (this.buffer[i] == e1) {
        return i;
      }
    } 
    
    return -1;
  }





  
  public boolean isEmpty() { return (this.elementsCount == 0); }









  
  public void ensureCapacity(int expectedElements) {
    int bufferLen = (this.buffer == null) ? 0 : this.buffer.length;
    if (expectedElements > bufferLen) {
      ensureBufferSpace(expectedElements - size());
    }
  }




  
  protected void ensureBufferSpace(int expectedAdditions) {
    int bufferLen = (this.buffer == null) ? 0 : this.buffer.length;
    if (this.elementsCount + expectedAdditions > bufferLen) {
      int newSize = this.resizer.grow(bufferLen, this.elementsCount, expectedAdditions);
      assert newSize >= this.elementsCount + expectedAdditions : "Resizer failed to return sensible new size: " + newSize + " <= " + (this.elementsCount + expectedAdditions);

      
      this.buffer = Arrays.copyOf(this.buffer, newSize);
    } 
  }







  
  public void resize(int newSize) {
    if (newSize <= this.buffer.length) {
      if (newSize < this.elementsCount) {
        Arrays.fill(this.buffer, newSize, this.elementsCount, 0);
      } else {
        Arrays.fill(this.buffer, this.elementsCount, newSize, 0);
      } 
    } else {
      ensureCapacity(newSize);
    } 
    this.elementsCount = newSize;
  }





  
  public int size() { return this.elementsCount; }




  
  public void trimToSize() {
    if (size() != this.buffer.length) {
      this.buffer = toArray();
    }
  }






  
  public void clear() {
    Arrays.fill(this.buffer, 0, this.elementsCount, 0);
    this.elementsCount = 0;
  }





  
  public void release() {
    this.buffer = EMPTY_ARRAY;
    this.elementsCount = 0;
  }










  
  public int[] toArray() { return Arrays.copyOf(this.buffer, this.elementsCount); }







  
  public IntArrayList clone() {
    try {
      IntArrayList cloned = (IntArrayList)super.clone();
      cloned.buffer = (int[])this.buffer.clone();
      return cloned;
    } catch (CloneNotSupportedException e) {
      throw new RuntimeException(e);
    } 
  }




  
  public int hashCode() {
    int h = 1, max = this.elementsCount;
    for (int i = 0; i < max; i++) {
      h = 31 * h + BitMixer.mix(this.buffer[i]);
    }
    return h;
  }






  
  public boolean equals(Object obj) { return (obj != null && getClass() == obj.getClass() && equalElements((IntArrayList)getClass().cast(obj))); }







  
  protected boolean equalElements(IntArrayList other) {
    int max = size();
    if (other.size() != max) {
      return false;
    }
    
    for (int i = 0; i < max; i++) {
      if (other.get(i) != get(i)) {
        return false;
      }
    } 
    
    return true;
  }

  
  static final class ValueIterator
    extends AbstractIterator<IntCursor>
  {
    private final IntCursor cursor;
    
    private final int[] buffer;
    private final int size;
    
    public ValueIterator(int[] buffer, int size) {
      this.cursor = new IntCursor();
      this.cursor.index = -1;
      this.size = size;
      this.buffer = buffer;
    }

    
    protected IntCursor fetch() {
      if (this.cursor.index + 1 == this.size) {
        return done();
      }
      this.cursor.value = this.buffer[++this.cursor.index];
      return this.cursor;
    }
  }





  
  public Iterator<IntCursor> iterator() { return new ValueIterator(this.buffer, size()); }






  
  public <T extends com.carrotsearch.hppc.procedures.IntProcedure> T forEach(T procedure) { return forEach(procedure, 0, size()); }






  
  public <T extends com.carrotsearch.hppc.procedures.IntProcedure> T forEach(T procedure, int fromIndex, int toIndex) {
    assert fromIndex >= 0 && fromIndex <= size() : "Index " + fromIndex + " out of bounds [" + false + ", " + size() + ").";

    
    assert toIndex >= 0 && toIndex <= size() : "Index " + toIndex + " out of bounds [" + false + ", " + size() + "].";
    
    assert fromIndex <= toIndex : "fromIndex must be <= toIndex: " + fromIndex + ", " + toIndex;

    
    int[] buffer = this.buffer;
    for (int i = fromIndex; i < toIndex; i++) {
      procedure.apply(buffer[i]);
    }
    
    return procedure;
  }




  
  public int removeAll(IntPredicate predicate) {
    int[] buffer = this.buffer;
    int elementsCount = this.elementsCount;
    int to = 0;
    int from = 0;
    try {
      for (; from < elementsCount; from++) {
        if (predicate.apply(buffer[from])) {
          buffer[from] = 0;
        }
        else {
          
          if (to != from) {
            buffer[to] = buffer[from];
            buffer[from] = 0;
          } 
          to++;
        } 
      } 
    } finally {
      for (; from < elementsCount; from++) {
        if (to != from) {
          buffer[to] = buffer[from];
          buffer[from] = 0;
        } 
        to++;
      } 
      
      this.elementsCount = to;
    } 
    
    return elementsCount - to;
  }





  
  public <T extends IntPredicate> T forEach(T predicate) { return forEach(predicate, 0, size()); }







  
  public <T extends IntPredicate> T forEach(T predicate, int fromIndex, int toIndex) {
    assert fromIndex >= 0 && fromIndex <= size() : "Index " + fromIndex + " out of bounds [" + false + ", " + size() + ").";
    
    assert toIndex >= 0 && toIndex <= size() : "Index " + toIndex + " out of bounds [" + false + ", " + size() + "].";
    
    assert fromIndex <= toIndex : "fromIndex must be <= toIndex: " + fromIndex + ", " + toIndex;
    
    int[] buffer = this.buffer;
    for (int i = fromIndex; i < toIndex && 
      predicate.apply(buffer[i]); i++);


    
    return predicate;
  }





  
  public static IntArrayList from(int... elements) {
    IntArrayList list = new IntArrayList(elements.length);
    list.add(elements);
    return list;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\IntArrayList.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */