package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.IntCursor;
import com.carrotsearch.hppc.predicates.IntPredicate;
import java.util.Arrays;
import java.util.Iterator;








































































public class IntHashSet
  extends AbstractIntCollection
  implements IntLookupContainer, IntSet, Preallocable, Cloneable
{
  public int[] keys;
  protected int assigned;
  protected int mask;
  protected int keyMixer;
  protected int resizeAt;
  protected boolean hasEmptyKey;
  protected double loadFactor;
  protected HashOrderMixingStrategy orderMixer;
  
  public IntHashSet() { this(4, 0.75D); }







  
  public IntHashSet(int expectedElements) { this(expectedElements, 0.75D); }







  
  public IntHashSet(int expectedElements, double loadFactor) { this(expectedElements, loadFactor, HashOrderMixing.defaultStrategy()); }














  
  public IntHashSet(int expectedElements, double loadFactor, HashOrderMixingStrategy orderMixer) {
    this.orderMixer = orderMixer;
    this.loadFactor = verifyLoadFactor(loadFactor);
    ensureCapacity(expectedElements);
  }



  
  public IntHashSet(IntContainer container) {
    this(container.size());
    addAll(container);
  }




  
  public boolean add(int key) {
    if (key == 0) {
      assert this.keys[this.mask + 1] == 0;
      boolean added = !this.hasEmptyKey;
      this.hasEmptyKey = true;
      return added;
    } 
    int[] keys = this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    int existing;
    while ((existing = keys[slot]) != 0) {
      if (existing == key) {
        return false;
      }
      slot = slot + 1 & mask;
    } 
    
    if (this.assigned == this.resizeAt) {
      allocateThenInsertThenRehash(slot, key);
    } else {
      keys[slot] = key;
    } 
    
    this.assigned++;
    return true;
  }








  
  public final int addAll(int... elements) {
    ensureCapacity(elements.length);
    int count = 0;
    for (int e : elements) {
      if (add(e)) {
        count++;
      }
    } 
    return count;
  }






  
  public int addAll(IntContainer container) {
    ensureCapacity(container.size());
    return addAll(container);
  }






  
  public int addAll(Iterable<? extends IntCursor> iterable) {
    int count = 0;
    for (IntCursor cursor : iterable) {
      if (add(cursor.value)) {
        count++;
      }
    } 
    return count;
  }





  
  public int[] toArray() {
    int[] cloned = new int[size()];
    int j = 0;
    if (this.hasEmptyKey) {
      cloned[j++] = 0;
    }
    
    int[] keys = this.keys;
    for (int slot = 0, max = this.mask; slot <= max; slot++) {
      int existing;
      if ((existing = keys[slot]) != 0) {
        cloned[j++] = existing;
      }
    } 
    
    return cloned;
  }



  
  public boolean remove(int key) {
    if (key == 0) {
      boolean hadEmptyKey = this.hasEmptyKey;
      this.hasEmptyKey = false;
      return hadEmptyKey;
    } 
    int[] keys = this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    int existing;
    while ((existing = keys[slot]) != 0) {
      if (existing == key) {
        shiftConflictingKeys(slot);
        return true;
      } 
      slot = slot + 1 & mask;
    } 
    return false;
  }






  
  public int removeAll(int key) { return remove(key) ? 1 : 0; }





  
  public int removeAll(IntPredicate predicate) {
    int before = size();
    
    if (this.hasEmptyKey && 
      predicate.apply(0)) {
      this.hasEmptyKey = false;
    }

    
    int[] keys = this.keys;
    for (int slot = 0, max = this.mask; slot <= max; ) {
      int existing;
      if ((existing = keys[slot]) != 0 && 
        predicate.apply(existing)) {
        shiftConflictingKeys(slot);
        
        continue;
      } 
      slot++;
    } 
    
    return before - size();
  }




  
  public boolean contains(int key) {
    if (key == 0) {
      return this.hasEmptyKey;
    }
    int[] keys = this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    int existing;
    while ((existing = keys[slot]) != 0) {
      if (existing == key) {
        return true;
      }
      slot = slot + 1 & mask;
    } 
    return false;
  }





  
  public void clear() {
    this.assigned = 0;
    this.hasEmptyKey = false;
    Arrays.fill(this.keys, 0);
  }




  
  public void release() {
    this.assigned = 0;
    this.hasEmptyKey = false;
    this.keys = null;
    ensureCapacity(4);
  }





  
  public boolean isEmpty() { return (size() == 0); }








  
  public void ensureCapacity(int expectedElements) {
    if (expectedElements > this.resizeAt || this.keys == null) {
      int[] prevKeys = this.keys;
      allocateBuffers(HashContainers.minBufferSize(expectedElements, this.loadFactor));
      if (prevKeys != null && !isEmpty()) {
        rehash(prevKeys);
      }
    } 
  }





  
  public int size() { return this.assigned + (this.hasEmptyKey ? 1 : 0); }





  
  public int hashCode() {
    int h = this.hasEmptyKey ? -559038737 : 0;
    int[] keys = this.keys;
    for (int slot = this.mask; slot >= 0; slot--) {
      int existing;
      if ((existing = keys[slot]) != 0) {
        h += BitMixer.mix(existing);
      }
    } 
    return h;
  }





  
  public boolean equals(Object obj) { return (obj != null && getClass() == obj.getClass() && sameKeys((IntSet)getClass().cast(obj))); }






  
  private boolean sameKeys(IntSet other) {
    if (other.size() != size()) {
      return false;
    }
    
    for (IntCursor c : other) {
      if (!contains(c.value)) {
        return false;
      }
    } 
    
    return true;
  }





  
  public IntHashSet clone() {
    try {
      IntHashSet cloned = (IntHashSet)super.clone();
      cloned.keys = (int[])this.keys.clone();
      cloned.hasEmptyKey = cloned.hasEmptyKey;
      cloned.orderMixer = this.orderMixer.clone();
      return cloned;
    } catch (CloneNotSupportedException e) {
      throw new RuntimeException(e);
    } 
  }





  
  public Iterator<IntCursor> iterator() { return new EntryIterator(); }

  
  protected final class EntryIterator
    extends AbstractIterator<IntCursor>
  {
    private final IntCursor cursor;
    
    private final int max = IntHashSet.this.mask + 1;
    private int slot = -1;

    
    public EntryIterator() { this.cursor = new IntCursor(); }


    
    protected IntCursor fetch() {
      if (this.slot < this.max) {
        
        this.slot++; for (; this.slot < this.max; this.slot++) {
          int existing; if ((existing = IntHashSet.this.keys[this.slot]) != 0) {
            this.cursor.index = this.slot;
            this.cursor.value = existing;
            return this.cursor;
          } 
        } 
      } 
      
      if (this.slot == this.max && IntHashSet.this.hasEmptyKey) {
        this.cursor.index = this.slot;
        this.cursor.value = 0;
        this.slot++;
        return this.cursor;
      } 
      
      return done();
    }
  }




  
  public <T extends com.carrotsearch.hppc.procedures.IntProcedure> T forEach(T procedure) {
    if (this.hasEmptyKey) {
      procedure.apply(0);
    }
    
    int[] keys = this.keys;
    for (int slot = 0, max = this.mask; slot <= max; slot++) {
      int existing;
      if ((existing = keys[slot]) != 0) {
        procedure.apply(existing);
      }
    } 
    
    return procedure;
  }




  
  public <T extends IntPredicate> T forEach(T predicate) {
    if (this.hasEmptyKey && 
      !predicate.apply(0)) {
      return predicate;
    }

    
    int[] keys = this.keys;
    for (int slot = 0, max = this.mask; slot <= max; slot++) {
      int existing;
      if ((existing = keys[slot]) != 0 && 
        !predicate.apply(existing)) {
        break;
      }
    } 

    
    return predicate;
  }






  
  public static IntHashSet from(int... elements) {
    IntHashSet set = new IntHashSet(elements.length);
    set.addAll(elements);
    return set;
  }












  
  protected int hashKey(int key) {
    assert key != 0;
    return BitMixer.mix(key, this.keyMixer);
  }




















  
  public int indexOf(int key) {
    int mask = this.mask;
    if (key == 0) {
      return this.hasEmptyKey ? (mask + 1) : (mask + 1 ^ 0xFFFFFFFF);
    }
    int[] keys = this.keys;
    int slot = hashKey(key) & mask;
    
    int existing;
    while ((existing = keys[slot]) != 0) {
      if (existing == key) {
        return slot;
      }
      slot = slot + 1 & mask;
    } 
    
    return slot ^ 0xFFFFFFFF;
  }









  
  public boolean indexExists(int index) {
    assert index == this.mask + 1 && this.hasEmptyKey;


    
    return (index >= 0);
  }











  
  public int indexGet(int index) {
    assert index >= 0 : "The index must point at an existing key.";
    assert index <= this.mask || (index == this.mask + 1 && this.hasEmptyKey);

    
    return this.keys[index];
  }













  
  public int indexReplace(int index, int equivalentKey) {
    assert index >= 0 : "The index must point at an existing key.";
    assert index <= this.mask || (index == this.mask + 1 && this.hasEmptyKey);
    
    assert equivalentKey == this.keys[index];
    
    int previousValue = this.keys[index];
    this.keys[index] = equivalentKey;
    return previousValue;
  }











  
  public void indexInsert(int index, int key) {
    assert index < 0 : "The index must not point at an existing key.";
    
    index ^= 0xFFFFFFFF;
    if (key == 0) {
      assert index == this.mask + 1;
      assert this.keys[index] == 0;
      this.hasEmptyKey = true;
    } else {
      assert this.keys[index] == 0;
      
      if (this.assigned == this.resizeAt) {
        allocateThenInsertThenRehash(index, key);
      } else {
        this.keys[index] = key;
      } 
      
      this.assigned++;
    } 
  }


  
  public String visualizeKeyDistribution(int characters) { return IntBufferVisualizer.visualizeKeyDistribution(this.keys, this.mask, characters); }





  
  protected double verifyLoadFactor(double loadFactor) {
    HashContainers.checkLoadFactor(loadFactor, 0.009999999776482582D, 0.9900000095367432D);
    return loadFactor;
  }



  
  protected void rehash(int[] fromKeys) {
    assert HashContainers.checkPowerOfTwo(fromKeys.length - 1);

    
    int[] keys = this.keys;
    int mask = this.mask;
    
    for (int i = fromKeys.length - 1; --i >= 0;) {
      if ((existing = fromKeys[i]) != 0) {
        int slot = hashKey(existing) & mask;
        while (keys[slot] != 0) {
          slot = slot + 1 & mask;
        }
        keys[slot] = existing;
      } 
    } 
  }




  
  protected void allocateBuffers(int arraySize) {
    assert Integer.bitCount(arraySize) == 1;

    
    int newKeyMixer = this.orderMixer.newKeyMixer(arraySize);

    
    int[] prevKeys = this.keys;
    try {
      int emptyElementSlot = 1;
      this.keys = new int[arraySize + emptyElementSlot];
    } catch (OutOfMemoryError e) {
      this.keys = prevKeys;
      throw new BufferAllocationException("Not enough memory to allocate buffers for rehashing: %,d -> %,d", e, new Object[] { Integer.valueOf((this.keys == null) ? 0 : size()), Integer.valueOf(arraySize) });
    } 




    
    this.resizeAt = HashContainers.expandAtCount(arraySize, this.loadFactor);
    this.keyMixer = newKeyMixer;
    this.mask = arraySize - 1;
  }









  
  protected void allocateThenInsertThenRehash(int slot, int pendingKey) {
    assert this.assigned == this.resizeAt && this.keys[slot] == 0 && pendingKey != 0;



    
    int[] prevKeys = this.keys;
    allocateBuffers(HashContainers.nextBufferSize(this.mask + 1, size(), this.loadFactor));
    assert this.keys.length > prevKeys.length;


    
    prevKeys[slot] = pendingKey;

    
    rehash(prevKeys);
  }



  
  protected void shiftConflictingKeys(int gapSlot) {
    int[] keys = this.keys;
    int mask = this.mask;

    
    int distance = 0;
    while (true) {
      int slot = gapSlot + ++distance & mask;
      int existing = keys[slot];
      if (existing == 0) {
        break;
      }
      
      int idealSlot = hashKey(existing);
      int shift = slot - idealSlot & mask;
      if (shift >= distance) {



        
        keys[gapSlot] = existing;
        gapSlot = slot;
        distance = 0;
      } 
    } 

    
    keys[gapSlot] = 0;
    this.assigned--;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\IntHashSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */