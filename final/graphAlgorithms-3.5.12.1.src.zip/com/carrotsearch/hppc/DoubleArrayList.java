package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.DoubleCursor;
import com.carrotsearch.hppc.predicates.DoublePredicate;
import java.util.Arrays;
import java.util.Iterator;



















public class DoubleArrayList
  extends AbstractDoubleCollection
  implements DoubleIndexedContainer, Preallocable, Cloneable
{
  public static final double[] EMPTY_ARRAY = new double[0];






  
  public double[] buffer = EMPTY_ARRAY;




  
  public int elementsCount;




  
  protected final ArraySizingStrategy resizer;





  
  public DoubleArrayList() { this(4); }









  
  public DoubleArrayList(int expectedElements) { this(expectedElements, new BoundedProportionalArraySizingStrategy()); }












  
  public DoubleArrayList(int expectedElements, ArraySizingStrategy resizer) {
    assert resizer != null;
    this.resizer = resizer;
    ensureCapacity(expectedElements);
  }




  
  public DoubleArrayList(DoubleContainer container) {
    this(container.size());
    addAll(container);
  }




  
  public void add(double e1) {
    ensureBufferSpace(1);
    this.buffer[this.elementsCount++] = e1;
  }





  
  public void add(double e1, double e2) {
    ensureBufferSpace(2);
    this.buffer[this.elementsCount++] = e1;
    this.buffer[this.elementsCount++] = e2;
  }



  
  public void add(double[] elements, int start, int length) {
    assert length >= 0 : "Length must be >= 0";
    
    ensureBufferSpace(length);
    System.arraycopy(elements, start, this.buffer, this.elementsCount, length);
    this.elementsCount += length;
  }









  
  public final void add(double... elements) { add(elements, 0, elements.length); }




  
  public int addAll(DoubleContainer container) {
    int size = container.size();
    ensureBufferSpace(size);
    
    for (DoubleCursor cursor : container) {
      add(cursor.value);
    }
    
    return size;
  }



  
  public int addAll(Iterable<? extends DoubleCursor> iterable) {
    int size = 0;
    for (DoubleCursor cursor : iterable) {
      add(cursor.value);
      size++;
    } 
    return size;
  }




  
  public void insert(int index, double e1) {
    assert index >= 0 && index <= size() : "Index " + index + " out of bounds [" + false + ", " + size() + "].";
    
    ensureBufferSpace(1);
    System.arraycopy(this.buffer, index, this.buffer, index + 1, this.elementsCount - index);
    this.buffer[index] = e1;
    this.elementsCount++;
  }




  
  public double get(int index) {
    assert index >= 0 && index < size() : "Index " + index + " out of bounds [" + false + ", " + size() + ").";
    
    return this.buffer[index];
  }




  
  public double set(int index, double e1) {
    assert index >= 0 && index < size() : "Index " + index + " out of bounds [" + false + ", " + size() + ").";
    
    double v = this.buffer[index];
    this.buffer[index] = e1;
    return v;
  }




  
  public double remove(int index) {
    assert index >= 0 && index < size() : "Index " + index + " out of bounds [" + false + ", " + size() + ").";
    
    double v = this.buffer[index];
    if (index + 1 < this.elementsCount) {
      System.arraycopy(this.buffer, index + 1, this.buffer, index, this.elementsCount - index - 1);
    }
    this.elementsCount--;
    this.buffer[this.elementsCount] = 0.0D;
    return v;
  }





  
  public void removeRange(int fromIndex, int toIndex) {
    assert fromIndex >= 0 && fromIndex <= size() : "Index " + fromIndex + " out of bounds [" + false + ", " + size() + ").";
    
    assert toIndex >= 0 && toIndex <= size() : "Index " + toIndex + " out of bounds [" + false + ", " + size() + "].";
    
    assert fromIndex <= toIndex : "fromIndex must be <= toIndex: " + fromIndex + ", " + toIndex;
    
    System.arraycopy(this.buffer, toIndex, this.buffer, fromIndex, this.elementsCount - toIndex);
    int count = toIndex - fromIndex;
    this.elementsCount -= count;
    Arrays.fill(this.buffer, this.elementsCount, this.elementsCount + count, 0.0D);
  }




  
  public int removeFirst(double e1) {
    int index = indexOf(e1);
    if (index >= 0)
      remove(index); 
    return index;
  }




  
  public int removeLast(double e1) {
    int index = lastIndexOf(e1);
    if (index >= 0)
      remove(index); 
    return index;
  }




  
  public int removeAll(double e1) {
    int to = 0;
    for (int from = 0; from < this.elementsCount; from++) {
      if (Double.doubleToLongBits(this.buffer[from]) == Double.doubleToLongBits(e1)) {
        this.buffer[from] = 0.0D;
      }
      else {
        
        if (to != from) {
          this.buffer[to] = this.buffer[from];
          this.buffer[from] = 0.0D;
        } 
        to++;
      } 
    } 
    int deleted = this.elementsCount - to;
    this.elementsCount = to;
    return deleted;
  }





  
  public boolean contains(double e1) { return (indexOf(e1) >= 0); }





  
  public int indexOf(double e1) {
    for (int i = 0; i < this.elementsCount; i++) {
      if (Double.doubleToLongBits(this.buffer[i]) == Double.doubleToLongBits(e1)) {
        return i;
      }
    } 
    
    return -1;
  }




  
  public int lastIndexOf(double e1) {
    for (int i = this.elementsCount - 1; i >= 0; i--) {
      if (Double.doubleToLongBits(this.buffer[i]) == Double.doubleToLongBits(e1)) {
        return i;
      }
    } 
    
    return -1;
  }





  
  public boolean isEmpty() { return (this.elementsCount == 0); }









  
  public void ensureCapacity(int expectedElements) {
    int bufferLen = (this.buffer == null) ? 0 : this.buffer.length;
    if (expectedElements > bufferLen) {
      ensureBufferSpace(expectedElements - size());
    }
  }




  
  protected void ensureBufferSpace(int expectedAdditions) {
    int bufferLen = (this.buffer == null) ? 0 : this.buffer.length;
    if (this.elementsCount + expectedAdditions > bufferLen) {
      int newSize = this.resizer.grow(bufferLen, this.elementsCount, expectedAdditions);
      assert newSize >= this.elementsCount + expectedAdditions : "Resizer failed to return sensible new size: " + newSize + " <= " + (this.elementsCount + expectedAdditions);

      
      this.buffer = Arrays.copyOf(this.buffer, newSize);
    } 
  }







  
  public void resize(int newSize) {
    if (newSize <= this.buffer.length) {
      if (newSize < this.elementsCount) {
        Arrays.fill(this.buffer, newSize, this.elementsCount, 0.0D);
      } else {
        Arrays.fill(this.buffer, this.elementsCount, newSize, 0.0D);
      } 
    } else {
      ensureCapacity(newSize);
    } 
    this.elementsCount = newSize;
  }





  
  public int size() { return this.elementsCount; }




  
  public void trimToSize() {
    if (size() != this.buffer.length) {
      this.buffer = toArray();
    }
  }






  
  public void clear() {
    Arrays.fill(this.buffer, 0, this.elementsCount, 0.0D);
    this.elementsCount = 0;
  }





  
  public void release() {
    this.buffer = EMPTY_ARRAY;
    this.elementsCount = 0;
  }










  
  public double[] toArray() { return Arrays.copyOf(this.buffer, this.elementsCount); }







  
  public DoubleArrayList clone() {
    try {
      DoubleArrayList cloned = (DoubleArrayList)super.clone();
      cloned.buffer = (double[])this.buffer.clone();
      return cloned;
    } catch (CloneNotSupportedException e) {
      throw new RuntimeException(e);
    } 
  }




  
  public int hashCode() {
    int h = 1, max = this.elementsCount;
    for (int i = 0; i < max; i++) {
      h = 31 * h + BitMixer.mix(this.buffer[i]);
    }
    return h;
  }






  
  public boolean equals(Object obj) { return (obj != null && getClass() == obj.getClass() && equalElements((DoubleArrayList)getClass().cast(obj))); }







  
  protected boolean equalElements(DoubleArrayList other) {
    int max = size();
    if (other.size() != max) {
      return false;
    }
    
    for (int i = 0; i < max; i++) {
      if (Double.doubleToLongBits(other.get(i)) != Double.doubleToLongBits(get(i))) {
        return false;
      }
    } 
    
    return true;
  }

  
  static final class ValueIterator
    extends AbstractIterator<DoubleCursor>
  {
    private final DoubleCursor cursor;
    
    private final double[] buffer;
    private final int size;
    
    public ValueIterator(double[] buffer, int size) {
      this.cursor = new DoubleCursor();
      this.cursor.index = -1;
      this.size = size;
      this.buffer = buffer;
    }

    
    protected DoubleCursor fetch() {
      if (this.cursor.index + 1 == this.size) {
        return done();
      }
      this.cursor.value = this.buffer[++this.cursor.index];
      return this.cursor;
    }
  }





  
  public Iterator<DoubleCursor> iterator() { return new ValueIterator(this.buffer, size()); }






  
  public <T extends com.carrotsearch.hppc.procedures.DoubleProcedure> T forEach(T procedure) { return forEach(procedure, 0, size()); }






  
  public <T extends com.carrotsearch.hppc.procedures.DoubleProcedure> T forEach(T procedure, int fromIndex, int toIndex) {
    assert fromIndex >= 0 && fromIndex <= size() : "Index " + fromIndex + " out of bounds [" + false + ", " + size() + ").";

    
    assert toIndex >= 0 && toIndex <= size() : "Index " + toIndex + " out of bounds [" + false + ", " + size() + "].";
    
    assert fromIndex <= toIndex : "fromIndex must be <= toIndex: " + fromIndex + ", " + toIndex;

    
    double[] buffer = this.buffer;
    for (int i = fromIndex; i < toIndex; i++) {
      procedure.apply(buffer[i]);
    }
    
    return procedure;
  }




  
  public int removeAll(DoublePredicate predicate) {
    double[] buffer = this.buffer;
    int elementsCount = this.elementsCount;
    int to = 0;
    int from = 0;
    try {
      for (; from < elementsCount; from++) {
        if (predicate.apply(buffer[from])) {
          buffer[from] = 0.0D;
        }
        else {
          
          if (to != from) {
            buffer[to] = buffer[from];
            buffer[from] = 0.0D;
          } 
          to++;
        } 
      } 
    } finally {
      for (; from < elementsCount; from++) {
        if (to != from) {
          buffer[to] = buffer[from];
          buffer[from] = 0.0D;
        } 
        to++;
      } 
      
      this.elementsCount = to;
    } 
    
    return elementsCount - to;
  }





  
  public <T extends DoublePredicate> T forEach(T predicate) { return forEach(predicate, 0, size()); }







  
  public <T extends DoublePredicate> T forEach(T predicate, int fromIndex, int toIndex) {
    assert fromIndex >= 0 && fromIndex <= size() : "Index " + fromIndex + " out of bounds [" + false + ", " + size() + ").";
    
    assert toIndex >= 0 && toIndex <= size() : "Index " + toIndex + " out of bounds [" + false + ", " + size() + "].";
    
    assert fromIndex <= toIndex : "fromIndex must be <= toIndex: " + fromIndex + ", " + toIndex;
    
    double[] buffer = this.buffer;
    for (int i = fromIndex; i < toIndex && 
      predicate.apply(buffer[i]); i++);


    
    return predicate;
  }





  
  public static DoubleArrayList from(double... elements) {
    DoubleArrayList list = new DoubleArrayList(elements.length);
    list.add(elements);
    return list;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\DoubleArrayList.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */