package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.FloatCursor;
import com.carrotsearch.hppc.predicates.FloatPredicate;
import java.util.Arrays;















abstract class AbstractFloatCollection
  implements FloatCollection
{
  public int removeAll(final FloatLookupContainer c) {
    return removeAll(new FloatPredicate()
        {
          public boolean apply(float k) { return c.contains(k); }
        });
  }






  
  public int retainAll(final FloatLookupContainer c) {
    return removeAll(new FloatPredicate()
        {
          public boolean apply(float k) { return !c.contains(k); }
        });
  }






  
  public int retainAll(final FloatPredicate predicate) {
    return removeAll(new FloatPredicate()
        {
          public boolean apply(float value) { return !predicate.apply(value); }
        });
  }







  
  public float[] toArray() {
    float[] array = new float[size()];
    int i = 0;
    for (FloatCursor c : this) {
      array[i++] = c.value;
    }
    return array;
  }







  
  public String toString() { return Arrays.toString(toArray()); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\AbstractFloatCollection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */