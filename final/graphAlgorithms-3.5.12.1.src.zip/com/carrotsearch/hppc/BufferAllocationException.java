package com.carrotsearch.hppc;

import java.util.IllegalFormatException;
import java.util.Locale;

public class BufferAllocationException
  extends RuntimeException
{
  public BufferAllocationException(String message) { super(message); }


  
  public BufferAllocationException(String message, Object... args) { this(message, null, args); }


  
  public BufferAllocationException(String message, Throwable t, Object... args) { super(formatMessage(message, t, args), t); }

  
  private static String formatMessage(String message, Throwable t, Object... args) {
    try {
      return String.format(Locale.ROOT, message, args);
    } catch (IllegalFormatException e) {
      BufferAllocationException substitute = new BufferAllocationException(message + " [ILLEGAL FORMAT, ARGS SUPPRESSED]");
      
      if (t != null) {
        substitute.addSuppressed(t);
      }
      substitute.addSuppressed(e);
      throw substitute;
    } 
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\BufferAllocationException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */