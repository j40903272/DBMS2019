package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.ObjectCursor;
import java.util.Iterator;

public interface ObjectContainer<KType> extends Iterable<ObjectCursor<KType>> {
  Iterator<ObjectCursor<KType>> iterator();
  
  boolean contains(KType paramKType);
  
  int size();
  
  boolean isEmpty();
  
  Object[] toArray();
  
  <T> T[] toArray(Class<T> paramClass);
  
  <T extends com.carrotsearch.hppc.procedures.ObjectProcedure<? super KType>> T forEach(T paramT);
  
  <T extends com.carrotsearch.hppc.predicates.ObjectPredicate<? super KType>> T forEach(T paramT);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\ObjectContainer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */