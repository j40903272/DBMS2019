package com.carrotsearch.hppc.sorting;

import java.util.Comparator;














public final class IndirectSort
{
  static int MIN_LENGTH_FOR_INSERTION_SORT = 30;














  
  public static int[] mergesort(int start, int length, IndirectComparator comparator) {
    int[] src = createOrderArray(start, length);
    
    if (length > 1) {
      int[] dst = (int[])src.clone();
      topDownMergeSort(src, dst, 0, length, comparator);
      return dst;
    } 
    
    return src;
  }











  
  public static <T> int[] mergesort(T[] input, int start, int length, Comparator<? super T> comparator) { return mergesort(start, length, new IndirectComparator.DelegatingComparator<>(input, comparator)); }









  
  private static void topDownMergeSort(int[] src, int[] dst, int fromIndex, int toIndex, IndirectComparator comp) {
    if (toIndex - fromIndex <= MIN_LENGTH_FOR_INSERTION_SORT) {
      insertionSort(fromIndex, toIndex - fromIndex, dst, comp);
      
      return;
    } 
    int mid = fromIndex + toIndex >>> 1;
    topDownMergeSort(dst, src, fromIndex, mid, comp);
    topDownMergeSort(dst, src, mid, toIndex, comp);



    
    if (comp.compare(src[mid - 1], src[mid]) <= 0) {



      
      System.arraycopy(src, fromIndex, dst, fromIndex, toIndex - fromIndex);
    
    }
    else {
      
      for (int i = fromIndex, j = mid, k = fromIndex; k < toIndex; k++) {
        if (j == toIndex || (i < mid && comp.compare(src[i], src[j]) <= 0)) {
          dst[k] = src[i++];
        } else {
          dst[k] = src[j++];
        } 
      } 
    } 
  }



  
  private static void insertionSort(int off, int len, int[] order, IndirectComparator intComparator) {
    for (int i = off + 1; i < off + len; i++) {
      int v = order[i];
      int j = i; int t;
      while (j > off && intComparator.compare(t = order[j - 1], v) > 0) {
        order[j--] = t;
      }
      order[j] = v;
    } 
  }



  
  private static int[] createOrderArray(int start, int length) {
    int[] order = new int[length];
    for (int i = 0; i < length; i++) {
      order[i] = start + i;
    }
    return order;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\sorting\IndirectSort.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */