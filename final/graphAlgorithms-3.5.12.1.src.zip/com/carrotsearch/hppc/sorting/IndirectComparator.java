package com.carrotsearch.hppc.sorting;

import java.util.Comparator;













public interface IndirectComparator
{
  int compare(int paramInt1, int paramInt2);
  
  public static class AscendingIntComparator
    implements IndirectComparator
  {
    private final int[] array;
    
    public AscendingIntComparator(int[] array) { this.array = array; }

    
    public int compare(int indexA, int indexB) {
      int a = this.array[indexA];
      int b = this.array[indexB];
      
      if (a < b)
        return -1; 
      if (a > b)
        return 1; 
      return 0;
    }
  }


  
  public static class DescendingIntComparator
    extends AscendingIntComparator
  {
    public DescendingIntComparator(int[] array) { super(array); }


    
    public final int compare(int indexA, int indexB) { return -super.compare(indexA, indexB); }
  }


  
  public static class AscendingShortComparator
    implements IndirectComparator
  {
    private final short[] array;

    
    public AscendingShortComparator(short[] array) { this.array = array; }

    
    public int compare(int indexA, int indexB) {
      short a = this.array[indexA];
      short b = this.array[indexB];
      
      if (a < b)
        return -1; 
      if (a > b)
        return 1; 
      return 0;
    }
  }


  
  public static class DescendingShortComparator
    extends AscendingShortComparator
  {
    public DescendingShortComparator(short[] array) { super(array); }


    
    public final int compare(int indexA, int indexB) { return -super.compare(indexA, indexB); }
  }


  
  public static class AscendingDoubleComparator
    implements IndirectComparator
  {
    private final double[] array;

    
    public AscendingDoubleComparator(double[] array) { this.array = array; }

    
    public int compare(int indexA, int indexB) {
      double a = this.array[indexA];
      double b = this.array[indexB];
      
      if (a < b)
        return -1; 
      if (a > b)
        return 1; 
      return 0;
    }
  }


  
  public static class DescendingDoubleComparator
    extends AscendingDoubleComparator
  {
    public DescendingDoubleComparator(double[] array) { super(array); }


    
    public final int compare(int indexA, int indexB) { return -super.compare(indexA, indexB); }
  }


  
  public static class AscendingFloatComparator
    implements IndirectComparator
  {
    private final float[] array;

    
    public AscendingFloatComparator(float[] array) { this.array = array; }

    
    public int compare(int indexA, int indexB) {
      float a = this.array[indexA];
      float b = this.array[indexB];
      
      if (a < b)
        return -1; 
      if (a > b)
        return 1; 
      return 0;
    }
  }


  
  public static class DescendingFloatComparator
    extends AscendingFloatComparator
  {
    public DescendingFloatComparator(float[] array) { super(array); }


    
    public final int compare(int indexA, int indexB) { return -super.compare(indexA, indexB); }
  }

  
  public static final class DelegatingComparator<T>
    implements IndirectComparator
  {
    private final T[] array;
    
    private final Comparator<? super T> delegate;
    
    public DelegatingComparator(T[] array, Comparator<? super T> delegate) {
      this.array = array;
      this.delegate = delegate;
    }

    
    public final int compare(int indexA, int indexB) { return this.delegate.compare(this.array[indexA], this.array[indexB]); }



    
    public String toString() { return getClass().getSimpleName() + " -> " + this.delegate; }
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\sorting\IndirectComparator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */