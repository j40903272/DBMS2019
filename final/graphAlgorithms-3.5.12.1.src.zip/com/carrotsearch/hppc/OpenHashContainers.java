package com.carrotsearch.hppc;





















public final class OpenHashContainers
{
  public static int emptyBufferSize() { return expectedBufferSize(4); }


  
  public static int expectedBufferSize(int elements) { return HashContainers.minBufferSize(elements, 0.75D) + 1; }


  
  private OpenHashContainers() { throw new UnsupportedOperationException("No instances"); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\OpenHashContainers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */