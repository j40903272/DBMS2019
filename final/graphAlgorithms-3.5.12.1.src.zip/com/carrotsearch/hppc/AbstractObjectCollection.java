package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.ObjectCursor;
import com.carrotsearch.hppc.predicates.ObjectPredicate;
import java.lang.reflect.Array;
import java.util.Arrays;
















abstract class AbstractObjectCollection<KType>
  implements ObjectCollection<KType>
{
  public int removeAll(final ObjectLookupContainer<? super KType> c) {
    return removeAll(new ObjectPredicate<KType>()
        {
          public boolean apply(KType k) { return c.contains(k); }
        });
  }






  
  public int retainAll(final ObjectLookupContainer<? super KType> c) {
    return removeAll(new ObjectPredicate<KType>()
        {
          public boolean apply(KType k) { return !c.contains(k); }
        });
  }






  
  public int retainAll(final ObjectPredicate<? super KType> predicate) {
    return removeAll(new ObjectPredicate<KType>()
        {
          public boolean apply(KType value) { return !predicate.apply(value); }
        });
  }








  
  public Object[] toArray() {
    KType[] array = (KType[])new Object[size()];
    int i = 0;
    for (ObjectCursor<KType> c : this) {
      array[i++] = (KType)c.value;
    }
    return (Object[])array;
  }

  
  public <T> T[] toArray(Class<T> componentClass) {
    int size = size();
    T[] array = (T[])Array.newInstance(componentClass, size);
    int i = 0;
    for (ObjectCursor<KType> c : this) {
      array[i++] = (T)c.value;
    }
    return array;
  }






  
  public String toString() { return Arrays.toString(toArray()); }



  
  protected boolean equals(Object v1, Object v2) { return (v1 == v2 || (v1 != null && v1.equals(v2))); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\AbstractObjectCollection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */