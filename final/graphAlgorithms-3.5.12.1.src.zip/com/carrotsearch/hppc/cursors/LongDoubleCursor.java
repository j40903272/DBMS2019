package com.carrotsearch.hppc.cursors;






















public final class LongDoubleCursor
{
  public int index;
  public long key;
  public double value;
  
  public String toString() { return "[cursor, index: " + this.index + ", key: " + this.key + ", value: " + this.value + "]"; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\cursors\LongDoubleCursor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */