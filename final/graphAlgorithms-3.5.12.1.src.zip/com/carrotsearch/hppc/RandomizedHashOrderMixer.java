package com.carrotsearch.hppc;

import java.util.concurrent.atomic.AtomicLong;



public final class RandomizedHashOrderMixer
  implements HashOrderMixingStrategy
{
  public static final RandomizedHashOrderMixer INSTANCE = new RandomizedHashOrderMixer();
  
  protected final AtomicLong seedMixer;

  
  public RandomizedHashOrderMixer() { this(Containers.randomSeed64()); }


  
  public RandomizedHashOrderMixer(long seed) { this.seedMixer = new AtomicLong(seed); }



  
  public int newKeyMixer(int newContainerBufferSize) { return (int)BitMixer.mix64(this.seedMixer.incrementAndGet()); }



  
  public HashOrderMixingStrategy clone() { return this; }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\RandomizedHashOrderMixer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */