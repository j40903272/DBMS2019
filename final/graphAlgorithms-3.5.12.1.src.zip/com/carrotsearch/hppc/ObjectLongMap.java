package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.ObjectLongCursor;

public interface ObjectLongMap<KType> extends ObjectLongAssociativeContainer<KType> {
  long get(KType paramKType);
  
  long getOrDefault(KType paramKType, long paramLong);
  
  long put(KType paramKType, long paramLong);
  
  int putAll(ObjectLongAssociativeContainer<? extends KType> paramObjectLongAssociativeContainer);
  
  int putAll(Iterable<? extends ObjectLongCursor<? extends KType>> paramIterable);
  
  long putOrAdd(KType paramKType, long paramLong1, long paramLong2);
  
  long addTo(KType paramKType, long paramLong);
  
  long remove(KType paramKType);
  
  boolean equals(Object paramObject);
  
  int hashCode();
  
  int indexOf(KType paramKType);
  
  boolean indexExists(int paramInt);
  
  long indexGet(int paramInt);
  
  long indexReplace(int paramInt, long paramLong);
  
  void indexInsert(int paramInt, KType paramKType, long paramLong);
  
  void clear();
  
  void release();
  
  String visualizeKeyDistribution(int paramInt);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\ObjectLongMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */