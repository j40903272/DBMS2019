package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.DoubleCursor;
import com.carrotsearch.hppc.cursors.LongCursor;
import com.carrotsearch.hppc.cursors.LongDoubleCursor;
import com.carrotsearch.hppc.predicates.DoublePredicate;
import com.carrotsearch.hppc.predicates.LongDoublePredicate;
import com.carrotsearch.hppc.predicates.LongPredicate;
import com.carrotsearch.hppc.procedures.LongDoubleProcedure;
import com.carrotsearch.hppc.procedures.LongProcedure;
import java.util.Arrays;
import java.util.Iterator;




































































public class LongDoubleHashMap
  implements LongDoubleMap, Preallocable, Cloneable
{
  public long[] keys;
  public double[] values;
  protected int keyMixer;
  protected int assigned;
  protected int mask;
  protected int resizeAt;
  protected boolean hasEmptyKey;
  protected double loadFactor;
  protected HashOrderMixingStrategy orderMixer;
  
  public LongDoubleHashMap() { this(4); }









  
  public LongDoubleHashMap(int expectedElements) { this(expectedElements, 0.75D); }












  
  public LongDoubleHashMap(int expectedElements, double loadFactor) { this(expectedElements, loadFactor, HashOrderMixing.defaultStrategy()); }














  
  public LongDoubleHashMap(int expectedElements, double loadFactor, HashOrderMixingStrategy orderMixer) {
    this.orderMixer = orderMixer;
    this.loadFactor = verifyLoadFactor(loadFactor);
    ensureCapacity(expectedElements);
  }



  
  public LongDoubleHashMap(LongDoubleAssociativeContainer container) {
    this(container.size());
    putAll(container);
  }




  
  public double put(long key, double value) {
    assert this.assigned < this.mask + 1;
    
    int mask = this.mask;
    if (key == 0L) {
      this.hasEmptyKey = true;
      double previousValue = this.values[mask + 1];
      this.values[mask + 1] = value;
      return previousValue;
    } 
    long[] keys = this.keys;
    int slot = hashKey(key) & mask;
    
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        double previousValue = this.values[slot];
        this.values[slot] = value;
        return previousValue;
      } 
      slot = slot + 1 & mask;
    } 
    
    if (this.assigned == this.resizeAt) {
      allocateThenInsertThenRehash(slot, key, value);
    } else {
      keys[slot] = key;
      this.values[slot] = value;
    } 
    
    this.assigned++;
    return 0.0D;
  }





  
  public int putAll(LongDoubleAssociativeContainer container) {
    int count = size();
    for (LongDoubleCursor c : container) {
      put(c.key, c.value);
    }
    return size() - count;
  }




  
  public int putAll(Iterable<? extends LongDoubleCursor> iterable) {
    int count = size();
    for (LongDoubleCursor c : iterable) {
      put(c.key, c.value);
    }
    return size() - count;
  }












  
  public boolean putIfAbsent(long key, double value) {
    int keyIndex = indexOf(key);
    if (!indexExists(keyIndex)) {
      indexInsert(keyIndex, key, value);
      return true;
    } 
    return false;
  }
















  
  public double putOrAdd(long key, double putValue, double incrementValue) {
    assert this.assigned < this.mask + 1;
    
    int keyIndex = indexOf(key);
    if (indexExists(keyIndex)) {
      putValue = this.values[keyIndex] + incrementValue;
      indexReplace(keyIndex, putValue);
    } else {
      indexInsert(keyIndex, key, putValue);
    } 
    return putValue;
  }













  
  public double addTo(long key, double incrementValue) { return putOrAdd(key, incrementValue, incrementValue); }






  
  public double remove(long key) {
    int mask = this.mask;
    if (key == 0L) {
      this.hasEmptyKey = false;
      double previousValue = this.values[mask + 1];
      this.values[mask + 1] = 0.0D;
      return previousValue;
    } 
    long[] keys = this.keys;
    int slot = hashKey(key) & mask;
    
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        double previousValue = this.values[slot];
        shiftConflictingKeys(slot);
        return previousValue;
      } 
      slot = slot + 1 & mask;
    } 
    
    return 0.0D;
  }





  
  public int removeAll(LongContainer other) {
    int before = size();




    
    if (other.size() >= size() && other instanceof LongLookupContainer) {
      
      if (this.hasEmptyKey && 
        other.contains(0L)) {
        this.hasEmptyKey = false;
        this.values[this.mask + 1] = 0.0D;
      } 

      
      long[] keys = this.keys;
      for (int slot = 0, max = this.mask; slot <= max; ) {
        long existing;
        if ((existing = keys[slot]) != 0L && other.contains(existing)) {
          
          shiftConflictingKeys(slot); continue;
        } 
        slot++;
      } 
    } else {
      
      for (LongCursor c : other) {
        remove(c.value);
      }
    } 
    
    return before - size();
  }




  
  public int removeAll(LongDoublePredicate predicate) {
    int before = size();
    
    int mask = this.mask;
    
    if (this.hasEmptyKey && 
      predicate.apply(0L, this.values[mask + 1])) {
      this.hasEmptyKey = false;
      this.values[mask + 1] = 0.0D;
    } 

    
    long[] keys = this.keys;
    double[] values = this.values;
    for (int slot = 0; slot <= mask; ) {
      long existing;
      if ((existing = keys[slot]) != 0L && predicate.apply(existing, values[slot])) {

        
        shiftConflictingKeys(slot); continue;
      } 
      slot++;
    } 

    
    return before - size();
  }




  
  public int removeAll(LongPredicate predicate) {
    int before = size();
    
    if (this.hasEmptyKey && 
      predicate.apply(0L)) {
      this.hasEmptyKey = false;
      this.values[this.mask + 1] = 0.0D;
    } 

    
    long[] keys = this.keys;
    for (int slot = 0, max = this.mask; slot <= max; ) {
      long existing;
      if ((existing = keys[slot]) != 0L && predicate.apply(existing)) {

        
        shiftConflictingKeys(slot); continue;
      } 
      slot++;
    } 

    
    return before - size();
  }




  
  public double get(long key) {
    if (key == 0L) {
      return this.hasEmptyKey ? this.values[this.mask + 1] : 0.0D;
    }
    long[] keys = this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        return this.values[slot];
      }
      slot = slot + 1 & mask;
    } 
    
    return 0.0D;
  }





  
  public double getOrDefault(long key, double defaultValue) {
    if (key == 0L) {
      return this.hasEmptyKey ? this.values[this.mask + 1] : defaultValue;
    }
    long[] keys = this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        return this.values[slot];
      }
      slot = slot + 1 & mask;
    } 
    
    return defaultValue;
  }





  
  public boolean containsKey(long key) {
    if (key == 0L) {
      return this.hasEmptyKey;
    }
    long[] keys = this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        return true;
      }
      slot = slot + 1 & mask;
    } 
    
    return false;
  }





  
  public int indexOf(long key) {
    int mask = this.mask;
    if (key == 0L) {
      return this.hasEmptyKey ? (mask + 1) : (mask + 1 ^ 0xFFFFFFFF);
    }
    long[] keys = this.keys;
    int slot = hashKey(key) & mask;
    
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        return slot;
      }
      slot = slot + 1 & mask;
    } 
    
    return slot ^ 0xFFFFFFFF;
  }





  
  public boolean indexExists(int index) {
    assert index == this.mask + 1 && this.hasEmptyKey;


    
    return (index >= 0);
  }




  
  public double indexGet(int index) {
    assert index >= 0 : "The index must point at an existing key.";
    assert index <= this.mask || (index == this.mask + 1 && this.hasEmptyKey);

    
    return this.values[index];
  }




  
  public double indexReplace(int index, double newValue) {
    assert index >= 0 : "The index must point at an existing key.";
    assert index <= this.mask || (index == this.mask + 1 && this.hasEmptyKey);

    
    double previousValue = this.values[index];
    this.values[index] = newValue;
    return previousValue;
  }




  
  public void indexInsert(int index, long key, double value) {
    assert index < 0 : "The index must not point at an existing key.";
    
    index ^= 0xFFFFFFFF;
    if (key == 0L) {
      assert index == this.mask + 1;
      this.values[index] = value;
      this.hasEmptyKey = true;
    } else {
      assert this.keys[index] == 0L;
      
      if (this.assigned == this.resizeAt) {
        allocateThenInsertThenRehash(index, key, value);
      } else {
        this.keys[index] = key;
        this.values[index] = value;
      } 
      
      this.assigned++;
    } 
  }




  
  public void clear() {
    this.assigned = 0;
    this.hasEmptyKey = false;
    
    Arrays.fill(this.keys, 0L);
  }






  
  public void release() {
    this.assigned = 0;
    this.hasEmptyKey = false;
    
    this.keys = null;
    this.values = null;
    ensureCapacity(4);
  }





  
  public int size() { return this.assigned + (this.hasEmptyKey ? 1 : 0); }





  
  public boolean isEmpty() { return (size() == 0); }





  
  public int hashCode() {
    int h = this.hasEmptyKey ? -559038737 : 0;
    for (LongDoubleCursor c : this) {
      h += BitMixer.mix(c.key) + BitMixer.mix(c.value);
    }
    
    return h;
  }





  
  public boolean equals(Object obj) { return (obj != null && getClass() == obj.getClass() && equalElements((LongDoubleHashMap)getClass().cast(obj))); }






  
  protected boolean equalElements(LongDoubleHashMap other) {
    if (other.size() != size()) {
      return false;
    }
    
    for (LongDoubleCursor c : other) {
      long key = c.key;
      if (!containsKey(key) || Double.doubleToLongBits(get(key)) != Double.doubleToLongBits(c.value))
      {
        return false;
      }
    } 
    
    return true;
  }







  
  public void ensureCapacity(int expectedElements) {
    if (expectedElements > this.resizeAt || this.keys == null) {
      long[] prevKeys = this.keys;
      double[] prevValues = this.values;
      allocateBuffers(HashContainers.minBufferSize(expectedElements, this.loadFactor));
      if (prevKeys != null && !isEmpty()) {
        rehash(prevKeys, prevValues);
      }
    } 
  }

  
  private final class EntryIterator
    extends AbstractIterator<LongDoubleCursor>
  {
    private final LongDoubleCursor cursor;
    private final int max = LongDoubleHashMap.this.mask + 1;
    private int slot = -1;

    
    public EntryIterator() { this.cursor = new LongDoubleCursor(); }


    
    protected LongDoubleCursor fetch() {
      if (this.slot < this.max) {
        
        this.slot++; for (; this.slot < this.max; this.slot++) {
          long existing; if ((existing = LongDoubleHashMap.this.keys[this.slot]) != 0L) {
            this.cursor.index = this.slot;
            this.cursor.key = existing;
            this.cursor.value = LongDoubleHashMap.this.values[this.slot];
            return this.cursor;
          } 
        } 
      } 
      
      if (this.slot == this.max && LongDoubleHashMap.this.hasEmptyKey) {
        this.cursor.index = this.slot;
        this.cursor.key = 0L;
        this.cursor.value = LongDoubleHashMap.this.values[this.max];
        this.slot++;
        return this.cursor;
      } 
      
      return done();
    }
  }





  
  public Iterator<LongDoubleCursor> iterator() { return new EntryIterator(); }





  
  public <T extends LongDoubleProcedure> T forEach(T procedure) {
    long[] keys = this.keys;
    double[] values = this.values;
    
    if (this.hasEmptyKey) {
      procedure.apply(0L, values[this.mask + 1]);
    }
    
    for (int slot = 0, max = this.mask; slot <= max; slot++) {
      if (keys[slot] != 0L) {
        procedure.apply(keys[slot], values[slot]);
      }
    } 
    
    return procedure;
  }




  
  public <T extends LongDoublePredicate> T forEach(T predicate) {
    long[] keys = this.keys;
    double[] values = this.values;
    
    if (this.hasEmptyKey && 
      !predicate.apply(0L, values[this.mask + 1])) {
      return predicate;
    }

    
    for (int slot = 0, max = this.mask; slot <= max && (
      keys[slot] == 0L || 
      predicate.apply(keys[slot], values[slot])); slot++);




    
    return predicate;
  }





  
  public KeysContainer keys() { return new KeysContainer(); }


  
  public final class KeysContainer
    extends AbstractLongCollection
    implements LongLookupContainer
  {
    private final LongDoubleHashMap owner = LongDoubleHashMap.this;


    
    public boolean contains(long e) { return this.owner.containsKey(e); }


    
    public <T extends LongProcedure> T forEach(final T procedure) {
      this.owner.forEach(new LongDoubleProcedure()
          {
            public void apply(long key, double value) {
              procedure.apply(key);
            }
          });
      
      return procedure;
    }

    
    public <T extends LongPredicate> T forEach(final T predicate) {
      this.owner.forEach(new LongDoublePredicate()
          {
            public boolean apply(long key, double value) {
              return predicate.apply(key);
            }
          });
      
      return predicate;
    }


    
    public boolean isEmpty() { return this.owner.isEmpty(); }



    
    public Iterator<LongCursor> iterator() { return new LongDoubleHashMap.KeysIterator(); }



    
    public int size() { return this.owner.size(); }



    
    public void clear() { this.owner.clear(); }



    
    public void release() { this.owner.release(); }



    
    public int removeAll(LongPredicate predicate) { return this.owner.removeAll(predicate); }


    
    public int removeAll(long e) {
      boolean hasKey = this.owner.containsKey(e);
      if (hasKey) {
        this.owner.remove(e);
        return 1;
      } 
      return 0;
    }
  }

  
  private final class KeysIterator
    extends AbstractIterator<LongCursor>
  {
    private final LongCursor cursor;
    
    private final int max = LongDoubleHashMap.this.mask + 1;
    private int slot = -1;

    
    public KeysIterator() { this.cursor = new LongCursor(); }


    
    protected LongCursor fetch() {
      if (this.slot < this.max) {
        
        this.slot++; for (; this.slot < this.max; this.slot++) {
          long existing; if ((existing = LongDoubleHashMap.this.keys[this.slot]) != 0L) {
            this.cursor.index = this.slot;
            this.cursor.value = existing;
            return this.cursor;
          } 
        } 
      } 
      
      if (this.slot == this.max && LongDoubleHashMap.this.hasEmptyKey) {
        this.cursor.index = this.slot;
        this.cursor.value = 0L;
        this.slot++;
        return this.cursor;
      } 
      
      return done();
    }
  }




  
  public DoubleCollection values() {
    return new ValuesContainer();
  }

  
  private final class ValuesContainer
    extends AbstractDoubleCollection
  {
    private final LongDoubleHashMap owner = LongDoubleHashMap.this;


    
    public int size() { return this.owner.size(); }



    
    public boolean isEmpty() { return this.owner.isEmpty(); }


    
    public boolean contains(double value) {
      for (LongDoubleCursor c : this.owner) {
        if (Double.doubleToLongBits(c.value) == Double.doubleToLongBits(value)) {
          return true;
        }
      } 
      return false;
    }

    
    public <T extends com.carrotsearch.hppc.procedures.DoubleProcedure> T forEach(T procedure) {
      for (LongDoubleCursor c : this.owner) {
        procedure.apply(c.value);
      }
      return procedure;
    }

    
    public <T extends DoublePredicate> T forEach(T predicate) {
      for (LongDoubleCursor c : this.owner) {
        if (!predicate.apply(c.value)) {
          break;
        }
      } 
      return predicate;
    }


    
    public Iterator<DoubleCursor> iterator() { return new LongDoubleHashMap.ValuesIterator(); }


    
    public int removeAll(final double e) {
      return this.owner.removeAll(new LongDoublePredicate()
          {
            public boolean apply(long key, double value) {
              return (Double.doubleToLongBits(value) == Double.doubleToLongBits(e));
            }
          });
    }

    
    public int removeAll(final DoublePredicate predicate) {
      return this.owner.removeAll(new LongDoublePredicate()
          {
            public boolean apply(long key, double value) {
              return predicate.apply(value);
            }
          });
    }


    
    public void clear() { this.owner.clear(); }



    
    public void release() { this.owner.release(); }
    
    private ValuesContainer() {}
  }
  
  private final class ValuesIterator
    extends AbstractIterator<DoubleCursor>
  {
    private final DoubleCursor cursor;
    private final int max = LongDoubleHashMap.this.mask + 1;
    private int slot = -1;

    
    public ValuesIterator() { this.cursor = new DoubleCursor(); }


    
    protected DoubleCursor fetch() {
      if (this.slot < this.max) {
        this.slot++; for (; this.slot < this.max; this.slot++) {
          if (LongDoubleHashMap.this.keys[this.slot] != 0L) {
            this.cursor.index = this.slot;
            this.cursor.value = LongDoubleHashMap.this.values[this.slot];
            return this.cursor;
          } 
        } 
      } 
      
      if (this.slot == this.max && LongDoubleHashMap.this.hasEmptyKey) {
        this.cursor.index = this.slot;
        this.cursor.value = LongDoubleHashMap.this.values[this.max];
        this.slot++;
        return this.cursor;
      } 
      
      return done();
    }
  }





  
  public LongDoubleHashMap clone() {
    try {
      LongDoubleHashMap cloned = (LongDoubleHashMap)super.clone();
      cloned.keys = (long[])this.keys.clone();
      cloned.values = (double[])this.values.clone();
      cloned.hasEmptyKey = cloned.hasEmptyKey;
      cloned.orderMixer = this.orderMixer.clone();
      return cloned;
    } catch (CloneNotSupportedException e) {
      throw new RuntimeException(e);
    } 
  }




  
  public String toString() {
    StringBuilder buffer = new StringBuilder();
    buffer.append("[");
    
    boolean first = true;
    for (LongDoubleCursor cursor : this) {
      if (!first) {
        buffer.append(", ");
      }
      buffer.append(cursor.key);
      buffer.append("=>");
      buffer.append(cursor.value);
      first = false;
    } 
    buffer.append("]");
    return buffer.toString();
  }


  
  public String visualizeKeyDistribution(int characters) { return LongBufferVisualizer.visualizeKeyDistribution(this.keys, this.mask, characters); }




  
  public static LongDoubleHashMap from(long[] keys, double[] values) {
    if (keys.length != values.length) {
      throw new IllegalArgumentException("Arrays of keys and values must have an identical length.");
    }
    
    LongDoubleHashMap map = new LongDoubleHashMap(keys.length);
    for (int i = 0; i < keys.length; i++) {
      map.put(keys[i], values[i]);
    }
    
    return map;
  }












  
  protected int hashKey(long key) {
    assert key != 0L;
    return BitMixer.mix(key, this.keyMixer);
  }




  
  protected double verifyLoadFactor(double loadFactor) {
    HashContainers.checkLoadFactor(loadFactor, 0.009999999776482582D, 0.9900000095367432D);
    return loadFactor;
  }



  
  protected void rehash(long[] fromKeys, double[] fromValues) {
    assert fromKeys.length == fromValues.length && HashContainers.checkPowerOfTwo(fromKeys.length - 1);


    
    long[] keys = this.keys;
    double[] values = this.values;
    int mask = this.mask;


    
    int from = fromKeys.length - 1;
    keys[keys.length - 1] = fromKeys[from];
    values[values.length - 1] = fromValues[from];
    while (--from >= 0) {
      long existing; if ((existing = fromKeys[from]) != 0L) {
        int slot = hashKey(existing) & mask;
        while (keys[slot] != 0L) {
          slot = slot + 1 & mask;
        }
        keys[slot] = existing;
        values[slot] = fromValues[from];
      } 
    } 
  }




  
  protected void allocateBuffers(int arraySize) {
    assert Integer.bitCount(arraySize) == 1;

    
    int newKeyMixer = this.orderMixer.newKeyMixer(arraySize);

    
    long[] prevKeys = this.keys;
    double[] prevValues = this.values;
    try {
      int emptyElementSlot = 1;
      this.keys = new long[arraySize + emptyElementSlot];
      this.values = new double[arraySize + emptyElementSlot];
    } catch (OutOfMemoryError e) {
      this.keys = prevKeys;
      this.values = prevValues;
      throw new BufferAllocationException("Not enough memory to allocate buffers for rehashing: %,d -> %,d", e, new Object[] { Integer.valueOf(this.mask + 1), Integer.valueOf(arraySize) });
    } 




    
    this.resizeAt = HashContainers.expandAtCount(arraySize, this.loadFactor);
    this.keyMixer = newKeyMixer;
    this.mask = arraySize - 1;
  }









  
  protected void allocateThenInsertThenRehash(int slot, long pendingKey, double pendingValue) {
    assert this.assigned == this.resizeAt && this.keys[slot] == 0L && pendingKey != 0L;



    
    long[] prevKeys = this.keys;
    double[] prevValues = this.values;
    allocateBuffers(HashContainers.nextBufferSize(this.mask + 1, size(), this.loadFactor));
    assert this.keys.length > prevKeys.length;


    
    prevKeys[slot] = pendingKey;
    prevValues[slot] = pendingValue;

    
    rehash(prevKeys, prevValues);
  }




  
  protected void shiftConflictingKeys(int gapSlot) {
    long[] keys = this.keys;
    double[] values = this.values;
    int mask = this.mask;

    
    int distance = 0;
    while (true) {
      int slot = gapSlot + ++distance & mask;
      long existing = keys[slot];
      if (existing == 0L) {
        break;
      }
      
      int idealSlot = hashKey(existing);
      int shift = slot - idealSlot & mask;
      if (shift >= distance) {



        
        keys[gapSlot] = existing;
        values[gapSlot] = values[slot];
        gapSlot = slot;
        distance = 0;
      } 
    } 

    
    keys[gapSlot] = 0L;
    values[gapSlot] = 0.0D;
    this.assigned--;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\LongDoubleHashMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */