package com.carrotsearch.hppc;

import java.util.RandomAccess;

public interface DoubleIndexedContainer extends DoubleCollection, RandomAccess {
  int removeFirst(double paramDouble);
  
  int removeLast(double paramDouble);
  
  int indexOf(double paramDouble);
  
  int lastIndexOf(double paramDouble);
  
  void add(double paramDouble);
  
  void insert(int paramInt, double paramDouble);
  
  double set(int paramInt, double paramDouble);
  
  double get(int paramInt);
  
  double remove(int paramInt);
  
  void removeRange(int paramInt1, int paramInt2);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\DoubleIndexedContainer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */