package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.DoubleCursor;
import java.util.Iterator;

public interface DoubleDeque extends DoubleCollection {
  int removeFirst(double paramDouble);
  
  int removeLast(double paramDouble);
  
  void addFirst(double paramDouble);
  
  void addLast(double paramDouble);
  
  double removeFirst();
  
  double removeLast();
  
  double getFirst();
  
  double getLast();
  
  Iterator<DoubleCursor> descendingIterator();
  
  <T extends com.carrotsearch.hppc.procedures.DoubleProcedure> T descendingForEach(T paramT);
  
  <T extends com.carrotsearch.hppc.predicates.DoublePredicate> T descendingForEach(T paramT);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\DoubleDeque.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */