package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.LongDoubleCursor;

public interface LongDoubleMap extends LongDoubleAssociativeContainer {
  double get(long paramLong);
  
  double getOrDefault(long paramLong, double paramDouble);
  
  double put(long paramLong, double paramDouble);
  
  int putAll(LongDoubleAssociativeContainer paramLongDoubleAssociativeContainer);
  
  int putAll(Iterable<? extends LongDoubleCursor> paramIterable);
  
  double putOrAdd(long paramLong, double paramDouble1, double paramDouble2);
  
  double addTo(long paramLong, double paramDouble);
  
  double remove(long paramLong);
  
  boolean equals(Object paramObject);
  
  int hashCode();
  
  int indexOf(long paramLong);
  
  boolean indexExists(int paramInt);
  
  double indexGet(int paramInt);
  
  double indexReplace(int paramInt, double paramDouble);
  
  void indexInsert(int paramInt, long paramLong, double paramDouble);
  
  void clear();
  
  void release();
  
  String visualizeKeyDistribution(int paramInt);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\LongDoubleMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */