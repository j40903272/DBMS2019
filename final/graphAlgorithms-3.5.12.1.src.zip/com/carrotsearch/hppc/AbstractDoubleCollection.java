package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.DoubleCursor;
import com.carrotsearch.hppc.predicates.DoublePredicate;
import java.util.Arrays;















abstract class AbstractDoubleCollection
  implements DoubleCollection
{
  public int removeAll(final DoubleLookupContainer c) {
    return removeAll(new DoublePredicate()
        {
          public boolean apply(double k) { return c.contains(k); }
        });
  }






  
  public int retainAll(final DoubleLookupContainer c) {
    return removeAll(new DoublePredicate()
        {
          public boolean apply(double k) { return !c.contains(k); }
        });
  }






  
  public int retainAll(final DoublePredicate predicate) {
    return removeAll(new DoublePredicate()
        {
          public boolean apply(double value) { return !predicate.apply(value); }
        });
  }







  
  public double[] toArray() {
    double[] array = new double[size()];
    int i = 0;
    for (DoubleCursor c : this) {
      array[i++] = c.value;
    }
    return array;
  }







  
  public String toString() { return Arrays.toString(toArray()); }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\AbstractDoubleCollection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */