package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.ObjectLongCursor;
import com.carrotsearch.hppc.predicates.ObjectLongPredicate;
import com.carrotsearch.hppc.predicates.ObjectPredicate;
import java.util.Iterator;

public interface ObjectLongAssociativeContainer<KType> extends Iterable<ObjectLongCursor<KType>> {
  Iterator<ObjectLongCursor<KType>> iterator();
  
  boolean containsKey(KType paramKType);
  
  int size();
  
  boolean isEmpty();
  
  int removeAll(ObjectContainer<? super KType> paramObjectContainer);
  
  int removeAll(ObjectPredicate<? super KType> paramObjectPredicate);
  
  int removeAll(ObjectLongPredicate<? super KType> paramObjectLongPredicate);
  
  <T extends com.carrotsearch.hppc.procedures.ObjectLongProcedure<? super KType>> T forEach(T paramT);
  
  <T extends ObjectLongPredicate<? super KType>> T forEach(T paramT);
  
  ObjectCollection<KType> keys();
  
  LongContainer values();
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\ObjectLongAssociativeContainer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */