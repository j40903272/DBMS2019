package com.carrotsearch.hppc;
























public final class HashContainers
{
  public static final int MAX_HASH_ARRAY_LENGTH = 1073741824;
  public static final int MIN_HASH_ARRAY_LENGTH = 4;
  public static final float DEFAULT_LOAD_FACTOR = 0.75F;
  public static final float MIN_LOAD_FACTOR = 0.01F;
  public static final float MAX_LOAD_FACTOR = 0.99F;
  
  public static int maxElements(double loadFactor) {
    checkLoadFactor(loadFactor, 0.0D, 1.0D);
    return expandAtCount(1073741824, loadFactor) - 1;
  }

  
  static int minBufferSize(int elements, double loadFactor) {
    if (elements < 0) {
      throw new IllegalArgumentException("Number of elements must be >= 0: " + elements);
    }

    
    long length = (long)Math.ceil(elements / loadFactor);
    if (length == elements) {
      length++;
    }
    length = Math.max(4L, BitUtil.nextHighestPowerOfTwo(length));
    
    if (length > 1073741824L) {
      throw new BufferAllocationException("Maximum array size exceeded for this load factor (elements: %d, load factor: %f)", new Object[] { Integer.valueOf(elements), Double.valueOf(loadFactor) });
    }



    
    return (int)length;
  }

  
  static int nextBufferSize(int arraySize, int elements, double loadFactor) {
    assert checkPowerOfTwo(arraySize);
    if (arraySize == 1073741824) {
      throw new BufferAllocationException("Maximum array size exceeded for this load factor (elements: %d, load factor: %f)", new Object[] { Integer.valueOf(elements), Double.valueOf(loadFactor) });
    }



    
    return arraySize << 1;
  }

  
  static int expandAtCount(int arraySize, double loadFactor) {
    assert checkPowerOfTwo(arraySize);

    
    return Math.min(arraySize - 1, (int)Math.ceil(arraySize * loadFactor));
  }

  
  static void checkLoadFactor(double loadFactor, double minAllowedInclusive, double maxAllowedInclusive) {
    if (loadFactor < minAllowedInclusive || loadFactor > maxAllowedInclusive) {
      throw new BufferAllocationException("The load factor should be in range [%.2f, %.2f]: %f", new Object[] { Double.valueOf(minAllowedInclusive), Double.valueOf(maxAllowedInclusive), Double.valueOf(loadFactor) });
    }
  }






  
  static boolean checkPowerOfTwo(int arraySize) {
    assert arraySize > 1;
    assert BitUtil.nextHighestPowerOfTwo(arraySize) == arraySize;
    return true;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\HashContainers.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */