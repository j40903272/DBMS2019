package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.LongCursor;
import com.carrotsearch.hppc.predicates.LongPredicate;
import com.carrotsearch.hppc.procedures.LongProcedure;
import java.util.Arrays;
import java.util.Iterator;














public class LongArrayDeque
  extends AbstractLongCollection
  implements LongDeque, Preallocable, Cloneable
{
  public long[] buffer = LongArrayList.EMPTY_ARRAY;





  
  public int head;




  
  public int tail;




  
  protected final ArraySizingStrategy resizer;





  
  public LongArrayDeque() { this(4); }









  
  public LongArrayDeque(int expectedElements) { this(expectedElements, new BoundedProportionalArraySizingStrategy()); }











  
  public LongArrayDeque(int expectedElements, ArraySizingStrategy resizer) {
    assert resizer != null;
    this.resizer = resizer;
    ensureCapacity(expectedElements);
  }




  
  public LongArrayDeque(LongContainer container) {
    this(container.size());
    addLast(container);
  }




  
  public void addFirst(long e1) {
    int h = oneLeft(this.head, this.buffer.length);
    if (h == this.tail) {
      ensureBufferSpace(1);
      h = oneLeft(this.head, this.buffer.length);
    } 
    this.buffer[this.head = h] = e1;
  }









  
  public final void addFirst(long... elements) {
    ensureBufferSpace(elements.length);
    for (long k : elements) {
      addFirst(k);
    }
  }








  
  public int addFirst(LongContainer container) {
    int size = container.size();
    ensureBufferSpace(size);
    
    for (LongCursor cursor : container) {
      addFirst(cursor.value);
    }
    
    return size;
  }








  
  public int addFirst(Iterable<? extends LongCursor> iterable) {
    int size = 0;
    for (LongCursor cursor : iterable) {
      addFirst(cursor.value);
      size++;
    } 
    return size;
  }




  
  public void addLast(long e1) {
    int t = oneRight(this.tail, this.buffer.length);
    if (this.head == t) {
      ensureBufferSpace(1);
      t = oneRight(this.tail, this.buffer.length);
    } 
    this.buffer[this.tail] = e1;
    this.tail = t;
  }











  
  public final void addLast(long... elements) {
    ensureBufferSpace(1);
    for (long k : elements) {
      addLast(k);
    }
  }








  
  public int addLast(LongContainer container) {
    int size = container.size();
    ensureBufferSpace(size);
    
    for (LongCursor cursor : container) {
      addLast(cursor.value);
    }
    
    return size;
  }








  
  public int addLast(Iterable<? extends LongCursor> iterable) {
    int size = 0;
    for (LongCursor cursor : iterable) {
      addLast(cursor.value);
      size++;
    } 
    return size;
  }




  
  public long removeFirst() {
    assert size() > 0 : "The deque is empty.";
    
    long result = this.buffer[this.head];
    this.buffer[this.head] = 0L;
    this.head = oneRight(this.head, this.buffer.length);
    return result;
  }




  
  public long removeLast() {
    assert size() > 0 : "The deque is empty.";
    
    this.tail = oneLeft(this.tail, this.buffer.length);
    long result = this.buffer[this.tail];
    this.buffer[this.tail] = 0L;
    return result;
  }




  
  public long getFirst() {
    assert size() > 0 : "The deque is empty.";
    
    return this.buffer[this.head];
  }




  
  public long getLast() {
    assert size() > 0 : "The deque is empty.";
    
    return this.buffer[oneLeft(this.tail, this.buffer.length)];
  }




  
  public int removeFirst(long e1) {
    int index = bufferIndexOf(e1);
    if (index >= 0)
      removeAtBufferIndex(index); 
    return index;
  }









  
  public int bufferIndexOf(long e1) {
    int last = this.tail;
    int bufLen = this.buffer.length; int i;
    for (i = this.head; i != last; i = oneRight(i, bufLen)) {
      if (this.buffer[i] == e1) {
        return i;
      }
    } 
    
    return -1;
  }




  
  public int removeLast(long e1) {
    int index = lastBufferIndexOf(e1);
    if (index >= 0) {
      removeAtBufferIndex(index);
    }
    return index;
  }









  
  public int lastBufferIndexOf(long e1) {
    int bufLen = this.buffer.length;
    int last = oneLeft(this.head, bufLen); int i;
    for (i = oneLeft(this.tail, bufLen); i != last; i = oneLeft(i, bufLen)) {
      if (this.buffer[i] == e1) {
        return i;
      }
    } 
    return -1;
  }




  
  public int removeAll(long e1) {
    int removed = 0;
    int last = this.tail;
    int bufLen = this.buffer.length;
    int from, to;
    for (from = to = this.head; from != last; from = oneRight(from, bufLen)) {
      if (this.buffer[from] == e1) {
        this.buffer[from] = 0L;
        removed++;
      }
      else {
        
        if (to != from) {
          this.buffer[to] = this.buffer[from];
          this.buffer[from] = 0L;
        } 
        
        to = oneRight(to, bufLen);
      } 
    } 
    this.tail = to;
    return removed;
  }











  
  public void removeAtBufferIndex(int index) { assert false;
    throw new AssertionError("Index out of range (head=" + this.head + ", tail=" + this.tail + ", index=" + index + ")."); }







































  
  public boolean isEmpty() { return (size() == 0); }





  
  public int size() {
    if (this.head <= this.tail) {
      return this.tail - this.head;
    }
    return this.tail - this.head + this.buffer.length;
  }










  
  public void clear() {
    if (this.head < this.tail) {
      Arrays.fill(this.buffer, this.head, this.tail, 0L);
    } else {
      Arrays.fill(this.buffer, 0, this.tail, 0L);
      Arrays.fill(this.buffer, this.head, this.buffer.length, 0L);
    } 
    this.head = this.tail = 0;
  }




  
  public void release() {
    this.head = this.tail = 0;
    this.buffer = LongArrayList.EMPTY_ARRAY;
    ensureBufferSpace(0);
  }









  
  public void ensureCapacity(int expectedElements) { ensureBufferSpace(expectedElements - size()); }





  
  protected void ensureBufferSpace(int expectedAdditions) {
    int bufferLen = this.buffer.length;
    int elementsCount = size();
    
    if (elementsCount + expectedAdditions >= bufferLen) {
      int emptySlot = 1;
      int newSize = this.resizer.grow(bufferLen, elementsCount + 1, expectedAdditions);
      assert newSize >= elementsCount + expectedAdditions + 1 : "Resizer failed to return sensible new size: " + newSize + " <= " + (elementsCount + expectedAdditions);

      
      try {
        long[] newBuffer = new long[newSize];
        if (bufferLen > 0) {
          toArray(newBuffer);
          this.tail = elementsCount;
          this.head = 0;
        } 
        this.buffer = newBuffer;
      } catch (OutOfMemoryError e) {
        throw new BufferAllocationException("Not enough memory to allocate new buffers: %,d -> %,d", e, new Object[] { Integer.valueOf(bufferLen), Integer.valueOf(newSize) });
      } 
    } 
  }








  
  public long[] toArray() {
    int size = size();
    return toArray(new long[size]);
  }









  
  public long[] toArray(long[] target) {
    assert target.length >= size() : "Target array must be >= " + size();
    
    if (this.head < this.tail) {
      
      System.arraycopy(this.buffer, this.head, target, 0, size());
    } else if (this.head > this.tail) {

      
      int rightCount = this.buffer.length - this.head;
      System.arraycopy(this.buffer, this.head, target, 0, rightCount);
      System.arraycopy(this.buffer, 0, target, rightCount, this.tail);
    } 
    
    return target;
  }






  
  public LongArrayDeque clone() {
    try {
      LongArrayDeque cloned = (LongArrayDeque)super.clone();
      cloned.buffer = (long[])this.buffer.clone();
      return cloned;
    } catch (CloneNotSupportedException e) {
      throw new RuntimeException(e);
    } 
  }



  
  protected static int oneLeft(int index, int modulus) {
    if (index >= 1) {
      return index - 1;
    }
    return modulus - 1;
  }



  
  protected static int oneRight(int index, int modulus) {
    if (index + 1 == modulus) {
      return 0;
    }
    return index + 1;
  }

  
  private final class ValueIterator
    extends AbstractIterator<LongCursor>
  {
    private final LongCursor cursor;
    private int remaining;
    
    public ValueIterator() {
      this.cursor = new LongCursor();
      this.cursor.index = LongArrayDeque.oneLeft(LongArrayDeque.this.head, LongArrayDeque.this.buffer.length);
      this.remaining = LongArrayDeque.this.size();
    }

    
    protected LongCursor fetch() {
      if (this.remaining == 0) {
        return done();
      }
      
      this.remaining--;
      this.cursor.value = LongArrayDeque.this.buffer[this.cursor.index = LongArrayDeque.oneRight(this.cursor.index, LongArrayDeque.this.buffer.length)];
      return this.cursor;
    }
  }

  
  private final class DescendingValueIterator
    extends AbstractIterator<LongCursor>
  {
    private final LongCursor cursor;
    
    private int remaining;
    
    public DescendingValueIterator() {
      this.cursor = new LongCursor();
      this.cursor.index = LongArrayDeque.this.tail;
      this.remaining = LongArrayDeque.this.size();
    }

    
    protected LongCursor fetch() {
      if (this.remaining == 0) {
        return done();
      }
      this.remaining--;
      this.cursor.value = LongArrayDeque.this.buffer[this.cursor.index = LongArrayDeque.oneLeft(this.cursor.index, LongArrayDeque.this.buffer.length)];
      return this.cursor;
    }
  }














  
  public Iterator<LongCursor> iterator() { return new ValueIterator(); }
















  
  public Iterator<LongCursor> descendingIterator() { return new DescendingValueIterator(); }





  
  public <T extends LongProcedure> T forEach(T procedure) {
    forEach((LongProcedure)procedure, this.head, this.tail);
    return procedure;
  }




  
  private void forEach(LongProcedure procedure, int fromIndex, int toIndex) {
    long[] buffer = this.buffer; int i;
    for (i = fromIndex; i != toIndex; i = oneRight(i, buffer.length)) {
      procedure.apply(buffer[i]);
    }
  }




  
  public <T extends LongPredicate> T forEach(T predicate) {
    int fromIndex = this.head;
    int toIndex = this.tail;
    
    long[] buffer = this.buffer; int i;
    for (i = fromIndex; i != toIndex && 
      predicate.apply(buffer[i]); i = oneRight(i, buffer.length));



    
    return predicate;
  }




  
  public <T extends LongProcedure> T descendingForEach(T procedure) {
    descendingForEach((LongProcedure)procedure, this.head, this.tail);
    return procedure;
  }




  
  private void descendingForEach(LongProcedure procedure, int fromIndex, int toIndex) {
    if (fromIndex == toIndex) {
      return;
    }
    long[] buffer = this.buffer;
    int i = toIndex;
    do {
      i = oneLeft(i, buffer.length);
      procedure.apply(buffer[i]);
    } while (i != fromIndex);
  }




  
  public <T extends LongPredicate> T descendingForEach(T predicate) {
    descendingForEach((LongPredicate)predicate, this.head, this.tail);
    return predicate;
  }





  
  private void descendingForEach(LongPredicate predicate, int fromIndex, int toIndex) {
    if (fromIndex == toIndex) {
      return;
    }
    long[] buffer = this.buffer;
    int i = toIndex;
    do {
      i = oneLeft(i, buffer.length);
      if (!predicate.apply(buffer[i])) {
        break;
      }
    } while (i != fromIndex);
  }




  
  public int removeAll(LongPredicate predicate) {
    long[] buffer = this.buffer;
    int last = this.tail;
    int bufLen = buffer.length;
    int removed = 0;
    
    int to = this.head, from = to;
    try {
      for (from = to = this.head; from != last; from = oneRight(from, bufLen)) {
        if (predicate.apply(buffer[from])) {
          buffer[from] = 0L;
          removed++;
        }
        else {
          
          if (to != from) {
            buffer[to] = buffer[from];
            buffer[from] = 0L;
          } 
          
          to = oneRight(to, bufLen);
        } 
      } 
    } finally {
      for (; from != last; from = oneRight(from, bufLen)) {
        if (to != from) {
          buffer[to] = buffer[from];
          buffer[from] = 0L;
        } 
        
        to = oneRight(to, bufLen);
      } 
      this.tail = to;
    } 
    
    return removed;
  }




  
  public boolean contains(long e) {
    int fromIndex = this.head;
    int toIndex = this.tail;
    
    long[] buffer = this.buffer; int i;
    for (i = fromIndex; i != toIndex; i = oneRight(i, buffer.length)) {
      if (buffer[i] == e) {
        return true;
      }
    } 
    
    return false;
  }




  
  public int hashCode() {
    int h = 1;
    int fromIndex = this.head;
    int toIndex = this.tail;
    
    long[] buffer = this.buffer; int i;
    for (i = fromIndex; i != toIndex; i = oneRight(i, buffer.length)) {
      h = 31 * h + BitMixer.mix(this.buffer[i]);
    }
    return h;
  }







  
  public boolean equals(Object obj) { return (obj != null && getClass() == obj.getClass() && equalElements((LongArrayDeque)getClass().cast(obj))); }






  
  protected boolean equalElements(LongArrayDeque other) {
    int max = size();
    if (other.size() != max) {
      return false;
    }
    
    Iterator<LongCursor> i1 = iterator();
    Iterator<? extends LongCursor> i2 = other.iterator();
    
    while (i1.hasNext() && i2.hasNext()) {
      if (((LongCursor)i2.next()).value != ((LongCursor)i1.next()).value) {
        return false;
      }
    } 
    
    return (!i1.hasNext() && !i2.hasNext());
  }






  
  public static LongArrayDeque from(long... elements) {
    LongArrayDeque coll = new LongArrayDeque(elements.length);
    coll.addLast(elements);
    return coll;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\LongArrayDeque.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */