package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.IntObjectCursor;

public interface IntObjectMap<VType> extends IntObjectAssociativeContainer<VType> {
  VType get(int paramInt);
  
  VType getOrDefault(int paramInt, VType paramVType);
  
  VType put(int paramInt, VType paramVType);
  
  int putAll(IntObjectAssociativeContainer<? extends VType> paramIntObjectAssociativeContainer);
  
  int putAll(Iterable<? extends IntObjectCursor<? extends VType>> paramIterable);
  
  VType remove(int paramInt);
  
  boolean equals(Object paramObject);
  
  int hashCode();
  
  int indexOf(int paramInt);
  
  boolean indexExists(int paramInt);
  
  VType indexGet(int paramInt);
  
  VType indexReplace(int paramInt, VType paramVType);
  
  void indexInsert(int paramInt1, int paramInt2, VType paramVType);
  
  void clear();
  
  void release();
  
  String visualizeKeyDistribution(int paramInt);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\IntObjectMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */