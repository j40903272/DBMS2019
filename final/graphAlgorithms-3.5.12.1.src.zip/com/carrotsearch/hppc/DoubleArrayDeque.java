package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.DoubleCursor;
import com.carrotsearch.hppc.predicates.DoublePredicate;
import com.carrotsearch.hppc.procedures.DoubleProcedure;
import java.util.Arrays;
import java.util.Iterator;














public class DoubleArrayDeque
  extends AbstractDoubleCollection
  implements DoubleDeque, Preallocable, Cloneable
{
  public double[] buffer = DoubleArrayList.EMPTY_ARRAY;





  
  public int head;




  
  public int tail;




  
  protected final ArraySizingStrategy resizer;





  
  public DoubleArrayDeque() { this(4); }









  
  public DoubleArrayDeque(int expectedElements) { this(expectedElements, new BoundedProportionalArraySizingStrategy()); }











  
  public DoubleArrayDeque(int expectedElements, ArraySizingStrategy resizer) {
    assert resizer != null;
    this.resizer = resizer;
    ensureCapacity(expectedElements);
  }




  
  public DoubleArrayDeque(DoubleContainer container) {
    this(container.size());
    addLast(container);
  }




  
  public void addFirst(double e1) {
    int h = oneLeft(this.head, this.buffer.length);
    if (h == this.tail) {
      ensureBufferSpace(1);
      h = oneLeft(this.head, this.buffer.length);
    } 
    this.buffer[this.head = h] = e1;
  }









  
  public final void addFirst(double... elements) {
    ensureBufferSpace(elements.length);
    for (double k : elements) {
      addFirst(k);
    }
  }








  
  public int addFirst(DoubleContainer container) {
    int size = container.size();
    ensureBufferSpace(size);
    
    for (DoubleCursor cursor : container) {
      addFirst(cursor.value);
    }
    
    return size;
  }








  
  public int addFirst(Iterable<? extends DoubleCursor> iterable) {
    int size = 0;
    for (DoubleCursor cursor : iterable) {
      addFirst(cursor.value);
      size++;
    } 
    return size;
  }




  
  public void addLast(double e1) {
    int t = oneRight(this.tail, this.buffer.length);
    if (this.head == t) {
      ensureBufferSpace(1);
      t = oneRight(this.tail, this.buffer.length);
    } 
    this.buffer[this.tail] = e1;
    this.tail = t;
  }











  
  public final void addLast(double... elements) {
    ensureBufferSpace(1);
    for (double k : elements) {
      addLast(k);
    }
  }








  
  public int addLast(DoubleContainer container) {
    int size = container.size();
    ensureBufferSpace(size);
    
    for (DoubleCursor cursor : container) {
      addLast(cursor.value);
    }
    
    return size;
  }








  
  public int addLast(Iterable<? extends DoubleCursor> iterable) {
    int size = 0;
    for (DoubleCursor cursor : iterable) {
      addLast(cursor.value);
      size++;
    } 
    return size;
  }




  
  public double removeFirst() {
    assert size() > 0 : "The deque is empty.";
    
    double result = this.buffer[this.head];
    this.buffer[this.head] = 0.0D;
    this.head = oneRight(this.head, this.buffer.length);
    return result;
  }




  
  public double removeLast() {
    assert size() > 0 : "The deque is empty.";
    
    this.tail = oneLeft(this.tail, this.buffer.length);
    double result = this.buffer[this.tail];
    this.buffer[this.tail] = 0.0D;
    return result;
  }




  
  public double getFirst() {
    assert size() > 0 : "The deque is empty.";
    
    return this.buffer[this.head];
  }




  
  public double getLast() {
    assert size() > 0 : "The deque is empty.";
    
    return this.buffer[oneLeft(this.tail, this.buffer.length)];
  }




  
  public int removeFirst(double e1) {
    int index = bufferIndexOf(e1);
    if (index >= 0)
      removeAtBufferIndex(index); 
    return index;
  }









  
  public int bufferIndexOf(double e1) {
    int last = this.tail;
    int bufLen = this.buffer.length; int i;
    for (i = this.head; i != last; i = oneRight(i, bufLen)) {
      if (Double.doubleToLongBits(this.buffer[i]) == Double.doubleToLongBits(e1)) {
        return i;
      }
    } 
    
    return -1;
  }




  
  public int removeLast(double e1) {
    int index = lastBufferIndexOf(e1);
    if (index >= 0) {
      removeAtBufferIndex(index);
    }
    return index;
  }









  
  public int lastBufferIndexOf(double e1) {
    int bufLen = this.buffer.length;
    int last = oneLeft(this.head, bufLen); int i;
    for (i = oneLeft(this.tail, bufLen); i != last; i = oneLeft(i, bufLen)) {
      if (Double.doubleToLongBits(this.buffer[i]) == Double.doubleToLongBits(e1)) {
        return i;
      }
    } 
    return -1;
  }




  
  public int removeAll(double e1) {
    int removed = 0;
    int last = this.tail;
    int bufLen = this.buffer.length;
    int from, to;
    for (from = to = this.head; from != last; from = oneRight(from, bufLen)) {
      if (Double.doubleToLongBits(this.buffer[from]) == Double.doubleToLongBits(e1)) {
        this.buffer[from] = 0.0D;
        removed++;
      }
      else {
        
        if (to != from) {
          this.buffer[to] = this.buffer[from];
          this.buffer[from] = 0.0D;
        } 
        
        to = oneRight(to, bufLen);
      } 
    } 
    this.tail = to;
    return removed;
  }











  
  public void removeAtBufferIndex(int index) { assert false;
    throw new AssertionError("Index out of range (head=" + this.head + ", tail=" + this.tail + ", index=" + index + ")."); }







































  
  public boolean isEmpty() { return (size() == 0); }





  
  public int size() {
    if (this.head <= this.tail) {
      return this.tail - this.head;
    }
    return this.tail - this.head + this.buffer.length;
  }










  
  public void clear() {
    if (this.head < this.tail) {
      Arrays.fill(this.buffer, this.head, this.tail, 0.0D);
    } else {
      Arrays.fill(this.buffer, 0, this.tail, 0.0D);
      Arrays.fill(this.buffer, this.head, this.buffer.length, 0.0D);
    } 
    this.head = this.tail = 0;
  }




  
  public void release() {
    this.head = this.tail = 0;
    this.buffer = DoubleArrayList.EMPTY_ARRAY;
    ensureBufferSpace(0);
  }









  
  public void ensureCapacity(int expectedElements) { ensureBufferSpace(expectedElements - size()); }





  
  protected void ensureBufferSpace(int expectedAdditions) {
    int bufferLen = this.buffer.length;
    int elementsCount = size();
    
    if (elementsCount + expectedAdditions >= bufferLen) {
      int emptySlot = 1;
      int newSize = this.resizer.grow(bufferLen, elementsCount + 1, expectedAdditions);
      assert newSize >= elementsCount + expectedAdditions + 1 : "Resizer failed to return sensible new size: " + newSize + " <= " + (elementsCount + expectedAdditions);

      
      try {
        double[] newBuffer = new double[newSize];
        if (bufferLen > 0) {
          toArray(newBuffer);
          this.tail = elementsCount;
          this.head = 0;
        } 
        this.buffer = newBuffer;
      } catch (OutOfMemoryError e) {
        throw new BufferAllocationException("Not enough memory to allocate new buffers: %,d -> %,d", e, new Object[] { Integer.valueOf(bufferLen), Integer.valueOf(newSize) });
      } 
    } 
  }








  
  public double[] toArray() {
    int size = size();
    return toArray(new double[size]);
  }









  
  public double[] toArray(double[] target) {
    assert target.length >= size() : "Target array must be >= " + size();
    
    if (this.head < this.tail) {
      
      System.arraycopy(this.buffer, this.head, target, 0, size());
    } else if (this.head > this.tail) {

      
      int rightCount = this.buffer.length - this.head;
      System.arraycopy(this.buffer, this.head, target, 0, rightCount);
      System.arraycopy(this.buffer, 0, target, rightCount, this.tail);
    } 
    
    return target;
  }






  
  public DoubleArrayDeque clone() {
    try {
      DoubleArrayDeque cloned = (DoubleArrayDeque)super.clone();
      cloned.buffer = (double[])this.buffer.clone();
      return cloned;
    } catch (CloneNotSupportedException e) {
      throw new RuntimeException(e);
    } 
  }



  
  protected static int oneLeft(int index, int modulus) {
    if (index >= 1) {
      return index - 1;
    }
    return modulus - 1;
  }



  
  protected static int oneRight(int index, int modulus) {
    if (index + 1 == modulus) {
      return 0;
    }
    return index + 1;
  }

  
  private final class ValueIterator
    extends AbstractIterator<DoubleCursor>
  {
    private final DoubleCursor cursor;
    private int remaining;
    
    public ValueIterator() {
      this.cursor = new DoubleCursor();
      this.cursor.index = DoubleArrayDeque.oneLeft(DoubleArrayDeque.this.head, DoubleArrayDeque.this.buffer.length);
      this.remaining = DoubleArrayDeque.this.size();
    }

    
    protected DoubleCursor fetch() {
      if (this.remaining == 0) {
        return done();
      }
      
      this.remaining--;
      this.cursor.value = DoubleArrayDeque.this.buffer[this.cursor.index = DoubleArrayDeque.oneRight(this.cursor.index, DoubleArrayDeque.this.buffer.length)];
      return this.cursor;
    }
  }

  
  private final class DescendingValueIterator
    extends AbstractIterator<DoubleCursor>
  {
    private final DoubleCursor cursor;
    
    private int remaining;
    
    public DescendingValueIterator() {
      this.cursor = new DoubleCursor();
      this.cursor.index = DoubleArrayDeque.this.tail;
      this.remaining = DoubleArrayDeque.this.size();
    }

    
    protected DoubleCursor fetch() {
      if (this.remaining == 0) {
        return done();
      }
      this.remaining--;
      this.cursor.value = DoubleArrayDeque.this.buffer[this.cursor.index = DoubleArrayDeque.oneLeft(this.cursor.index, DoubleArrayDeque.this.buffer.length)];
      return this.cursor;
    }
  }














  
  public Iterator<DoubleCursor> iterator() { return new ValueIterator(); }
















  
  public Iterator<DoubleCursor> descendingIterator() { return new DescendingValueIterator(); }





  
  public <T extends DoubleProcedure> T forEach(T procedure) {
    forEach((DoubleProcedure)procedure, this.head, this.tail);
    return procedure;
  }




  
  private void forEach(DoubleProcedure procedure, int fromIndex, int toIndex) {
    double[] buffer = this.buffer; int i;
    for (i = fromIndex; i != toIndex; i = oneRight(i, buffer.length)) {
      procedure.apply(buffer[i]);
    }
  }




  
  public <T extends DoublePredicate> T forEach(T predicate) {
    int fromIndex = this.head;
    int toIndex = this.tail;
    
    double[] buffer = this.buffer; int i;
    for (i = fromIndex; i != toIndex && 
      predicate.apply(buffer[i]); i = oneRight(i, buffer.length));



    
    return predicate;
  }




  
  public <T extends DoubleProcedure> T descendingForEach(T procedure) {
    descendingForEach((DoubleProcedure)procedure, this.head, this.tail);
    return procedure;
  }




  
  private void descendingForEach(DoubleProcedure procedure, int fromIndex, int toIndex) {
    if (fromIndex == toIndex) {
      return;
    }
    double[] buffer = this.buffer;
    int i = toIndex;
    do {
      i = oneLeft(i, buffer.length);
      procedure.apply(buffer[i]);
    } while (i != fromIndex);
  }




  
  public <T extends DoublePredicate> T descendingForEach(T predicate) {
    descendingForEach((DoublePredicate)predicate, this.head, this.tail);
    return predicate;
  }





  
  private void descendingForEach(DoublePredicate predicate, int fromIndex, int toIndex) {
    if (fromIndex == toIndex) {
      return;
    }
    double[] buffer = this.buffer;
    int i = toIndex;
    do {
      i = oneLeft(i, buffer.length);
      if (!predicate.apply(buffer[i])) {
        break;
      }
    } while (i != fromIndex);
  }




  
  public int removeAll(DoublePredicate predicate) {
    double[] buffer = this.buffer;
    int last = this.tail;
    int bufLen = buffer.length;
    int removed = 0;
    
    int to = this.head, from = to;
    try {
      for (from = to = this.head; from != last; from = oneRight(from, bufLen)) {
        if (predicate.apply(buffer[from])) {
          buffer[from] = 0.0D;
          removed++;
        }
        else {
          
          if (to != from) {
            buffer[to] = buffer[from];
            buffer[from] = 0.0D;
          } 
          
          to = oneRight(to, bufLen);
        } 
      } 
    } finally {
      for (; from != last; from = oneRight(from, bufLen)) {
        if (to != from) {
          buffer[to] = buffer[from];
          buffer[from] = 0.0D;
        } 
        
        to = oneRight(to, bufLen);
      } 
      this.tail = to;
    } 
    
    return removed;
  }




  
  public boolean contains(double e) {
    int fromIndex = this.head;
    int toIndex = this.tail;
    
    double[] buffer = this.buffer; int i;
    for (i = fromIndex; i != toIndex; i = oneRight(i, buffer.length)) {
      if (Double.doubleToLongBits(buffer[i]) == Double.doubleToLongBits(e)) {
        return true;
      }
    } 
    
    return false;
  }




  
  public int hashCode() {
    int h = 1;
    int fromIndex = this.head;
    int toIndex = this.tail;
    
    double[] buffer = this.buffer; int i;
    for (i = fromIndex; i != toIndex; i = oneRight(i, buffer.length)) {
      h = 31 * h + BitMixer.mix(this.buffer[i]);
    }
    return h;
  }







  
  public boolean equals(Object obj) { return (obj != null && getClass() == obj.getClass() && equalElements((DoubleArrayDeque)getClass().cast(obj))); }






  
  protected boolean equalElements(DoubleArrayDeque other) {
    int max = size();
    if (other.size() != max) {
      return false;
    }
    
    Iterator<DoubleCursor> i1 = iterator();
    Iterator<? extends DoubleCursor> i2 = other.iterator();
    
    while (i1.hasNext() && i2.hasNext()) {
      if (Double.doubleToLongBits(((DoubleCursor)i2.next()).value) != Double.doubleToLongBits(((DoubleCursor)i1.next()).value)) {
        return false;
      }
    } 
    
    return (!i1.hasNext() && !i2.hasNext());
  }






  
  public static DoubleArrayDeque from(double... elements) {
    DoubleArrayDeque coll = new DoubleArrayDeque(elements.length);
    coll.addLast(elements);
    return coll;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\DoubleArrayDeque.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */