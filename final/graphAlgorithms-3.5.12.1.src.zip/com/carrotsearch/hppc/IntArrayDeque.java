package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.IntCursor;
import com.carrotsearch.hppc.predicates.IntPredicate;
import com.carrotsearch.hppc.procedures.IntProcedure;
import java.util.Arrays;
import java.util.Iterator;














public class IntArrayDeque
  extends AbstractIntCollection
  implements IntDeque, Preallocable, Cloneable
{
  public int[] buffer = IntArrayList.EMPTY_ARRAY;





  
  public int head;




  
  public int tail;




  
  protected final ArraySizingStrategy resizer;





  
  public IntArrayDeque() { this(4); }









  
  public IntArrayDeque(int expectedElements) { this(expectedElements, new BoundedProportionalArraySizingStrategy()); }











  
  public IntArrayDeque(int expectedElements, ArraySizingStrategy resizer) {
    assert resizer != null;
    this.resizer = resizer;
    ensureCapacity(expectedElements);
  }




  
  public IntArrayDeque(IntContainer container) {
    this(container.size());
    addLast(container);
  }




  
  public void addFirst(int e1) {
    int h = oneLeft(this.head, this.buffer.length);
    if (h == this.tail) {
      ensureBufferSpace(1);
      h = oneLeft(this.head, this.buffer.length);
    } 
    this.buffer[this.head = h] = e1;
  }









  
  public final void addFirst(int... elements) {
    ensureBufferSpace(elements.length);
    for (int k : elements) {
      addFirst(k);
    }
  }








  
  public int addFirst(IntContainer container) {
    int size = container.size();
    ensureBufferSpace(size);
    
    for (IntCursor cursor : container) {
      addFirst(cursor.value);
    }
    
    return size;
  }








  
  public int addFirst(Iterable<? extends IntCursor> iterable) {
    int size = 0;
    for (IntCursor cursor : iterable) {
      addFirst(cursor.value);
      size++;
    } 
    return size;
  }




  
  public void addLast(int e1) {
    int t = oneRight(this.tail, this.buffer.length);
    if (this.head == t) {
      ensureBufferSpace(1);
      t = oneRight(this.tail, this.buffer.length);
    } 
    this.buffer[this.tail] = e1;
    this.tail = t;
  }











  
  public final void addLast(int... elements) {
    ensureBufferSpace(1);
    for (int k : elements) {
      addLast(k);
    }
  }








  
  public int addLast(IntContainer container) {
    int size = container.size();
    ensureBufferSpace(size);
    
    for (IntCursor cursor : container) {
      addLast(cursor.value);
    }
    
    return size;
  }








  
  public int addLast(Iterable<? extends IntCursor> iterable) {
    int size = 0;
    for (IntCursor cursor : iterable) {
      addLast(cursor.value);
      size++;
    } 
    return size;
  }




  
  public int removeFirst() {
    assert size() > 0 : "The deque is empty.";
    
    int result = this.buffer[this.head];
    this.buffer[this.head] = 0;
    this.head = oneRight(this.head, this.buffer.length);
    return result;
  }




  
  public int removeLast() {
    assert size() > 0 : "The deque is empty.";
    
    this.tail = oneLeft(this.tail, this.buffer.length);
    int result = this.buffer[this.tail];
    this.buffer[this.tail] = 0;
    return result;
  }




  
  public int getFirst() {
    assert size() > 0 : "The deque is empty.";
    
    return this.buffer[this.head];
  }




  
  public int getLast() {
    assert size() > 0 : "The deque is empty.";
    
    return this.buffer[oneLeft(this.tail, this.buffer.length)];
  }




  
  public int removeFirst(int e1) {
    int index = bufferIndexOf(e1);
    if (index >= 0)
      removeAtBufferIndex(index); 
    return index;
  }









  
  public int bufferIndexOf(int e1) {
    int last = this.tail;
    int bufLen = this.buffer.length; int i;
    for (i = this.head; i != last; i = oneRight(i, bufLen)) {
      if (this.buffer[i] == e1) {
        return i;
      }
    } 
    
    return -1;
  }




  
  public int removeLast(int e1) {
    int index = lastBufferIndexOf(e1);
    if (index >= 0) {
      removeAtBufferIndex(index);
    }
    return index;
  }









  
  public int lastBufferIndexOf(int e1) {
    int bufLen = this.buffer.length;
    int last = oneLeft(this.head, bufLen); int i;
    for (i = oneLeft(this.tail, bufLen); i != last; i = oneLeft(i, bufLen)) {
      if (this.buffer[i] == e1) {
        return i;
      }
    } 
    return -1;
  }




  
  public int removeAll(int e1) {
    int removed = 0;
    int last = this.tail;
    int bufLen = this.buffer.length;
    int from, to;
    for (from = to = this.head; from != last; from = oneRight(from, bufLen)) {
      if (this.buffer[from] == e1) {
        this.buffer[from] = 0;
        removed++;
      }
      else {
        
        if (to != from) {
          this.buffer[to] = this.buffer[from];
          this.buffer[from] = 0;
        } 
        
        to = oneRight(to, bufLen);
      } 
    } 
    this.tail = to;
    return removed;
  }











  
  public void removeAtBufferIndex(int index) { assert false;
    throw new AssertionError("Index out of range (head=" + this.head + ", tail=" + this.tail + ", index=" + index + ")."); }







































  
  public boolean isEmpty() { return (size() == 0); }





  
  public int size() {
    if (this.head <= this.tail) {
      return this.tail - this.head;
    }
    return this.tail - this.head + this.buffer.length;
  }










  
  public void clear() {
    if (this.head < this.tail) {
      Arrays.fill(this.buffer, this.head, this.tail, 0);
    } else {
      Arrays.fill(this.buffer, 0, this.tail, 0);
      Arrays.fill(this.buffer, this.head, this.buffer.length, 0);
    } 
    this.head = this.tail = 0;
  }




  
  public void release() {
    this.head = this.tail = 0;
    this.buffer = IntArrayList.EMPTY_ARRAY;
    ensureBufferSpace(0);
  }









  
  public void ensureCapacity(int expectedElements) { ensureBufferSpace(expectedElements - size()); }





  
  protected void ensureBufferSpace(int expectedAdditions) {
    int bufferLen = this.buffer.length;
    int elementsCount = size();
    
    if (elementsCount + expectedAdditions >= bufferLen) {
      int emptySlot = 1;
      int newSize = this.resizer.grow(bufferLen, elementsCount + 1, expectedAdditions);
      assert newSize >= elementsCount + expectedAdditions + 1 : "Resizer failed to return sensible new size: " + newSize + " <= " + (elementsCount + expectedAdditions);

      
      try {
        int[] newBuffer = new int[newSize];
        if (bufferLen > 0) {
          toArray(newBuffer);
          this.tail = elementsCount;
          this.head = 0;
        } 
        this.buffer = newBuffer;
      } catch (OutOfMemoryError e) {
        throw new BufferAllocationException("Not enough memory to allocate new buffers: %,d -> %,d", e, new Object[] { Integer.valueOf(bufferLen), Integer.valueOf(newSize) });
      } 
    } 
  }








  
  public int[] toArray() {
    int size = size();
    return toArray(new int[size]);
  }









  
  public int[] toArray(int[] target) {
    assert target.length >= size() : "Target array must be >= " + size();
    
    if (this.head < this.tail) {
      
      System.arraycopy(this.buffer, this.head, target, 0, size());
    } else if (this.head > this.tail) {

      
      int rightCount = this.buffer.length - this.head;
      System.arraycopy(this.buffer, this.head, target, 0, rightCount);
      System.arraycopy(this.buffer, 0, target, rightCount, this.tail);
    } 
    
    return target;
  }






  
  public IntArrayDeque clone() {
    try {
      IntArrayDeque cloned = (IntArrayDeque)super.clone();
      cloned.buffer = (int[])this.buffer.clone();
      return cloned;
    } catch (CloneNotSupportedException e) {
      throw new RuntimeException(e);
    } 
  }



  
  protected static int oneLeft(int index, int modulus) {
    if (index >= 1) {
      return index - 1;
    }
    return modulus - 1;
  }



  
  protected static int oneRight(int index, int modulus) {
    if (index + 1 == modulus) {
      return 0;
    }
    return index + 1;
  }

  
  private final class ValueIterator
    extends AbstractIterator<IntCursor>
  {
    private final IntCursor cursor;
    private int remaining;
    
    public ValueIterator() {
      this.cursor = new IntCursor();
      this.cursor.index = IntArrayDeque.oneLeft(IntArrayDeque.this.head, IntArrayDeque.this.buffer.length);
      this.remaining = IntArrayDeque.this.size();
    }

    
    protected IntCursor fetch() {
      if (this.remaining == 0) {
        return done();
      }
      
      this.remaining--;
      this.cursor.value = IntArrayDeque.this.buffer[this.cursor.index = IntArrayDeque.oneRight(this.cursor.index, IntArrayDeque.this.buffer.length)];
      return this.cursor;
    }
  }

  
  private final class DescendingValueIterator
    extends AbstractIterator<IntCursor>
  {
    private final IntCursor cursor;
    
    private int remaining;
    
    public DescendingValueIterator() {
      this.cursor = new IntCursor();
      this.cursor.index = IntArrayDeque.this.tail;
      this.remaining = IntArrayDeque.this.size();
    }

    
    protected IntCursor fetch() {
      if (this.remaining == 0) {
        return done();
      }
      this.remaining--;
      this.cursor.value = IntArrayDeque.this.buffer[this.cursor.index = IntArrayDeque.oneLeft(this.cursor.index, IntArrayDeque.this.buffer.length)];
      return this.cursor;
    }
  }














  
  public Iterator<IntCursor> iterator() { return new ValueIterator(); }
















  
  public Iterator<IntCursor> descendingIterator() { return new DescendingValueIterator(); }





  
  public <T extends IntProcedure> T forEach(T procedure) {
    forEach((IntProcedure)procedure, this.head, this.tail);
    return procedure;
  }




  
  private void forEach(IntProcedure procedure, int fromIndex, int toIndex) {
    int[] buffer = this.buffer; int i;
    for (i = fromIndex; i != toIndex; i = oneRight(i, buffer.length)) {
      procedure.apply(buffer[i]);
    }
  }




  
  public <T extends IntPredicate> T forEach(T predicate) {
    int fromIndex = this.head;
    int toIndex = this.tail;
    
    int[] buffer = this.buffer; int i;
    for (i = fromIndex; i != toIndex && 
      predicate.apply(buffer[i]); i = oneRight(i, buffer.length));



    
    return predicate;
  }




  
  public <T extends IntProcedure> T descendingForEach(T procedure) {
    descendingForEach((IntProcedure)procedure, this.head, this.tail);
    return procedure;
  }




  
  private void descendingForEach(IntProcedure procedure, int fromIndex, int toIndex) {
    if (fromIndex == toIndex) {
      return;
    }
    int[] buffer = this.buffer;
    int i = toIndex;
    do {
      i = oneLeft(i, buffer.length);
      procedure.apply(buffer[i]);
    } while (i != fromIndex);
  }




  
  public <T extends IntPredicate> T descendingForEach(T predicate) {
    descendingForEach((IntPredicate)predicate, this.head, this.tail);
    return predicate;
  }





  
  private void descendingForEach(IntPredicate predicate, int fromIndex, int toIndex) {
    if (fromIndex == toIndex) {
      return;
    }
    int[] buffer = this.buffer;
    int i = toIndex;
    do {
      i = oneLeft(i, buffer.length);
      if (!predicate.apply(buffer[i])) {
        break;
      }
    } while (i != fromIndex);
  }




  
  public int removeAll(IntPredicate predicate) {
    int[] buffer = this.buffer;
    int last = this.tail;
    int bufLen = buffer.length;
    int removed = 0;
    
    int to = this.head, from = to;
    try {
      for (from = to = this.head; from != last; from = oneRight(from, bufLen)) {
        if (predicate.apply(buffer[from])) {
          buffer[from] = 0;
          removed++;
        }
        else {
          
          if (to != from) {
            buffer[to] = buffer[from];
            buffer[from] = 0;
          } 
          
          to = oneRight(to, bufLen);
        } 
      } 
    } finally {
      for (; from != last; from = oneRight(from, bufLen)) {
        if (to != from) {
          buffer[to] = buffer[from];
          buffer[from] = 0;
        } 
        
        to = oneRight(to, bufLen);
      } 
      this.tail = to;
    } 
    
    return removed;
  }




  
  public boolean contains(int e) {
    int fromIndex = this.head;
    int toIndex = this.tail;
    
    int[] buffer = this.buffer; int i;
    for (i = fromIndex; i != toIndex; i = oneRight(i, buffer.length)) {
      if (buffer[i] == e) {
        return true;
      }
    } 
    
    return false;
  }




  
  public int hashCode() {
    int h = 1;
    int fromIndex = this.head;
    int toIndex = this.tail;
    
    int[] buffer = this.buffer; int i;
    for (i = fromIndex; i != toIndex; i = oneRight(i, buffer.length)) {
      h = 31 * h + BitMixer.mix(this.buffer[i]);
    }
    return h;
  }







  
  public boolean equals(Object obj) { return (obj != null && getClass() == obj.getClass() && equalElements((IntArrayDeque)getClass().cast(obj))); }






  
  protected boolean equalElements(IntArrayDeque other) {
    int max = size();
    if (other.size() != max) {
      return false;
    }
    
    Iterator<IntCursor> i1 = iterator();
    Iterator<? extends IntCursor> i2 = other.iterator();
    
    while (i1.hasNext() && i2.hasNext()) {
      if (((IntCursor)i2.next()).value != ((IntCursor)i1.next()).value) {
        return false;
      }
    } 
    
    return (!i1.hasNext() && !i2.hasNext());
  }






  
  public static IntArrayDeque from(int... elements) {
    IntArrayDeque coll = new IntArrayDeque(elements.length);
    coll.addLast(elements);
    return coll;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\IntArrayDeque.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */