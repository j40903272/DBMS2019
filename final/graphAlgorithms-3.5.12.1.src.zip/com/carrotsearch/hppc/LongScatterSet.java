package com.carrotsearch.hppc;






















public class LongScatterSet
  extends LongHashSet
{
  public LongScatterSet() { this(4, 0.75D); }





  
  public LongScatterSet(int expectedElements) { this(expectedElements, 0.75D); }






  
  public LongScatterSet(int expectedElements, double loadFactor) { super(expectedElements, loadFactor, HashOrderMixing.none()); }



  
  protected int hashKey(long key) { return BitMixer.mixPhi(key); }







  
  public static LongScatterSet from(long... elements) {
    LongScatterSet set = new LongScatterSet(elements.length);
    set.addAll(elements);
    return set;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\LongScatterSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */