package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.IntFloatCursor;

public interface IntFloatMap extends IntFloatAssociativeContainer {
  float get(int paramInt);
  
  float getOrDefault(int paramInt, float paramFloat);
  
  float put(int paramInt, float paramFloat);
  
  int putAll(IntFloatAssociativeContainer paramIntFloatAssociativeContainer);
  
  int putAll(Iterable<? extends IntFloatCursor> paramIterable);
  
  float putOrAdd(int paramInt, float paramFloat1, float paramFloat2);
  
  float addTo(int paramInt, float paramFloat);
  
  float remove(int paramInt);
  
  boolean equals(Object paramObject);
  
  int hashCode();
  
  int indexOf(int paramInt);
  
  boolean indexExists(int paramInt);
  
  float indexGet(int paramInt);
  
  float indexReplace(int paramInt, float paramFloat);
  
  void indexInsert(int paramInt1, int paramInt2, float paramFloat);
  
  void clear();
  
  void release();
  
  String visualizeKeyDistribution(int paramInt);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\IntFloatMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */