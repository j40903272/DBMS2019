package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.FloatCursor;
import com.carrotsearch.hppc.cursors.LongCursor;
import com.carrotsearch.hppc.cursors.LongFloatCursor;
import com.carrotsearch.hppc.predicates.FloatPredicate;
import com.carrotsearch.hppc.predicates.LongFloatPredicate;
import com.carrotsearch.hppc.predicates.LongPredicate;
import com.carrotsearch.hppc.procedures.LongFloatProcedure;
import com.carrotsearch.hppc.procedures.LongProcedure;
import java.util.Arrays;
import java.util.Iterator;




































































public class LongFloatHashMap
  implements LongFloatMap, Preallocable, Cloneable
{
  public long[] keys;
  public float[] values;
  protected int keyMixer;
  protected int assigned;
  protected int mask;
  protected int resizeAt;
  protected boolean hasEmptyKey;
  protected double loadFactor;
  protected HashOrderMixingStrategy orderMixer;
  
  public LongFloatHashMap() { this(4); }









  
  public LongFloatHashMap(int expectedElements) { this(expectedElements, 0.75D); }












  
  public LongFloatHashMap(int expectedElements, double loadFactor) { this(expectedElements, loadFactor, HashOrderMixing.defaultStrategy()); }














  
  public LongFloatHashMap(int expectedElements, double loadFactor, HashOrderMixingStrategy orderMixer) {
    this.orderMixer = orderMixer;
    this.loadFactor = verifyLoadFactor(loadFactor);
    ensureCapacity(expectedElements);
  }



  
  public LongFloatHashMap(LongFloatAssociativeContainer container) {
    this(container.size());
    putAll(container);
  }




  
  public float put(long key, float value) {
    assert this.assigned < this.mask + 1;
    
    int mask = this.mask;
    if (key == 0L) {
      this.hasEmptyKey = true;
      float previousValue = this.values[mask + 1];
      this.values[mask + 1] = value;
      return previousValue;
    } 
    long[] keys = this.keys;
    int slot = hashKey(key) & mask;
    
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        float previousValue = this.values[slot];
        this.values[slot] = value;
        return previousValue;
      } 
      slot = slot + 1 & mask;
    } 
    
    if (this.assigned == this.resizeAt) {
      allocateThenInsertThenRehash(slot, key, value);
    } else {
      keys[slot] = key;
      this.values[slot] = value;
    } 
    
    this.assigned++;
    return 0.0F;
  }





  
  public int putAll(LongFloatAssociativeContainer container) {
    int count = size();
    for (LongFloatCursor c : container) {
      put(c.key, c.value);
    }
    return size() - count;
  }




  
  public int putAll(Iterable<? extends LongFloatCursor> iterable) {
    int count = size();
    for (LongFloatCursor c : iterable) {
      put(c.key, c.value);
    }
    return size() - count;
  }












  
  public boolean putIfAbsent(long key, float value) {
    int keyIndex = indexOf(key);
    if (!indexExists(keyIndex)) {
      indexInsert(keyIndex, key, value);
      return true;
    } 
    return false;
  }
















  
  public float putOrAdd(long key, float putValue, float incrementValue) {
    assert this.assigned < this.mask + 1;
    
    int keyIndex = indexOf(key);
    if (indexExists(keyIndex)) {
      putValue = this.values[keyIndex] + incrementValue;
      indexReplace(keyIndex, putValue);
    } else {
      indexInsert(keyIndex, key, putValue);
    } 
    return putValue;
  }













  
  public float addTo(long key, float incrementValue) { return putOrAdd(key, incrementValue, incrementValue); }






  
  public float remove(long key) {
    int mask = this.mask;
    if (key == 0L) {
      this.hasEmptyKey = false;
      float previousValue = this.values[mask + 1];
      this.values[mask + 1] = 0.0F;
      return previousValue;
    } 
    long[] keys = this.keys;
    int slot = hashKey(key) & mask;
    
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        float previousValue = this.values[slot];
        shiftConflictingKeys(slot);
        return previousValue;
      } 
      slot = slot + 1 & mask;
    } 
    
    return 0.0F;
  }





  
  public int removeAll(LongContainer other) {
    int before = size();




    
    if (other.size() >= size() && other instanceof LongLookupContainer) {
      
      if (this.hasEmptyKey && 
        other.contains(0L)) {
        this.hasEmptyKey = false;
        this.values[this.mask + 1] = 0.0F;
      } 

      
      long[] keys = this.keys;
      for (int slot = 0, max = this.mask; slot <= max; ) {
        long existing;
        if ((existing = keys[slot]) != 0L && other.contains(existing)) {
          
          shiftConflictingKeys(slot); continue;
        } 
        slot++;
      } 
    } else {
      
      for (LongCursor c : other) {
        remove(c.value);
      }
    } 
    
    return before - size();
  }




  
  public int removeAll(LongFloatPredicate predicate) {
    int before = size();
    
    int mask = this.mask;
    
    if (this.hasEmptyKey && 
      predicate.apply(0L, this.values[mask + 1])) {
      this.hasEmptyKey = false;
      this.values[mask + 1] = 0.0F;
    } 

    
    long[] keys = this.keys;
    float[] values = this.values;
    for (int slot = 0; slot <= mask; ) {
      long existing;
      if ((existing = keys[slot]) != 0L && predicate.apply(existing, values[slot])) {

        
        shiftConflictingKeys(slot); continue;
      } 
      slot++;
    } 

    
    return before - size();
  }




  
  public int removeAll(LongPredicate predicate) {
    int before = size();
    
    if (this.hasEmptyKey && 
      predicate.apply(0L)) {
      this.hasEmptyKey = false;
      this.values[this.mask + 1] = 0.0F;
    } 

    
    long[] keys = this.keys;
    for (int slot = 0, max = this.mask; slot <= max; ) {
      long existing;
      if ((existing = keys[slot]) != 0L && predicate.apply(existing)) {

        
        shiftConflictingKeys(slot); continue;
      } 
      slot++;
    } 

    
    return before - size();
  }




  
  public float get(long key) {
    if (key == 0L) {
      return this.hasEmptyKey ? this.values[this.mask + 1] : 0.0F;
    }
    long[] keys = this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        return this.values[slot];
      }
      slot = slot + 1 & mask;
    } 
    
    return 0.0F;
  }





  
  public float getOrDefault(long key, float defaultValue) {
    if (key == 0L) {
      return this.hasEmptyKey ? this.values[this.mask + 1] : defaultValue;
    }
    long[] keys = this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        return this.values[slot];
      }
      slot = slot + 1 & mask;
    } 
    
    return defaultValue;
  }





  
  public boolean containsKey(long key) {
    if (key == 0L) {
      return this.hasEmptyKey;
    }
    long[] keys = this.keys;
    int mask = this.mask;
    int slot = hashKey(key) & mask;
    
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        return true;
      }
      slot = slot + 1 & mask;
    } 
    
    return false;
  }





  
  public int indexOf(long key) {
    int mask = this.mask;
    if (key == 0L) {
      return this.hasEmptyKey ? (mask + 1) : (mask + 1 ^ 0xFFFFFFFF);
    }
    long[] keys = this.keys;
    int slot = hashKey(key) & mask;
    
    long existing;
    while ((existing = keys[slot]) != 0L) {
      if (existing == key) {
        return slot;
      }
      slot = slot + 1 & mask;
    } 
    
    return slot ^ 0xFFFFFFFF;
  }





  
  public boolean indexExists(int index) {
    assert index == this.mask + 1 && this.hasEmptyKey;


    
    return (index >= 0);
  }




  
  public float indexGet(int index) {
    assert index >= 0 : "The index must point at an existing key.";
    assert index <= this.mask || (index == this.mask + 1 && this.hasEmptyKey);

    
    return this.values[index];
  }




  
  public float indexReplace(int index, float newValue) {
    assert index >= 0 : "The index must point at an existing key.";
    assert index <= this.mask || (index == this.mask + 1 && this.hasEmptyKey);

    
    float previousValue = this.values[index];
    this.values[index] = newValue;
    return previousValue;
  }




  
  public void indexInsert(int index, long key, float value) {
    assert index < 0 : "The index must not point at an existing key.";
    
    index ^= 0xFFFFFFFF;
    if (key == 0L) {
      assert index == this.mask + 1;
      this.values[index] = value;
      this.hasEmptyKey = true;
    } else {
      assert this.keys[index] == 0L;
      
      if (this.assigned == this.resizeAt) {
        allocateThenInsertThenRehash(index, key, value);
      } else {
        this.keys[index] = key;
        this.values[index] = value;
      } 
      
      this.assigned++;
    } 
  }




  
  public void clear() {
    this.assigned = 0;
    this.hasEmptyKey = false;
    
    Arrays.fill(this.keys, 0L);
  }






  
  public void release() {
    this.assigned = 0;
    this.hasEmptyKey = false;
    
    this.keys = null;
    this.values = null;
    ensureCapacity(4);
  }





  
  public int size() { return this.assigned + (this.hasEmptyKey ? 1 : 0); }





  
  public boolean isEmpty() { return (size() == 0); }





  
  public int hashCode() {
    int h = this.hasEmptyKey ? -559038737 : 0;
    for (LongFloatCursor c : this) {
      h += BitMixer.mix(c.key) + BitMixer.mix(c.value);
    }
    
    return h;
  }





  
  public boolean equals(Object obj) { return (obj != null && getClass() == obj.getClass() && equalElements((LongFloatHashMap)getClass().cast(obj))); }






  
  protected boolean equalElements(LongFloatHashMap other) {
    if (other.size() != size()) {
      return false;
    }
    
    for (LongFloatCursor c : other) {
      long key = c.key;
      if (!containsKey(key) || Float.floatToIntBits(get(key)) != Float.floatToIntBits(c.value))
      {
        return false;
      }
    } 
    
    return true;
  }







  
  public void ensureCapacity(int expectedElements) {
    if (expectedElements > this.resizeAt || this.keys == null) {
      long[] prevKeys = this.keys;
      float[] prevValues = this.values;
      allocateBuffers(HashContainers.minBufferSize(expectedElements, this.loadFactor));
      if (prevKeys != null && !isEmpty()) {
        rehash(prevKeys, prevValues);
      }
    } 
  }

  
  private final class EntryIterator
    extends AbstractIterator<LongFloatCursor>
  {
    private final LongFloatCursor cursor;
    private final int max = LongFloatHashMap.this.mask + 1;
    private int slot = -1;

    
    public EntryIterator() { this.cursor = new LongFloatCursor(); }


    
    protected LongFloatCursor fetch() {
      if (this.slot < this.max) {
        
        this.slot++; for (; this.slot < this.max; this.slot++) {
          long existing; if ((existing = LongFloatHashMap.this.keys[this.slot]) != 0L) {
            this.cursor.index = this.slot;
            this.cursor.key = existing;
            this.cursor.value = LongFloatHashMap.this.values[this.slot];
            return this.cursor;
          } 
        } 
      } 
      
      if (this.slot == this.max && LongFloatHashMap.this.hasEmptyKey) {
        this.cursor.index = this.slot;
        this.cursor.key = 0L;
        this.cursor.value = LongFloatHashMap.this.values[this.max];
        this.slot++;
        return this.cursor;
      } 
      
      return done();
    }
  }





  
  public Iterator<LongFloatCursor> iterator() { return new EntryIterator(); }





  
  public <T extends LongFloatProcedure> T forEach(T procedure) {
    long[] keys = this.keys;
    float[] values = this.values;
    
    if (this.hasEmptyKey) {
      procedure.apply(0L, values[this.mask + 1]);
    }
    
    for (int slot = 0, max = this.mask; slot <= max; slot++) {
      if (keys[slot] != 0L) {
        procedure.apply(keys[slot], values[slot]);
      }
    } 
    
    return procedure;
  }




  
  public <T extends LongFloatPredicate> T forEach(T predicate) {
    long[] keys = this.keys;
    float[] values = this.values;
    
    if (this.hasEmptyKey && 
      !predicate.apply(0L, values[this.mask + 1])) {
      return predicate;
    }

    
    for (int slot = 0, max = this.mask; slot <= max && (
      keys[slot] == 0L || 
      predicate.apply(keys[slot], values[slot])); slot++);




    
    return predicate;
  }





  
  public KeysContainer keys() { return new KeysContainer(); }


  
  public final class KeysContainer
    extends AbstractLongCollection
    implements LongLookupContainer
  {
    private final LongFloatHashMap owner = LongFloatHashMap.this;


    
    public boolean contains(long e) { return this.owner.containsKey(e); }


    
    public <T extends LongProcedure> T forEach(final T procedure) {
      this.owner.forEach(new LongFloatProcedure()
          {
            public void apply(long key, float value) {
              procedure.apply(key);
            }
          });
      
      return procedure;
    }

    
    public <T extends LongPredicate> T forEach(final T predicate) {
      this.owner.forEach(new LongFloatPredicate()
          {
            public boolean apply(long key, float value) {
              return predicate.apply(key);
            }
          });
      
      return predicate;
    }


    
    public boolean isEmpty() { return this.owner.isEmpty(); }



    
    public Iterator<LongCursor> iterator() { return new LongFloatHashMap.KeysIterator(); }



    
    public int size() { return this.owner.size(); }



    
    public void clear() { this.owner.clear(); }



    
    public void release() { this.owner.release(); }



    
    public int removeAll(LongPredicate predicate) { return this.owner.removeAll(predicate); }


    
    public int removeAll(long e) {
      boolean hasKey = this.owner.containsKey(e);
      if (hasKey) {
        this.owner.remove(e);
        return 1;
      } 
      return 0;
    }
  }

  
  private final class KeysIterator
    extends AbstractIterator<LongCursor>
  {
    private final LongCursor cursor;
    
    private final int max = LongFloatHashMap.this.mask + 1;
    private int slot = -1;

    
    public KeysIterator() { this.cursor = new LongCursor(); }


    
    protected LongCursor fetch() {
      if (this.slot < this.max) {
        
        this.slot++; for (; this.slot < this.max; this.slot++) {
          long existing; if ((existing = LongFloatHashMap.this.keys[this.slot]) != 0L) {
            this.cursor.index = this.slot;
            this.cursor.value = existing;
            return this.cursor;
          } 
        } 
      } 
      
      if (this.slot == this.max && LongFloatHashMap.this.hasEmptyKey) {
        this.cursor.index = this.slot;
        this.cursor.value = 0L;
        this.slot++;
        return this.cursor;
      } 
      
      return done();
    }
  }




  
  public FloatCollection values() {
    return new ValuesContainer();
  }

  
  private final class ValuesContainer
    extends AbstractFloatCollection
  {
    private final LongFloatHashMap owner = LongFloatHashMap.this;


    
    public int size() { return this.owner.size(); }



    
    public boolean isEmpty() { return this.owner.isEmpty(); }


    
    public boolean contains(float value) {
      for (LongFloatCursor c : this.owner) {
        if (Float.floatToIntBits(c.value) == Float.floatToIntBits(value)) {
          return true;
        }
      } 
      return false;
    }

    
    public <T extends com.carrotsearch.hppc.procedures.FloatProcedure> T forEach(T procedure) {
      for (LongFloatCursor c : this.owner) {
        procedure.apply(c.value);
      }
      return procedure;
    }

    
    public <T extends FloatPredicate> T forEach(T predicate) {
      for (LongFloatCursor c : this.owner) {
        if (!predicate.apply(c.value)) {
          break;
        }
      } 
      return predicate;
    }


    
    public Iterator<FloatCursor> iterator() { return new LongFloatHashMap.ValuesIterator(); }


    
    public int removeAll(final float e) {
      return this.owner.removeAll(new LongFloatPredicate()
          {
            public boolean apply(long key, float value) {
              return (Float.floatToIntBits(value) == Float.floatToIntBits(e));
            }
          });
    }

    
    public int removeAll(final FloatPredicate predicate) {
      return this.owner.removeAll(new LongFloatPredicate()
          {
            public boolean apply(long key, float value) {
              return predicate.apply(value);
            }
          });
    }


    
    public void clear() { this.owner.clear(); }



    
    public void release() { this.owner.release(); }
    
    private ValuesContainer() {}
  }
  
  private final class ValuesIterator
    extends AbstractIterator<FloatCursor>
  {
    private final FloatCursor cursor;
    private final int max = LongFloatHashMap.this.mask + 1;
    private int slot = -1;

    
    public ValuesIterator() { this.cursor = new FloatCursor(); }


    
    protected FloatCursor fetch() {
      if (this.slot < this.max) {
        this.slot++; for (; this.slot < this.max; this.slot++) {
          if (LongFloatHashMap.this.keys[this.slot] != 0L) {
            this.cursor.index = this.slot;
            this.cursor.value = LongFloatHashMap.this.values[this.slot];
            return this.cursor;
          } 
        } 
      } 
      
      if (this.slot == this.max && LongFloatHashMap.this.hasEmptyKey) {
        this.cursor.index = this.slot;
        this.cursor.value = LongFloatHashMap.this.values[this.max];
        this.slot++;
        return this.cursor;
      } 
      
      return done();
    }
  }





  
  public LongFloatHashMap clone() {
    try {
      LongFloatHashMap cloned = (LongFloatHashMap)super.clone();
      cloned.keys = (long[])this.keys.clone();
      cloned.values = (float[])this.values.clone();
      cloned.hasEmptyKey = cloned.hasEmptyKey;
      cloned.orderMixer = this.orderMixer.clone();
      return cloned;
    } catch (CloneNotSupportedException e) {
      throw new RuntimeException(e);
    } 
  }




  
  public String toString() {
    StringBuilder buffer = new StringBuilder();
    buffer.append("[");
    
    boolean first = true;
    for (LongFloatCursor cursor : this) {
      if (!first) {
        buffer.append(", ");
      }
      buffer.append(cursor.key);
      buffer.append("=>");
      buffer.append(cursor.value);
      first = false;
    } 
    buffer.append("]");
    return buffer.toString();
  }


  
  public String visualizeKeyDistribution(int characters) { return LongBufferVisualizer.visualizeKeyDistribution(this.keys, this.mask, characters); }




  
  public static LongFloatHashMap from(long[] keys, float[] values) {
    if (keys.length != values.length) {
      throw new IllegalArgumentException("Arrays of keys and values must have an identical length.");
    }
    
    LongFloatHashMap map = new LongFloatHashMap(keys.length);
    for (int i = 0; i < keys.length; i++) {
      map.put(keys[i], values[i]);
    }
    
    return map;
  }












  
  protected int hashKey(long key) {
    assert key != 0L;
    return BitMixer.mix(key, this.keyMixer);
  }




  
  protected double verifyLoadFactor(double loadFactor) {
    HashContainers.checkLoadFactor(loadFactor, 0.009999999776482582D, 0.9900000095367432D);
    return loadFactor;
  }



  
  protected void rehash(long[] fromKeys, float[] fromValues) {
    assert fromKeys.length == fromValues.length && HashContainers.checkPowerOfTwo(fromKeys.length - 1);


    
    long[] keys = this.keys;
    float[] values = this.values;
    int mask = this.mask;


    
    int from = fromKeys.length - 1;
    keys[keys.length - 1] = fromKeys[from];
    values[values.length - 1] = fromValues[from];
    while (--from >= 0) {
      long existing; if ((existing = fromKeys[from]) != 0L) {
        int slot = hashKey(existing) & mask;
        while (keys[slot] != 0L) {
          slot = slot + 1 & mask;
        }
        keys[slot] = existing;
        values[slot] = fromValues[from];
      } 
    } 
  }




  
  protected void allocateBuffers(int arraySize) {
    assert Integer.bitCount(arraySize) == 1;

    
    int newKeyMixer = this.orderMixer.newKeyMixer(arraySize);

    
    long[] prevKeys = this.keys;
    float[] prevValues = this.values;
    try {
      int emptyElementSlot = 1;
      this.keys = new long[arraySize + emptyElementSlot];
      this.values = new float[arraySize + emptyElementSlot];
    } catch (OutOfMemoryError e) {
      this.keys = prevKeys;
      this.values = prevValues;
      throw new BufferAllocationException("Not enough memory to allocate buffers for rehashing: %,d -> %,d", e, new Object[] { Integer.valueOf(this.mask + 1), Integer.valueOf(arraySize) });
    } 




    
    this.resizeAt = HashContainers.expandAtCount(arraySize, this.loadFactor);
    this.keyMixer = newKeyMixer;
    this.mask = arraySize - 1;
  }









  
  protected void allocateThenInsertThenRehash(int slot, long pendingKey, float pendingValue) {
    assert this.assigned == this.resizeAt && this.keys[slot] == 0L && pendingKey != 0L;



    
    long[] prevKeys = this.keys;
    float[] prevValues = this.values;
    allocateBuffers(HashContainers.nextBufferSize(this.mask + 1, size(), this.loadFactor));
    assert this.keys.length > prevKeys.length;


    
    prevKeys[slot] = pendingKey;
    prevValues[slot] = pendingValue;

    
    rehash(prevKeys, prevValues);
  }




  
  protected void shiftConflictingKeys(int gapSlot) {
    long[] keys = this.keys;
    float[] values = this.values;
    int mask = this.mask;

    
    int distance = 0;
    while (true) {
      int slot = gapSlot + ++distance & mask;
      long existing = keys[slot];
      if (existing == 0L) {
        break;
      }
      
      int idealSlot = hashKey(existing);
      int shift = slot - idealSlot & mask;
      if (shift >= distance) {



        
        keys[gapSlot] = existing;
        values[gapSlot] = values[slot];
        gapSlot = slot;
        distance = 0;
      } 
    } 

    
    keys[gapSlot] = 0L;
    values[gapSlot] = 0.0F;
    this.assigned--;
  }
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\LongFloatHashMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */