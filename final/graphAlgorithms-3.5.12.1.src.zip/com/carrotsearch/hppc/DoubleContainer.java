package com.carrotsearch.hppc;

import com.carrotsearch.hppc.cursors.DoubleCursor;
import java.util.Iterator;

public interface DoubleContainer extends Iterable<DoubleCursor> {
  Iterator<DoubleCursor> iterator();
  
  boolean contains(double paramDouble);
  
  int size();
  
  boolean isEmpty();
  
  double[] toArray();
  
  <T extends com.carrotsearch.hppc.procedures.DoubleProcedure> T forEach(T paramT);
  
  <T extends com.carrotsearch.hppc.predicates.DoublePredicate> T forEach(T paramT);
}


/* Location:              C:\User\\user\.Neo4jDesktop\neo4jDatabases\database-721cf047-8b17-4bcd-8b36-418bdfe8b433\installation-3.5.12\plugins\graphAlgorithms-3.5.12.1\!\com\carrotsearch\hppc\DoubleContainer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.2
 */